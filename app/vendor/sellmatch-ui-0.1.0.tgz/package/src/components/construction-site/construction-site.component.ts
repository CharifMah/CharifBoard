
import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { EmailService } from '../../core/sellmatchdb/services/email/email.service';
import { EmailDTO } from '../../core/sellmatchdb/dto/email/email.dto';
import { BaseComponent } from '../../core/base/BaseComponent';
import { MessageDisplayComponent } from '../../shared/components/message-display/message-display.component';
import { ButtonComponent } from '../../shared/components/button/button.component';
import { ImageComponent } from '../../shared/components/image/image.component';
import { InputComponent } from '../../shared/components/input/input.component';

@Component({
  selector: 'app-construction-site',
  standalone: true,
  imports: [FormsModule, MessageDisplayComponent, ButtonComponent, ImageComponent, InputComponent],
  templateUrl: './construction-site.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./construction-site.component.scss']
})
export class ConstructionSiteComponent extends BaseComponent
{
  private _EmailService: EmailService = inject(EmailService);

  email: string = '';
  isSubmitted = false;
  isLoading = false;
  successMessage = '';
  errorMessage = '';

  async onSubmit(pForm: NgForm): Promise<void>
  {
    if (pForm.invalid)
    {
      return;
    }

    this.isLoading = true;
    this.successMessage = '';
    this.errorMessage = '';

    try
    {
      const lEmail: EmailDTO = {
        emails: pForm.value.email,  
        createdAt: new Date()
      };
      // cm - Crée email
      await this._EmailService.create(lEmail);

      this.isSubmitted = true;
      this.successMessage = 'Merci ! Vous serez informé dès le lancement.';

      pForm.reset();
      this.email = '';

    } catch (e)
    {
      console.error('Erreur:', e);
      this.errorMessage = 'Une erreur est survenue. Veuillez réessayer.';

    } finally
    {
      this.isLoading = false;

    }
  }
}
