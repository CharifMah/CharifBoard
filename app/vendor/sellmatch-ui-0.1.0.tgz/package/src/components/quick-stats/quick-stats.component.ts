import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../core/base/BaseComponent';
import { SidebarStats } from '../../core/states/pro-state/pro-state.service';

@Component({
  selector: 'app-quick-stats',
  templateUrl: './quick-stats.component.html',
  styleUrls: ['./quick-stats.component.scss'],
  standalone: true,
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: []
})
export class QuickStatsComponent extends BaseComponent
{
  @Input() stats: SidebarStats = {
    DossiersEnCours: 0,
    DossiersHistorique: 0,
    TotalCandidatures: 0,
    ChiffreAffaires: 0,
    TauxConversion: 0,
    MandatsActifs:0
  };

  constructor ()
  {
    super();
  }
}
