import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, OnChanges } from '@angular/core';

import { FormsModule, ReactiveFormsModule, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { UsersDTO } from '../../core/sellmatchdb/dto';
import { BaseComponent } from '../../core/base/BaseComponent';
import { RouterLink } from '@angular/router';
import { ButtonComponent } from "../../shared/components/button/button.component";
import { AideImmoApiPopupComponent } from "@views/Dashboards/pro/AideImmoApiPopup/aide-immo-api-popup.component";
import { InputComponent } from "../../shared/components/input/input.component";
import { LanguageSelectorComponent } from "../../shared/components/language-selector/language-selector.component";
import { SupportedLanguage } from '../../core/services/i18n/TranslationService';

/**
 * Composant d'affichage et d'édition des informations de profil utilisateur.
 * Gère l'affichage des données personnelles et le formulaire de modification.
 */
@Component({
  selector: 'app-profil-card',
  standalone: true,
  templateUrl: './profil-card.component.html',
  styleUrls: ['./profil-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [FormsModule, ReactiveFormsModule, RouterLink, ButtonComponent, AideImmoApiPopupComponent, InputComponent, LanguageSelectorComponent]
})
export class ProfilCardComponent extends BaseComponent implements OnChanges
{
  /** Objet utilisateur contenant les informations à afficher. */
  @Input() User: UsersDTO = {};
  /** Indique si le composant est en mode édition. */
  @Input() IsEditing: boolean = false;
  /** Indique si une sauvegarde est en cours. */
  @Input() IsSaving: boolean = false;
  /** Indique si le profil est public. */
  @Input() IsPublic: boolean = false;
  /** Émetteur d'événement pour la sauvegarde des données. */
  @Output() OnSave = new EventEmitter<UsersDTO>();
  /** Émetteur d'événement pour l'annulation de l'édition. */
  @Output() OnCancel = new EventEmitter<void>();
  /** Contrôle l'ouverture de la popup d'aide Immodvisor. */
  @Input() IsImmoAidePopupOpen: boolean = false;
  @Output() OnLangueChange = new EventEmitter<SupportedLanguage>();

  /** Formulaire réactif principal pour le profil. */
  public ProfilForm: FormGroup;

  /** Visibilité de la clé API. */
  public isApiKeyVisible: boolean = false;
  /** Validateurs personnalisés pour l'adresse. */
  public AddressValidators = []; // - cm - À définir selon les règles métier
  /** Messages d'erreur pour l'adresse. */
  public AddressErrorMessages: Record<string, string> = {
    required: 'L\'adresse est obligatoire.'
  };

  /**
   * Constructeur : initialise le formulaire réactif.
   */
  constructor ()
  {
    super();
    this.ProfilForm = this.InitForm();
  }

  /**
   * Handler déclenché par le LanguageSelectorComponent (mode select ou chips)
   * Met à jour le formControl 'langue' sans déclencher de save automatique :
   * la valeur sera incluse dans le payload OnSave au clic sur Enregistrer.
   * @param pLang Code langue sélectionné.
   */
  public OnLangueChangee(pLang: SupportedLanguage): void
  {
    // On émet l'événement vers le parent, sans persister immédiatement
    this.OnLangueChange.emit(pLang);
  }

  /**
   * Initialise le formulaire avec validateurs.
   * @returns FormGroup configuré.
   */
  private InitForm(): FormGroup
  {
    const lBuilder = new FormBuilder();
    return lBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      address: ['', [Validators.required]],
      profilUrl: [''],
      immodvisorCid: [''],
      immodvisorApiKey: [''],
      userSettings: [this.User.userSettings]
    });
  }

  /**
   * Cycle de vie Angular : détecte les changements sur les inputs.
   */
  ngOnChanges(): void
  {
    if (this.IsEditing)
    {
      this.resetForm();
    }
  }

  /**
   * Émet l'événement de sauvegarde avec les données du formulaire.
   */
  public save(): void
  {
    if (this.ProfilForm.valid)
    {
      const lFormValue = this.ProfilForm.getRawValue();
      const lPayload: UsersDTO = {
        firstName: lFormValue.firstName,
        lastName: lFormValue.lastName,
        email: lFormValue.email,
        phone: lFormValue.phone,
        profilUrl: lFormValue.profilUrl,
        immodvisorCid: lFormValue.immodvisorCid,
        immodvisorApiKey: lFormValue.immodvisorApiKey,
        address: lFormValue.address,
        userSettings: lFormValue.userSettings,
      };
      this.OnSave.emit(lPayload);
    }
  }

  /**
   * Émet l'événement d'annulation.
   */
  public cancel(): void
  {
    this.OnCancel.emit();
  }

  /**
   * Bascule la visibilité de la clé API.
   */
  public toggleApiKeyVisibility(): void
  {
    this.isApiKeyVisible = !this.isApiKeyVisible;
  }

  /**
   * Retourne l'adresse complète formatée pour l'affichage.
   * @returns Chaîne formatée de l'adresse.
   */
  public GetFullAddress(): string
  {
    if (!this.User.address) return '-';
    const lParts = [
      this.User.address.street,
      this.User.address.postcode,
      this.User.address.city
    ].filter(pPart => !!pPart);
    return lParts.length > 0 ? lParts.join(', ') : '-';
  }

  /**
   * Réinitialise le formulaire d'édition avec les données utilisateur.
   */
  private resetForm(): void
  {
    this.ProfilForm.reset();
    this.ProfilForm.patchValue({
      firstName: this.User.firstName,
      lastName: this.User.lastName,
      email: this.User.email,
      phone: this.User.phone,
      address: this.User.address,
      profilUrl: this.User.profilUrl,
      immodvisorCid: this.User.immodvisorCid,
      immodvisorApiKey: this.User.immodvisorApiKey,
      userSettings: this.User.userSettings,
    });
  }

  /**
   * Gère le changement d'état de la popup d'aide.
   * @param pIsOpen Nouvel état d'ouverture de la popup.
   */
  onPopupChange(pIsOpen: boolean): void
  {
    this.IsImmoAidePopupOpen = pIsOpen;
  }
}
