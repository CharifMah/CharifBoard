import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../core/base/BaseComponent';
import { ConversationsDTO } from '../../core/sellmatchdb/dto/conversations/conversations.dto';
import { BadgeComponent } from '../../shared/components/badge/badge.component';
import { PopupComponent } from '../../shared/components/popup/popup.component';
import { ProfilCardComponent } from "../../components/profil-card/profil-card.component";

@Component({
  selector: 'app-conversation-item',
  standalone: true,
  templateUrl: './conversation-item.component.html',
  styleUrls: ['./conversation-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [BadgeComponent, PopupComponent, ProfilCardComponent]
})
export class ConversationItemComponent extends BaseComponent {
  @Input() conversation!: ConversationsDTO;
  @Input() isActive: boolean = false;
  @Output() conversationDelete = new EventEmitter<ConversationsDTO>();

  @Output() conversationClick = new EventEmitter<ConversationsDTO>();
  IsOpenPopup: any;

  constructor() {
    super();
  }

  getUnreadCount(): number {
    return this.conversation.messages?.filter(m => !m.readAt && m.senderId?.toString() !== this.CurrentUserId).length || 0;
  }

  getLastMessage(): string {
    const msgs = this.conversation.messages;
    if (!msgs?.length) return 'Aucun message';

    const last = [...msgs].sort((a, b) =>
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    )[0];

    const content = last.content || '';
    return content.length > 50 ? content.substring(0, 50) + '...' : content;
  }

  getLastMessageTime(): string {
    const msgs = this.conversation.messages;
    if (!msgs?.length) return '';

    const last = [...msgs].sort((a, b) =>
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    )[0];

    return this.FormatDate(last.createdAt);
  }

  getConversationTitle(): string {
    if (this.conversation.opportunity?.address?.street) {
      return this.conversation.opportunity.address?.street;
    }

    if (this.conversation.opportunity?.propertyType) {
      return this.conversation.opportunity.propertyType;
    }

    return `Conversation #${this.conversation.id}`;
  }

  onDeleteClick(event: MouseEvent): void {
    event.stopPropagation(); // Empêcher la sélection de la conversation

    this.conversationDelete.emit(this.conversation);
  }

  onClick(event: MouseEvent): void {
    this.conversationClick.emit(this.conversation);
  }
}
