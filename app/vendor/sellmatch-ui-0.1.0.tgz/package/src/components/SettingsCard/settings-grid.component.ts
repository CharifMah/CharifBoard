import
{
  Component,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  inject,
  OnInit,
  computed,
  signal,
  Signal,
  WritableSignal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseCritereDTO } from '../../core/base/base.critere';
import { GridComponent, GridActionEvent, GridSortEvent } from '../../shared/components/grid/grid.component';
import { GridColumnDirective } from '../../shared/components/grid/grid-column.directive';
import { FilterFieldConfig } from '../../shared/components/FilterBar/filter-bar.component';
import { SettingsDTO } from '../../core/sellmatchdb/dto';
import { SettingsCritereDTO } from '../../core/sellmatchdb/dto/settings/settings.critere';
import { SettingsService } from '../../core/sellmatchdb/services/settings/settings.service';
import { BaseDTO } from '../../core/base/BaseDTO';
import { BaseComponent } from '../../core/base/BaseComponent';
import { TranslateKeyPipe } from '../../core/services/i18n/TranslateKeyPipe';
import { TranslateDirective } from '../../core/services/i18n/TranslateDirective';
import { TranslationService } from '../../core/services/i18n/TranslationService';
// - cm - L'ancienne `GridI18nMixin` a été supprimée : `T()` et `_Translation`
//      sont portés par `BaseComponent`.
/**
 * Grille CRUD pour les paramètres (Settings).
 * Respecte le pattern i18n de CrmBiensComponent :
 * - Namespace 'settings' défini via appTranslate dans le template.
 * - Tous les libellés via le pipe `tkey`.
 * - Les champs de filtre sont un `computed` réactif à la langue.
 * - Les actions (edit/delete) utilisent `this.T()` depuis BaseComponent.
 */
@Component({
  selector: 'app-settings-grid',
  standalone: true,
  imports: [
    CommonModule,
    GridComponent,
    GridColumnDirective,
    TranslateKeyPipe,
    TranslateDirective
  ],
  templateUrl: './settings-grid.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsGridComponent extends BaseComponent implements OnInit
{
  /** Service Settings injecté pour le mode server-side. */
  private readonly _SettingsService: SettingsService = inject(SettingsService);

  //#region ViewChild
  @ViewChild(GridComponent) public Grid!: GridComponent<SettingsDTO>;
  //#endregion

  //#region Inputs
  @Input({ required: true }) public Data: BaseDTO[] = [];

  /** Indicateur de chargement. */
  @Input() public Loading: boolean = false;

  /** Active le mode server-side. Défaut : `false` (mode client historique). */
  @Input() public ServerSide: boolean = false;

  /** Critère initial passé par le parent en mode server-side. */
  @Input() public CritereInit: SettingsCritereDTO | null = null;

  //#endregion

  //#region Outputs
  @Output() public readonly ActionClicked = new EventEmitter<GridActionEvent<SettingsDTO>>();

  /** Émis après un chargement server-side réussi. */
  @Output() public readonly ServerSideLoaded = new EventEmitter<number>();

  /** Émis en cas d'erreur lors d'un chargement server-side. */
  @Output() public readonly ServerSideError = new EventEmitter<string>();
  //#endregion

  //#region Properties - server-side
  /** Critère courant en mode server-side. */
  protected readonly _Critere = signal<SettingsCritereDTO>(this._BuildInitialCritere());
  /** Données chargées en mode server-side. */
  protected readonly _ServerSideData = signal<SettingsDTO[]>([]);
  /** Indicateur de chargement server-side. */
  protected readonly _ServerSideLoading = signal<boolean>(false);
  /** Message d'erreur server-side (null si OK). */
  protected readonly _ServerSideError = signal<string | null>(null);
  // - cm - 2026-08-12 : EffectiveData/Loading/Error sont des **méthodes** (et non
  //      des `computed`) parce qu'elles lisent principalement des @Input primitifs
  //      (`this.ServerSide`, `this.Loading`, `this.Data`). Un `computed` ne se
  //      ré-évalue que quand un Signal qu'il a lu change ; ici, seul
  //      `_ServerSideLoading` est un Signal. Quand le parent fait `Loading.set(false)`
  //      après la résolution de la requête API, l'input `Loading` est mis à jour
  //      par Angular mais le `computed` ne se redéclenche pas → le skeleton
  //      reste affiché. Une méthode est appelée à chaque change detection cycle
  //      et reste synchronisée avec l'input primitif. Un `getter` ferait
  //      l'affaire mais le template existant appelle `EffectiveLoading()` avec
  //      des parenthèses → le compilateur Angular refuse un `get` accessor
  //      appelable (`TS6234`). On garde donc la signature `EffectiveXxx()`.
  //      Cf. branche `fix/crm-grid-effective-loading-getter` (août 2026).
  /** Données effectivement passées à `<app-grid>`. */
  public EffectiveData(): BaseDTO[] { return this.ServerSide ? this._ServerSideData() : this.Data; }
  /** Indicateur de chargement effectivement passé à `<app-grid [Loading]>`. */
  public EffectiveLoading(): boolean { return this.ServerSide ? (this.Loading || this._ServerSideLoading()) : this.Loading; }
  /** Message d'erreur effectivement passé à `<app-grid [Error]>`. */
  public EffectiveError(): string | null { return this.ServerSide ? this._ServerSideError() : null; }
  //#endregion

  //#region Methods - server-side
  /** Construit le critère initial en mode server-side. `BaseCritereDTO` TS est en camelCase. */
  private _BuildInitialCritere(): SettingsCritereDTO {
    const lInit: SettingsCritereDTO = (this.CritereInit ?? {}) as SettingsCritereDTO;
    return { ...lInit, page: lInit.page ?? 1, pageSize: lInit.pageSize ?? 25, sortDirection: lInit.sortDirection ?? 'desc' };
  }
  /** Charge la page courante des settings depuis le back. */
  public async LoadCurrentPage(): Promise<void> {
    if (!this.ServerSide) { return; }
    this._ServerSideLoading.set(true);
    this._ServerSideError.set(null);
    try {
      const lData: SettingsDTO[] = await this._SettingsService.getAll(this._Critere());
      this._ServerSideData.set(lData ?? []);
      this.ServerSideLoaded.emit((lData ?? []).length);
    } catch (pErr: unknown) {
      const lMessage: string = pErr instanceof Error ? pErr.message : 'Erreur de chargement server-side.';
      this._ServerSideError.set(lMessage);
      this.ServerSideError.emit(lMessage);
      console.error('[settings-grid] server-side load failed:', pErr);
    } finally {
      this._ServerSideLoading.set(false);
    }
  }
  /** Handler (PageChanged) émis par `<app-grid>`. */
  public async OnServerSidePageChange(pEvent: { Page: number; PageSize: number }): Promise<void> {
    const lCurrent: SettingsCritereDTO = this._Critere();
    if ((lCurrent.page ?? 1) === pEvent.Page && (lCurrent.pageSize ?? 25) === pEvent.PageSize) { return; }
    this._Critere.set({ ...lCurrent, page: pEvent.Page, pageSize: pEvent.PageSize });
    await this.LoadCurrentPage();
  }
  /** Handler (SortChanged) émis par `<app-grid>`. */
  public async OnServerSideSortChange(pEvent: GridSortEvent): Promise<void> {
    const lCurrent: SettingsCritereDTO = this._Critere();
    const lDirection: 'asc' | 'desc' | undefined = pEvent.Direction ?? undefined;
    this._Critere.set({ ...lCurrent, orderBy: pEvent.Key || undefined, sortDirection: lDirection });
    await this.LoadCurrentPage();
  }
  /** Handler (FilterChanged) émis par `<app-grid>`. */
  public async OnServerSideFilterChange(pCritere: BaseCritereDTO): Promise<void> {
    const lMapped: SettingsCritereDTO = { ...pCritere } as SettingsCritereDTO;
    const lCurrent: SettingsCritereDTO = this._Critere();
    this._Critere.set({ ...lMapped, page: 1, pageSize: lCurrent.pageSize ?? 25 });
    await this.LoadCurrentPage();
  }
  //#endregion

  //#region Lifecycle
    /** Déclenche le premier chargement server-side si `ServerSide=true`. */
    public ngOnInit(): void {
      if (this.ServerSide) { void this.LoadCurrentPage(); }
    }
    //#endregion

    //#region i18n
    /**
     * Service i18n (alias local de `Translate` hérité de `BaseComponent`).
     * Conservé sous le nom `_Translation` pour les computed FilterFields
     * qui ont besoin du pattern `InstantTick() + translate()`.
     */
    protected readonly _Translation: TranslationService = this.Translate;

    /**
     * Crée un `Signal<string>` computed pour un label i18n.
     * Migré ici depuis l'ex-`GridI18nMixin` (cf. commentaire dans `BaseComponent`).
     */
    public T(pKey: string): Signal<string> {
      return computed<string>(() => {
        this.Translate.InstantTick();
        return this.Translate.translate(pKey);
      });
    }
    //#endregion

  /** Libellé de l'action "Supprimer" dans le menu de ligne. */
  public readonly DeleteActionLabel = this.T('grid.actions.delete');

  //#endregion

  //#region Computed Filter Fields (réactifs à la langue)
  public readonly SettingFilterFields: Signal<FilterFieldConfig[]> = computed(() =>
  {
    // Force la réactivité au changement de langue
    this.Translate.InstantTick();

    return [
      {
        Key: 'key',
        Label: this.Translate.translate('key'),
        Type: 'text',
        Placeholder: this.Translate.translate('filter.keyPlaceholder')
      },
      {
        Key: 'value',
        Label: this.Translate.translate('value'),
        Type: 'text',
        Placeholder: this.Translate.translate('filter.valuePlaceholder')
      }
    ];
  });
  //#endregion

  //#endregion
}
