import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, inject } from '@angular/core';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { TooltipComponent } from '../../../shared/components/tooltip/tooltip.component';
import { EStatCardVariant, StatCardVariantService } from '../../../core/services/ui/stat-card-variant.service';

/**
 * Accent sémantique appliqué à la carte (couleur d'icône, ligne, fond selon la variante).
 */
export type EStatCardAccent = 'success' | 'info' | 'danger' | 'warning' | 'primary' | 'neutral';

/**
 * Tendance affichée sous la valeur (ex: +12% vs N-1).
 */
export interface IStatCardTrend {
  /** Valeur signée (positive = up, négative = down). */
  value: number;
  /** Direction explicite (permet de surcharger le signe de `value`). */
  direction: 'up' | 'down' | 'flat';
}

/**
 * Carte d'indicateur générique pour le dashboard CRM et tous les écrans
 * d'analytics. Supporte 4 variantes visuelles (`EStatCardVariant`) et 6 accents.
 * Lit la variante globale via `StatCardVariantService` si aucune n'est passée
 * explicitement en `@Input`.
 */
@Component({
  selector: 'app-stat-card',
  standalone: true,
  imports: [TooltipComponent],
  templateUrl: './stat-card.component.html',
  styleUrl: './stat-card.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatCardComponent extends BaseComponent
{
  //#region Attributes
  /** Service exposant la variante active (signal + localStorage). */
  private readonly _VariantService: StatCardVariantService = inject(StatCardVariantService);

  /** Indique si une variante a été passée explicitement (sinon on suit le service). */
  private _HasExplicitVariant: boolean = false;

  /** Stockage interne du champ `variant` (géré par le setter ci-dessous). */
  private _Variant: EStatCardVariant = 'minimal-flat';
  //#endregion

  //#region Inputs
  /** Libellé court affiché au-dessus de la valeur. */
  @Input({ required: true }) public label!: string;

  /** Valeur principale (montant formaté, compteur, etc.). */
  @Input({ required: true }) public value!: string | number;

  /** Nom d'icône Material Icons. */
  @Input({ required: true }) public icon!: string;

  /** Description complémentaire affichée sous la valeur. */
  @Input() public hint: string | null = null;

  /** Formule de calcul affichée dans le tooltip d'info. */
  @Input() public formula: string | null = null;

  /** Accent sémantique (couleur de l'icône, ligne gauche, etc.). */
  @Input() public accent: EStatCardAccent = 'primary';

  /**
   * Variante visuelle explicite (override du service global). Si la valeur
   * par défaut (`'minimal-flat'`) est conservée, on suit le service global.
   */
  @Input() public set variant(pVariant: EStatCardVariant)
  {
    this._HasExplicitVariant = true;
    this._Variant = pVariant;
  }
  public get variant(): EStatCardVariant
  {
    return this._Variant;
  }

  /** Tendance optionnelle (ex: +12% vs période précédente). */
  @Input() public trend: IStatCardTrend | null = null;

  /** Active l'état interactif (curseur pointer, hover renforcé, événements clic). */
  @Input() public clickable: boolean = false;
  //#endregion

  //#region Outputs
  /** Émis au clic sur la carte (uniquement si `clickable` est `true`). */
  @Output() public cardClick = new EventEmitter<void>();
  //#endregion

  //#region Properties
  /** Variante effective résolue (override ou service). */
  public ResolvedVariant(): EStatCardVariant
  {
    return this._HasExplicitVariant ? this._Variant : this._VariantService.Variant();
  }

  /** Symbole affiché devant la valeur de tendance (▲ ▼ =). */
  public TrendSymbol(): string
  {
    const lTrend: IStatCardTrend | null = this.trend;
    if (lTrend === null) return '';
    if (lTrend.direction === 'up') return '▲';
    if (lTrend.direction === 'down') return '▼';
    return '=';
  }

  /** Classe CSS appliquée à la tendance pour la couleur (up/down/flat). */
  public TrendClass(): string
  {
    const lTrend: IStatCardTrend | null = this.trend;
    if (lTrend === null) return '';
    return `stat-card__trend--${lTrend.direction}`;
  }

  /** Texte formaté de la tendance (ex: "+12%"). */
  public TrendText(): string
  {
    const lTrend: IStatCardTrend | null = this.trend;
    if (lTrend === null) return '';
    const lSign: string = lTrend.value > 0 ? '+' : '';
    return `${lSign}${lTrend.value}%`;
  }

  /** Indique si une tendance est définie. */
  public HasTrend(): boolean
  {
    return this.trend !== null;
  }
  //#endregion

  //#region Methods
  /**
   * Gère le clic sur la carte. Émet `cardClick` et tracke dans PostHog.
   */
  public OnClick(): void
  {
    if (!this.clickable) return;
    this.PostHog.Capture(this.BuildTrackingName(`stat_card_click_${this.label}`, 'tracking'));
    this.cardClick.emit();
  }
  //#endregion
}
