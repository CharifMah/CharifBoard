import { Component, Input, OnInit, ElementRef, HostBinding, inject, PLATFORM_ID, ChangeDetectionStrategy } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-image',
  standalone: true,
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [CommonModule]
})
export class ImageComponent extends BaseComponent implements OnInit
{
  @Input() src!: string;
  @Input() alt!: string;
  @Input() width?: number;
  @Input() height?: number;
  @Input() priority: boolean = false;
  @Input() loading: 'lazy' | 'eager' = 'lazy';
  @Input() objectFit: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down' = 'contain';
  @Input() isWebp: boolean = false;

  // L'hôte ne remplit pas automatiquement son conteneur
  @HostBinding('style.display') display = 'inline-block';

  // Dimensions de l'hôte basées sur les inputs
  @HostBinding('style.width') get hostWidth()
  {
    return this.width ? `${this.width}px` : '100%';
  }

  @HostBinding('style.height') get hostHeight()
  {
    return this.height ? `${this.height}px` : '100%';
  }

  isLoaded: boolean = false;
  hasError: boolean = false;
  webpSupported: boolean = true;

  /** Indique si l'on s'exécute côté navigateur (SSR-safe) */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  // Chemin WebP
  get webpSrc(): string
  {
    if (!this.src) return '';
    const lastDotIndex = this.src.lastIndexOf('.');
    if (lastDotIndex === -1) return `${this.src}.webp`;
    return `${this.src.substring(0, lastDotIndex)}.webp`;
  }

  // Styles appliqués à l'image
  get imageStyles(): any
  {
    return {
      'width': '100%',
      'height': '100%',
      'object-fit': this.objectFit
    };
  }

  constructor (private el: ElementRef)
  {
    super();
  }

  ngOnInit(): void
  {
    this.checkWebPSupport();
  }

  // Vérification du support WebP
  private checkWebPSupport(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    const canvas = document.createElement('canvas');
    if (canvas.getContext && canvas.getContext('2d'))
    {
      canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0
        ? this.webpSupported = true
        : this.webpSupported = false;
    }
  }

  // Gestion des événements
  onLoad(): void
  {
    this.isLoaded = true;
    this.hasError = false;
    this.PostHog.Capture(this.BuildTrackingName('image_chargee', 'tracking'), { src: this.src });
  }

  onError(): void
  {
    this.isLoaded = false;
    this.hasError = true;
    this.PostHog.Capture(this.BuildTrackingName('image_erreur', 'tracking'), { src: this.src });
  }
}
