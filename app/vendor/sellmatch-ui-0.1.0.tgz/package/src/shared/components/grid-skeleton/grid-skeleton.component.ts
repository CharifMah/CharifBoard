import { Component, Input, ChangeDetectionStrategy, computed, signal } from '@angular/core';
import { SkeletonComponent } from '../../../shared/components/skeleton/skeleton.component';

/**
 * Composant skeleton réutilisable pour le loading des grilles.
 * Affiche des lignes factices avec animation shimmer via le composant générique <app-skeleton>.
 */
@Component({
  selector: 'app-grid-skeleton',
  standalone: true,
  imports: [SkeletonComponent],
  templateUrl: './grid-skeleton.component.html',
  styleUrl: './grid-skeleton.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GridSkeletonComponent {
  /** Nombre de colonnes à afficher (défaut: 5). */
  @Input() public set ColumnCount(pValue: number) {
    this._ColumnCount.set(pValue);
  }
  public get ColumnCount(): number {
    return this._ColumnCount();
  }
  private readonly _ColumnCount = signal(5);

  /** Nombre de lignes skeleton (défaut: 8). */
  @Input() public set RowCount(pValue: number) {
    this._RowCount.set(pValue);
  }
  public get RowCount(): number {
    return this._RowCount();
  }
  private readonly _RowCount = signal(8);

  /** Affiche une colonne checkbox au début (défaut: false). */
  @Input() public Selectable = false;

  /** Affiche une colonne actions à la fin (défaut: false). */
  @Input() public HasActions = false;

  /** Tableau d'indices de colonnes pour le @for du template. */
  public readonly Cols = computed(() => Array.from({ length: this._ColumnCount() }, (_, i) => i));

  /** Tableau d'indices de lignes pour le @for du template. */
  public readonly Rows = computed(() => Array.from({ length: this._RowCount() }, (_, i) => i));

  /**
   * Calcule le delai d'animation shimmer (en ms) pour distribuer les cellules
   * de maniere desynchronisee. Formule : (ligne * 180ms) + (col * 100ms).
   * Couvre le cycle de 1.4s avec un double stagger visible.
   * @param pRowIdx Index de la ligne.
   * @param pColIdx Index de la colonne (-1 pour la cellule check si Selectable).
   * @returns Le delai en millisecondes, modulo la duree du cycle.
   */
  public ComputeShimmerDelay(pRowIdx: number, pColIdx: number): number {
    const lDelay: number = pRowIdx * 180 + Math.max(0, pColIdx) * 100;
    // Module 1400 (= duree du cycle) pour eviter que les dernieres lignes
    // aient un delai superieur a la duree et donc un shimmer "fige" sur l'etat final.
    return lDelay % 1400;
  }
}