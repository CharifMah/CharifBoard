
import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, inject, PLATFORM_ID, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { RouteUtils } from '../../../shared/utils/route-utils';
import { ButtonComponent } from '../button/button.component';
import { BadgeComponent } from '../badge/badge.component';

export interface TabItem {
  id: string;
  label: string;
  icon?: string;
  badge?: number;
  badgeColor?: string;
  badgeType?: 'new' | 'hot' | 'premium' | 'urgent' | 'success' | 'warning' | 'info' | 'error';
  badgeIcon?: string;
  badgeAnimated?: boolean;
  badgePulse?: boolean;
  disabled?: boolean;
}

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  standalone: true,
  styleUrls: ['./tabs.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [ButtonComponent, BadgeComponent]
})
export class TabsComponent extends BaseComponent implements OnInit, OnDestroy, AfterViewInit {
  //#region Properties
  @Input() tabs: TabItem[] = [];
  @Input() activeTab = '';
  @Input() showIcons = true;
  @Input() showBadges = true;
  @Input() size: 'sm' | 'md' | 'lg' = 'md';
  @Input() variant: 'default' | 'pills' | 'underline' = 'default';
  @Input() fullWidth = false;
  @Input() iconPosition: 'left' | 'right' | 'top' = 'left';
  @Input() IsVisible: boolean = true;
  /**
   * Clé explicite du query param utilisé pour persister l'onglet actif dans l'URL.
   * Si vide (défaut), la clé est déduite automatiquement de l'URL courante
   * (ex: '/crm/biens' → 'crm-biens', '/' → 'tab').
   * Permet à plusieurs instances de <app-tabs> de coexister avec des clés distinctes.
   * Rétrocompatibilité : un consumer existant qui passe [PersistQueryParam]="'tab'"
   * conserve exactement le même comportement qu'avant.
   */
  @Input() PersistQueryParam: string = '';
  /**
   * Indique si la persistance de l'onglet actif dans l'URL est désactivée.
   * Par défaut false : la persistance est active sur toutes les instances de <app-tabs>.
   * Pour la désactiver explicitement, passer [DisableUrlPersistence]="true".
   */
  @Input() DisableUrlPersistence: boolean = false;

  @Output() tabChange = new EventEmitter<string>();

  private readonly _PlatformId: object = inject(PLATFORM_ID);
  private readonly _Route: ActivatedRoute = inject(ActivatedRoute);
  private readonly _RouteUtils: RouteUtils = inject(RouteUtils);
  private readonly _Subs: Subscription = new Subscription();
  //#endregion

  //#region CTOR
  constructor() {
    super();
  }
  //#endregion

  /**
   * Clé du query param calculée pour persister l'onglet actif.
   * Ordre de résolution :
   * 1. Empty string si on n'est pas dans un navigateur (SSR) ou si DisableUrlPersistence=true.
   * 2. PersistQueryParam explicite (rétrocompatibilité).
   * 3. Sinon, déduit de l'URL courante : 'segment1-segment2-...' (ex: '/crm/biens' → 'crm-biens').
   * 4. Fallback 'tab' pour la route racine '/'.
   * @returns La clé du query param, ou '' si la persistance doit être désactivée.
   */
  private get _QueryParamKey(): string {
    if (!isPlatformBrowser(this._PlatformId)) return ''; // - cm - SSR safe
    if (this.DisableUrlPersistence) return ''; // - cm - Opt-out explicite

    // - cm - Priorité : clé explicite (rétrocompat)
    if (this.PersistQueryParam) return this.PersistQueryParam;

    // - cm - Sinon, déduire de l'URL courante
    const lSegments = this._Route.snapshot.url;
    if (!lSegments || lSegments.length === 0) return 'tab';
    const lKey = lSegments.map(s => s.path).join('-');
    return lKey || 'tab';
  }

  //#region Init
  /**
   * Initialisation du composant : restaure l'onglet actif depuis l'URL si la persistance est activée.
   * La persistance est active par défaut sur toutes les instances (opt-out via [DisableUrlPersistence]).
   */
  ngOnInit(): void {
    if (this._QueryParamKey) {
      this._RestoreFromQueryParams(this._Route.snapshot.queryParams);
    }
  }

  /**
   * À l'initialisation de la vue, écoute les changements de query params
   * pour gérer la navigation back/forward du navigateur et synchroniser l'onglet actif.
   * Ne s'abonne que si la persistance est effective (clé calculée non vide).
   */
  ngAfterViewInit(): void {
    if (this._QueryParamKey) {
      this._Subs.add(
        this._Route.queryParams.subscribe(pParams => this._RestoreFromQueryParams(pParams))
      );
    }
  }

  /**
   * Nettoie toutes les subscriptions pour éviter les fuites mémoire.
   */
  ngOnDestroy(): void {
    this._Subs.unsubscribe(); // - cm - Désabonnement global de toutes les subscriptions
  }
  //#endregion

  //#region Methods
  /**
   * Change l'onglet actif et synchronise l'URL si la persistance est activée.
   * - cm - Reproduit la même logique que BaseViewComponent.Go() : merge du query param sans navigation.
   * @param pTabId L'identifiant de l'onglet à activer
   */
  switchTab(pTabId: string): void {
    const lTab: TabItem | undefined = this.tabs.find(t => t.id === pTabId);
    if (lTab && !lTab.disabled) {
      this.activeTab = pTabId;
      this.PostHog.Capture(this.BuildTrackingName('onglet_change', 'tracking'), { onglet: pTabId, libelle: lTab.label });
      this.tabChange.emit(pTabId);

      // - cm - Persistance de l'onglet actif dans l'URL (query param) si activée
      const lQueryKey = this._QueryParamKey;
      if (lQueryKey) {
        const lUrlTree = this._RouteUtils.Router.createUrlTree([], {
          relativeTo: this._Route,
          queryParams: { [lQueryKey]: pTabId },
          queryParamsHandling: 'merge'
        });
        void this._RouteUtils.Router.navigateByUrl(lUrlTree, { replaceUrl: true });
      }
    }
  }

  /**
   * Détermine le type de badge à utiliser pour un onglet donné, selon le type explicite ou l'id de l'onglet.
   * @param pTab L'onglet dont on veut le type de badge
   * @returns Le type de badge à appliquer
   */
  getBadgeType(pTab: TabItem): 'new' | 'hot' | 'premium' | 'urgent' | 'success' | 'warning' | 'info' | 'error' {
    if (pTab.badgeType) {
      return pTab.badgeType;
    }

    // - cm - Détermination automatique basée sur le type d'onglet
    if (pTab.id === 'selectionnes' || pTab.id === 'selected') {
      return 'success';
    }
    if (pTab.id === 'urgent') {
      return 'urgent';
    }
    if (pTab.id === 'new' || pTab.id === 'nouveaux') {
      return 'new';
    }
    if (pTab.id === 'hot' || pTab.id === 'populaires') {
      return 'hot';
    }
    if (pTab.id === 'premium') {
      return 'premium';
    }

    return 'info';
  }

  /**
   * Restaure l'onglet actif depuis les query params de l'URL.
   * Vérifie que l'id est valide (présent dans tabs et non désactivé) avant de l'appliquer.
   * - cm - Émet tabChange pour que le composant parent reste cohérent avec l'état restauré.
   * - cm - Utilise _QueryParamKey pour résoudre la clé (rétrocompat + auto-détection).
   * @param pParams Les query params de la route active
   */
  private _RestoreFromQueryParams(pParams: Params): void {
    const lKey = this._QueryParamKey;
    if (!lKey) {
      return;
    }

    const lValue: string | null = pParams[lKey] ?? null;
    if (!lValue) {
      return;
    }

    const lTab: TabItem | undefined = this.tabs.find(t => t.id === lValue);
    if (!lTab || lTab.disabled) {
      return;
    }

    if (this.activeTab === lValue) {
      return; // - cm - Pas de changement, évite un emit inutile
    }

    this.activeTab = lValue;
    this.tabChange.emit(lValue);
  }
  //#endregion
}
