import { Component, Input, Output, EventEmitter, computed, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';

export type BadgeType = 'new' | 'hot' | 'premium' | 'urgent' | 'success' | 'warning' | 'info' | 'error' | 'default';
export type BadgeSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type BadgePosition = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'inline' | 'left' | 'right' | 'top' | 'bottom';
export type BadgeVariant = 'solid' | 'outline' | 'soft' | 'gradient';
export type BadgeShape = 'rounded' | 'pill' | 'square' | 'circle';

@Component({
  selector: 'app-badge',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './badge.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./badge.component.scss']
})
export class BadgeComponent extends BaseComponent {
  //#region Inputs
  @Input() type: BadgeType = 'default';
  @Input() size: BadgeSize = 'md';
  @Input() position: BadgePosition = 'inline';
  @Input() variant: BadgeVariant = 'solid';
  @Input() shape: BadgeShape = 'pill';
  @Input() icon?: string;
  @Input() label?: string;
  @Input() count?: number;
  @Input() maxCount?: number = 99;
  @Input() animated: boolean = false;
  @Input() pulse: boolean = false;
  @Input() IsVisible: boolean = true;
  @Input() glow: boolean = false;
  @Input() clickable: boolean = false;
  @Input() disabled: boolean = false;
  @Input() removable: boolean = false;
  @Input() showIcon: boolean = true;
  @Input() showClose: boolean = false;
  @Input() customColor?: string;
  @Input() customBgColor?: string;
  @Input() tooltip?: string;
  //#endregion

  //#region Outputs
  @Output() closed = new EventEmitter<void>();
  @Output() clicked = new EventEmitter<void>();
  //#endregion

  //#region Internal State
  private _isVisible = signal(true);
  //#endregion

  //#region Computed Properties
  get displayLabel(): string {
    if (this.count !== undefined) {
      return this.count > this.maxCount! ? `${this.maxCount}+` : this.count.toString();
    }
    return this.label || this.DefaultLabel;
  }

  get CustomStyles(): Record<string, string> {
    const styles: Record<string, string> = {};

    if (this.customColor) {
      styles['color'] = this.customColor;
    }

    if (this.customBgColor) {
      if (this.variant === 'outline') {
        styles['border-color'] = this.customBgColor;
        styles['background'] = 'transparent';
      } else if (this.variant === 'soft') {
        styles['background'] = this.hexToRgba(this.customBgColor, 0.15);
        styles['color'] = this.customBgColor;
      } else {
        styles['background'] = this.customBgColor;
      }
    }

    return styles;
  }

  get BadgeClasses(): string[] {
    const classes = [
      'badge',
      `badge-${this.type}`,
      `badge-${this.size}`,
      `badge-${this.position}`,
      `badge-${this.variant}`,
      `badge-${this.shape}`
    ];

    if (this.animated && !this.disabled) classes.push('badge-animated');
    if (this.pulse && !this.disabled) classes.push('badge-pulse');
    if (this.glow) classes.push('badge-glow');
    if (this.clickable && !this.disabled) classes.push('badge-clickable');
    if (this.disabled) classes.push('badge-disabled');
    if (!this._isVisible()) classes.push('badge-hidden');

    return classes;
  }

  get DefaultIcon(): string {
    if (this.icon === '') return '';

    const icons: Record<BadgeType, string> = {
      new: 'fiber_new',
      hot: 'local_fire_department',
      premium: 'star',
      urgent: 'priority_high',
      success: 'check_circle',
      warning: 'warning',
      info: 'info',
      error: 'error',
      default: 'circle'
    };
    return this.icon || icons[this.type];
  }

  get DefaultLabel(): string {
    if (this.count !== undefined) return '';

    const labels: Record<BadgeType, string> = {
      new: 'Nouveau',
      hot: 'Tendance',
      premium: 'Premium',
      urgent: 'Urgent',
      success: 'Succès',
      warning: 'Attention',
      info: 'Information',
      error: 'Erreur',
      default: 'Badge'
    };
    return this.label || labels[this.type];
  }
  //#endregion

  //#region Public Methods
  onClose(event: Event): void {
    event.stopPropagation();
    if (!this.disabled) {
      this._isVisible.set(false);
      this.PostHog.Capture(this.BuildTrackingName('badge_ferme', 'tracking'), { type: this.type, label: this.displayLabel });
      this.closed.emit();
    }
  }

  onClick(): void {
    if (this.clickable && !this.disabled && this._isVisible()) {
      this.PostHog.Capture(this.BuildTrackingName('badge_clique', 'tracking'), { type: this.type, label: this.displayLabel });
      this.clicked.emit();
    }
  }

  show(): void {
    this._isVisible.set(true);
  }

  hide(): void {
    this._isVisible.set(false);
  }
  //#endregion

  //#region Private Methods
  private hexToRgba(hex: string, alpha: number): string {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  //#endregion
}
