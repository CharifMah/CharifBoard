/**
 * Préréglages d'éclairage Mapbox Standard (4 modes : Dawn / Day / Dusk / Night).
 * - cm - Cf. https://docs.mapbox.com/map-styles/guides/standard-styles/
 * - cm - Appliqués via `map.setConfigProperty('basemap', 'lightPreset', value)`.
 * - cm - Dawn = couleurs tièdes (lever de soleil), Day = clair standard,
 * - cm - Dusk = couleurs tièdes (coucher de soleil), Night = sombre optimisé.
 */

export enum EMapLightMode {
    /** Mode par défaut de Mapbox Standard (Day). */
    Default = 'default',
    /** Lumière de l'aube. */
    Dawn = 'dawn',
    /** Plein jour. */
    Day = 'day',
    /** Crépuscule. */
    Dusk = 'dusk',
    /** Nuit. */
    Night = 'night'
}
