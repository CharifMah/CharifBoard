import { EMarkerType } from './EMarkerType';

/**
 * Mapping centralisé `EMarkerType` → style visuel des markers.
 * - cm - Utilisé par le dashboard, le crm-biens, l'address-map-tooltip, et le
 * - cm - map-card pour garantir que la couleur, l'icône Material, et le caractère
 * - cm - Unicode Material Icons sont cohérents partout dans l'application.
 */
export interface IMarkerStyle {
  /** Code de l'icône Material (utilisé dans les markers principaux et le tooltip). */
  Icon: string;
  /** Couleur CSS (var(--sm-xxx) ou hex). */
  Color: string;
  /** Caractère Unicode Material Icons (utilisé dans le canvas généré par le map-card). */
  MaterialChar: string;
}

/**
 * Styles visuels par type de marker. Une seule source de vérité.
 * - cm - Le map-card dessine le caractère Unicode via Canvas2D.
 * - cm - Les autres composants (tooltips, dashboard) passent simplement
 * - cm - `Icon` + `Color` à `<app-map-card>` via `[Markers]`.
 */
export const MARKER_STYLES: Record<EMarkerType, IMarkerStyle> = {
  [EMarkerType.Default]:   { Icon: 'place',     Color: '#9c27b0', MaterialChar: '\uE55F' },
  [EMarkerType.Property]:   { Icon: 'home_work', Color: 'var(--sm-success)', MaterialChar: '\uE88A' },
  [EMarkerType.Transaction]: { Icon: 'sell',     Color: 'var(--sm-primary)', MaterialChar: '\uE227' },
  [EMarkerType.Location]:  { Icon: 'key',       Color: 'var(--sm-info)',    MaterialChar: '\uE73C' },
  [EMarkerType.Contact]:   { Icon: 'person',    Color: 'var(--sm-warning)', MaterialChar: '\uE7EF' },
  [EMarkerType.Objectif]:  { Icon: 'flag',      Color: 'var(--sm-primary)', MaterialChar: '\uE153' },
  [EMarkerType.Tache]:     { Icon: 'task_alt',  Color: 'var(--sm-accent)',  MaterialChar: '\uE762' }
};

/**
 * Récupère le style visuel d'un marker à partir de son `Type`.
 * Retourne le style `Default` si le type est inconnu ou absent.
 * @param pType Le `EMarkerType` (ou `undefined`).
 * @returns Le style `{ Icon, Color, MaterialChar }`.
 */
export function GetMarkerStyle(pType: EMarkerType | string | undefined): IMarkerStyle
{
  if (!pType)
  {
    return MARKER_STYLES[EMarkerType.Default];
  }
  return MARKER_STYLES[pType as EMarkerType] ?? MARKER_STYLES[EMarkerType.Default];
}
