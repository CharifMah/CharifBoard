import { BaseDTO } from '../../../core/base/BaseDTO';
import { EMarkerType } from './EMarkerType';

/**
 * Représente un marqueur à afficher sur la carte.
 */

export interface IMapMarker {
    /** Latitude du marqueur. */
    Lat: number;
    /** Longitude du marqueur. */
    Lng: number;
    /** Titre affiché dans le popup (optionnel). */
    Title?: string;
    /** Sous-titre affiché sous le titre (optionnel). */
    Subtitle?: string;
    /** Contenu HTML ou texte du popup (optionnel). */
    Popup?: string;
    /** Couleur du marqueur (hex ou nom CSS). Défaut: couleur primaire. */
    Color?: string;
    /** Icône Material Icons optionnelle (ex: "location_on"). */
    Icon?: string;
    /** Label court affiché à côté du pin (optionnel). */
    Label?: string;
    /** Type/catégorie du marqueur (impacte l'icône par défaut). */
    Type?: EMarkerType;
    /**
     * DTO source associé au marqueur (ex : Transaction, Location, Property, Contact).
     * Permet à la popup d'afficher la ligne complète de la grille correspondante
     * au lieu du simple résumé textuel. Stocké en `unknown` pour rester agnostique
     * du type métier ; la page consommatrice (cf. `BuildXxxMapMarkers` dans
     * `crm-biens/crm-biens.component.ts`) décide du typage.
     * - cm - L'héritage des `unknown` exige que les pages fassent un cast
     * - cm - explicite (`marker.Data as TransactionsDTO`).
     */
    Data?: BaseDTO;
    /**
     * Identifiant logique du DTO (optionnel, utile quand `Data` n'est pas fourni
     * mais qu'on veut pouvoir retrouver la ligne dans la source de données).
     */
    DataId?: number | string;
}
