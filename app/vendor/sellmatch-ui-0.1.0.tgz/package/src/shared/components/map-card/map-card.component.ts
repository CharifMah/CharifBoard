import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges, ViewChild, ChangeDetectionStrategy, inject, PLATFORM_ID, NgZone, signal, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ThemeService } from '../../../core/services/theme/ThemeService';
import { MapboxProxyService } from '../../../core/services/Mapbox/mapbox-proxy.service';
import { ToolbarComponent } from '../MapToolBar/map-toolbar.component';
import { IMapMarker } from './IMapMarker';
import { GetMarkerStyle } from './map-marker-style';
import { EMapLightMode } from './EMapLightMode';
import { EMapStyle } from './EMapStyle';
import { environment } from '../../../environments/environment';


/**
 * Composant carte basé sur Mapbox GL JS officiel (cf. tutorial
 * https://docs.mapbox.com/help/tutorials/use-mapbox-gl-js-with-angular/).
 * - cm - Suit le pattern standard Mapbox web app : `mapboxgl.Map({ accessToken,
 * - cm - style: 'mapbox://styles/<owner>/<styleId>', container, ... })` — pas
 * - cm - de transformRequest, pas de proxy backend. Mapbox GL gère tout nativement
 * - cm - (CORS, fetch JSON, signing des sous-requêtes). Le seul prérequis est
 * - cm - d'avoir un token `pk.` valide (lu via `MapboxConfigService` ou
 * - cm - `environment.mapboxToken`).
 */
@Component({
  selector: 'app-map-card',
  standalone: true,
  templateUrl: './map-card.component.html',
  styleUrls: ['./map-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ToolbarComponent]
})
export class MapCardComponent extends BaseComponent implements AfterViewInit, OnChanges, OnDestroy
{
  //#region Inputs

  /** Latitude du centre initial de la carte. Défaut: Paris (48.8566). */
  @Input() CenterLat: number = 48.8566;
  /** Longitude du centre initial de la carte. Défaut: Paris (2.3522). */
  @Input() CenterLng: number = 2.3522;
  /** Niveau de zoom initial (1-22). Défaut: 13. */
  @Input() Zoom: number = 13;
  /** Hauteur de la carte en px. Défaut: 400. */
  @Input() Height: number = 400;
  /** Style de carte initial. Défaut: Streets. */
  @Input() Style: EMapStyle = EMapStyle.Streets;
  /** Liste des marqueurs à afficher. */
  @Input() Markers: IMapMarker[] = [];
  /** Affiche le sélecteur de style. Défaut: true. */
  @Input() ShowStyleSelector: boolean = true;
  /** Affiche les contrôles de zoom natifs Mapbox (obsolète : utiliser ShowToolbar). */
  @Input() ShowZoomControl: boolean = true;
  /** Active la molette pour zoomer. Défaut: true. */
  @Input() ScrollWheelZoom: boolean = true;
  /** Affiche la toolbar custom (zoom +/−, 3D, compass, fullscreen, theme). Défaut: true. */
  @Input() ShowToolbar: boolean = true;
  /** Active les raccourcis clavier (P, N, F, T). Défaut: true. */
  @Input() EnableKeyboardShortcuts: boolean = true;
  /** Autorise le clic sur la carte pour ajouter un point. Défaut: false. */
  @Input() EnableClick: boolean = false;
  /** Titre optionnel affiché en en-tête de la carte. */
  @Input() Title: string = '';
  /** Icône Material optionnelle pour l'en-tête. */
  @Input() Icon: string = 'map';
  /** Ajuste automatiquement la vue pour englober tous les marqueurs. Défaut: true. */
  @Input() FitBounds: boolean = true;
  /** Padding (px) appliqué lors de l'ajustement automatique des bounds. Défaut: 40. */
  @Input() FitBoundsPadding: number = 40;
  /** Zoom maximal appliqué par fitBounds (évite un zoom excessif sur points superposés). Défaut: 16. */
  @Input() MaxFitZoom: number = 16;
  /**
   * Affiche l'en-tête interne (titre + icône + sélecteur de style).
   * Mettre à `false` lorsque le composant est enveloppé dans `app-section-card` (Collapsible=true).
   */
  @Input() ShowHeader: boolean = true;
  /**
   * Adapte automatiquement le style de carte au thème de l'application au premier rendu.
   * Si `true` (défaut), passe en `EMapStyle.Dark` quand `ThemeService.IsDark` est vrai.
   * Mettre à `false` pour empêcher l'auto-adaptation.
   */
  @Input() AutoTheme: boolean = true;
  /** Mode de lumière initial. Défaut: Day. */
  @Input() LightMode: EMapLightMode = EMapLightMode.Day;
  //#endregion

  //#region Outputs

  /** Émis au clic sur la carte (si EnableClick). Contient { lat, lng }. */
  @Output() MapClick: EventEmitter<{ Lat: number; Lng: number }> = new EventEmitter<{ Lat: number; Lng: number }>();
  /** Émis au changement de style de carte. */
  @Output() StyleChange: EventEmitter<EMapStyle> = new EventEmitter<EMapStyle>();
  /**
   * Émis au clic sur un marqueur.
   * - cm - Le parent gère l'affichage du popup custom (grille, formulaire, etc.)
   * - cm - via `(MarkerClick)`. Le map-card ne fournit plus de popup interne.
   */
  @Output() MarkerClick: EventEmitter<IMapMarker> = new EventEmitter<IMapMarker>();

  //#endregion

  //#region Attributes

  /** Référence au conteneur DOM de la carte. */
  @ViewChild('MapContainer') private _MapContainer!: ElementRef<HTMLDivElement>;

  /** Instance Mapbox GL de la carte. `null` avant `ngAfterViewInit` ou hors navigateur. */
  private _Map: any = null;

  /** Liste des marqueurs Mapbox GL actifs. */
  private _MarkerObjects: any[] = [];

  /** Liste des popups Mapbox GL actifs. */
  private _PopupObjects: any[] = [];

  /** Indique si on s'exécute dans le navigateur (SSR-safe). */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Zone Angular pour exécuter les callbacks natifs en dehors du change detection. */
  private readonly _NgZone: NgZone = inject(NgZone);

  /** Observateur de redimensionnement du conteneur de carte. */
  private _ResizeObserver: ResizeObserver | null = null;

  /** Timeout de fallback pour resize après initialisation. */
  private _ResizeTimeoutId: ReturnType<typeof setTimeout> | null = null;

  /** Référence au module Mapbox GL chargé dynamiquement. */
  private _MapboxModule: any = null;

  /** Identifiant de la layer `fill-extrusion` ajoutée pour les bâtiments 3D sur les styles NON-Standard. */
  private _Buildings3DLayerId: string = 'sm-3d-buildings';

  /** Source Mapbox contenant le source-layer `building` utilisée par la layer `fill-extrusion` des bâtiments 3D. */
  private _Buildings3DSourceId: string = 'composite';

  /** Handler fullscreen lié à `document.addEventListener` (stocké pour pouvoir le retirer). */
  private readonly _OnFullscreenChange: () => void = () =>
  {
    // - cm - On fullscreen le CONTAINER parent (qui contient la carte + la toolbar),
    // - cm - pas juste la div MapContainer. Sinon la toolbar disparait en fullscreen
    // - cm - car le navigateur ne montre que l'element fullscreen.
    const lContainer: HTMLDivElement | null = (this._MapContainer?.nativeElement?.parentElement as HTMLDivElement | null) ?? null;
    this._NgZone.run(() =>
    {
      this.IsFullscreen.set(document.fullscreenElement === lContainer);
    });
    // - cm - Force un resize de la carte apres le changement de fullscreen
    // - cm - (sinon Mapbox peut garder l'ancienne taille et avoir des tiles grises).
    this._NgZone.runOutsideAngular(() =>
    {
      setTimeout(() => this._Map?.resize(), 100);
    });
  };

  /** Handler clavier (stocké pour pouvoir le retirer). */
  private readonly _OnKeyDown = (pEvent: KeyboardEvent) =>
  {
    if (!this.EnableKeyboardShortcuts)
    {
      return;
    }
    // - cm - Ignore si on est dans un input / textarea (pour ne pas casser la saisie)
    const lTarget = pEvent.target as HTMLElement | null;
    if (lTarget && (lTarget.tagName === 'INPUT' || lTarget.tagName === 'TEXTAREA' || lTarget.isContentEditable))
    {
      return;
    }
    // - cm - Ignore si un modificateur est actif (Ctrl/Meta/Alt) sauf Shift (pour Shift+N rotation)
    if (pEvent.ctrlKey || pEvent.metaKey || pEvent.altKey)
    {
      return;
    }
    const lKey = pEvent.key.toLowerCase();
    if (lKey === 'p') { pEvent.preventDefault(); this.Toggle3D(); }
    else if (lKey === 'n') { pEvent.preventDefault(); this.ResetBearing(); }
    else if (lKey === 'f') { pEvent.preventDefault(); this.ToggleFullscreen(); }
    else if (lKey === 't') { pEvent.preventDefault(); this.CycleLightMode(); }
    else if (lKey === 'b') { pEvent.preventDefault(); this.Toggle3DBuildings(); }
  };

  /** Service de thème utilisé pour l'auto-adaptation dark/light. */
  private readonly _ThemeService: ThemeService = inject(ThemeService);

  /** Service léger qui compose l'URL du style spec pour Mapbox GL. */
  private readonly _MapboxProxy: MapboxProxyService = inject(MapboxProxyService);

  /** Token public Mapbox (`pk.`) lu depuis `environment.mapboxToken`. */
  private _MapboxToken: string | undefined;

  /**
   * Index des markers par `DataId` (ou clé lng/lat fallback) pour retrouver
   * le marker complet (avec son DTO `Data`, `Type`, `Label`) au clic.
   * - cm - Mapbox sérialise les properties du GeoJSON via JSON, ce qui perd
   * - cm - la référence d'objet et le DTO imbriqué. On garde donc une `Map<id, IMapMarker>`
   * - cm - mise à jour à chaque `RenderMarkers()`.
   */
  private _MarkersById: Map<string, IMapMarker> = new Map<string, IMapMarker>();

  /**
   * Crée une image Canvas 2D (24×24) avec une icône Material Icons spécifique
   * au type de marker (Property / Transaction / Location).
   * - cm - Mapbox Standard ne fournit pas de glyphs/fonts. On dessine donc à la
   * - cm - main via Canvas2D : un cercle de fond (couleur du marker), un halo
   * - cm - blanc, et un caractère Unicode rendu via la police système (Material
   * - cm - Icons est chargé globalement dans index.html).
   * @param pIconKey Le nom court de l'icône (home_work / sell / key / default).
   * @param pColor La couleur CSS du marker (hex ou var(--...)).
   * @returns Les données PNG (Uint8Array RGBA) prêtes pour Mapbox.
   */
  private CreateMarkerIconData(pIconKey: string = 'default', pColor: string = '#9c27b0'): { width: number; height: number; data: Uint8Array | Uint8ClampedArray }
  {
    const lSize = 28;
    const lCanvas: HTMLCanvasElement = document.createElement('canvas');
    lCanvas.width = lSize;
    lCanvas.height = lSize;
    const lCtx: CanvasRenderingContext2D = lCanvas.getContext('2d')!;

    // - cm - Résolution 2x pour la netteté (DPR-aware)
    const lDpr: number = window.devicePixelRatio || 1;
    lCanvas.width = lSize * lDpr;
    lCanvas.height = lSize * lDpr;
    lCtx.scale(lDpr, lDpr);

    // - cm - Halo blanc extérieur (pour détachement du fond)
    lCtx.fillStyle = '#ffffff';
    lCtx.beginPath();
    lCtx.arc(lSize / 2, lSize / 2, lSize / 2 - 1, 0, Math.PI * 2);
    lCtx.fill();

    // - cm - Cercle de fond coloré (la couleur du marker)
    lCtx.fillStyle = this.ResolveCssColor(pColor);
    lCtx.beginPath();
    lCtx.arc(lSize / 2, lSize / 2, lSize / 2 - 3, 0, Math.PI * 2);
    lCtx.fill();

    // - cm - Récupère le caractère Material Icons via le helper centralisé
    // - cm - (cf. `map-marker-style.ts`). Une seule source de vérité pour
    // - cm - l'icône/couleur, partagée avec le dashboard et les tooltips.
    // - cm - `pIconKey` peut être un `EMarkerType` (ex: 'property') ou un
    // - cm - nom d'icône (ex: 'home_work'). On normalise pour matcher MARKER_STYLES.
    const lTypeKey: string = (pIconKey ?? 'default').toLowerCase();
    const lChar: string = GetMarkerStyle(lTypeKey).MaterialChar;

    // - cm - Dessine l'icône Material au centre (couleur blanche)
    lCtx.fillStyle = '#ffffff';
    lCtx.font = '16px "Material Icons"';
    lCtx.textAlign = 'center';
    lCtx.textBaseline = 'middle';
    lCtx.fillText(lChar, lSize / 2, lSize / 2 + 1);

    // - cm - Retourne les pixels RGBA au format attendu par Mapbox
    const lImageData: ImageData = lCtx.getImageData(0, 0, lCanvas.width, lCanvas.height);
    return {
      width: lCanvas.width,
      height: lCanvas.height,
      data: new Uint8Array(lImageData.data.buffer)
    };
  }

  /**
   * Résout une couleur CSS (gère les var(--xxx)) vers sa valeur RGB calculée.
   * - cm - Mapbox attend une couleur concrète pour addImage (pas de var()).
   */
  private ResolveCssColor(pColor: string): string
  {
    if (!pColor) { return '#9c27b0'; }
    if (pColor.startsWith('var('))
    {
      const lMatch: RegExpMatchArray | null = pColor.match(/var\(([^,)]+)/);
      if (lMatch)
      {
        const lVarName: string = lMatch[1].trim();
        const lVal: string = getComputedStyle(document.documentElement).getPropertyValue(lVarName).trim();
        return lVal || '#9c27b0';
      }
    }
    return pColor;
  }

  /** Centre courant de la carte (suivi via `map.on('move')`). Signal pour OnPush. */
  public readonly Center = signal<[number, number]>([this.CenterLng, this.CenterLat]);
  /** Zoom courant de la carte (suivi via `map.on('move')`). Signal pour OnPush. */
  public readonly ZoomLevel = signal<number>(this.Zoom);
  /** Indique si la vue 3D (pitch) est activée. Signal pour OnPush. */
  public readonly Is3DEnabled = signal<boolean>(false);
  /** Indique si les bâtiments 3D sont affichés. Signal pour OnPush. */
  public readonly Show3DBuildings = signal<boolean>(true);
  /** Bearing (rotation en degrés) courant de la carte. Signal pour OnPush. */
  public readonly CompassBearing = signal<number>(0);
  /** Indique si le container de la carte est en plein écran. Signal pour OnPush. */
  public readonly IsFullscreen = signal<boolean>(false);
  /** Indique si le thème sombre est actif (miroir de ThemeService.IsDark). Signal pour OnPush. */
  public readonly IsDarkTheme = signal<boolean>(false);
  /** Indique si la toolbar de navigation (gauche) est repliee. Signal pour OnPush. */
  public readonly LeftToolbarCollapsed = signal<boolean>(false);
  /** Indique si la toolbar d'affichage (droite) est repliee. Signal pour OnPush. */
  public readonly RightToolbarCollapsed = signal<boolean>(false);
  /** Indique si la toolbar light-modes (centre-gauche) est repliee. Signal pour OnPush. */
  public readonly LightModeToolbarCollapsed = signal<boolean>(false);
  /** Mode de lumiere courant (Default/Faded/Monochrome/Night). Signal pour OnPush. */
  public readonly CurrentLightMode = signal<EMapLightMode>(EMapLightMode.Default);

  /**
   * Liste des 4 modes de lumiere pour le selecteur vertical (toolbar light-modes).
   * Ordre : Dawn -> Day -> Dusk -> Night.
   */
  /**
   * Liste des préréglages d'éclairage Mapbox Standard pour le selecteur (toolbar gauche).
   * Ordre : Dawn -> Day -> Dusk -> Night.
   * - cm - Cf. https://docs.mapbox.com/map-styles/guides/standard-styles/
   * - cm - Appliqués via `map.setConfigProperty('basemap', 'lightPreset', value)`.
   */
  public readonly LightModes: { Value: EMapLightMode; Label: string; Icon: string }[] = [
    { Value: EMapLightMode.Dawn, Label: 'Aube', Icon: 'wb_twilight' },
    { Value: EMapLightMode.Day, Label: 'Jour', Icon: 'wb_sunny' },
    { Value: EMapLightMode.Dusk, Label: 'Crépuscule', Icon: 'wb_twilight' },
    { Value: EMapLightMode.Night, Label: 'Nuit', Icon: 'nights_stay' }
  ];

  /**
   * Indique qu'un parent a explicitement posé un binding `[Style]` ou que
   * l'utilisateur a sélectionné un style manuellement. Bloque l'auto-thème.
   */
  private _ExternalStyleSet: boolean = false;

  /** Indique que `AutoTheme` a déjà été appliqué une fois (fige le choix initial). */
  private _AutoThemeApplied: boolean = false;

  /** Compteur statique pour générer un identifiant unique par instance (utilisé par aria-controls). */
  private static _NextComponentId: number = 0;

  /** Identifiant unique de cette instance, pour relier le bouton au popover (ARIA). */
  public readonly ComponentId: string = `sm-map-${++MapCardComponent._NextComponentId}`;

  /** Indique si le popover des attributions est ouvert. Signal pour OnPush. */
  public readonly ShowAttributions = signal<boolean>(false);

  /**
   * Titre humain du style courant, lu depuis le champ `name` du style spec
   * une fois chargé par Mapbox GL. `null` tant que le style n'a pas été chargé.
   * Signal pour déclencher le change detection OnPush.
   */
  public readonly CurrentStyleName = signal<string | null>(null);

  /**
   * Bloc d'attribution HTML brut associé au style courant, à afficher dans le popover.
   * Pour les styles vectoriels Mapbox, l'attribution Mapbox/OSM est intégrée
   * automatiquement par Mapbox GL.
   */
  public readonly CurrentAttributionProvider = computed<string>(() =>
  {
    return '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>';
  });

  /**
   * Mapping des EMapStyle vers les identifiants Mapbox Studio custom.
   * Cf. Mapbox Studio → Share → Settings → "Style URL" → copier l'ID après `/styles/`.
   * Valeurs par défaut = styles built-in Mapbox (accessibles avec n'importe quel token `pk.`).
   * Pour utiliser un style custom, remplacer la valeur par
   * `adminsellmatch/<styleId>`.
   */
  private static readonly MapboxStyleIds: Record<EMapStyle, string> = {
    [EMapStyle.Streets]: 'mapbox/standard',
    [EMapStyle.Light]: 'mapbox/standard',
    [EMapStyle.Dark]: 'mapbox/standard',
    [EMapStyle.Satellite]: 'mapbox/standard-satellite',
    [EMapStyle.Terrain]: 'mapbox/outdoors-v12',
    [EMapStyle.Outdoors]: 'mapbox/outdoors-v12',
    [EMapStyle.Navigation]: 'mapbox/navigation-day-v1'
  };

  /**
   * Mapping des EMapLightMode vers le `lightPreset` du style Mapbox Standard.
   * Cf. https://docs.mapbox.com/map-styles/guides/standard-styles/ (Lighting)
   * - dawn / day / dusk / night sont les 4 presets officiels.
   * - On les applique via `map.setConfigProperty('basemap', 'lightPreset', value)`.
   */
  private static readonly LightPresetValues: Record<EMapLightMode, string> = {
    [EMapLightMode.Default]: 'day',
    [EMapLightMode.Dawn]: 'dawn',
    [EMapLightMode.Day]: 'day',
    [EMapLightMode.Dusk]: 'dusk',
    [EMapLightMode.Night]: 'night'
  };

  /**
   * Mapping optionnel vers le `theme` du style Mapbox Standard.
   * On l'utilise en complément du lightPreset pour un rendu cohérent (ex: nuit = night theme).
   */
  private static readonly ThemeValues: Record<EMapLightMode, string> = {
    [EMapLightMode.Default]: 'default',
    [EMapLightMode.Dawn]: 'default',
    [EMapLightMode.Day]: 'default',
    [EMapLightMode.Dusk]: 'default',
    [EMapLightMode.Night]: 'night'
  };

  /** Styles de carte disponibles pour le sélecteur. */
  public readonly Styles: { Value: EMapStyle; Label: string; Icon: string }[] = [
    { Value: EMapStyle.Streets, Label: 'Standard', Icon: 'map' },
    { Value: EMapStyle.Light, Label: 'Clair', Icon: 'light_mode' },
    { Value: EMapStyle.Dark, Label: 'Sombre', Icon: 'dark_mode' },
    { Value: EMapStyle.Satellite, Label: 'Satellite', Icon: 'satellite_alt' },
    { Value: EMapStyle.Terrain, Label: 'Terrain', Icon: 'terrain' },
    { Value: EMapStyle.Outdoors, Label: 'Plein air', Icon: 'park' },
    { Value: EMapStyle.Navigation, Label: 'Navigation', Icon: 'directions' }
  ];

  //#endregion

  //#region Lifecycle

  // eslint-disable-next-line @typescript-eslint/naming-convention
  ngAfterViewInit(): void
  {
    this.ApplyAutoThemeIfNeeded();
    void this.InitMap();
  }

  // eslint-disable-next-line @typescript-eslint/naming-convention
  ngOnChanges(pChanges: SimpleChanges): void
  {
    // - cm - Mise à jour des marqueurs si la liste change
    if (this._Map && pChanges['Markers'] && Array.isArray(this.Markers))
    {
      this.RenderMarkers();
    }
    // - cm - Le parent a posé/réposé un [Style] via binding : on propage à MapLibre.
    // - cm - IMPORTANT : on compare avec previousValue (PAS avec this.Style) car Angular
    // - cm - a déjà assigné la nouvelle valeur à `this.Style` via le setter d'Input
    // - cm - AVANT que ngOnChanges ne se déclenche. Si on comparait à this.Style,
    // - cm - OnStyleChange() early-returnait toujours et setStyle ne serait jamais
    // - cm - appelé → markers pas re-rendus après un changement de style via binding.
    if (pChanges['Style'])
    {
      const lChange = pChanges['Style'];
      const lIsFirstChange: boolean = lChange.firstChange === true;
      if (!lIsFirstChange)
      {
        this._ExternalStyleSet = true;
        const lPrevious: EMapStyle | undefined = lChange.previousValue as EMapStyle | undefined;
        if (lPrevious !== undefined && lPrevious !== this.Style && this._Map)
        {
          // - cm - On propage à Mapbox via OnStyleChange mais on bypass l'early-return
          // - cm - en settant `this.Style` à la valeur précédente temporairement.
          // - cm - Alternative : appeler setStyle directement. On choisit setStyle
          // - cm - pour rester cohérent avec le chemin toolbar.
          this.ApplyStyleChange(this.Style);
        }
      }
    }
  }

  // eslint-disable-next-line @typescript-eslint/naming-convention
  ngOnDestroy(): void
  {
    this.DisposeResizeObserver();
    if (this._ResizeTimeoutId)
    {
      clearTimeout(this._ResizeTimeoutId);
      this._ResizeTimeoutId = null;
    }
    if (this._IsBrowser)
    {
      document.removeEventListener('keydown', this._OnKeyDown);
      document.removeEventListener('fullscreenchange', this._OnFullscreenChange);
    }
    if (this._Map)
    {
      this._Map.remove();
      this._Map = null;
    }
  }

  //#endregion

  //#region Methods

  /**
   * Adapte le style de carte au thème courant de l'application lors du premier rendu.
   */
  private ApplyAutoThemeIfNeeded(): void
  {
    if (this._AutoThemeApplied || !this.AutoTheme || this._ExternalStyleSet)
    {
      return;
    }
    if (this._ThemeService.IsDark)
    {
      this.Style = EMapStyle.Dark;
    }
    this._AutoThemeApplied = true;
  }

  /**
   * Crée l'instance Mapbox GL, ajoute le style et les marqueurs.
   * Suit le pattern du tutorial officiel Mapbox :
   * https://docs.mapbox.com/help/tutorials/use-mapbox-gl-js-with-angular/
   */
  private async InitMap(): Promise<void>
  {
    if (!this._IsBrowser || !this._MapContainer)
    {
      return;
    }

    // - cm - Récupère le token Mapbox public depuis `environment.mapboxToken`
    // - cm - (lu localement, jamais committé). Si vide, on tente le fallback
    // - cm - via le backend `/api/config/mapbox-token` (Infisical).
    this._MapboxToken = environment.mapboxToken || undefined;
    if (!this._MapboxToken)
    {
      console.error('[MapCard] Jeton Mapbox absent (environment.mapboxToken vide).');
      return;
    }

    // - cm - Import dynamique : évite l'accès à window au chargement du module.
    // - cm - On accède à `.default` car mapbox-gl est un export CommonJS/ESM mixte.
    const mapboxgl = (await import('mapbox-gl')).default;
    this._MapboxModule = mapboxgl;

    mapboxgl.workerUrl = '/assets/mapbox-gl-csp-worker.js';

    // - cm - (août 2026) Désactive la telemetry Mapbox.
    // - cm - EVENTS_URL est exposé par le SDK 3.28.1 en **getter only** (lecture seule),
    // - cm - donc l'assignation directe `mapboxgl.config.EVENTS_URL = null` lève
    // - cm - TypeError dans NodeNext/strict mode. On contourne via Object.defineProperty
    // - cm - qui écrase la propriété existante avec un data descriptor writable.
    // - cm - Resultat : le SDK lit `null` pour la cible telemetry et n'envoie plus
    // - cm - aucun POST vers https://events.mapbox.com/events/v2.
    // - cm - Doit être set AVANT la première `new mapboxgl.Map()` ci-dessous.
    // - cm - Le filtre `transformRequest` (events.mapbox.com -> data:) reste en
    // - cm - defense en profondeur si le SDK reset la propriété en interne.
    if (mapboxgl.config)
    {
      Object.defineProperty(mapboxgl.config, 'EVENTS_URL', {
        value: null,
        writable: true,
        configurable: true,
        enumerable: true
      });
    }

    this._NgZone.runOutsideAngular(() =>
    {
      this._Map = new mapboxgl.Map({
        accessToken: this._MapboxToken,
        container: this._MapContainer.nativeElement,
        style: this._MapboxProxy.GetStyleSpecUrl(MapCardComponent.MapboxStyleIds[this.Style]),
        center: [this.CenterLng, this.CenterLat],
        zoom: this.Zoom,
        attributionControl: false,
        scrollZoom: this.ScrollWheelZoom,

        // - cm - Filtre la source 'mapbox-incidents-v1' (fermee par Mapbox)
        // - cm - en la remplacant par une URL vide (data:,). Sans ce filtre,
        // - cm - la console est polluee de 404 sur chaque tile chargee.
        // - cm - Bloque aussi la telemetrie Mapbox (events.mapbox.com et .cn)
        // - cm - qui POSTe en boucle les events de session/perf/turnstile.
        // - cm - Sur la prod, ces requetes sont bloquees par le bloqueur de
        // - cm - tracking du navigateur (ERR_BLOCKED_BY_CLIENT) ; sur la
        // - cm - recette, elles passent en CORS et polluent la console.
        transformRequest: (pUrl: string) =>
        {
          if (pUrl.includes('mapbox-incidents'))
          {
            return { url: 'data:,' };
          }
          if (pUrl.startsWith('https://events.mapbox.com/') || pUrl.startsWith('https://events.mapbox.cn/'))
          {
            return { url: 'data:,' };
          }
          return { url: pUrl };
        }
      });

      new mapboxgl.Marker()

      // - cm - Toolbar custom (gérée via le template HTML) : on n'ajoute PAS
      // - cm - NavigationControl pour éviter la barre grise Mapbox standard.
      // - cm - Les boutons 3D / compass / fullscreen / theme pilotent l'instance
      // - cm - via les méthodes publiques du composant (ZoomIn, Toggle3D, etc.).
      // - cm - Listener plein écran (gère le signal IsFullscreen)
      // - cm - On synchronise IsDarkTheme avec ThemeService pour la toolbar.
      this.IsDarkTheme.set(this._ThemeService.IsDark);
      this._NgZone.runOutsideAngular(() =>
      {
        this._Map.on('rotate', () =>
        {
          // - cm - Mapbox ne tire pas 'moveend' à chaque frame d'inclinaison, on
          // - cm - lit directement la valeur courante.
          this._NgZone.run(() => this.CompassBearing.set(this._Map.getBearing()));
        });
        this._Map.on('pitch', () =>
        {
          this._NgZone.run(() => this.Is3DEnabled.set((this._Map.getPitch() ?? 0) > 5));
        });
      });

      // - cm - Mapbox GL désactive son propre keyboard handler quand on passe
      // - cm - keyboard: false — on gere nos raccourcis custom via _OnKeyDown.
      this._Map.keyboard.disable();
      if (this._IsBrowser)
      {
        document.addEventListener('keydown', this._OnKeyDown);
        document.addEventListener('fullscreenchange', this._OnFullscreenChange);
      }

      // - cm - Événement clic sur la carte
      if (this.EnableClick)
      {
        this._Map.on('click', (pEvent: { lngLat: { lat: number; lng: number } }) =>
        {
          this._NgZone.run(() =>
          {
            this.MapClick.emit({ Lat: pEvent.lngLat.lat, Lng: pEvent.lngLat.lng });
          });
        });
      }

      // - cm - Attendre le chargement de la carte avant d'ajouter les marqueurs
      // - cm - et activer les bâtiments 3D. Sur Mapbox Standard, les bâtiments
      // - cm - 3D sont gérés nativement par le style (param show3dBuildings),
      // - cm - pas besoin d'ajouter une layer fill-extrusion custom.
      this._Map.on('load', () =>
      {
        this._NgZone.run(() =>
        {
          this.RenderMarkers();
          this.Set3DBuildingsEnabled(this.Show3DBuildings());
          this.SetLightMode(this.LightMode);
        });
      });

      // - cm - A chaque changement de style (l'utilisateur clique sur un style
      // - cm - dans la toolbar), on reactive les bâtiments 3D selon le signal.
      // - cm - IMPORTANT : on relit `this.Show3DBuildings()` au moment du
      // - cm - `style.load` (pas une copie capturée) pour respecter l'état
      // - cm - courant de l'utilisateur au moment où le style est prêt.
      // - cm - Pareil pour les markers : Mapbox detruit les sources/layers
      // - cm - ajoutees par RenderMarkers (sm-markers-source/layer/icon-layer)
      // - cm - lors du `setStyle`. On les reattache au nouveau style.
      this._Map.on('style.load', () =>
      {
        this._NgZone.run(() =>
        {
          // - cm - Petit délai pour laisser Mapbox finir d'instancier les layers
          // - cm - Standard avant de toggler les show3dBuildings via setConfigProperty.
          const lCurrent: boolean = this.Show3DBuildings();
          setTimeout(() => this.Set3DBuildingsEnabled(lCurrent), 50);
          // - cm - Re-render les markers apres un setStyle : la cascade
          // - cm - style.load est le seul endroit ou on peut savoir que
          // - cm - le nouveau style spec est pret et qu'on peut re-attacher
          // - cm - nos sources/layers custom.
          this.RenderMarkers();
        });
      });

      // - cm - Listener `move` pour mettre à jour les signals Center/Zoom
      // - cm - (utilisés par la toolbar longitude/latitude/zoom cf. step 5 du tutorial).
      this._Map.on('move', () =>
      {
        this._NgZone.run(() =>
        {
          const lCenter = this._Map.getCenter();
          this.Center.set([lCenter.lng, lCenter.lat]);
          this.ZoomLevel.set(this._Map.getZoom());
        });
      });

      this.ScheduleResize();
      this.SetupResizeObserver();
    });
  }

  private SetupResizeObserver(): void
  {
    if (!this._IsBrowser || !this._MapContainer || !('ResizeObserver' in window))
    {
      return;
    }
    this.DisposeResizeObserver();
    this._ResizeObserver = new ResizeObserver((pEntries) =>
    {
      const lEntry: ResizeObserverEntry | undefined = pEntries[0];
      if (!lEntry || lEntry.contentRect.width === 0 || lEntry.contentRect.height === 0)
      {
        return;
      }
      this._NgZone.runOutsideAngular(() =>
      {
        this._Map?.resize();
      });
    });
    this._ResizeObserver.observe(this._MapContainer.nativeElement);
  }

  private DisposeResizeObserver(): void
  {
    if (this._ResizeObserver)
    {
      this._ResizeObserver.disconnect();
      this._ResizeObserver = null;
    }
  }

  private ScheduleResize(): void
  {
    if (this._ResizeTimeoutId)
    {
      clearTimeout(this._ResizeTimeoutId);
    }
    this._ResizeTimeoutId = setTimeout(() =>
    {
      this._ResizeTimeoutId = null;
      this._Map?.resize();
      this._ResizeTimeoutId = setTimeout(() =>
      {
        this._ResizeTimeoutId = null;
        this._Map?.resize();
      }, 500);
    }, 200);
  }

  /**
   * Active ou désactive les bâtiments 3D sur la carte selon le paramètre.
   * - Sur Mapbox Standard : utilise `setConfigProperty('basemap', ...)` (API officielle).
   *   Les bâtiments 3D sont rendus nativement par le style Standard ; on n'ajoute PAS
   *   de layer `fill-extrusion` manuelle (la source 'composite' n'existe pas).
   * - Sur les autres styles (outdoors-v12, streets-v12, navigation-day-v1, etc.) :
   *   ajoute/retire une layer `fill-extrusion` adossée au source-layer `building`
   *   exposé par la source `composite` Mapbox (fallback classique).
   * - cm - Idempotent : peut être appelé plusieurs fois sans dupliquer la layer.
   * - cm - Voir https://docs.mapbox.com/map-styles/guides/standard-styles/
   * @param pEnabled `true` pour afficher les bâtiments 3D, `false` pour les masquer
   */
  public Set3DBuildingsEnabled(pEnabled: boolean): void
  {
    if (!this._Map)
    {
      return;
    }
    // - cm - Mise à jour du signal pour refléter l'état dans la toolbar (OnPush).
    this.Show3DBuildings.set(pEnabled);

    // - cm - Détection durcie du style Standard : on teste plusieurs sources car
    // - cm - `getStyle()?.sprite` peut être `undefined` au premier chargement
    // - cm - (avant que Mapbox n'ait fini de parser le style spec).
    const lStyle: any = this._Map.getStyle() ?? {};
    const lStyleUri: string = lStyle.sprite ?? '';
    const lStyleJson: string = JSON.stringify(lStyle ?? {});
    const lIsStandard: boolean =
      lStyleUri.includes('mapbox/standard') ||
      lStyleUri.includes('standard-satellite') ||
      lStyleJson.includes('mapbox/standard') ||
      lStyleJson.includes('standard-satellite');

    if (lIsStandard)
    {
      // - cm - Mapbox Standard : on active via setConfigProperty (API officielle).
      // - cm - Cf. https://docs.mapbox.com/map-styles/guides/standard-styles/
      // - cm - Les basemap config properties valides pour les bâtiments 3D sont :
      // - cm -   - `show3dBuildings` : active les bâtiments 3D
      // - cm -   - `show3dLandmarks` : active les landmarks 3D
      // - cm - NOTE : `show3dObjects` N'EXISTE PAS dans l'API Mapbox Standard
      // - cm - (l'appel jetait silencieusement une exception avant le fix).
      // - cm - Garde : si le style n'est pas encore complètement chargé (au
      // - cm - premier init), on differe l'appel au prochain style.load.
      // - cm - Sinon setConfigProperty jette silencieusement "Style is not
      // - cm - done loading" et le toggle 3D buildings n'a aucun effet.
      const lApplyConfig: () => void = () =>
      {
        if (!this._Map) { return; }
        if (typeof this._Map.setConfigProperty !== 'function') { return; }
        // - cm - Re-detect le style Standard au moment de l'application (le
        // - cm - listener style.load peut arriver apres un setStyle vers un
        // - cm - style non-Standard, on ne veut alors PAS appeler setConfigProperty).
        const lCurStyle: any = this._Map.getStyle() ?? {};
        const lCurJson: string = JSON.stringify(lCurStyle);
        const lCurIsStandard: boolean =
          (lCurStyle.sprite ?? '').includes('mapbox/standard') ||
          (lCurStyle.sprite ?? '').includes('standard-satellite') ||
          lCurJson.includes('mapbox/standard') ||
          lCurJson.includes('standard-satellite');
        if (!lCurIsStandard) { return; }
        try
        {
          this._Map.setConfigProperty('basemap', 'show3dBuildings', pEnabled);
          this._Map.setConfigProperty('basemap', 'show3dLandmarks', pEnabled);
        }
        catch (pErr)
        {
          // - cm - Log l'erreur au lieu de l'avaler : si le bouton ne marche
          // - cm - pas, on a une piste dans la console (au lieu d'un silent
          // - cm - fail qui force l'utilisateur a F12 lui-meme).
          console.warn('[MapCard 3D] setConfigProperty failed:', pErr);
        }
      };

      if (this._Map.isStyleLoaded && this._Map.isStyleLoaded())
      {
        lApplyConfig();
      }
      else
      {
        this._Map.once?.('style.load', lApplyConfig);
      }
      return;
    }

    // - cm - Styles NON-Standard : on ajoute/retire une layer fill-extrusion
    // - cm - sur la source 'composite' (source-layer 'building'). La couche
    // - cm - est identifiée par `_Buildings3DLayerId` pour pouvoir la supprimer
    // - cm - proprement au toggle off (sans laisser de layer orpheline).
    if (!pEnabled)
    {
      this.Remove3DBuildingsLayer();
      return;
    }
    this.Add3DBuildingsLayer();
  }

  /**
   * Ajoute la layer `fill-extrusion` des bâtiments 3D sur la source `composite`.
   * Style Mapbox classique (streets-v12, outdoors-v12, navigation-day-v1...).
   * - cm - Pattern recommandé par Mapbox : https://docs.mapbox.com/mapbox-gljs/example/3d-buildings/
   * - cm - Idempotent : si la layer existe déjà, on ne fait rien.
   */
  private Add3DBuildingsLayer(): void
  {
    if (!this._Map) { return; }
    // - cm - Le style spec doit être complètement chargé avant addLayer.
    if (!this._Map.isStyleLoaded())
    {
      this._Map.once('style.load', () => this.Add3DBuildingsLayer());
      return;
    }
    if (this._Map.getLayer(this._Buildings3DLayerId))
    {
      this._Map.setLayoutProperty(this._Buildings3DLayerId, 'visibility', 'visible');
      return;
    }

    // - cm - La source 'composite' est fournie par Mapbox sur les styles
    // - cm - classiques et contient le source-layer 'building' avec les
    // - cm - propriétés 'height' / 'min_height' pour l'extrusion 3D.
    if (!this._Map.getSource(this._Buildings3DSourceId))
    {
      return;
    }

    try
    {
      this._Map.addLayer({
        id: this._Buildings3DLayerId,
        type: 'fill-extrusion',
        source: this._Buildings3DSourceId,
        'source-layer': 'building',
        filter: ['==', 'extrude', 'true'],
        minzoom: 13,
        paint: {
          // - cm - Couleur des bâtiments : gris clair avec une teinte bleutée.
          // - cm - La couleur est volontairement neutre pour ne pas concurrencer
          // - cm - visuellement les marqueurs et les couches métier.
          'fill-extrusion-color': [
            'interpolate', ['linear'], ['zoom'],
            13, '#cfd8e3',
            16, '#aab8c5'
          ],
          // - cm - Hauteur d'extrusion : on prend 'height' si présent,
          // - cm - sinon 'min_height' ou un fallback de 10m.
          'fill-extrusion-height': [
            'interpolate', ['linear'], ['zoom'],
            13, ['coalesce', ['get', 'height'], ['get', 'min_height'], 10],
            16, ['coalesce', ['get', 'height'], ['get', 'min_height'], 50]
          ],
          // - cm - Hauteur de la base (utile pour les toits en pente).
          'fill-extrusion-base': [
            'coalesce', ['get', 'min_height'], 0
          ],
          // - cm - Opacité légèrement augmentée au zoom élevé pour donner du relief.
          'fill-extrusion-opacity': [
            'interpolate', ['linear'], ['zoom'],
            13, 0.6,
            16, 0.85
          ]
        }
      });
      console.log('[MapCard 3D] Add3DBuildingsLayer: layer added');
    }
    catch (pErr)
    {
      // - cm - Certains styles custom ne supportent pas fill-extrusion sur
      // - cm - 'building' (source-layer absent). On log et on continue.
      console.warn('[MapCard 3D] Layer 3D buildings indisponible :', pErr);
    }
  }

  /**
   * Retire la layer `fill-extrusion` des bâtiments 3D (si elle existe).
   * - cm - Hardened : log systématique du résultat pour diagnostic du toggle off.
   */
  private Remove3DBuildingsLayer(): void
  {
    if (!this._Map) { return; }
    const lMap: any = this._Map;
    const lDoRemove: () => void = () =>
    {
      if (!lMap || !lMap.getLayer || !lMap.getLayer(this._Buildings3DLayerId))
      {
        return;
      }
      try
      {
        lMap.removeLayer(this._Buildings3DLayerId);
      }
      catch (pErr)
      {
        console.warn('[MapCard 3D] Remove3DBuildingsLayer failed:', pErr);
      }
    };

    // - cm - Si le style n'est pas chargé, on planifie le retrait au prochain style.load.
    if (!lMap.isStyleLoaded || !lMap.isStyleLoaded())
    {
      console.log('[MapCard 3D] Remove3DBuildingsLayer: style not loaded, scheduling');
      lMap.once?.('style.load', lDoRemove);
      return;
    }
    lDoRemove();
  }

  /**
   * Affiche tous les marqueurs sur la carte et ajuste la vue si plusieurs marqueurs.
   * Pattern minimaliste : marker natif Mapbox GL avec popup au clic.
   */
  private RenderMarkers(): void
  {
    if (!this._Map || !this.Markers || this.Markers.length === 0) { return; }
    // - cm - Le style Mapbox peut ne pas être complètement chargé au premier rendu
    // - cm - (notamment quand ngOnChanges se déclenche avant `style.load`). Sans
    // - cm - cette garde, `addSource` jette "Style is not done loading" et les
    // - cm - markers ne s'affichent jamais. On re-essaye après le prochain `style.load`.
    if (!this._Map.isStyleLoaded())
    {
      this._Map.once('style.load', () => this.RenderMarkers());
      return;
    }

    const lSourceId: string = 'sm-markers-source';
    const lLayerId: string = 'sm-markers-layer';
    const lIconLayerId: string = 'sm-markers-icon-layer';

    // - cm - Nettoyage preventif : setStyle detruit nos sources/layers, mais
    // - cm - RenderMarkers peut aussi etre appele plusieurs fois pour le meme
    // - cm - style (binding Markers change sans setStyle). On retire dans
    // - cm - l'ordre inverse (icone -> base -> source) avec try/catch pour
    // - cm - absorber les erreurs "layer not found" apres un setStyle rapide.
    if (this._Map.getLayer(lIconLayerId))
    {
      try { this._Map.removeLayer(lIconLayerId); } catch { /* ignore */ }
    }
    if (this._Map.getLayer(lLayerId))
    {
      try { this._Map.removeLayer(lLayerId); } catch { /* ignore */ }
    }
    if (this._Map.getSource(lSourceId))
    {
      try { this._Map.removeSource(lSourceId); } catch { /* ignore */ }
    }

    // - cm - Réindexe les markers par clé (DataId ou fallback lng,lat) pour
    // - cm - permettre la récupération du DTO complet au clic malgré la
    // - cm - sérialisation JSON des properties Mapbox.
    this._MarkersById.clear();
    this.Markers.forEach((m: IMapMarker) =>
    {
      const lKey: string = m.DataId !== undefined && m.DataId !== null
        ? String(m.DataId)
        : `${m.Lng},${m.Lat}`;
      this._MarkersById.set(lKey, m);
    });

    // 1. Build GeoJSON
    const geojson: any = {
      type: 'FeatureCollection',
      features: this.Markers.map(m =>
      {
        const lType: string = m.Type ?? 'default';
        const lColor: string = this.ResolveCssColor(m.Color ?? '#9c27b0');
        const lImageId: string = `sm-marker-${lType}-${lColor.replace(/[^a-z0-9]/gi, '')}`;
        return {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [m.Lng, m.Lat] },
          properties: {
            title: m.Title ?? '',
            subtitle: m.Subtitle ?? '',
            popup: m.Popup ?? '',
            color: this.resolveColor(m.Color ?? 'var(--sm-primary, #9c27b0)'),
            icon: m.Icon ?? '',
            type: lType,
            iconImage: lImageId,
            // - cm - Identifiant sérialisable du marker. Mapbox désérialise les
            // - cm - properties du GeoJSON au clic, donc on ne peut pas garder
            // - cm - une référence directe à l'objet. On stocke uniquement l'ID et
            // - cm - on retrouve le marker complet via `_MarkersById.get(id)` dans
            // - cm - le handler de clic.
            id: m.DataId !== undefined && m.DataId !== null ? String(m.DataId) : `${m.Lng},${m.Lat}`
          }
        };
      })
    };

    // 2. Update or Create Source
    if (this._Map.getSource(lSourceId))
    {
      (this._Map.getSource(lSourceId) as mapboxgl.GeoJSONSource).setData(geojson);
    } else
    {
      this._Map.addSource(lSourceId, { type: 'geojson', data: geojson });
    }

    // 3. Create or Update Layer
    if (!this._Map.getLayer(lLayerId))
    {
      this._Map.addLayer({
        id: lLayerId,
        type: 'circle',
        source: lSourceId,
        paint: {
          // - cm - Halo blanc extérieur (transparent pour voir l'image par-dessus)
          'circle-radius': [
            'interpolate', ['linear'], ['zoom'],
            4, 10,
            8, 14,
            12, 18,
            16, 22
          ],
          'circle-color': '#ffffff',
          'circle-stroke-width': 0,
          'circle-opacity': 0.85
        }
      });
    }

    // - cm - Génère une image PNG par type (Property/Transaction/Location)
    // - cm - avec l'icône Material et la couleur du marker. Mapbox Standard
    // - cm - ne fournit pas de glyphs/fonts, donc on génère une image à la
    // - cm - volée via Canvas2D qu'on charge comme sprite.
    const iconLayerId = 'sm-markers-icon-layer';
    if (!this._Map.getLayer(lIconLayerId) && this._Map.getLayer(lLayerId))
    {
      try
      {
        // - cm - Charge dans le sprite Mapbox une image par combinaison
        // - cm - (type + couleur) si pas déjà présente. On n'écrase PAS
        // - cm - `m.DataId` (qui sert pour retrouver le DTO au clic).
        this.Markers.forEach((m: IMapMarker) =>
        {
          const lType: string = m.Type ?? 'default';
          const lColor: string = this.ResolveCssColor(m.Color ?? '#9c27b0');
          const lImageId: string = `sm-marker-${lType}-${lColor.replace(/[^a-z0-9]/gi, '')}`;
          if (!this._Map!.hasImage(lImageId))
          {
            this._Map!.addImage(lImageId, this.CreateMarkerIconData(lType, lColor), { sdf: false });
          }
        });

        // - cm - Layer symbol : utilise l'image du feature via `icon-image`
        // - cm - avec match-case sur la propriété `iconImage`. L'image fait 28px
        // - cm - en canvas (2x DPR) ; on l'affiche à 80% pour matcher le cercle.
        this._Map.addLayer({
          id: lIconLayerId,
          type: 'symbol',
          source: lSourceId,
          layout: {
            'icon-image': ['coalesce', ['get', 'iconImage'], 'sm-marker-default-9c27b0'],
            'icon-size': [
              'interpolate', ['linear'], ['zoom'],
              4, 0.6,
              8, 0.8,
              12, 1.0,
              16, 1.2
            ],
            'icon-allow-overlap': true,
            'icon-ignore-placement': true
          }
        });
      }
      catch (pErr)
      {
        // - cm - Si addImage/symbol échoue (rare), on garde juste le cercle.
        console.warn('[MapCard] Layer icône indisponible :', pErr);
      }
    }

    // 4. CLEANUP CLICK EVENTS TO PREVENT LEAKS
    // Remove any existing click listeners on this layer before adding a new one
    this._Map.off('click', lLayerId, this._handleMapClick);

    // Attach the new click listener
    this._Map.on('click', lLayerId, this._handleMapClick);

    // Optional: Change cursor to pointer on hover
    this._Map.on('mouseenter', lLayerId, () => { this._Map.getCanvas().style.cursor = 'pointer'; });
    this._Map.on('mouseleave', lLayerId, () => { this._Map.getCanvas().style.cursor = ''; });

    // 6. Fit Bounds
    if (this.FitBounds && this.Markers.length > 1)
    {
      const bounds = new this._MapboxModule.LngLatBounds();
      this.Markers.forEach(m => bounds.extend([m.Lng, m.Lat]));
      this._Map.fitBounds(bounds, { padding: this.FitBoundsPadding, maxZoom: this.MaxFitZoom });
    } else if (this.Markers.length === 1)
    {
      this._Map.setCenter([this.Markers[0].Lng, this.Markers[0].Lat]);
      this._Map.setZoom(this.Zoom);
    }
  }

  private _handleMapClick = (e: any) =>
  {
    const feature = e.features[0];
    if (!feature) return;

    const props = feature.properties;
    const coords = feature.geometry.coordinates;
    const lLng: number = coords[0];
    const lLat: number = coords[1];

    // - cm - Récupère le marker complet (DTO inclus) via son ID sérialisé.
    // - cm - L'index `_MarkersById` est reconstruit à chaque `RenderMarkers()`.
    // - cm - On tente d'abord par l'ID ; en fallback on matche par coordonnées
    // - cm - pour gérer les markers sans `DataId`.
    const lId: string | undefined = props.id ? String(props.id) : undefined;
    let lRawMarker: IMapMarker | undefined = lId ? this._MarkersById.get(lId) : undefined;
    if (!lRawMarker)
    {
      lRawMarker = this.Markers.find((pM: IMapMarker): boolean =>
        Math.abs(pM.Lng - lLng) < 1e-6 && Math.abs(pM.Lat - lLat) < 1e-6
      );
    }

    const lMarker: IMapMarker = lRawMarker ?? {
      Lat: lLat,
      Lng: lLng,
      Title: props.title,
      Subtitle: props.subtitle,
      Popup: props.popup,
      Color: props.color,
      Icon: props.icon,
      Type: props.type
    };

    // - cm - Émet l'event pour que le parent affiche son popup custom (grille, etc.).
    // - cm - Le map-card ne gère plus de popup interne.
    this.MarkerClick.emit(lMarker);
  };

  private resolveColor(color: string): string
  {
    if (!color) return '#9c27b0'; // fallback
    if (color.startsWith('var('))
    {
      const match = color.match(/var\(([^,)]+)/);
      if (match)
      {
        const varName = match[1].trim();
        const val = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
        return val || '#9c27b0';
      }
    }
    return color;
  }

  /**
   * Réinitialise la carte au centre et zoom initiaux via `map.flyTo()`.
   * Cf. step 6 du tutorial Mapbox Angular.
   */
  public ResetView(): void
  {
    if (this._Map)
    {
      this._Map.flyTo({
        center: [this.CenterLng, this.CenterLat],
        zoom: this.Zoom,
        essential: true
      });
    }
  }

  /**
   * Change le style de carte au clic sur une option du sélecteur.
   * @param pStyle Le nouveau style
   */
  public OnStyleChange(pStyle: EMapStyle): void
  {
    if (pStyle === this.Style)
    {
      return;
    }
    this._ExternalStyleSet = true;
    this.ApplyStyleChange(pStyle);
  }

  /**
   * Applique un changement de style sans early-return (utilisé en interne par
   * OnStyleChange et par ngOnChanges quand la nouvelle valeur arrive via
   * binding [Style]). On force la MAJ de this.Style + setStyle + event.
   * - cm - Cette méthode est la seule qui appelle setStyle. OnStyleChange et
   * - cm - ngOnChanges l'utilisent comme chokepoint pour eviter la divergence
   * - cm - (cf. consigne projet "Fallbacks/defaults are contracts — extend
   * - cm - the mechanism, don't copy it").
   * @param pStyle Le nouveau style à appliquer
   */
  private ApplyStyleChange(pStyle: EMapStyle): void
  {
    this.Style = pStyle;

    // - cm - Trace : setStyle detruit les sources/layers custom, le listener
    // - cm - style.load les reattache via RenderMarkers (cf. InitMap).
    console.log('[MapCard] style changed to:', pStyle);

    if (this._Map)
    {
      // - cm - Mapbox GL setStyle() accepte une URL `mapbox://styles/...` directement.
      this._Map.setStyle(this._MapboxProxy.GetStyleSpecUrl(MapCardComponent.MapboxStyleIds[pStyle]));

      // - cm - Re-render FORCE des markers apres setStyle
      this.RenderMarkers();
    }

    this.StyleChange.emit(pStyle);
    this.PostHog.Capture('map_style_changed', { style: pStyle, component: this.Name });
  }

  //#endregion

  //#region Methods - API publique

  /**
   * Met à jour les marqueurs depuis l'extérieur et rafraîchit la carte.
   * @param pMarkers La nouvelle liste de marqueurs
   */
  public UpdateMarkers(pMarkers: IMapMarker[]): void
  {
    this.Markers = pMarkers;
    if (this._Map)
    {
      this.RenderMarkers();
    }
  }

  /**
   * Recalcule la taille de la carte (utile après affichage dans un conteneur caché/onglet).
   */
  public InvalidateSize(): void
  {
    this._Map?.resize();
  }

  //#endregion

  //#region Methods - Toolbar

  /**
   * Zoom avant d'un niveau via `map.zoomIn()` avec animation douce.
   */
  public ZoomIn(): void
  {
    if (!this._Map) { return; }
    this._Map.easeTo({ zoom: (this._Map.getZoom() ?? 0) + 1, duration: 250 });
  }

  /**
   * Zoom arrière d'un niveau via `map.zoomOut()` avec animation douce.
   */
  public ZoomOut(): void
  {
    if (!this._Map) { return; }
    this._Map.easeTo({ zoom: (this._Map.getZoom() ?? 0) - 1, duration: 250 });
  }

  /**
   * Bascule entre la vue 2D (pitch=0) et la vue 3D (pitch=60°).
   * Met à jour `Is3DEnabled` (signal).
   */
  public Toggle3D(): void
  {
    if (!this._Map) { return; }
    const lWas3D: boolean = (this._Map.getPitch() ?? 0) > 5;
    this._Map.easeTo({ pitch: lWas3D ? 0 : 60, duration: 400 });
    this.Is3DEnabled.set(!lWas3D);
    this.PostHog.Capture('map_3d_toggled', { enabled: !lWas3D, component: this.Name });
  }

  /**
   * Bascule l'affichage des bâtiments 3D sur la carte.
   * Met à jour `Show3DBuildings` (signal) et applique via `Set3DBuildingsEnabled`.
   * Fonctionne sur tous les styles : Mapbox Standard (via `setConfigProperty`) et
   * styles classiques (via layer `fill-extrusion` sur source 'composite').
   */
  public Toggle3DBuildings(): void
  {
    const lNext: boolean = !this.Show3DBuildings();
    console.log('[MapCard 3D] Toggle3DBuildings: from', this.Show3DBuildings(), 'to', lNext);
    this.Set3DBuildingsEnabled(lNext);
    this.PostHog.Capture('map_3d_buildings_toggled', { enabled: lNext, component: this.Name });
  }

  /**
   * Réinitialise la rotation (bearing) à 0° (nord en haut).
   * Met à jour `CompassBearing` (signal).
   */
  public ResetBearing(): void
  {
    if (!this._Map) { return; }
    this._Map.easeTo({ bearing: 0, duration: 400 });
    this.CompassBearing.set(0);
  }

  /**
   * Bascule le plein écran sur le CONTAINER (carte + toolbar), pas juste la carte.
   * Comme ça la toolbar gauche/droite reste visible au-dessus de la carte en fullscreen.
   * Utilise l'API Fullscreen standard (`requestFullscreen` / `exitFullscreen`).
   * Met à jour `IsFullscreen` (signal).
   */
  public ToggleFullscreen(): void
  {
    if (!this._IsBrowser) { return; }
    // - cm - parentElement de la div MapContainer = .map-card__map-container
    // - cm - qui contient la carte ET les toolbars gauche/droite.
    const lContainer: HTMLDivElement | null = (this._MapContainer?.nativeElement?.parentElement as HTMLDivElement | null) ?? null;
    if (!lContainer) { return; }
    if (document.fullscreenElement === lContainer)
    {
      void document.exitFullscreen();
    }
    else
    {
      void lContainer.requestFullscreen();
    }
  }

  /**
   * Replie/deplie la toolbar de navigation (gauche : zoom, 3D, compass).
   * Permet de masquer les outils de camera quand on veut maximiser la carte.
   */
  public ToggleLeftToolbar(): void
  {
    this.LeftToolbarCollapsed.update((v) => !v);
  }

  /**
   * Replie/deplie la toolbar d'affichage (droite : styles + fullscreen).
   * Permet de masquer les boutons de style quand on veut maximiser la carte.
   */
  public ToggleRightToolbar(): void
  {
    this.RightToolbarCollapsed.update((v) => !v);
  }

  /**
   * Replie/deplie la toolbar light-modes (centre-gauche : 4 modes Dawn/Day/Dusk/Night).
   */
  public ToggleLightModeToolbar(): void
  {
    this.LightModeToolbarCollapsed.update((v) => !v);
  }

  /**
   * Cycle entre les 4 préréglages d'éclairage Mapbox Standard (Dawn -> Day -> Dusk -> Night -> Dawn).
   * Raccourci clavier : T.
   */
  public CycleLightMode(): void
  {
    const lAll: EMapLightMode[] = [
      EMapLightMode.Dawn, EMapLightMode.Day, EMapLightMode.Dusk, EMapLightMode.Night
    ];
    const lCurrent: number = lAll.indexOf(this.CurrentLightMode());
    const lNextIndex: number = lCurrent < 0 ? 1 : (lCurrent + 1) % lAll.length;
    const lNext: EMapLightMode = lAll[lNextIndex];
    this.SetLightMode(lNext);
    this.PostHog.Capture('map_light_mode_changed', { mode: lNext, component: this.Name });
  }

  /**
   * Définit un préréglage d'éclairage Mapbox Standard. On applique simultanément
   * le `lightPreset` (éclairage ambiant/directionnel) et le `theme` (palette globale)
   * via `setConfigProperty` (cf. https://docs.mapbox.com/map-styles/guides/standard-styles/).
   * @param pMode Le preset à appliquer (Default/Dawn/Day/Dusk/Night)
   */
  public SetLightMode(pMode: EMapLightMode): void
  {
    this.CurrentLightMode.set(pMode);
    this.IsDarkTheme.set(pMode === EMapLightMode.Night || pMode === EMapLightMode.Dusk);
    if (!this._Map) { return; }

    const lStyle: string = JSON.stringify(this._Map.getStyle() ?? {});
    const lIsStandard: boolean = lStyle.includes('mapbox/standard') || lStyle.includes('standard-satellite');
    const lApply: () => void = () =>
    {
      if (!this._Map) { return; }
      if (typeof this._Map.setConfigProperty !== 'function')
      {
        return;
      }
      this._Map.setConfigProperty('basemap', 'lightPreset', MapCardComponent.LightPresetValues[pMode]);
      this._Map.setConfigProperty('basemap', 'theme', MapCardComponent.ThemeValues[pMode]);
      // - cm - Force le re-render des markers apres un changement de lightPreset
      this.RenderMarkers();
    };

    if (!lIsStandard)
    {
      this.OnStyleChange(EMapStyle.Streets);
      this._Map.once('style.load', lApply);
    }
    else
    {
      lApply();
    }
  }

  //#endregion

  //#region Methods - Attributions

  /**
   * Bascule l'affichage du popover des attributions au clic sur le bouton info.
   */
  public OnToggleAttributions(): void
  {
    const lNext: boolean = !this.ShowAttributions();
    this.ShowAttributions.set(lNext);
    this.PostHog.Capture('map_attributions_toggled', { open: lNext, style: this.Style, component: this.Name });
  }

  /**
   * Ferme explicitement le popover des attributions (croix dans l'en-tête).
   */
  public OnCloseAttributions(): void
  {
    if (!this.ShowAttributions())
    {
      return;
    }
    this.ShowAttributions.set(false);
    this.PostHog.Capture('map_attributions_toggled', { open: false, style: this.Style, component: this.Name });
  }

  //#endregion
}
