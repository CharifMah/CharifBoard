/**
 * Types de marqueurs prédéfinis avec icônes et couleurs par défaut.
 */

export enum EMarkerType {
    Default = 'default',
    Property = 'property',
    Transaction = 'transaction',
    Contact = 'contact',
    Location = 'location',
    Objectif = 'objectif',
    Tache = 'tache'
}
