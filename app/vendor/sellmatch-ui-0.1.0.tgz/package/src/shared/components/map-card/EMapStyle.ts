/**
 * Énumération des styles de carte disponibles (Mapbox Studio custom).
 * Les identifiants correspondent aux styles créés dans Mapbox Studio sous
 * le compte `adminsellmatch` et consommés via `mapbox://styles/<owner>/<styleId>`.
 * Pour récupérer un nouveau styleId : Mapbox Studio → Share → Settings → "Style URL"
 * → copier l'ID après `/styles/`.
 */

export enum EMapStyle {
    /** Style principal (Streets / Standard). */
    Streets = 'streets',
    /** Variante claire. */
    Light = 'light',
    /** Variante sombre. */
    Dark = 'dark',
    /** Vue satellite (avec rues superposées). */
    Satellite = 'satellite',
    /** Relief / terrain. */
    Terrain = 'terrain',
    /** Plein air / outdoor. */
    Outdoors = 'outdoors',
    /** Vue navigation (jour). */
    Navigation = 'navigation'
}
