
import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../../core/base/BaseComponent';
import { ScrollRevealDirective } from '../../../../shared/directives/TextRevealDirective';

/**
 * Variante visuelle du header de dashboard.
 * - `default` : layout standard (icône à gauche + texte).
 * - `compact` : sans icône, marges réduites.
 * - `hero`    : plus grand, espacement vertical augmenté, bordure inférieure décorative.
 */
export type EDashboardHeaderVariant = 'default' | 'compact' | 'hero';

/**
 * Couleur d'accent disponible pour le badge.
 */
export type EDashboardHeaderAccent = 'primary' | 'success' | 'warning' | 'info';

@Component({
  selector: 'app-dashboard-header',
  standalone: true,
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [ScrollRevealDirective]
})
export class DashboardHeaderComponent extends BaseComponent
{
  //#region Inputs

  /**
   * Titre principal affiché dans le header.
   * Affiché seul, sans concaténation avec le nom de l'utilisateur.
   * @default ''
   * @example [title]="'Biens'"
   */
  @Input() title = '';

  /**
   * Sous-titre affiché sous le titre.
   * Optionnel. Si vide, le sous-titre n'est pas rendu.
   * @default ''
   * @example [subtitle]="'Gérez votre portefeuille de biens immobiliers'"
   */
  @Input() subtitle = '';

  /**
   * Ligne de description optionnelle, affichée en italique/petit sous le subtitle.
   * Sert pour un message contextuel plus discret.
   * @default null
   * @example [description]="'Astuce : utilisez les filtres pour affiner votre recherche'"
   */
  @Input() description: string | null = null;

  /**
   * Icône Material affichée à gauche du bloc texte.
   * - Si `null` ou chaîne vide, le bloc icône est masqué (utile pour `variant='compact'`).
   * - Si non fournie, l'icône par défaut `waving_hand` est utilisée.
   * @default null
   * @example [icon]="'apartment'"
   */
  @Input() icon: string | null = null;

  /**
   * Badge optionnel affiché à droite du titre (ex. "Nouveau", "Beta").
   * @default null
   * @example [badge]="'Nouveau'"
   */
  @Input() badge: string | null = null;

  /**
   * Couleur d'accent du badge.
   * Si non fournie, la valeur par défaut `primary` est utilisée.
   * @default null (résolu en `'primary'` côté template)
   * @example [accentColor]="'success'"
   */
  @Input() accentColor: EDashboardHeaderAccent | null = null;

  /**
   * Variante visuelle du header.
   * - `default` : layout standard avec icône.
   * - `compact` : sans icône, marges réduites.
   * - `hero`    : mise en avant avec bordure décorative inférieure.
   * @default 'default'
   * @example [variant]="'hero'"
   */
  @Input() variant: EDashboardHeaderVariant = 'default';

  /**
   * Active un préfixe de salutation ("Bienvenue") devant le titre.
   * Utilisé sur les pages d'accueil (ex. `home-pro`, `home-vendeur`).
   * Par défaut `false` : aucune concaténation forcée avec le nom utilisateur.
   * @default false
   * @example [showGreeting]="true"
   */
  @Input() showGreeting = false;

  //#endregion

  //#region Methods

  /**
   * Couleur d'accent effective pour le badge (fallback `'primary'`).
   * @returns La couleur d'accent résolue
   */
  public getBadgeAccent(): EDashboardHeaderAccent
  {
    return this.accentColor ?? 'primary';
  }

  /**
   * Préfixe de salutation utilisé quand `showGreeting` est à `true`.
   * @returns Le préfixe de salutation ou une chaîne vide
   */
  public getGreetingPrefix(): string
  {
    return this.showGreeting ? 'Bienvenue' : '';
  }

  //#endregion
}
