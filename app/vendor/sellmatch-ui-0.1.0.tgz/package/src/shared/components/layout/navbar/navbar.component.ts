import { Component, inject, ChangeDetectionStrategy, DestroyRef, computed } from '@angular/core';
import { RouterModule, Router, NavigationEnd } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs';

import { BaseComponent } from '../../../../core/base/BaseComponent';
import { ROUTE_PATHS, RoutePath } from '../../../../routes/app.routes.constants';
import { ImageComponent } from '../../../../shared/components/image/image.component';
import { ButtonComponent } from '../../../../shared/components/button/button.component';
import { LanguageSelectorComponent } from '../../../../shared/components/language-selector/language-selector.component';
import { PopupSupportComponent } from '../../../../components/popup-support/popup-support.component';
import { ThemeService } from '../../../../core/services/theme/ThemeService';

interface INavItem
{
  /** Cle de traduction i18n (ex: 'navbar.howItWorks'). */
  TranslationKey: string;
  route: RoutePath;
  exact: boolean;
}

interface INavItemResolved
{
  /** Label traduit (recalcule a chaque changement de langue). */
  label: string;
  route: RoutePath;
  exact: boolean;
}

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, ImageComponent, ButtonComponent, LanguageSelectorComponent, PopupSupportComponent],
  templateUrl: './navbar.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent extends BaseComponent
{
  readonly routes = ROUTE_PATHS;
  public readonly Theme: ThemeService = inject(ThemeService);

  /** Indique si le popup de support local est ouvert (menu hamburger). */
  public ShowSupport: boolean = false;

  /**
   * Items de navigation declaratifs : on stocke la cle i18n et on derive le label
   * via `SyncTranslations()` appele au changement de langue.
   */
  private readonly _NavItemKeys: INavItem[] = [
    { TranslationKey: 'navbar.howItWorks', route: ROUTE_PATHS.VENDEUR, exact: false },
    { TranslationKey: 'navbar.estimation', route: ROUTE_PATHS.OUTILESTIMATION, exact: false },
    { TranslationKey: 'navbar.pricing', route: ROUTE_PATHS.PRICING, exact: false },
    { TranslationKey: 'navbar.blog', route: ROUTE_PATHS.BLOG, exact: false },
    { TranslationKey: 'navbar.faq', route: ROUTE_PATHS.FAQ, exact: false },
    { TranslationKey: 'navbar.contact', route: ROUTE_PATHS.CONTACT, exact: false },
  ];

  //#region Labels i18n (computed réactifs sur InstantTick)

  /**
   * - cm - Computed branchés sur Translate.InstantTick : chaque lecture appelle
   * d'abord `this.Translate.InstantTick()` pour s'abonner au tick. Quand le JSON
   * i18n finit de charger (ou que la langue change), InstantiateTick s'incrémente,
   * ce qui invalide le computed → Angular recalcule le label au prochain cycle.
   * Cela résout le timing : la navbar (layout, construite AVANT la fin du chargement
   * i18n) se met à jour dès que le dictionnaire arrive, sans souscription manuelle.
   * Pas de NG0600 : InstantTick est un signal Angular distinct des signaux internes
   * de ngx-translate (on n'écrit jamais dans un signal ngx depuis le computed).
   */
  private TranslateKey(pKey: string): string
  {
    this.Translate.InstantTick(); // - cm - Abonnement réactif au tick
    return this.Translate.translate(pKey);
  }

  public readonly navItems = computed<INavItemResolved[]>(() =>
    this._NavItemKeys.map((pItem) => ({
      label: this.TranslateKey(pItem.TranslationKey),
      route: pItem.route,
      exact: pItem.exact
    }))
  );

  public readonly DashboardLabel = computed<string>(() => this.TranslateKey('navbar.dashboard'));
  public readonly CrmLabel = computed<string>(() => this.TranslateKey('navbar.crm'));
  public readonly DashboardProLabel = computed<string>(() => this.TranslateKey('navbar.dashboardPro'));
  public readonly DashboardVendeurLabel = computed<string>(() => this.TranslateKey('navbar.dashboardVendeur'));
  public readonly PlaygroundLabel = computed<string>(() => this.TranslateKey('navbar.playground'));
  public readonly SupportLabel = computed<string>(() => this.TranslateKey('navbar.support'));
  public readonly ThemeAriaLabel = computed<string>(() => this.TranslateKey(this.Theme.IsDark ? 'navbar.themeLight' : 'navbar.themeDark'));
  public readonly VendeursLabel = computed<string>(() => this.TranslateKey('navbar.vendeurs'));
  public readonly ProfessionnelsLabel = computed<string>(() => this.TranslateKey('navbar.professionnels'));
  public readonly LogoutLabel = computed<string>(() => this.TranslateKey('navbar.logout'));
  public readonly ChangeLanguageLabel = computed<string>(() => this.TranslateKey('navbar.changeLanguage'));

  //#endregion

  isMenuOpen = false;

  private readonly _Router: Router = inject(Router);

  constructor ()
  {
    super();

    // - cm - Ferme le menu hamburger a chaque changement de route reussi
    this._Router.events.pipe(
      filter((pEvent): pEvent is NavigationEnd => pEvent instanceof NavigationEnd),
      takeUntilDestroyed(inject(DestroyRef))
    ).subscribe(() => this.closeMenu());
  }

  toggleMenu(): void
  {
    this.isMenuOpen = !this.isMenuOpen;
    this.SyncBodyScrollLock();
    this.PostHog.Capture(this.BuildTrackingName(this.isMenuOpen ? 'navbar_menu_ouvert' : 'navbar_menu_ferme', 'tracking'));
  }

  closeMenu(): void
  {
    this.isMenuOpen = false;
    this.SyncBodyScrollLock();
  }

  // - cm - Bascule la classe body.menu-open pour bloquer le scroll arrière-plan sur mobile
  private SyncBodyScrollLock(): void
  {
    if (typeof document === 'undefined') { return; }
    document.body.classList.toggle('menu-open', this.isMenuOpen);
  }

  /**
   * Ouvre le popup de support depuis le menu hamburger et ferme le menu.
   */
  public OnSupportClick(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('navbar_support', 'tracking'));
    this.closeMenu();
    this.ShowSupport = true;
  }

  onLogout(): void
  {
    this.closeMenu();
    this.PostHog.Capture(this.BuildTrackingName('navbar_deconnexion', 'tracking'));
    this.UsersService.logout();
  }

  /**
   * Bascule entre le thème clair et sombre.
   */
  public ToggleTheme(): void
  {
    this.Theme.Toggle();
    // - cm - ThemeAriaLabel est un computed qui dépend déjà de Theme.IsDark
    // (signal). Il se recalcule automatiquement — pas de .set() manuel.
    this.PostHog.Capture(this.BuildTrackingName(this.Theme.IsDark ? 'theme_dark' : 'theme_light', 'tracking'));
  }

  getDashboardRoute(): string
  {
    if (this.UsersService.IsProfessionnel() || this.UsersService.isAdmin())
    {
      return this.RouteUtils.GetRoute(ROUTE_PATHS.DASHBOARD_PRO);
    }
    return this.RouteUtils.GetRoute(ROUTE_PATHS.DASHBOARD_VENDEUR);
  }
}
