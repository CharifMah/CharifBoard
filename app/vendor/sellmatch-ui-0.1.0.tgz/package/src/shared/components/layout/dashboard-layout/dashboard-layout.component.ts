// dashboard-layout.component.ts
import { Component, Input, Output, EventEmitter, ContentChild, TemplateRef, ChangeDetectionStrategy, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BaseComponent } from '../../../../core/base/BaseComponent';
import { SidebarComponent, MenuItem } from '../sidebar/sidebar.component';
import { ButtonComponent } from '../../button/button.component';
import { SplitterComponent } from '../../../../shared/components/Splitter/splitter.component';
import { SidebarStats } from '../../../../core/states/pro-state/pro-state.service';


@Component({
  selector: 'app-dashboard-layout',
  standalone: true,
  imports: [SidebarComponent, SplitterComponent, CommonModule],
  templateUrl: './dashboard-layout.component.html',
  changeDetection: ChangeDetectionStrategy.Default,
  styleUrls: ['./dashboard-layout.component.scss']
})
export class DashboardLayoutComponent extends BaseComponent implements OnInit
{
  @Input() title: string = '';
  @Input() subtitle: string = '';
  @Input() extraMenuItems: MenuItem[] = [];
  @Input() activeView: string = '';
  @Input() stats: SidebarStats = {
    DossiersEnCours: 0,
    DossiersHistorique: 0,
    TotalCandidatures: 0,
    ChiffreAffaires: 0,
    TauxConversion: 0,
    MandatsActifs: 0
  };

  /** Active le redimensionnement du sidebar par le splitter (mode desktop uniquement). */
  @Input() resizableSidebar: boolean = false;

  /**
   * Affiche les items de base (Messages) dans la sidebar.
   * Default true. Le CRM passe false pour ne pas afficher Messages dans son shell
   * (le CRM a son propre menu custom et le chat agent est exposé via 'chat-ia').
   * @default true
   */
  @Input() showBaseMenuItems: boolean = true;

  /** Indique si le viewport est sous le breakpoint tablette (le splitter est alors désactivé). */
  public IsBelowTablet: boolean = false;

  @Output() viewChanged = new EventEmitter<string>();
  @Output() supportClicked = new EventEmitter<void>();

  // Récupère le contenu avec l'attribut sidebar-button
  @ContentChild('sidebarButton', { static: false }) sidebarButtonTemplate?: TemplateRef<ButtonComponent>;

  /**
   * Items de menu ajoutes par defaut a toutes les sous-classes.
   * - cm - Virtual pour permettre aux sous-classes de surcharger la liste
   * (ex. CRM qui ne veut pas afficher "Messages").
   * @returns Le tableau d'items de base a inserer dans le menu.
   */
  protected getBaseMenuItems(): MenuItem[] {
    return [
      { Label: 'Messages', View: 'messages', icon: 'chat' }
    ];
  }

  constructor ()
  {
    super();
  }

  //#region Lifecycle
  /** @inheritdoc */
  public ngOnInit(): void
  {
    this._CheckViewport();
  }

  /** Met à jour l'état tablette au redimensionnement de la fenêtre. */
  @HostListener('window:resize')
  public OnResize(): void
  {
    this._CheckViewport();
  }
  //#endregion

  //#region Private Methods
  /**
   * Détermine si le viewport est sous le breakpoint tablette.
   */
  private _CheckViewport(): void
  {
    this.IsBelowTablet = typeof window !== 'undefined' && window.innerWidth <= 1200;
  }
  //#endregion

  get menuItems(): MenuItem[]
  {
    const items = [...this.extraMenuItems];
    // - cm - Les items de base (par défaut "Messages") ne s'affichent que si
    // showBaseMenuItems est true. Le CRM passe showBaseMenuItems=false pour
    // ne pas afficher "Messages" dans son shell (l'item chat-ia le remplace).
    const baseItems: MenuItem[] = this.showBaseMenuItems ? this.getBaseMenuItems() : [];
    const profilIndex = items.findIndex(item => item.View === 'profil');

    if (profilIndex !== -1)
    {
      // Insère les items de base avant le profil
      items.splice(profilIndex, 0, ...baseItems);
    } else
    {
      // Ajoute les items de base à la fin
      items.push(...baseItems);
    }

    return items;
  }

  onViewChanged(view: string): void
  {
    this.viewChanged.emit(view);
  }

  onSupportClicked(): void
  {
    this.supportClicked.emit();
  }
}
