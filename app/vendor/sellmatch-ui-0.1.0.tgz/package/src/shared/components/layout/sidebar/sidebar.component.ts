import { Component, Input, Output, EventEmitter, TemplateRef, AfterViewInit, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslatePipe } from '@ngx-translate/core';
import { BaseComponent } from '../../../../core/base/BaseComponent';
import { QuickStatsComponent } from '../../../../components/quick-stats/quick-stats.component';
import { ButtonComponent } from '../../button/button.component';
import { AvatarComponent } from '../../Avatar/avatar.component';
import { SidebarStats } from '../../../../core/states/pro-state/pro-state.service';

export interface MenuItem {
  icon?: string;
  /** Libellé déjà traduit à fournir si pas de clé i18n disponible (legacy / fallback). */
  Label?: string;
  /** Clé i18n (ex: "crm-layout.menu.dashboard"). Si fournie, le template la traduit via le pipe translate en priorité sur `Label`. */
  LabelCle?: string;
  View: string;
  badge?: number;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, QuickStatsComponent, ButtonComponent, AvatarComponent, TranslatePipe],
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent extends BaseComponent implements AfterViewInit, OnDestroy {
  @Input() showUserProfil: boolean = true;
  @Input() agencyName: string = '';
  @Input() Items: MenuItem[] = [];
  @Input() Stats: SidebarStats = {
    DossiersEnCours: 0,
    DossiersHistorique: 0,
    TotalCandidatures: 0,
    ChiffreAffaires: 0,
    TauxConversion: 0,
    MandatsActifs:0
  };
  @Input() activeSection: string = 'dashboard';

  @Output() newDossierClicked = new EventEmitter<void>();
  @Output() supportClicked = new EventEmitter<void>();
  @Output() sectionChanged = new EventEmitter<string>();
  @Input() customButtonTemplate?: TemplateRef<BaseComponent>;

  private _WidgetInitialized: boolean = false;

  constructor() {
    super();
  }

  /**
   * Tracke le clic sur le bouton nouveau dossier.
   */
  public OnNewDossierClick(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('sidebar_nouveau_dossier', 'tracking'));
    this.newDossierClicked.emit();
  }

  /**
   * Tracke le clic sur le bouton support.
   */
  public OnSupportClick(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('sidebar_support', 'tracking'));
    this.supportClicked.emit();
  }

  //#region Lifecycle
  ngAfterViewInit(): void {
    this._InitImmodvisorWidget();
  }

  ngOnDestroy(): void {
    this._WidgetInitialized = false;
  }
  //#endregion

  //#region Private Methods
  private _InitImmodvisorWidget(): void {
    if (this._WidgetInitialized || !this.IsProfessionnel || !this.UsersService.currentUser?.immodvisorApiKey) {
      return;
    }

    setTimeout(() => {
      const lImdw = (window as any).imdw;
      if (lImdw?.run) {
        lImdw.run();
        this._WidgetInitialized = true;
      }
    }, 100);
  }
  //#endregion

  //#region Public Methods
  public getDefaultMenuItems(): MenuItem[] {
    return [
      {
        View: 'dashboard',
        icon: 'dashboard',
        Label: 'Tableau de bord'
      },
      {
        View: 'dossiers',
        icon: 'folder_open',
        Label: 'Mes dossiers',
        badge: this.Stats.DossiersEnCours
      },
      {
        View: 'candidats',
        icon: 'people',
        Label: 'Candidatures',
        badge: this.Stats.TotalCandidatures
      },
      {
        View: 'historique',
        icon: 'history',
        Label: 'Historique'
      },
      {
        View: 'profil',
        icon: 'person',
        Label: 'Mon profil'
      }
    ];
  }

  public getMenuItems(): MenuItem[] {
    return this.Items.length > 0 ? this.Items : this.getDefaultMenuItems();
  }

  public onMenuItemClick(pItem: MenuItem): void {
    this.PostHog.Capture(this.BuildTrackingName('sidebar_navigation', 'tracking'), { section: pItem.View, libelle: pItem.Label });
    this.sectionChanged.emit(pItem.View);
  }

  public isActive(pItem: MenuItem): boolean {
    return this.activeSection === pItem.View;
  }
  //#endregion
}
