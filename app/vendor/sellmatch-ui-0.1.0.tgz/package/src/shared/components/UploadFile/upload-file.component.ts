import { Component, Input, Output, EventEmitter, inject, ChangeDetectionStrategy, ElementRef, ViewChild } from '@angular/core';
import { BaseComponent } from '../../../core/base/BaseComponent';

import { FormsModule } from '@angular/forms';
import { ButtonComponent } from '../button/button.component';
import { UploadService } from '../../../core/services/Upload/UploadService';

/**
 * Thème d'affichage du composant d'upload.
 */
type EUploadFileTheme = 'default' | 'compact-inline' | 'card-dropzone' | 'minimal-chip' | 'agent-message-dropzone';

export interface FileTypeConfig {
  type: string;
  label: string;
  extensions: string[];
  maxSize?: number; // en MB
  icon?: string;
}

export interface ImageProcessingOptions {
  convertToWebp?: boolean;
  resize?: {
    width?: number;
    height?: number;
    maintainAspectRatio?: boolean;
  };
  crop?: {
    enabled: boolean;
    aspectRatio?: number; // width/height
  };
}

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss'],
  standalone: true,
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [FormsModule, ButtonComponent]
})
export class UploadFileComponent extends BaseComponent {
  private uploadService: UploadService = inject(UploadService);

  @Input() label: string = 'Télécharger un fichier';
  @Input() showPreview: boolean = true;
  @Input() accept: string = '';
  @Input() autoUpload: boolean = true;

  @Input() fileTypes: FileTypeConfig[] = [
    {
      type: 'image',
      label: 'Image',
      extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
      maxSize: 5,
      icon: 'image'
    }
  ];

  @Input() selectedType: string = this.fileTypes.length > 0 ? this.fileTypes[0].type : '';

  /** Thème d'affichage de la zone d'upload. */
  @Input() theme: EUploadFileTheme = 'default';

  /** Indique si la zone dropzone est ouverte (thème minimal-chip). */
  public IsDropzoneOpen: boolean = false;

  // Options de traitement d'image
  @Input() imageProcessing: ImageProcessingOptions = {
    convertToWebp: true,
    resize: {
      width: 1200,
      height: 1200,
      maintainAspectRatio: true
    },
    crop: {
      enabled: false, // désactivé par défaut
      aspectRatio: 1 // carré par défaut
    }
  };

  @Output() fileSelected = new EventEmitter<File>();
  @Output() uploadError = new EventEmitter<string>();
  @Output() uploadSuccess = new EventEmitter<string>();
  @Output() processingComplete = new EventEmitter<File>();

  file: File | null = null;
  processedFile: File | null = null;
  dragOver: boolean = false;
  uploadProgress: number = 0;
  isUploading: boolean = false;
  isProcessing: boolean = false;
  previewUrl: string = '';

  /** Référence à l'input file caché. */
  @ViewChild('fileInput') private _FileInput?: ElementRef<HTMLInputElement>;

  // - cm - Contrôleur d'annulation de l'upload en cours
  private _UploadAbortController: AbortController | null = null;

  constructor() {
    super();
  }

  //#region Theme helpers
  /**
   * Indique si le thème actuel correspond à l'un des thèmes fournis.
   * @param pThemes Liste de thèmes à tester
   * @returns true si le thème courant est dans la liste
   */
  public IsTheme(...pThemes: EUploadFileTheme[]): boolean {
    return pThemes.includes(this.theme);
  }
  //#endregion

  get activeFileType(): FileTypeConfig | undefined {
    return this.fileTypes.find(type => type.type === this.selectedType);
  }

  get acceptedFileTypes(): string {
    if (this.accept) return this.accept;
    if (!this.activeFileType) return '';
    return '.' + this.activeFileType.extensions.join(',.');
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.handleFile(input.files[0]);
      // Réinitialiser le champ pour permettre de sélectionner le même fichier
      input.value = '';
    }
    this.PostHog.Capture(this.BuildTrackingName('upload_fichier_selectionne', 'tracking'));
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver = false;

    if (event.dataTransfer?.files && event.dataTransfer.files.length > 0) {
      this.handleFile(event.dataTransfer.files[0]);
    }

    this.PostHog.Capture(this.BuildTrackingName('upload_deposer', 'tracking'));
  }

  handleFile(file: File): void {
    // Nettoyage de l'état précédent
    this.clearFile();

    // Validation du type de fichier
    if (this.activeFileType) {
      const extension = this.getFileExtension(file.name).toLowerCase();
      if (!this.activeFileType.extensions.includes(extension)) {
        const validExtensions = this.activeFileType.extensions.join(', ');
        this.uploadError.emit(`Type de fichier non valide. Extensions autorisées: ${validExtensions}`);
        return;
      }

      // Validation de la taille
      const fileSizeMB = file.size / (1024 * 1024);
      if (this.activeFileType.maxSize && fileSizeMB > this.activeFileType.maxSize) {
        this.uploadError.emit(`Fichier trop volumineux. Taille maximum: ${this.activeFileType.maxSize} MB`);
        return;
      }
    }

    this.file = file;

    // Si c'est une image et qu'on a besoin de traitement (conversion WebP, redimensionnement)
    if (file.type.startsWith('image/')) {
      // Créer la prévisualisation
      this.createImagePreview(file);

      // Traiter l'image directement
      this.processImage(file);
    } else {
      // Si ce n'est pas une image, on continue normalement
      this.fileSelected.emit(file);

      if (this.autoUpload) {
        this.uploadFile();
      }
    }
  }

  /**
   * Crée une prévisualisation de l'image
   */
  private createImagePreview(file: File): void {
    if (this.showPreview) {
      this.previewUrl = URL.createObjectURL(file);
    }
  }

  /**
   * Traite l'image (redimensionnement et conversion WebP)
   */
  async processImage(file: File): Promise<void> {
    if (!file) return;

    this.isProcessing = true;

    try {
      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Impossible de charger l'image"));
        img.src = URL.createObjectURL(file);
      });

      // Redimensionner si nécessaire
      let width = img.width;
      let height = img.height;

      if (this.imageProcessing.resize) {
        const maxWidth = this.imageProcessing.resize.width;
        const maxHeight = this.imageProcessing.resize.height;
        const maintainRatio = this.imageProcessing.resize.maintainAspectRatio !== false;

        if (maxWidth && maxHeight) {
          if (maintainRatio) {
            if (img.width > img.height) {
              // Image horizontale
              if (img.width > maxWidth) {
                width = maxWidth;
                height = (img.height * maxWidth) / img.width;
              }
            } else {
              // Image verticale
              if (img.height > maxHeight) {
                height = maxHeight;
                width = (img.width * maxHeight) / img.height;
              }
            }
          } else {
            // Taille forcée sans maintenir le ratio
            width = maxWidth;
            height = maxHeight;
          }
        }
      }

      // Dessiner l'image redimensionnée
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error("Impossible de créer le contexte du canvas");

      ctx.drawImage(img, 0, 0, width, height);

      // Convertir en WebP si demandé
      const mimeType = this.imageProcessing.convertToWebp ? 'image/webp' : file.type;
      const quality = 0.85; // Qualité de 85% par défaut

      const blob = await new Promise<Blob | null>((resolve) => {
        canvas.toBlob(resolve, mimeType, quality);
      });

      if (!blob) throw new Error("Échec de la génération de l'image");

      // Créer un nouveau fichier avec l'extension appropriée
      let newFileName = file.name;
      if (this.imageProcessing.convertToWebp) {
        // Remplacer l'extension par .webp
        const baseName = file.name.substring(0, file.name.lastIndexOf('.'));
        newFileName = `${baseName}.webp`;
      }

      this.processedFile = new File([blob], newFileName, {
        type: mimeType,
        lastModified: new Date().getTime()
      });

      // Mettre à jour la prévisualisation
      if (this.showPreview) {
        URL.revokeObjectURL(this.previewUrl);
        this.previewUrl = URL.createObjectURL(this.processedFile);
      }

      // Émettre l'événement de fichier traité
      this.processingComplete.emit(this.processedFile);
      this.fileSelected.emit(this.processedFile);

      // Uploader automatiquement si nécessaire
      if (this.autoUpload) {
        this.uploadFile();
      }

    } catch (error: any) {
      console.error("Erreur lors du traitement de l'image:", error);
      this.uploadError.emit(error.message || "Échec du traitement de l'image");
    } finally {
      this.isProcessing = false;
    }
  }

  clearFile(): void {
    // Libérer l'URL de prévisualisation
    if (this.previewUrl) {
      URL.revokeObjectURL(this.previewUrl);
      this.previewUrl = '';
    }

    this.file = null;
    this.processedFile = null;
    this.uploadProgress = 0;
  }

  removeFile(): void {
    this.clearFile();
    this.fileSelected.emit(null as any);
    this.PostHog.Capture(this.BuildTrackingName('upload_supprimer', 'tracking'));
  }

  selectFileType(type: string): void {
    this.selectedType = type;
    this.PostHog.Capture(this.BuildTrackingName('upload_type_fichier', 'tracking'), { type });
  }

  triggerFileInput(): void {
    const lFileInput = this._FileInput?.nativeElement;
    if (lFileInput) {
      lFileInput.click();
    }
    this.PostHog.Capture(this.BuildTrackingName('upload_parcourir', 'tracking'));
  }

  /**
   * Bascule l'affichage de la dropzone (thème minimal-chip).
   */
  public ToggleDropzone(): void {
    this.IsDropzoneOpen = !this.IsDropzoneOpen;
  }

  /**
   * Ouvre la dropzone (thème minimal-chip).
   */
  public OpenDropzone(): void {
    this.IsDropzoneOpen = true;
  }

  /**
   * Ferme la dropzone (thème minimal-chip).
   */
  public CloseDropzone(): void {
    this.IsDropzoneOpen = false;
  }

  /**
   * Upload le fichier sélectionné via le service d'upload
   */
  async uploadFile(): Promise<void> {
    // Utiliser le fichier traité si disponible, sinon le fichier original
    const lFileToUpload = this.processedFile || this.file;

    if (!lFileToUpload || this.isUploading) return;

    this.isUploading = true;
    this.uploadProgress = 10; // Commencer à 10% pour montrer une activité
    this.PostHog.Capture(this.BuildTrackingName('upload_lancement', 'tracking'));
    this.uploadError.emit(''); // Effacer les erreurs précédentes

    // - cm - Création d'un contrôleur d'annulation dédié à cet upload
    this._UploadAbortController = new AbortController();

    try {
      console.log(`Début de l'upload: ${lFileToUpload.name}`);

      // Upload pour les images
      if (lFileToUpload.type.startsWith('image/')) {
        this.uploadProgress = 30; // Mise à jour de la progression

        const lUrl = await this.uploadService.uploadImage(lFileToUpload, this._UploadAbortController.signal);
        console.log(`Upload réussi: ${lUrl}`);

        this.uploadProgress = 100;
        this.uploadSuccess.emit(lUrl);
      } else {
        throw new Error('Seules les images sont prises en charge pour le moment');
      }
    } catch (lError: any) {
      if (lError.name === 'AbortError' || lError.message === "L'upload a été annulé ou a expiré.") {
        console.warn('Upload annulé par l\'utilisateur');
        this.uploadError.emit('Upload annulé');
      } else {
        console.error('Erreur lors de l\'upload:', lError);
        this.uploadError.emit(lError.message || 'Échec de l\'upload');
      }
      this.uploadProgress = 0;
    } finally {
      this.isUploading = false;
      this._UploadAbortController = null;
    }
  }

  /**
   * Annule l'upload en cours.
   */
  public cancelUpload(): void {
    if (this._UploadAbortController) {
      this._UploadAbortController.abort();
      this._UploadAbortController = null;
    }
  }

  private getFileExtension(filename: string): string {
    return filename.slice((filename.lastIndexOf('.') - 1 >>> 0) + 2);
  }
}
