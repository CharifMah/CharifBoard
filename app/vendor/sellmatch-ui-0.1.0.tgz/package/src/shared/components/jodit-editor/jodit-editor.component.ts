import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, forwardRef, inject, ChangeDetectionStrategy } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { Jodit } from 'jodit';

/**
 * Composant wrapper standalone pour l'éditeur WYSIWYG Jodit (MIT, sans clé API, sans télémétrie).
 * Implémente ControlValueAccessor pour être compatible avec [(ngModel)].
 * Toolbar complète type Outlook/Thunderbird : titres, gras/italique/souligné, couleurs, alignement,
 * listes, liens, images, tableaux, code source HTML, plein écran, aperçu.
 */
@Component({
  selector: 'app-jodit-editor',
  standalone: true,
  imports: [FormsModule],
  template: `<textarea #editor [ngModel]="value" (ngModelChange)="onInput($event)"></textarea>`,
  changeDetection: ChangeDetectionStrategy.Eager,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => JoditEditorComponent),
      multi: true
    }
  ]
})
export class JoditEditorComponent implements AfterViewInit, OnDestroy, ControlValueAccessor
{
  //#region Attributes
  @ViewChild('editor', { static: true }) private readonly _EditorRef!: ElementRef<HTMLTextAreaElement>;
  // - cm - Instance Jodit (typée any : l'API Jodit est un namespace, éviter la friction de typage)
  private _JoditInstance: any = null;
  private _IsInternalChange: boolean = false;
  //#endregion

  //#region Properties
  public value: string = '';
  //#endregion

  //#region Lifecycle

  /**
   * Initialise l'instance Jodit après le rendu du textarea.
   */
  public ngAfterViewInit(): void
  {
    this._JoditInstance = Jodit.make(this._EditorRef.nativeElement, {
      height: 420,
      toolbarSticky: true,
      buttons: [
        'bold', 'italic', 'underline', 'strikethrough', '|',
        'font', 'fontsize', 'brush', 'paragraph', '|',
        'ul', 'ol', 'indent', 'outdent', '|',
        'left', 'center', 'right', 'justify', '|',
        'link', 'image', 'table', 'hr', '|',
        'undo', 'redo', '|',
        'source', 'fullsize', 'preview', 'print'
      ],
      buttonsMD: [
        'bold', 'italic', 'underline', '|',
        'ul', 'ol', '|',
        'link', 'image', '|',
        'undo', 'redo', '|',
        'source', 'fullsize'
      ],
      showCharsCounter: false,
      showWordsCounter: false,
      showXPathInStatusbar: false,
      allowTabNavigation: true,
      // - cm - Sauts de ligne en <br> au lieu de <p> (évite le double espacement dans les emails :
      // les <p> ont des marges qui se cumulent avec le padding du template SellMatch).
      enter: Jodit.constants.BR,
      // - cm - Neutralise les marges par défaut des paragraphes pour un rendu compact dans l'email
      style: { margin: '0' },
      uploader: { insertImageAsBase64URI: true } // - cm - Images en base64 (pas de serveur d'upload requis)
    });

    // - cm - Synchronise les changements de Jodit vers le ControlValueAccessor
    this._JoditInstance.events.on('change', (pValue: string): void =>
    {
      if (!this._IsInternalChange)
      {
        this.onChange(pValue);
      }
    });
  }

  /**
   * Détruit l'instance Jodit pour éviter les fuites mémoire.
   */
  public ngOnDestroy(): void
  {
    this._JoditInstance?.destruct();
    this._JoditInstance = null;
  }
  //#endregion

  //#region ControlValueAccessor

  /**
   * Gère la saisie depuis le textarea (utilisé avant l'init Jodit).
   * @param pValue La valeur saisie
   */
  public onInput(pValue: string): void
  {
    this.value = pValue;
    this.onChange(pValue);
  }

  /**
   * Écrit la valeur dans l'éditeur (appelé par ngModel).
   * @param pValue La valeur à écrire
   */
  public writeValue(pValue: string): void
  {
    this.value = pValue ?? '';
    if (this._JoditInstance)
    {
      this._IsInternalChange = true;
      this._JoditInstance.value = this.value;
      this._IsInternalChange = false;
    }
  }

  /** Enregistre le callback de changement. */
  public registerOnChange(pFn: (pValue: string) => void): void
  {
    this.onChange = pFn;
  }

  /** Enregistre le callback de touch. */
  public registerOnTouched(pFn: () => void): void
  {
    this.onTouched = pFn;
  }

  /** Active/désactive l'éditeur. */
  public setDisabledState(pIsDisabled: boolean): void
  {
    this._JoditInstance?.setDisabled(pIsDisabled);
  }

  private onChange: (pValue: string) => void = (): void => {};
  private onTouched: () => void = (): void => {};
  //#endregion
}