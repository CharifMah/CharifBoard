import { Component, Input, ChangeDetectionStrategy, computed, signal } from '@angular/core';
import { SkeletonComponent } from '../../../shared/components/skeleton/skeleton.component';

/**
 * Composant skeleton réutilisable pour le loading des cartes KPI.
 * Affiche des cartes factices avec animation shimmer via <app-skeleton>.
 */
@Component({
  selector: 'app-card-skeleton',
  standalone: true,
  imports: [SkeletonComponent],
  templateUrl: './card-skeleton.component.html',
  styleUrl: './card-skeleton.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardSkeletonComponent {
  /** Nombre de cartes skeleton à afficher (défaut: 6). */
  @Input() public set Count(pValue: number) {
    this._Count.set(pValue);
  }
  public get Count(): number {
    return this._Count();
  }
  private readonly _Count = signal(6);

  /** Affiche une ligne de hint sous la valeur (défaut: true). */
  @Input() public HasHint = true;

  /** Tableau d'indices pour le @for du template. */
  public readonly Cards = computed(() => Array.from({ length: this._Count() }, (_, i) => i));

  /**
   * Calcule le delai d'animation shimmer (en ms) pour distribuer les cartes
   * de maniere desynchronisee. Formule : (carte * 200ms) + (slot * 30ms).
   * Couvre le cycle de 1.4s pour eviter un shimmer "fige" sur les dernieres cartes.
   * @param pCardIdx Index de la carte.
   * @param pSlot Index du slot a l'interieur de la carte (0..3 : avatar, name, value, hint).
   * @returns Le delai en millisecondes, modulo la duree du cycle.
   */
  public ComputeShimmerDelay(pCardIdx: number, pSlot: number): number {
    const lDelay: number = pCardIdx * 200 + pSlot * 30;
    return lDelay % 1400;
  }
}