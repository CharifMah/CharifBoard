import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, computed, inject, signal } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { TranslationService, SupportedLanguage } from '../../../core/services/i18n/TranslationService';

///PROTECTEDFILE

/**
 * Sélecteur de langue générique de l'application SellMatch.
 * S'appuie sur :
 *  - `TranslationService` (persistance localStorage + fallback)
 *  - Drapeaux SVG bundlés localement (`public/flags/*.svg`)
 *  - `ButtonComponent` (mode compact en chip)
 *
 * Deux modes d'affichage :
 *  - `select` (défaut) : bouton custom + dropdown rendu à la main, drapeaux SVG partout.
 *  - `chips` : groupe de boutons app-button, drapeaux SVG en ligne.
 *
 * Aucun service externe supplémentaire : le composant est 100% self-contained.
 */
@Component({
  selector: 'app-language-selector',
  standalone: true,
  imports: [ButtonComponent, UpperCasePipe],
  templateUrl: './language-selector.component.html',
  styleUrls: ['./language-selector.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LanguageSelectorComponent extends BaseComponent
{
  //#region Inputs

  /**
   * Mode d'affichage : 'select' (dropdown) ou 'chips' (boutons en ligne).
   */
  @Input() mode: 'select' | 'chips' = 'select';

  /**
   * Libellé affiché au-dessus du sélecteur (mode `select`). Vide = pas de label.
   */
  @Input() label: string = '';

  /**
   * Taille des boutons en mode `chips` (sm | md | lg).
   */
  @Input() size: 'sm' | 'md' | 'lg' = 'sm';

  /**
 * Mode lecture seule : désactive toute interaction (clic, ouverture dropdown).
 */
  @Input() readonly: boolean = false;

  //#endregion

  //#region Outputs

  /**
   * Émet le code langue sélectionné à chaque changement (mode select + chips).
   * Permet au composant parent (ex. profil-card) de synchroniser un formControl
   * et de déclencher la persistance BDD (users.langue) sans dépendre du
   * TranslationService global.
   */
  @Output() LangChange: EventEmitter<SupportedLanguage> = new EventEmitter<SupportedLanguage>();

  //#endregion

  //#region Attributes

  /** Service de traduction central (persistance + fallback). */
  private readonly _Translation: TranslationService = inject(TranslationService);

  /** Code langue courant (signal pour OnPush). */
  public readonly CurrentLang: ReturnType<typeof signal<SupportedLanguage>> = signal<SupportedLanguage>(this.Translate.getCurrentLanguage());

  /** ID unique du bouton trigger (mode select) pour relier label + aria. */
  public readonly SelectId: string = `language-selector-${Math.random().toString(36).slice(2, 10)}`;

  /** Dropdown ouvert/fermé (mode select). */
  public readonly SelectOpen: ReturnType<typeof signal<boolean>> = signal<boolean>(false);

  /**
   * Liste des langues disponibles pour le select et les chips.
   * `Country` = code ISO pays pour le drapeau (fr, gb, es…), distinct de `Code` (langue).
   * Drapeaux colorés SVG bundlés localement depuis `public/flags/`.
   */
  public readonly AvailableLanguages: ILanguageDescriptor[] = [
    { Code: 'fr', Country: 'fr', Label: 'Français' },
    { Code: 'en', Country: 'gb', Label: 'English' },
    { Code: 'es', Country: 'es', Label: 'Español' },
    { Code: 'pt', Country: 'pt', Label: 'Português' }
  ];

  /** Descripteur de la langue courante (helper pour le template). */
  public readonly CurrentLangDescriptor: ReturnType<typeof computed<ILanguageDescriptor>> = computed<ILanguageDescriptor>(() =>
    this.AvailableLanguages.find((pLang: ILanguageDescriptor) => pLang.Code === this.CurrentLang())
    ?? this.AvailableLanguages[0]
  );

  /** Code pays de la langue courante (drapeau à afficher dans le trigger). */
  public readonly CurrentCountryCode: ReturnType<typeof computed<string>> = computed<string>(() => this.CurrentLangDescriptor().Country);

  /** Libellé natif de la langue courante (pour alt et aria). */
  public readonly CurrentLangLabel: ReturnType<typeof computed<string>> = computed<string>(() => this.CurrentLangDescriptor().Label);

  /**
   * Helper : chemin du drapeau SVG pour un code pays donné.
   * Les SVG sont stockés dans `public/flags/{country}.svg` (Angular les sert à la racine).
   * Aucune dépendance externe (CDN), pas de requête réseau cross-origin au runtime.
   */
  public FlagUrl(pCountry: string): string {
    return `flags/${pCountry}.svg`;
  }

  //#endregion

  //#region CTOR

  constructor()
  {
    super();

    // - cm - Sync du signal interne à chaque changement de langue (init + changement externe)
    this.Translate.LanguageChanged.subscribe((pLang: SupportedLanguage) =>
    {
      this.CurrentLang.set(pLang);
    });
  }

  //#endregion

  //#region Methods

  /**
   * Ouvre ou ferme le dropdown (mode `select`).
   */
  public ToggleSelect(): void
  {
    this.SelectOpen.update((pOpen: boolean) => !pOpen);
  }

  /**
   * Ferme le dropdown (perte de focus du trigger).
   */
  public OnTriggerBlur(): void
  {
    // - cm - Petit delai pour laisser mousedown s'executer avant la fermeture
    setTimeout(() => this.SelectOpen.set(false), 120);
  }

  /**
   * Ferme le dropdown et change la langue (mousedown sur item, avant le blur).
   * @param pEvent MouseEvent pour preventDefault (evite le blur du trigger).
   * @param pLang Code langue sélectionné.
   */
  public OnOptionMouseDown(pEvent: MouseEvent, pLang: SupportedLanguage): void
  {
    pEvent.preventDefault();
    this.SelectOpen.set(false);
    this.OnLanguageChange(pLang);
  }

  /**
   * Navigation clavier sur le trigger (Enter/Espace ouvrent, Echap ferme).
   * @param pEvent KeyboardEvent.
   */
  public OnSelectKeydown(pEvent: KeyboardEvent): void
  {
    if (pEvent.key === 'Enter' || pEvent.key === ' ')
    {
      pEvent.preventDefault();
      this.ToggleSelect();
    }
    else if (pEvent.key === 'Escape' && this.SelectOpen())
    {
      this.SelectOpen.set(false);
    }
  }

  /**
   * Change la langue active (utilisé par le mode `chips` et le dropdown).
   * @param pLang Nouveau code langue.
   */
  public OnLanguageChange(pLang: SupportedLanguage): void
  {
    if (!pLang || pLang === this.CurrentLang())
    {
      return;
    }
    this.Translate.setLanguage(pLang);
    this.CurrentLang.set(pLang);
    this.PostHog.Capture('language_changed', { lang: pLang, mode: this.mode });
    // - cm - Notifie le parent (formControl profil-card, etc.) après le changement effectif
    this.LangChange.emit(pLang);
  }

  /**
   * Helper : indique si une langue est active (utilisé par les chips et le dropdown).
   * @param pLang Code langue à tester.
   */
  public IsActive(pLang: SupportedLanguage): boolean
  {
    return this.CurrentLang() === pLang;
  }

  //#endregion
}

/**
 * Descripteur interne d'une langue disponible dans le sélecteur.
 */
interface ILanguageDescriptor
{
  /** Code ISO 639-1 de la langue (fr, en, es). */
  Code: SupportedLanguage;
  /** Code ISO 3166-1 alpha-2 du pays pour le drapeau (fr, gb, es). */
  Country: string;
  /** Libellé natif. */
  Label: string;
}
