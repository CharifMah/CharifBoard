// message-display.component.ts
import { NgClass } from '@angular/common';
import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-message-display',
  standalone: true,
  imports: [NgClass],
  templateUrl: './message-display.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrl: './message-display.component.scss'
})
export class MessageDisplayComponent
{
  @Input() message: string | null = null;
  @Input() icon: string | null = 'error_outline';
  @Input() type: 'error' | 'info' | 'success' | 'warning' = 'error';
  @Input() additionalClasses: string = '';
  @Input() isField: boolean = false; // Nouvelle propriété pour choisir le style

  get cssClass(): string
  {
    if (this.isField)
    {
      return `field-${this.type}`;
    }
    return `${this.type}-message`;
  }
}
