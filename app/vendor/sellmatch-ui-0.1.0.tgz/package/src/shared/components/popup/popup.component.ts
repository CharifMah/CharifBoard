import { Component, Input, Output, EventEmitter, OnDestroy, OnChanges, SimpleChanges, HostListener, TemplateRef, ViewChild, ViewContainerRef, ElementRef, inject, Renderer2, AfterViewInit, ChangeDetectionStrategy, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { CommonModule } from '@angular/common';
import { PortalModule, DomPortalOutlet, TemplatePortal } from '@angular/cdk/portal';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../../../shared/components/button/button.component';

export type PopupSize = 'small' | 'medium' | 'large' | 'full' | 'form';
export type PopupType = 'default' | 'success' | 'warning' | 'error' | 'info';

@Component({
  selector: 'app-popup',
  standalone: true,
  imports: [CommonModule, PortalModule, ButtonComponent],
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager
})
export class PopupComponent extends BaseComponent implements OnDestroy, OnChanges, AfterViewInit
{
  // Affichage
  @Input() isOpen = false;
  @Input() title = '';
  @Input() subtitle = '';
  @Input() icon = '';
  @Input() iconClass = '';

  // Configuration
  @Input() size: PopupSize = 'medium';
  @Input() type: PopupType = 'default';
  @Input() closeOnOverlay = false;
  @Input() closeOnEscape = true;
  @Input() showCloseButton = true;
  @Input() showHeader = true;
  @Input() showFooter = false;
  // - cm - Options d'overlay : permettent d'attenuer le voile pour les contextes ou la page
  // doit rester lisible en arriere-plan (ex. tuto guide). Valeurs par defaut preservent
  // le comportement historique (fond noir 50% + backdrop blur).
  @Input() disableBackdropBlur = false;
  @Input() overlayOpacity: number | null = null;

  // Boutons standards
  @Input() confirmText = 'Confirmer';
  @Input() cancelText = 'Annuler';
  @Input() showConfirmButton = true;
  @Input() showCancelButton = true;
  @Input() confirmDisabled = false;
  @Input() cancelDisabled = false;
  @Input() confirmLoading = false;
  @Input() confirmClass = '';
  @Input() cancelClass = '';

  // Actions personnalisées
  @Input() customActions: {
    text: string;
    icon?: string;
    class?: string;
    disabled?: boolean;
    loading?: boolean;
    onClick: () => void;
  }[] = [];

  // Contenu personnalisé via templates
  @Input() headerTemplate: TemplateRef<any> | null = null;
  @Input() bodyTemplate: TemplateRef<any> | null = null;
  @Input() footerTemplate: TemplateRef<any> | null = null;

  // Positionnement
  @Input() position: 'center' | 'top' | 'bottom' = 'center';

  // Nouveaux paramètres pour le redimensionnement et le déplacement
  @Input() resizable = true;
  // - cm - Masquer le bouton plein écran dans le header. Indépendant de `resizable` (true par défaut
  // = comportement historique : bouton visible quand resizable).
  /// <summary>
  /// Affiche ou masque le bouton plein écran dans le header de la popup.
  /// Indépendant du mode <see cref="resizable"/> : par défaut, le bouton est visible
  /// dès que la popup est redimensionnable. Mettre à <c>false</c> pour le cacher
  /// tout en conservant le redimensionnement aux poignées.
  /// </summary>
  @Input() showFullscreenButton = true;
  /// <summary>
  /// Ouvre la popup directement en mode plein écran (équivalent à un appel à
  /// <see cref="toggleFullscreen"/> au moment de l'attachement). L'utilisateur peut
  /// toujours réduire via le bouton plein écran. À combiner avec <see cref="resizable"/>
  /// et <see cref="showFullscreenButton"/> selon les besoins d'UX.
  /// </summary>
  @Input() defaultFullscreen = false;
  @Input() draggable = true;
  @Input() minWidth = 300;
  @Input() minHeight = 200;
  @Input() maxWidth?: number;
  @Input() maxHeight?: number;
  @Input() autoSize = true; // Nouvelle option pour auto-dimensionner
  @Input() preserveAspectRatio = false;
  @Input() padding = 20; // Padding entre la popup et les bords de l'écran

  // Events
  @Output() closed = new EventEmitter<void>();
  @Output() confirmed = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();
  @Output() opened = new EventEmitter<void>();
  @Output() isOpenChange = new EventEmitter<boolean>();
  @Output() resized = new EventEmitter<{ width: number, height: number }>();
  @Output() moved = new EventEmitter<{ x: number, y: number }>();

  // Pour le portal
  @ViewChild('popupTemplate') popupTemplate!: TemplateRef<any>;
  @ViewChild('popupElement', { static: false }) popupElement!: ElementRef;
  @ViewChild('headerElement', { static: false }) headerElement!: ElementRef;

  // Références au contenu projeté
  @ViewChild('contentWrapper', { static: true }) contentWrapper!: ElementRef;
  @ViewChild('footerLeftWrapper', { static: true }) footerLeftWrapper!: ElementRef;

  private portalOutlet: DomPortalOutlet | null = null;
  private portal: TemplatePortal<any> | null = null;
  private originalOverflow = '';
  private bodyContainer: HTMLElement | null = null;
  private viewContainerRef: ViewContainerRef = inject(ViewContainerRef);
  private renderer = inject(Renderer2);
  // - cm - SSR-safe flag (injected once at construction; used by methods that touch `window`/`document`).
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));
  // - cm - Gestion de l'animation de sortie CSS (remplace l'API @angular/animations)
  private isClosing = false;
  private closingTimer: ReturnType<typeof setTimeout> | null = null;

  // Variables pour le redimensionnement
  currentWidth: number = 0;
  currentHeight: number = 0;
  isFullscreen: boolean = false;
  private savedWidth: number = 0;
  private savedHeight: number = 0;
  private isResizing = false;
  private isDragging = false;
  private resizeDirection = '';
  private resizeStartX = 0;
  private resizeStartY = 0;
  private resizeStartWidth = 0;
  private resizeStartHeight = 0;
  private dragStartX = 0;
  private dragStartY = 0;
  private dragStartLeft = 0;
  private dragStartTop = 0;
  private aspectRatio = 1;

  ngOnChanges(changes: SimpleChanges): void
  {
    if (changes['isOpen'])
    {
      if (this.isOpen)
      {
        setTimeout(() =>
        {
          this.attachPopup();
        });
      } else
      {
        this.detachPopup();
      }
    }
  }

  ngAfterViewInit(): void
  {
    if (this.isOpen && this.popupElement)
    {
      this.initResizable();
    }
  }

  ngOnDestroy(): void
  {
    // - cm - Nettoyage du timer d'animation de sortie pour éviter un detach différé sur outlet disposé
    if (this.closingTimer !== null)
    {
      clearTimeout(this.closingTimer);
      this.closingTimer = null;
      this.isClosing = false;
    }
    this.detachPopup(true);
    this.portalOutlet?.dispose();
    this.bodyContainer?.remove();
  }

  private initResizable(): void
  {
    if (!this.popupElement) return;

    setTimeout(() =>
    {
      const element = this.popupElement.nativeElement as HTMLElement;

      if (this.autoSize)
      {
        // Calculer automatiquement les dimensions en fonction du contenu
        this.autoSizePopup(element);
      } else
      {
        // Utiliser les dimensions définies ou par défaut
        if (!this.currentWidth)
        {
          this.currentWidth = element.offsetWidth;
        }

        if (!this.currentHeight)
        {
          this.currentHeight = element.offsetHeight;
        }

        // Appliquer les dimensions au conteneur
        this.renderer.setStyle(element, 'width', `${this.currentWidth}px`);
        this.renderer.setStyle(element, 'height', `${this.currentHeight}px`);
      }

      // Calculer le ratio d'aspect si nécessaire
      if (this.preserveAspectRatio)
      {
        this.aspectRatio = this.currentWidth / this.currentHeight;
      }
    }, 0);
  }

  private autoSizePopup(element: HTMLElement): void
  {
    // Réinitialiser les styles pour mesurer le contenu naturel
    this.renderer.removeStyle(element, 'width');
    this.renderer.removeStyle(element, 'height');

    // Mesurer le contenu naturel
    const contentWidth = element.scrollWidth;
    const contentHeight = element.scrollHeight;

    // Obtenir les dimensions de la fenêtre
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    // Calculer les dimensions maximales disponibles (avec padding)
    const maxAvailableWidth = windowWidth - (this.padding * 2);
    const maxAvailableHeight = windowHeight - (this.padding * 2);

    // Déterminer les dimensions finales (ne pas dépasser l'écran, respecter min/max)
    this.currentWidth = Math.min(
      contentWidth,
      maxAvailableWidth,
      this.maxWidth || Number.MAX_SAFE_INTEGER
    );

    this.currentHeight = Math.min(
      contentHeight,
      maxAvailableHeight,
      this.maxHeight || Number.MAX_SAFE_INTEGER
    );

    // S'assurer que les dimensions minimales sont respectées
    this.currentWidth = Math.max(this.currentWidth, this.minWidth);
    this.currentHeight = Math.max(this.currentHeight, this.minHeight);

    // Appliquer les dimensions finales
    this.renderer.setStyle(element, 'width', `${this.currentWidth}px`);
    this.renderer.setStyle(element, 'height', `${this.currentHeight}px`);

    // Si la popup est plus petite que l'écran, la centrer
    if (this.position === 'center')
    {
      this.centerPopup(element);
    }
  }

  private centerPopup(element: HTMLElement): void
  {
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    const left = Math.max(0, (windowWidth - this.currentWidth) / 2);
    const top = Math.max(0, (windowHeight - this.currentHeight) / 2);

    this.renderer.setStyle(element, 'left', `${left}px`);
    this.renderer.setStyle(element, 'top', `${top}px`);
  }

  private attachPopup(): void
  {
    if (!this.popupTemplate) return;

    // Créer un conteneur dans le body si nécessaire
    if (!this.bodyContainer)
    {
      this.bodyContainer = document.createElement('div');
      this.bodyContainer.className = 'popup-portal-container';
      document.body.appendChild(this.bodyContainer);
    }

    // Créer le portal outlet
    if (!this.portalOutlet)
    {
      this.portalOutlet = new DomPortalOutlet(
        this.bodyContainer,
        undefined,
        undefined
      );
    }

    // Attacher le template
    if (!this.portalOutlet.hasAttached())
    {
      this.portal = new TemplatePortal(this.popupTemplate, this.viewContainerRef);
      this.portalOutlet.attach(this.portal);
      this.lockScroll();
      this.PostHog.Capture(this.BuildTrackingName('popup_ouverte', 'tracking'), { titre: this.title, taille: this.size });
      this.opened.emit();

      // Initialiser les dimensions et position après l'attachement
      setTimeout(() =>
      {
        this.initResizable();

        // - cm - Mode plein écran par défaut (optionnel) : on bascule après init pour conserver
        // les dimensions d'origine dans savedWidth/savedHeight et permettre le retour via le bouton header.
        if (this.defaultFullscreen && !this.isFullscreen)
        {
          this.toggleFullscreen();
        }
      }, 0);
    }
  }

  /**
   Détache le popup du portail.
   @param pImmediate Détachement immédiat sans animation (ex: ngOnDestroy)
   */
  private detachPopup(pImmediate = false): void
  {
    if (!this.portalOutlet?.hasAttached()) return;

    // - cm - Détachement immédiat (destruction) : on annule l'animation en cours et on détache
    if (pImmediate)
    {
      if (this.closingTimer !== null)
      {
        clearTimeout(this.closingTimer);
        this.closingTimer = null;
      }
      this.isClosing = false;
      this.portalOutlet.detach();
      this.unlockScroll();
      return;
    }

    // - cm - Animation de sortie déjà en cours : on ne relance pas le détachement
    if (this.isClosing) return;

    // - cm - Récupère l'overlay pour piloter l'animation de sortie via la classe .is-closing
    const lOverlay = this.bodyContainer?.querySelector('.popup-overlay') as HTMLElement | null;
    if (lOverlay)
    {
      this.isClosing = true;
      this.renderer.addClass(lOverlay, 'is-closing');
      // - cm - Délai correspondant à la durée de l'animation de sortie (150ms)
      this.closingTimer = setTimeout(() =>
      {
        this.closingTimer = null;
        this.isClosing = false;
        this.portalOutlet?.detach();
        this.unlockScroll();
      }, 150);
    } else
    {
      this.portalOutlet.detach();
      this.unlockScroll();
    }
  }

  @HostListener('document:keydown.escape')
  onEscapePressed(): void
  {
    if (this.isOpen && this.closeOnEscape)
    {
      this.close();
    }
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void
  {
    if (this.isResizing)
    {
      this.resize(event);
    } else if (this.isDragging)
    {
      this.drag(event);
    }
  }

  @HostListener('document:mouseup')
  onMouseUp(): void
  {
    if (this.isResizing)
    {
      this.stopResizing();
    } else if (this.isDragging)
    {
      this.stopDragging();
    }
  }

  @HostListener('window:resize')
  onWindowResize(): void
  {
    // Si la popup est ouverte et en mode auto-size, réajuster si besoin
    if (this.isOpen && this.autoSize && this.popupElement)
    {
      this.autoSizePopup(this.popupElement.nativeElement);
    }
  }

  startResizing(event: MouseEvent, direction: string): void
  {
    if (!this.resizable) return;

    event.preventDefault();
    this.isResizing = true;
    this.resizeDirection = direction;

    const element = this.popupElement.nativeElement as HTMLElement;
    this.resizeStartX = event.clientX;
    this.resizeStartY = event.clientY;
    this.resizeStartWidth = element.offsetWidth;
    this.resizeStartHeight = element.offsetHeight;

    // Ajouter une classe pendant le redimensionnement
    this.PostHog.Capture(this.BuildTrackingName('popup_redimensionnement', 'tracking'), { titre: this.title, direction });
    this.renderer.addClass(element, 'resizing');

    // Désactiver le mode auto-size quand on commence à redimensionner manuellement
    this.autoSize = false;
  }

  private resize(event: MouseEvent): void
  {
    if (!this.isResizing || !this.popupElement) return;

    const element = this.popupElement.nativeElement as HTMLElement;
    const dx = event.clientX - this.resizeStartX;
    const dy = event.clientY - this.resizeStartY;

    let newWidth = this.resizeStartWidth;
    let newHeight = this.resizeStartHeight;

    // Position actuelle de l'élément
    const rect = element.getBoundingClientRect();
    let newLeft = rect.left;
    let newTop = rect.top;

    // Ajuster la largeur et la position horizontale en fonction de la direction
    if (this.resizeDirection.includes('e'))
    {
      newWidth = this.resizeStartWidth + dx;
    } else if (this.resizeDirection.includes('w'))
    {
      newWidth = this.resizeStartWidth - dx;
      if (newWidth >= this.minWidth)
      {
        newLeft = rect.right - newWidth;
      }
    }

    // Ajuster la hauteur et la position verticale en fonction de la direction
    if (this.resizeDirection.includes('s'))
    {
      newHeight = this.resizeStartHeight + dy;
    } else if (this.resizeDirection.includes('n'))
    {
      newHeight = this.resizeStartHeight - dy;
      if (newHeight >= this.minHeight)
      {
        newTop = rect.bottom - newHeight;
      }
    }

    // Appliquer les contraintes min/max
    newWidth = Math.max(this.minWidth, newWidth);
    newHeight = Math.max(this.minHeight, newHeight);

    if (this.maxWidth)
    {
      newWidth = Math.min(this.maxWidth, newWidth);
    }

    if (this.maxHeight)
    {
      newHeight = Math.min(this.maxHeight, newHeight);
    }

    // Limiter par la taille de l'écran (avec padding)
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    newWidth = Math.min(newWidth, windowWidth - (this.padding * 2));
    newHeight = Math.min(newHeight, windowHeight - (this.padding * 2));

    // Maintenir le ratio d'aspect si nécessaire
    if (this.preserveAspectRatio)
    {
      if (this.resizeDirection.includes('e') || this.resizeDirection.includes('w'))
      {
        // Si on redimensionne horizontalement, ajuster la hauteur
        newHeight = newWidth / this.aspectRatio;
      } else
      {
        // Si on redimensionne verticalement, ajuster la largeur
        newWidth = newHeight * this.aspectRatio;
      }
    }

    // Mettre à jour les dimensions
    this.currentWidth = newWidth;
    this.currentHeight = newHeight;

    // Appliquer les nouvelles dimensions et position
    this.renderer.setStyle(element, 'width', `${newWidth}px`);
    this.renderer.setStyle(element, 'height', `${newHeight}px`);
    this.renderer.setStyle(element, 'left', `${newLeft}px`);
    this.renderer.setStyle(element, 'top', `${newTop}px`);

    // Émettre l'événement de redimensionnement
    this.resized.emit({ width: newWidth, height: newHeight });
  }

  private stopResizing(): void
  {
    if (!this.isResizing) return;

    this.isResizing = false;
    const element = this.popupElement.nativeElement as HTMLElement;
    this.renderer.removeClass(element, 'resizing');
    this.PostHog.Capture(this.BuildTrackingName('popup_redimensionne', 'tracking'), { titre: this.title, largeur: element.offsetWidth, hauteur: element.offsetHeight });

    // Vérifier que la popup est toujours visible dans la fenêtre
    this.ensurePopupVisibility(element);
  }

  private ensurePopupVisibility(element: HTMLElement): void
  {
    const rect = element.getBoundingClientRect();
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let newLeft = rect.left;
    let newTop = rect.top;

    // Si la popup dépasse à gauche
    if (newLeft < this.padding)
    {
      newLeft = this.padding;
    }

    // Si la popup dépasse en haut
    if (newTop < this.padding)
    {
      newTop = this.padding;
    }

    // Si la popup dépasse à droite
    if (newLeft + rect.width > windowWidth - this.padding)
    {
      newLeft = windowWidth - rect.width - this.padding;
    }

    // Si la popup dépasse en bas
    if (newTop + rect.height > windowHeight - this.padding)
    {
      newTop = windowHeight - rect.height - this.padding;
    }

    // Appliquer la position corrigée
    this.renderer.setStyle(element, 'left', `${newLeft}px`);
    this.renderer.setStyle(element, 'top', `${newTop}px`);
  }

  startDragging(event: MouseEvent): void
  {
    if (!this.draggable || !this.headerElement) return;

    // Vérifier si l'événement provient du header (pour ne pas interférer avec les boutons)
    const targetElement = event.target as HTMLElement;
    const headerEl = this.headerElement.nativeElement as HTMLElement;

    if (!headerEl.contains(targetElement) || targetElement.closest('button'))
    {
      return;
    }

    event.preventDefault();
    this.isDragging = true;

    const element = this.popupElement.nativeElement as HTMLElement;
    this.dragStartX = event.clientX;
    this.dragStartY = event.clientY;

    // Obtenir la position actuelle
    const rect = element.getBoundingClientRect();
    this.dragStartLeft = rect.left;
    this.dragStartTop = rect.top;

    // Ajouter une classe pendant le déplacement
    this.PostHog.Capture(this.BuildTrackingName('popup_deplacement', 'tracking'), { titre: this.title });
    this.renderer.addClass(element, 'dragging');
  }

  private drag(event: MouseEvent): void
  {
    if (!this.isDragging || !this.popupElement) return;

    const element = this.popupElement.nativeElement as HTMLElement;
    const dx = event.clientX - this.dragStartX;
    const dy = event.clientY - this.dragStartY;

    // Calculer la nouvelle position
    let newLeft = this.dragStartLeft + dx;
    let newTop = this.dragStartTop + dy;

    // Obtenir les dimensions de l'élément et de la fenêtre
    const width = element.offsetWidth;
    const height = element.offsetHeight;
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    // Empêcher la popup de sortir de l'écran
    newLeft = Math.max(this.padding, Math.min(newLeft, windowWidth - width - this.padding));
    newTop = Math.max(this.padding, Math.min(newTop, windowHeight - height - this.padding));

    // Appliquer la nouvelle position
    this.renderer.setStyle(element, 'left', `${newLeft}px`);
    this.renderer.setStyle(element, 'top', `${newTop}px`);

    // Émettre l'événement de déplacement
    this.moved.emit({ x: newLeft, y: newTop });
  }

  private stopDragging(): void
  {
    if (!this.isDragging) return;

    this.isDragging = false;
    const element = this.popupElement.nativeElement as HTMLElement;
    this.renderer.removeClass(element, 'dragging');
    this.PostHog.Capture(this.BuildTrackingName('popup_deplacee', 'tracking'), { titre: this.title, x: element.offsetLeft, y: element.offsetTop });
  }

  open(): void
  {
    this.isOpen = true;
    this.isOpenChange.emit(true);
    this.attachPopup();
  }

  close(): void
  {
    this.isOpen = false;
    this.isOpenChange.emit(false);
    this.detachPopup();
    this.PostHog.Capture(this.BuildTrackingName('popup_fermee', 'tracking'), { titre: this.title });
    this.closed.emit();
  }

  /**
   * Positions the popup next to a target element (used by the tutorial overlay).
  /**
   * Bascule le mode plein écran (avec un écart de 16px par rapport aux bords).
   */
  toggleFullscreen(): void
  {
    if (!this.popupElement?.nativeElement) return;

    const lElement: HTMLElement = this.popupElement.nativeElement;

    if (this.isFullscreen)
    {
      // - cm - Restaurer : retirer tous les styles inline pour que le CSS par défaut reprenne
      this.currentWidth = this.savedWidth > 0 ? this.savedWidth : 0;
      this.currentHeight = this.savedHeight > 0 ? this.savedHeight : 0;

      if (this.savedWidth > 0)
      {
        this.renderer.setStyle(lElement, 'width', `${this.savedWidth}px`);
        this.renderer.setStyle(lElement, 'height', `${this.savedHeight}px`);
      }
      else
      {
        this.renderer.removeStyle(lElement, 'width');
        this.renderer.removeStyle(lElement, 'height');
      }

      this.renderer.removeStyle(lElement, 'top');
      this.renderer.removeStyle(lElement, 'left');
      this.renderer.removeStyle(lElement, 'transform');
      this.isFullscreen = false;
    }
    else
    {
      // - cm - Sauvegarder la taille actuelle (offsetWidth si currentWidth est 0)
      this.savedWidth = this.currentWidth > 0 ? this.currentWidth : lElement.offsetWidth;
      this.savedHeight = this.currentHeight > 0 ? this.currentHeight : lElement.offsetHeight;

      // - cm - Plein écran avec écart de 16px (centré horizontalement)
      const lMargin: number = 16;
      const lWidth: number = window.innerWidth - lMargin * 2;
      const lHeight: number = window.innerHeight - lMargin * 2;

      this.currentWidth = lWidth;
      this.currentHeight = lHeight;
      this.renderer.setStyle(lElement, 'width', `${lWidth}px`);
      this.renderer.setStyle(lElement, 'height', `${lHeight}px`);
      this.renderer.setStyle(lElement, 'top', `${lMargin}px`);
      this.renderer.setStyle(lElement, 'left', '50%');
      this.renderer.setStyle(lElement, 'transform', 'translateX(-50%)');
      this.isFullscreen = true;
    }

    this.PostHog.Capture(this.BuildTrackingName(this.isFullscreen ? 'popup_plein_ecran' : 'popup_reduire', 'tracking'), { titre: this.title });
  }

  onOverlayClick(event: MouseEvent): void
  {
    if (this.closeOnOverlay && event.target === event.currentTarget)
    {
      this.close();
    }
  }

  onConfirm(): void
  {
    if (!this.confirmDisabled && !this.confirmLoading)
    {
      this.PostHog.Capture(this.BuildTrackingName('popup_confirmee', 'tracking'), { titre: this.title });
      this.confirmed.emit();
    }
  }

  onCancel(): void
  {
    if (!this.cancelDisabled)
    {
      this.PostHog.Capture(this.BuildTrackingName('popup_annulee', 'tracking'), { titre: this.title });
      this.cancelled.emit();
      this.close();
    }
  }

  private lockScroll(): void
  {
    this.originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }

  private unlockScroll(): void
  {
    document.body.style.overflow = this.originalOverflow;
  }

  get typeIcon(): string
  {
    if (this.icon) return this.icon;

    const icons: Record<PopupType, string> = {
      default: '',
      success: 'check_circle',
      warning: 'warning',
      error: 'error',
      info: 'info'
    };
    return icons[this.type];
  }

  get sizeClass(): string { return `popup-${this.size}`; }
  get typeClass(): string { return `popup-type-${this.type}`; }
  get positionClass(): string { return `popup-position-${this.position}`; }

  /**
   * Returns the inline `background` value for the overlay.
   * - cm - When `overlayOpacity` is set, uses that alpha on the standard scrim color.
   *         When unset, returns an empty string so the SCSS default applies.
   *         Exposed as a method (not a getter) so it can be invoked from the template.
   */
  public overlayStyle(): string {
    if (this.overlayOpacity === null || this.overlayOpacity === undefined) {
      return '';
    }
    const lAlpha: number = Math.max(0, Math.min(1, this.overlayOpacity));
    return `rgba(0, 0, 0, ${lAlpha})`;
  }

  /** Classe appliquée quand l'auto-dimensionnement est actif pour libérer la largeur fixe imposée par la classe de taille. */
  get autoSizeClass(): string { return this.autoSize ? 'popup-autosize' : ''; }
}
