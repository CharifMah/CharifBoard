import
{
  Component,
  OnInit,
  OnDestroy,
  inject,
  ViewChild,
  Input,
  ChangeDetectionStrategy,
  signal,
  computed
} from '@angular/core';
import { Subscription } from 'rxjs';
import { RouterLink } from '@angular/router';

import { BaseComponent } from '../../../core/base/BaseComponent';
import { UsersDTO } from '../../../core/sellmatchdb/dto';
import { SettingsDTO } from '../../../core/sellmatchdb/dto/settings/settings.dto';
import { SettingsService } from '../../../core/sellmatchdb/services/settings/settings.service';
import { ProfilCardComponent } from '../../../components/profil-card/profil-card.component';
import { ButtonComponent } from '../button/button.component';
import { PopupComponent } from '../popup/popup.component';
import { UploadFileComponent, ImageProcessingOptions, FileTypeConfig } from '../UploadFile/upload-file.component';
import { UploadService } from '../../../core/services/Upload/UploadService';
import { AvatarComponent } from '../Avatar/avatar.component';
import { BadgeComponent } from '../badge/badge.component';
import { ThemeService } from '../../../core/services/theme/ThemeService';

import { GridCellEditedEvent, GridActionEvent } from '../../../shared/components/grid/grid.component';
import { IInputOption } from '../../../shared/components/input/input.types';
import { SettingsGridComponent } from '../../../components/SettingsCard/settings-grid.component';
import { SupportedLanguage } from '../../../core/services/i18n/TranslationService';

/**
 * Composant de profil utilisateur.
 * Affiche et permet la modification des informations personnelles,
 * la gestion de l'avatar, et l'édition des paramètres utilisateur (settings).
 */
@Component({
  selector: 'app-profil',
  standalone: true,
  imports: [
    ProfilCardComponent,
    ButtonComponent,
    PopupComponent,
    UploadFileComponent,
    AvatarComponent,
    BadgeComponent,
    SettingsGridComponent,
    RouterLink
  ],
  templateUrl: './profil.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrl: './profil.component.scss'
})
export class ProfilComponent extends BaseComponent implements OnInit, OnDestroy
{
  //#region ViewChild
  /** Référence vers le composant d'upload d'avatar. */
  @ViewChild('uploadComponent') uploadComponent!: UploadFileComponent;
  //#endregion

  //#region Attributes
  private _UserSubscription?: Subscription;
  private previousAvatarUrl: string | null = null;
  private uploadService: UploadService = inject(UploadService);
  private _SelectedLanguage: SupportedLanguage | null = null;

  /** Service de gestion du thème (clair/sombre). */
  public readonly Theme: ThemeService = inject(ThemeService);

  /** Service de gestion des settings utilisateur. */
  private readonly _SettingsService: SettingsService = inject(SettingsService);
  //#endregion

  //#region State Signals
  /** Settings de l'utilisateur courant (chargés à l'ouverture du profil). */
  public readonly UserSettings = signal<SettingsDTO[]>([]);

  /** Indique que les settings sont en cours de chargement. */
  public readonly SettingsLoading = signal<boolean>(false);

  /**
   * Loading global de la grid settings = OR entre le signal local et la persistance BDD du theme.
   * - cm - Affiche le skeleton de la grid des settings pendant :
   *   1. les operations CRUD explicites (update/create/delete via CellEdited/RowValidated/etc.)
   *   2. la persistance BDD du theme lancee par ThemeService._PersistThemeToServer.
   *      La valeur du setting `ui.theme` dans la grid est mise a jour avec un delai (le POST
   *      reseau prend ~150-500ms) et pendant ce delai on veut le skeleton.
   * - cm - Suit le pattern 16 de sellmatch-crm-grid-patterns : skeleton par grille independant,
   * pas de BusyService global.
   */
  public readonly SettingsLoadingCombined = computed(() => this.SettingsLoading() || this.Theme.IsPersisting());

  /** Options pour les selects userId et updatedById (liste des utilisateurs). */
  public readonly UserOptions = signal<IInputOption[]>([]);

  /** Utilisateur courant. */
  public User: UsersDTO | null = null;

  /** Mode édition du profil. */
  public IsEditing = false;

  /** Sauvegarde en cours. */
  public IsSaving = false;

  /** Popup de suppression de compte. */
  public ShowDeletePopup = false;

  /** Message d'erreur global. */
  public errorMessage: string = '';

  /** Upload d'avatar en cours. */
  public isAvatarUploading = false;

  /** Indique si la popup ImmoAide est ouverte (transmis par le parent). */
  @Input() IsImmoAidePopupOpen: boolean = false;

  /** URL de la page Mon abonnement (utilisé par la sous-section abonnement). */
  public readonly SubscriptionUrl: string = this.RouteUtils.GetRoute(this.Routes.SUBSCRIPTION_MANAGEMENT);

  // -- État pour la suppression d'un setting --
  /** Setting en cours de suppression. */
  public readonly RowToDeleteSetting = signal<SettingsDTO | null>(null);

  /** Popup de confirmation de suppression d'un setting. */
  public readonly ShowDeleteSettingPopup = signal<boolean>(false);

  /** Suppression de setting en cours. */
  public readonly DeletingSetting = signal<boolean>(false);
  //#endregion

  //#region Avatar Upload Configuration
  /** Types de fichiers acceptés pour l'avatar. */
  public AvatarFileTypes: FileTypeConfig[] = [{
    type: 'image',
    label: 'Photo de profil',
    extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    maxSize: 5,
    icon: 'person'
  }];

  /** Options de traitement d'image pour l'avatar. */
  public avatarProcessingOptions: ImageProcessingOptions = {
    convertToWebp: true,
    resize: {
      width: 400,
      height: 400,
      maintainAspectRatio: true
    },
    crop: {
      enabled: true,
      aspectRatio: 1
    }
  };
  //#endregion

  //#region Lifecycle
  /** @inheritdoc */
  public ngOnInit(): void
  {
    // - cm - Theme.Init() déplacé vers AppComponent (initialisation globale)
    this._UserSubscription = this.UsersService.currentUser$.subscribe(async user =>
    {
      this.User = user;
      this.previousAvatarUrl = user?.avatarUrl || null;
      if (user?.id)
      {
        // Charge les options des utilisateurs pour les selects
        await this.LoadUserOptions();
      }
    });
  }

  /** @inheritdoc */
  public ngOnDestroy(): void
  {
    this._UserSubscription?.unsubscribe();
  }
  //#endregion

  //#region Methods - Data Loading

  /**
   * Charge la liste des utilisateurs pour les selects des settings (userId, updatedById).
   * - cm - Utilisé uniquement si l'utilisateur a les droits d'édition des settings.
   */
  private async LoadUserOptions(): Promise<void>
  {
    try
    {
      const lUsers: UsersDTO | null = await this.UsersService.currentUser; // À adapter selon le service
      if (lUsers && lUsers.userSettings)
      {
        this.UserSettings.set(lUsers.userSettings);
      }

    } catch (pErr)
    {
      console.error('Erreur chargement utilisateurs pour selects', pErr);
      this.UserOptions.set([]);
    }
  }
  //#endregion

  public onLangueChange(pLang: SupportedLanguage): void
  {
    this._SelectedLanguage = pLang;
  }

  //#region Methods - Avatar
  /**
   * Déclenche le composant d'upload caché.
   */
  public triggerAvatarUpload(): void
  {
    if (!this.isAvatarUploading && this.uploadComponent)
    {
      this.isAvatarUploading = true;
      this.PostHog.Capture(this.BuildTrackingName('avatar_upload_declenche', 'tracking'));
      this.uploadComponent.triggerFileInput();
    }
  }

  /**
   * Gestion de l'upload d'avatar réussi via le composant UploadFile.
   * @param imageUrl URL ou tableau d'URLs des images uploadées.
   */
  public async onAvatarUploaded(imageUrl: string | string[]): Promise<void>
  {
    if (!this.User) return;

    this.errorMessage = '';

    try
    {
      const avatarUrl = Array.isArray(imageUrl) ? imageUrl[0] : imageUrl;
      if (!avatarUrl)
      {
        this.errorMessage = "Aucune URL d'image valide reçue";
        this.isAvatarUploading = false;
        return;
      }

      this.User.avatarUrl = avatarUrl;
      await this.deleteOldAvatar();

      const result = await this.UsersService.update(this.User, { id: this.User.id });

      if (result)
      {
        this.User = result;
        this.previousAvatarUrl = result.avatarUrl || '';
        this.PostHog.Capture(this.BuildTrackingName('avatar_upload_succes', 'tracking'));
      }
    } catch (error: any)
    {
      console.error('Erreur lors de la mise à jour du profil:', error);
      this.errorMessage = error.message || 'Erreur lors de la mise à jour de l\'avatar';
      this.PostHog.Capture(this.BuildTrackingName('avatar_upload_erreur', 'tracking'), { erreur: error.message });
    } finally
    {
      this.isAvatarUploading = false;
    }
  }

  /**
   * Supprime l'avatar actuel de l'utilisateur.
   */
  public async removeAvatar(): Promise<void>
  {
    if (!this.User || !this.User.avatarUrl || this.isAvatarUploading) return;

    this.isAvatarUploading = true;
    this.errorMessage = '';

    try
    {
      const oldAvatarUrl = this.User.avatarUrl;
      this.User.avatarUrl = undefined;
      const result = await this.UsersService.update(this.User, { id: this.User.id });

      if (result)
      {
        this.User = result;
        await this.uploadService.deleteImage(oldAvatarUrl);
        this.previousAvatarUrl = null;
        this.PostHog.Capture(this.BuildTrackingName('avatar_supprime', 'tracking'));
      }
    } catch (error: any)
    {
      console.error('Erreur lors de la suppression de l\'avatar:', error);
      this.errorMessage = error.message || 'Erreur lors de la suppression de l\'avatar';
      this.PostHog.Capture(this.BuildTrackingName('avatar_suppression_erreur', 'tracking'), { erreur: error.message });
    } finally
    {
      this.isAvatarUploading = false;
    }
  }

  /**
   * Supprime l'ancien avatar de l'utilisateur du serveur si nécessaire.
   */
  private async deleteOldAvatar(): Promise<void>
  {
    if (this.previousAvatarUrl)
    {
      try
      {
        const result = await this.uploadService.deleteImage(this.previousAvatarUrl);
        if (!result.success)
        {
          console.warn('Impossible de supprimer l\'ancien avatar:', result.message);
        }
      } catch (error)
      {
        console.error('Erreur lors de la suppression de l\'ancien avatar:', error);
      }
    }
  }

  /**
   * Gestion des erreurs d'upload du composant UploadFile.
   * @param error Message d'erreur.
   */
  public onUploadError(error: string): void
  {
    this.errorMessage = error;
    this.isAvatarUploading = false;
  }
  //#endregion

  //#region Methods - Profil Edition
  /**
   * Active le mode édition du profil.
   */
  public startEditing(): void
  {
    this.IsEditing = true;
    this.PostHog.Capture(this.BuildTrackingName('profil_edition', 'tracking'));
  }

  /**
   * Annule le mode édition du profil.
   */
  public cancelEditing(): void
  {
    this.IsEditing = false;
    this.errorMessage = '';
    this.PostHog.Capture(this.BuildTrackingName('profil_edition_annulee', 'tracking'));
  }

  /**
   * Sauvegarde les modifications du profil.
   * @param formData Données du formulaire.
   */
  public async saveProfil(formData: UsersDTO): Promise<void>
  {
    if (!this.User?.id || this.IsSaving) return;

    this.IsSaving = true;
    this.errorMessage = '';

    try
    {
      const lUpdatedUser: UsersDTO = { ...this.User, ...formData };
      const lResult: UsersDTO | null = await this.UsersService.update(lUpdatedUser, undefined);

      if (lResult)
      {

        // Sauvegarder la langue si elle a changé
        if (this._SelectedLanguage)
        {
          const lCurrentLang = this.Translate.getCurrentLanguage();

          // Mettre à jour le setting
          await this.updateLanguageSetting(this._SelectedLanguage);

        }

        this.User = this.UsersService.currentUser;
        this.IsEditing = false;
        this.PostHog.Capture(this.BuildTrackingName('profil_sauvegarde', 'tracking'));

      }
    } catch (error: any)
    {
      console.error('Erreur lors de la sauvegarde:', error);
      this.errorMessage = error.message || 'Une erreur est survenue lors de la sauvegarde';
      this.PostHog.Capture(this.BuildTrackingName('profil_erreur_sauvegarde', 'tracking'), { erreur: error.message });
    } finally
    {
      this.IsSaving = false;
    }
  }

  private async updateLanguageSetting(pLang: SupportedLanguage): Promise<void>
  {
    const lLangueSetting = this.UsersService.getLangue();
    if (lLangueSetting)
    {
      lLangueSetting.value = pLang;
      await this._SettingsService.update(lLangueSetting, { key: 'langue' });
    } else
    {
      const lNewSetting: SettingsDTO = {
        key: 'langue',
        value: pLang,
        valueType: 'string',
        userId: this.User?.id ?? undefined
      };
      await this._SettingsService.create(lNewSetting);
    }
  }

  /**
   * Bascule entre le thème clair et sombre.
   */
  public toggleTheme(): void
  {
    this.Theme.Toggle();
    this.PostHog.Capture(this.BuildTrackingName('theme_toggle', 'tracking'), { theme: this.Theme.CurrentTheme() });
  }

  /**
   * Supprime le compte utilisateur après confirmation.
   */
  public async ConfirmDelete(): Promise<void>
  {
    try
    {
      await this.UsersService.delete({ id: this.UsersService.currentUser?.id });

      if (this.User?.avatarUrl)
      {
        try
        {
          await this.uploadService.deleteImage(this.User.avatarUrl);
        } catch (error)
        {
          console.error('Erreur lors de la suppression de l\'avatar après suppression de compte:', error);
        }
      }

      this.ShowDeletePopup = false;
      this.UsersService.logout();
    } catch (e: any)
    {
      this.errorMessage = e.message || 'Une erreur est survenue lors de la suppression du compte';
      console.error('Erreur lors de la suppression:', e);
    }
  }
  //#endregion

  //#region Methods - Settings Grid Handlers
  /**
   * Gère l'édition inline d'une cellule de setting.
   * @param pEvent Événement d'édition.
   */
  public async onSettingCellEdited(pEvent: GridCellEditedEvent<SettingsDTO>): Promise<void>
  {
    // - cm - Convertit la nouvelle valeur si l'ancienne est numérique (select à valeurs id)
    const lNewValue: unknown = this.ConvertNumericValue(pEvent.OldValue, pEvent.NewValue);
    // - cm - Applique la modification sur le DTO local avant persistance
    this.ApplyCellValue(pEvent.Row, pEvent.Key, lNewValue);

    this.PostHog.Capture(this.BuildTrackingName('setting_edit', 'tracking'));

    // - cm - Nouvelle ligne (id temporaire négatif ou absent) : pas d'update, attend la validation complète
    if (!pEvent.Row.id || pEvent.Row.id < 0)
    {
      return;
    }

    // - cm - Active le skeleton de la grid pendant l'appel reseau update.
    this.SettingsLoading.set(true);
    try
    {
      const lUpdated = await this._SettingsService.update(pEvent.Row, { id: pEvent.Row.id });
      if (lUpdated)
      {
        const lRows = this.UserSettings();
        const lIndex = lRows.findIndex(r => r.id === pEvent.Row.id);
        if (lIndex >= 0)
        {
          const lNewRows = [...lRows];
          lNewRows[lIndex] = lUpdated;
          this.UserSettings.set(lNewRows);
        }
      }
    } catch (pErr)
    {
      console.error('Erreur mise à jour setting', pErr);
      this.errorMessage = 'Impossible de modifier le paramètre.';
    }
    finally
    {
      this.SettingsLoading.set(false);
    }
  }

  /**
   * Gère le clic sur une action de ligne (edit/delete).
   * @param pEvent Événement d'action.
   */
  public onSettingActionClicked(pEvent: GridActionEvent<SettingsDTO>): void
  {
    this.PostHog.Capture(this.BuildTrackingName('setting_action', 'tracking'), { action: pEvent.Action });
    if (pEvent.Action === 'delete')
    {
      this.RowToDeleteSetting.set(pEvent.Row);
      this.ShowDeleteSettingPopup.set(true);
    }
  }

  /**
   * Callback RowAdded : crée immédiatement le brouillon en BDD avec les valeurs par défaut.
   * @param pRow La nouvelle ligne.
   */
  public async onSettingRowAdded(pRow: SettingsDTO): Promise<void>
  {
    await this.CreateSettingRow(pRow);
  }

  /**
   * Callback RowValidated : si la ligne n'a pas de vrai id, la crée.
   * @param pRow La ligne validée.
   */
  public async onSettingRowValidated(pRow: SettingsDTO): Promise<void>
  {
    if (pRow.id && pRow.id > 0)
    {
      return;
    }
    await this.CreateSettingRow(pRow);
  }

  /**
   * Crée une ligne de setting en BDD (brouillon).
   * @param pRow La ligne à créer.
   */
  private async CreateSettingRow(pRow: SettingsDTO): Promise<void>
  {
    // - cm - Active le skeleton de la grid pendant l'appel reseau create.
    this.SettingsLoading.set(true);
    try
    {
      // - cm - Retire l'id temporaire avant création (le backend assignera le vrai id)
      const lDto: SettingsDTO = { ...pRow };
      delete lDto.id;

      // - cm - Force le userId au CurrentUserId sauf si déjà renseigné
      if (!lDto.userId && this.User?.id)
      {
        lDto.userId = this.User.id;
      }

      const lCreated = await this._SettingsService.create(lDto);
      // - cm - Remplace la ligne temporaire par la ligne créée dans le signal
      const lRows = this.UserSettings();
      const lIndex = lRows.findIndex(r => r.id === pRow.id);
      if (lIndex >= 0)
      {
        const lNewRows = [...lRows];
        lNewRows[lIndex] = lCreated;
        this.UserSettings.set(lNewRows);
      } else
      {
        // - cm - Si la ligne n'est pas trouvée (peu probable), on l'ajoute
        this.UserSettings.set([...lRows, lCreated]);
      }
      this.PostHog.Capture(this.BuildTrackingName('setting_add', 'tracking'));
    } catch (pErr)
    {
      console.error('Erreur création setting', pErr);
      this.errorMessage = 'Impossible de créer le paramètre.';
    }
    finally
    {
      this.SettingsLoading.set(false);
    }
  }

  /**
   * Confirme la suppression d'un setting depuis la popup.
   */
  public async confirmDeleteSetting(): Promise<void>
  {
    const lRow: SettingsDTO | null = this.RowToDeleteSetting();
    if (!lRow || !lRow.id)
    {
      this.ShowDeleteSettingPopup.set(false);
      this.RowToDeleteSetting.set(null);
      return;
    }
    this.DeletingSetting.set(true);
    // - cm - Active le skeleton de la grid pendant l'appel reseau delete.
    this.SettingsLoading.set(true);
    try
    {
      await this._SettingsService.delete({ id: lRow.id });
      // - cm - Retire la ligne de la liste
      const lRows = this.UserSettings().filter(r => r.id !== lRow.id);
      this.UserSettings.set(lRows);
      this.PostHog.Capture(this.BuildTrackingName('setting_delete', 'tracking'));
    } catch (pErr)
    {
      console.error('Erreur suppression setting', pErr);
      this.errorMessage = 'Impossible de supprimer le paramètre.';
    } finally
    {
      this.DeletingSetting.set(false);
      this.SettingsLoading.set(false);
      this.ShowDeleteSettingPopup.set(false);
      this.RowToDeleteSetting.set(null);
    }
  }

  /**
   * Annule la suppression d'un setting (ferme la popup).
   */
  public cancelDeleteSetting(): void
  {
    this.ShowDeleteSettingPopup.set(false);
    this.RowToDeleteSetting.set(null);
  }
  //#endregion

  //#region Methods - Grid Utilities
  /**
   * Convertit la nouvelle valeur si l'ancienne est numérique (select à valeurs id).
   * @param pOldValue L'ancienne valeur (détermine si numérique).
   * @param pNewValue La nouvelle valeur (string ou number).
   * @returns La valeur convertie.
   */
  public ConvertNumericValue(pOldValue: unknown, pNewValue: unknown): unknown
  {
    if (typeof pOldValue === 'number' && typeof pNewValue === 'string')
    {
      return pNewValue === '' ? undefined : Number(pNewValue);
    }
    if (pOldValue === undefined && typeof pNewValue === 'string' && pNewValue === '')
    {
      return undefined;
    }
    return pNewValue;
  }

  /**
   * Applique une nouvelle valeur sur le DTO local avant persistance.
   * @param pRow La ligne concernée.
   * @param pKey La clé du champ.
   * @param pValue La valeur à appliquer.
   */
  public ApplyCellValue(pRow: SettingsDTO, pKey: string, pValue: unknown): void
  {
    const lRow = pRow as unknown as Record<string, unknown>;
    lRow[pKey] = pValue;
  }

  //#endregion
}
