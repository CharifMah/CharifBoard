import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdressesDTO } from '../../../core/sellmatchdb/dto';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { MapCardComponent } from '../../../shared/components/map-card/map-card.component';
import { EMarkerType } from '../map-card/EMarkerType';
import { GetMarkerStyle } from '../map-card/map-marker-style';
import { EMapStyle } from '../map-card/EMapStyle';
import { IMapMarker } from '../map-card/IMapMarker';
import { TooltipComponent, TooltipPosition, TooltipVariant } from '../../../shared/components/tooltip/tooltip.component';

/**
 * Affiche une adresse avec un tooltip de carte interactive au survol.
 * Basé sur les composants génériques `app-tooltip` et `app-map-card`.
 * Le tooltip expose le sélecteur de mode de carte (plan, satellite, terrain, etc.)
 * lorsque l'adresse possède des coordonnées géographiques.
 */
@Component({
  selector: 'app-address-map-tooltip',
  standalone: true,
  templateUrl: './address-map-tooltip.component.html',
  styleUrls: ['./address-map-tooltip.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MapCardComponent, TooltipComponent]
})
export class AddressMapTooltipComponent extends BaseComponent
{
  //#region Inputs

  /** Adresse à afficher et localiser sur la carte. */
  @Input() Address: AdressesDTO | null | undefined = null;

  /** Libellé affiché à la place de la ville si besoin. */
  @Input() Label: string = '';

  /** Position du tooltip par rapport au texte. */
  @Input() Position: TooltipPosition = 'bottom';

  /** Variante visuelle du tooltip. */
  @Input() Variant: TooltipVariant = 'light';

  /** Largeur maximale du tooltip en px. */
  @Input() MaxWidth: number = 380;

  /** Hauteur de la carte dans le tooltip en px. */
  @Input() MapHeight: number = 220;

  /** Niveau de zoom initial de la carte. */
  @Input() MapZoom: number = 15;

  /** Affiche le sélecteur de style de carte (modes plan, satellite, terrain, etc.). */
  @Input() ShowStyleSelector: boolean = true;

  /** Affiche les contrôles de zoom sur la carte. */
  @Input() ShowZoomControl: boolean = true;

  /** Active la molette de zoom sur la carte. */
  @Input() ScrollWheelZoom: boolean = true;

  /** Titre affiché dans l'en-tête de la carte. */
  @Input() MapTitle: string = 'Localisation';

  /** Icône affichée dans l'en-tête de la carte. */
  @Input() MapIcon: string = 'location_on';

  /**
   * Type du marker (Property / Transaction / Location / etc.).
   * - cm - Source de vérité unique pour le style du marker : la couleur et
   * - cm - l'icône Material sont dérivées via `GetMarkerStyle(EMarkerType)`
   * - cm - (cf. `map-marker-style.ts`), partagé avec le dashboard et les grilles.
   * - cm - Accepte `EMarkerType` ou `string` (les valeurs de l'enum sont déjà
   * - cm - des chaînes minuscules, ce qui permet la liaison directe depuis
   * - cm - les templates sans cast).
   */
  @Input() MarkerType: EMarkerType | string | null = null;

  /**
   * @deprecated Préférer `MarkerType` qui centralise icône + couleur.
   * Icône Material du marker sur la mini-carte (fallback si MarkerType non fourni).
   */
  @Input() MarkerIcon: string | null = null;

  /**
   * @deprecated Préférer `MarkerType` qui centralise icône + couleur.
   * Couleur CSS du marker sur la mini-carte (fallback si MarkerType non fourni).
   */
  @Input() MarkerColor: string | null = null;

  //#endregion

  //#region Outputs

  /** Émis au changement de mode de carte depuis le tooltip. */
  @Output() MapStyleChange: EventEmitter<EMapStyle> = new EventEmitter<EMapStyle>();

  //#endregion

  //#region Properties

  /** Indique si l'adresse possède des coordonnées géographiques. */
  public get HasCoordinates(): boolean
  {
    return !!this.Address?.latitude && !!this.Address?.longitude;
  }

  /** Libellé affiché pour l'adresse. */
  public get DisplayLabel(): string
  {
    return this.Label || this.Address?.city || '';
  }

  /** Centre latitude de la carte. */
  public get CenterLat(): number
  {
    return this.Address?.latitude ?? 0;
  }

  /** Centre longitude de la carte. */
  public get CenterLng(): number
  {
    return this.Address?.longitude ?? 0;
  }

  /** Marqueur unique représentant l'adresse sur la carte. */
  public get MapMarkers(): IMapMarker[]
  {
    if (!this.HasCoordinates)
    {
      return [];
    }

    // - cm - Style centralisé via GetMarkerStyle : la couleur et l'icône sont
    // - cm - dérivées du `MarkerType` fourni par la grille parente. Cela garantit
    // - cm - que le marker adresse dans la mini-carte a exactement la même
    // - cm - apparence que le marker correspondant sur la carte principale.
    // - cm - `MarkerType` accepte `EMarkerType | string | null` pour permettre
    // - cm - la liaison directe depuis les templates (`[MarkerType]="'property'"`).
    // - cm - `GetMarkerStyle` normalise la clé (string) vers le bon style.
    const lType: EMarkerType = (this.MarkerType ?? EMarkerType.Default) as EMarkerType;
    const lStyle = GetMarkerStyle(lType);
    return [{
      Lat: this.Address!.latitude!,
      Lng: this.Address!.longitude!,
      Title: this.Address?.city ?? '',
      Popup: this.Address?.label ?? this.Address?.street ?? this.Address?.city ?? '',
      Type: lType,
      Icon: lStyle.Icon,
      Color: lStyle.Color
    }];
  }

  //#endregion

  //#region CTOR

  /**
   * Initialise le composant.
   */
  constructor()
  {
    super();
  }

  //#endregion

  //#region Methods

  /**
   * Publie le changement de mode de carte.
   * @param pStyle Le nouveau mode de carte
   */
  public OnStyleChange(pStyle: EMapStyle): void
  {
    this.MapStyleChange.emit(pStyle);
  }

  //#endregion
}
