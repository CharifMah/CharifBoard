import { AfterViewInit, computed, Directive, EventEmitter, OnDestroy, Output, signal, Input, Signal, viewChild } from '@angular/core';
import type { IInputOption } from '../../../shared/components/input/input.types';
import { GridBase } from '../../../shared/components/grid/grid-base';
import { GenerateTempId as GenTempId, GenerateReference as GenRef, IsAdressesDTO as IsAddr } from '../../../shared/components/grid/grid-helpers';
import { GridCellEditedEvent, GridComponent, GridSortEvent, GridActionEvent } from '../../../shared/components/grid/grid.component';
import type { ServiceBase } from '../../../core/base/ServiceBase';
import type { BaseCritereDTO } from '../../../core/base/base.critere';
import { BaseDTO } from '../../../core/base/BaseDTO';

/**
 * Base commune des grilles CRUD SellMatch
 *
 * @typeParam TDTO Type du DTO de la ligne.
 * @typeParam TCritere Type du critère de pagination server-side (hérite de `BaseCritereDTO`).
 */
@Directive()
export abstract class GridComponentBase<TDTO extends BaseDTO, TCritere extends BaseCritereDTO = BaseCritereDTO> extends GridBase<TDTO,TCritere> implements AfterViewInit, OnDestroy {
  /**
   * Référence interne vers le `<app-grid>` enfant (signal-based, Angular 17+).
   * - cm - Résolu automatiquement quel que soit le nom de template (`#recrutementGrid`,
   *      `#contactGrid`, `#tacheGrid`, etc.). La base s'abonne programmatiquement aux
   *      events `PageChanged` / `SortChanged` / `FilterChanged` dans `ngAfterViewInit`
   *      et déclenche `LoadCurrentPage()` à chaque changement. Plus besoin de
   *      brancher `(PageChanged)="OnServerSidePageChange($event)"` côté template.
   */
  protected readonly _Grid = viewChild<GridComponent<TDTO, TCritere>>(GridComponent);
  /**
   * Mode lecture seule : désactive l'édition inline, l'ajout de ligne, et les actions edit/delete.
   * Réémis ici pour qu'Angular reconnaisse `[ReadOnly]` comme input sur les wrappers concrets.
   */
  @Input() public override set ReadOnly(pValue: boolean) {
    this._ReadOnly = pValue;
  }
  /** Getter réémis pour préserver l'accessibilité après override du setter. */
  public override get ReadOnly(): boolean {
    return this._ReadOnly;
  }
  //#region Properties
  /** Préfixe de référence pour les nouvelles lignes (TRX, LOC, PROP, PRJ, OBJ, CON, REC, HIS, PRO). */
  protected abstract readonly PREFIX: string;

  /** Liste des options nature de l'affaire (signal réactif). */
  public readonly NatureAffaireOptions = signal<IInputOption[]>([]);

  /** Liste des options statut (signal réactif). */
  public readonly StatutOptions = signal<IInputOption[]>([]);

  /** Liste des options état commercial (signal réactif). */
  public readonly EtatCommercialOptions = signal<IInputOption[]>([]);

  /** Liste des options motif de blocage (signal réactif). */
  public readonly MotifBlocageOptions = signal<IInputOption[]>([]);

  /** Liste des options contacts (signal réactif). */
  public readonly ContactOptions = signal<IInputOption[]>([]);

  /** Liste des options biens (signal réactif). */
  public readonly PropertyOptions = signal<IInputOption[]>([]);

  //#region Shared inputs
  /**
   * Liste des DTOs à afficher. En mode server-side (`ServerSide=true`),
   * la grille utilise `ServerSideData` à la place (cf. `EffectiveData`).
   */
  @Input() public Data: TDTO[] = [];
  /** Indique le chargement des données (skeleton). */
  @Input() public Loading: boolean = false;
  //#endregion
  //#endregion

  //#region Refs
  /**
   * Injecte les options des référentiels chargées par le composant parent.
   * Doit être appelé après le chargement des refs et avant le premier rendu
   * de la grille. Tous les paramètres sont optionnels.
   * @param pNatureAffaire Liste des options nature de l'affaire.
   * @param pStatut Liste des options statut.
   * @param pEtatCommercial Liste des options état commercial.
   * @param pMotifBlocage Liste des options motif de blocage.
   * @param pContact Liste des options contacts.
   * @param pProperty Liste des options biens (FK propertyId).
   */
  public setRefOptions(
    pNatureAffaire?: IInputOption[],
    pStatut?: IInputOption[],
    pEtatCommercial?: IInputOption[],
    pMotifBlocage?: IInputOption[],
    pContact?: IInputOption[],
    pProperty?: IInputOption[]
  ): void {
    this.NatureAffaireOptions.set(pNatureAffaire ?? []);
    this.StatutOptions.set(pStatut ?? []);
    this.EtatCommercialOptions.set(pEtatCommercial ?? []);
    this.MotifBlocageOptions.set(pMotifBlocage ?? []);
    this.ContactOptions.set(pContact ?? []);
    this.PropertyOptions.set(pProperty ?? []);
  }

  /** Premier id des options nature de l'affaire (fallback 1 = 'vente' en BDD). */
  protected GetDefaultNatureAffaireId(): number {
    return (this.NatureAffaireOptions()[0]?.Value as number) ?? 1;
  }

  /** Premier id des options statut (undefined si pas chargé). */
  protected GetDefaultStatutId(): number | undefined {
    return this.StatutOptions()[0]?.Value as number | undefined;
  }
  //#endregion

  //#region Factories
  /** Génère un id temporaire négatif pour distinguer une nouvelle ligne. */
  protected GenerateTempId(): number {
    return GenTempId();
  }

  /** Génère une référence unique au format PREFIX-YYYYMMDDHHmmssRRR. */
  protected GenerateReference(): string {
    return GenRef(this.PREFIX);
  }

  /**
   * Crée un nouveau DTO avec id temporaire + référence générée.
   * @returns Un DTO prêt à être ajouté à la grille.
   */
  protected CreateNewRow(): TDTO {
    return { } as TDTO;
  }
  //#endregion

  //#region Type guards & Formatters
  /** Détermine si une valeur est un AdressesDTO. */
  protected IsAdressesDTO(pValue: unknown): pValue is { city?: string } {
    return IsAddr(pValue);
  }

  /**
   * Résout une option de référentiel par sa valeur.
   * - cm - Méthode mutualisée entre les grilles : utilisée par les pastilles
   * (Icon/Color/Variant) et les markers Map. Source unique de la résolution.
   * Si l'option a une `Color`, c'est elle qui pilote la pastille. Sinon
   * retour d'`undefined` → la pastille/marker est masqué.
   * @param pValue La valeur (id numérique ou code string).
   * @param pOptions Le tableau d'options à parcourir.
   * @returns L'option correspondante ou undefined.
   */
  protected ResolveOption(pValue: unknown, pOptions: IInputOption[]): IInputOption | undefined {
    if (pValue === undefined || pValue === null) {
      return undefined;
    }
    return pOptions.find((pO: IInputOption) => pO.Value === pValue);
  }
  //#endregion

  //#region i18n

  /**
   * Lit la valeur d'une clé i18n en s'abonnant au tick de chargement.
   * @param pKey Clé i18n à résoudre (ex: 'transactions.reference').
   * @param pParams Paramètres optionnels d'interpolation i18next (ex: { Nom: 'Alice' }).
   * @returns Chaîne traduite (ou la clé brute si non trouvée).
   */
  protected TranslateKey(pKey: string, pParams?: Record<string, unknown>): string {
    this.Translate.InstantTick();
    return this.Translate.translate(pKey, pParams);
  }

  /**
  /** Crée un `Signal<string>` computed pour un label i18n.
   * Le Signal est recalculé à chaque changement de langue ou chargement JSON.
   * @param pKey Clé i18n (ex: 'transactions.reference').
   * @returns Signal<string> réactif sur InstantTick.
   */
  public T(pKey: string): Signal<string> {
    return computed<string>(() => this.TranslateKey(pKey));
  }
  //#endregion

  //#region Cell edit persistence
  /**
   * Service CRUD utilisé pour persister les éditions inline d'une cellule ET
   * pour exécuter le `getAll` server-side (méthode `LoadCurrentPage`).
   * Chaque wrapper concret override ce getter pour exposer son service
   * (ex: `return this._RecrutementsService;`). Retourne `null` si la grille
   * n'a pas de persistance automatique (ex: lecture seule).
   */
  protected get Service(): ServiceBase<TDTO, TCritere> | null {
    return null;
  }

  /**
   * Convertit la nouvelle valeur si l'ancienne est numérique (cas typique d'un
   * select à valeurs id où l'app-input émet un string mais le DTO attend un number).
   * @param pOldValue L'ancienne valeur (détermine si numérique).
   * @param pNewValue La nouvelle valeur (string ou number).
   * @returns La valeur convertie ou `undefined` si vide.
   */
  public ConvertNumericValue(pOldValue: unknown, pNewValue: unknown): unknown {
    if (typeof pOldValue === 'number' && typeof pNewValue === 'string') {
      return pNewValue === '' ? undefined : Number(pNewValue);
    }
    return pNewValue;
  }

  /**
   * Applique une nouvelle valeur sur le DTO local avant persistance.
   * Par défaut, affectation directe `row[key] = value`.
   * @param pRow La ligne concernée.
   * @param pKey La clé du champ.
   * @param pValue La valeur à appliquer.
   */
  public ApplyCellValue(pRow: TDTO, pKey: string, pValue: unknown): void {
    const lRow: Record<string, unknown> = pRow as unknown as Record<string, unknown>;
    lRow[pKey] = pValue;
  }

  /**
   * Gère l'édition inline d'une cellule : convertit, applique sur le DTO local,
   * puis persiste via le service si la ligne a un id réel. En server-side, recharge
   * la page courante après l'update. Les nouvelles lignes (id négatif ou absent)
   * ne sont pas persistées ici : elles attendent la validation complète (`RowValidated`).
   *
   * Méthode à brancher sur `(CellEdited)` du `<app-grid>` interne. Les wrappers
   * qui ont besoin d'un skeleton pendant la requête peuvent override les hooks
   * `BeginEditSaving` / `EndEditSaving`.
   * @param pEvent L'événement d'édition.
   */
  public async OnCellEdited(pEvent: GridCellEditedEvent<TDTO>): Promise<void> {
    const lNewValue: unknown = this.ConvertNumericValue(pEvent.OldValue, pEvent.NewValue);
    this.ApplyCellValue(pEvent.Row, pEvent.Key, lNewValue);
    this.Recalculate(pEvent.Row);

    if (!pEvent.Row.id || pEvent.Row.id < 0) {
      return;
    }
    const lService: ServiceBase<TDTO, TCritere> | null = this.Service;
    if (!lService) {
      console.warn('[GridComponentBase.OnCellEdited] no service wired for', this.constructor.name);
      return;
    }
    this.BeginEditSaving(pEvent.Row);
    try {
      await lService.update(pEvent.Row, { id: pEvent.Row.id } as unknown as TCritere);
      await this.ReloadAfterEdit();
    } catch (pErr) {
      console.error('Erreur mise à jour', pErr, { key: pEvent.Key, value: lNewValue });
    } finally {
      this.EndEditSaving(pEvent.Row);
    }
  }

  /**
   * Hook appelé avant la requête de persistance. Par défaut no-op.
   * Les wrappers qui exposent un `ViewChild Grid` peuvent override pour
   * afficher un skeleton via `this.Grid?.SetRowSaving(pRow)`.
   * @param pRow La ligne en cours d'édition.
   */
  protected BeginEditSaving(_pRow: TDTO): void {
    // no-op par défaut
  }

  /**
   * Hook appelé après la requête de persistance (succès OU erreur).
   * Symétrique de `BeginEditSaving`.
   * @param pRow La ligne en cours d'édition.
   */
  protected EndEditSaving(_pRow: TDTO): void {
    // no-op par défaut
  }

  /**
   * Hook d'override : recalcule les champs dérivés après `ApplyCellValue`.
   * Exemple : transactions met à jour `commissionEstimee` et `revenuTotalEncaisse`
   * à partir des champs prix/honoraires. Par défaut no-op.
   * @param pRow La ligne en cours d'édition.
   */
  protected Recalculate(_pRow: TDTO): void {
    // no-op par défaut
  }

  /**
   * Hook d'override : prépare le DTO brouillon AVANT `Service.create()`.
   * Permet de pré-remplir des FK NOT NULL (ex: `userId` pour locations) ou
   * des champs calculés métier spécifiques au wrapper.
   *
   * Implémentation par défaut : pré-remplit `userId` avec `BaseComponent.CurrentUserId`
   * si la propriété existe sur le DTO et est null/undefined. Les validateurs BDD
   * déclarent `UserId.NotNull()` sur 100% des DTO CRM (cf. crm_historique_echanges,
   * crm_locations, crm_recrutements, etc.) : sans ce pré-remplissage, le create
   * échoue en 400 et la ligne disparaît côté UI. Les wrappers qui ont une logique
   * spécifique peuvent override en appelant `super.PrepareRowBeforeCreate(pRow)`
   * pour conserver le comportement par défaut.
   * - cm - Appelé dans `OnRowAdded` après `PrepareBrouillonDto` (qui delete
   *      l'id et recalcule les champs dérivés). Le DTO est déjà une copie
   *      immuable de la ligne locale : la mutation est safe.
   * @param pRow Le DTO brouillon (déjà copié, sans id).
   */
  protected PrepareRowBeforeCreate(pRow: TDTO): void {
    const lRow: Record<string, unknown> = pRow as unknown as Record<string, unknown>;
    if (!('userId' in lRow)) {
      return;
    }
    if (lRow['userId'] !== null && lRow['userId'] !== undefined) {
      return;
    }
    const lUserIdStr: string | null = this.CurrentUserId;
    if (lUserIdStr === null || lUserIdStr === '') {
      return;
    }
    const lUserId: number = Number(lUserIdStr);
    if (Number.isFinite(lUserId) && lUserId > 0) {
      lRow['userId'] = lUserId;
    }
  }

  /**
   * Recharge les données après une édition. Par défaut, ne fait rien (mode
   * client : le DTO local est la source de vérité). En server-side, les
   * wrappers surchargent pour appeler `LoadCurrentPage()`.
   */
  protected async ReloadAfterEdit(): Promise<void> {
    // no-op par défaut
  }

  //#region Outputs

  //#region RowAdded — auto-création du brouillon en BDD

  /** TrackBy anti-double POST pour `OnRowAdded`. */
  private readonly _RowAddedTracker: WeakSet<object> = new WeakSet<object>();

  /**
   * Émis par `OnRowAdded()` APRÈS la tentative de création BDD.
   * - cm - Le parent reçoit la ligne avec un vrai id (issu de `Service.create`)
   *      si la création a réussi. La garde `id > 0` dans
   *      `BaseComponent.OnBrouillonRowAdded` no-op si le parent réagit aussi à
   *      `RowAdded` (cas crm-biens avec ses `SurXxxAjoutee` legacy).
   */
  @Output() public readonly RowAdded = new EventEmitter<TDTO>();

  /**
   * Émis par `<app-grid>` quand une ligne passe tous les EditorValidator.
   * Le parent écoute pour relancer la création si nécessaire (rare : la
   * création a déjà eu lieu dans `OnRowAdded`). Voir aussi
   * `BaseComponent.OnBrouillonRowValidated` qui no-op si l'id est déjà > 0.
   */
  @Output() public readonly RowValidated = new EventEmitter<TDTO>();

  /**
   * Émis APRÈS la création BDD réussie (par `OnRowAdded`).
   * - cm - Permet au parent de déclencher ses hooks post-création (re-fetch
   *      server-side, capture PostHog, refresh marker map, etc.) sans
   *      déclencher une 2e création. Distinct de `RowAdded` qui est émis
   *      même en cas d'échec API (cf. garde anti-double-POST).
   * - cm - Avant ce fix, les parents crm-biens utilisaient `SurXxxValidee`
   *      (post-validation complète) pour recharger, pas `SurXxxAjoutee`.
   *      Avec l'auto-create dans la base, `RowCreated` est le hook propre
   *      pour re-fetch immédiatement après création.
   */
  @Output() public readonly RowCreated = new EventEmitter<TDTO>();

  /**
   * Handler par défaut pour `(RowAdded)` de `<app-grid>`.
   * - cm - Crée le brouillon en BDD via le `Service` câblé par chaque wrapper
   *      (getter `Service`). Émet ensuite `RowAdded` au parent pour la
   *      rétrocompat (PostHog, refresh UI custom, etc.). Les wrappers qui
   *      ont une logique spécifique (FK pré-remplissage custom, etc.) peuvent
   *      override cette méthode : appeler `super.OnRowAdded(pRow)` à la fin
   *      pour conserver le comportement par défaut.
   * - cm - Brancher côté template via `(RowAdded)="OnRowAdded($event)"`.
   *      Avant ce fix, les pages CRM câblaient `(RowAdded)="SurXxxAjoutee(...)"`
   *      qui délèguait à `BaseComponent.OnBrouillonRowAdded`. 7 grilles
   *      (contact, tache, projet, recrutement, objectif, prospection,
   *      historique) n'avaient même pas le binding : le bouton "Ajouter une
   *      ligne" créait une ligne locale fantôme mais aucun appel API ne partait.
   * @param pRow La nouvelle ligne émise par `<app-grid>`.
   */
  public async OnRowAdded(pRow: TDTO): Promise<void> {
    // - cm - Garde anti double-POST (réentrance RowAdded → RowValidated).
    const lId: unknown = (pRow as { id?: unknown }).id;
    if (typeof lId === 'number' && lId > 0) {
      return;
    }
    if (this._RowAddedTracker.has(pRow)) {
      return;
    }
    this._RowAddedTracker.add(pRow);

    const lService: ServiceBase<TDTO, TCritere> | null = this.Service;
    if (!lService) {
      console.warn('[GridComponentBase.OnRowAdded] no service wired for', this.constructor.name);
      // - cm - Pas de service : on émet quand même RowAdded pour ne pas casser
      //      les parents qui dépendent de l'event (rétrocompat).
      this.RowAdded.emit(pRow);
      return;
    }

    // - cm - Prépare le DTO brouillon (delete id, recalcule les champs dérivés,
    //      puis hook wrapper pour FK NOT NULL spécifiques métier).
    const lDto: TDTO | null = this.PrepareBrouillonDto(pRow, (pD: TDTO) => this.Recalculate(pD));
    if (!lDto) {
      return;
    }
    this.PrepareRowBeforeCreate(lDto);

    try {
      const lCreated: TDTO = await lService.create(lDto);
      // - cm - Remplace le brouillon local par le DTO persisté (vrai id, timestamps,
      //      valeurs back-calculées) pour que (1) la grille affiche la ligne créée
      //      avec son id réel et (2) `OnBrouillonRowAdded` côté parent no-op
      //      (garde `id > 0`).
      Object.assign(pRow, lCreated);
      // - cm - Hook post-création : le parent peut re-fetch la liste server-side
      //      ou capturer PostHog via `(RowCreated)`.
      this.RowCreated.emit(pRow);
    } catch (pErr) {
      console.error('[GridComponentBase.OnRowAdded] create failed:', pErr, { row: pRow });
      // - cm - On ne lève pas : l'erreur est loggée et le parent peut écouter
      //      (RowAdded.emit) pour afficher un popup custom.
    }

    // - cm - Émet APRÈS la tentative de create pour que le parent puisse
    //      recharger sa vue (PostHog, marker map, etc.) sans recréer.
    this.RowAdded.emit(pRow);
  }
  //#endregion

  //#region Server-side pagination helpers (typés TCritere)
  /**
   * Helper de mise à jour du critère sur changement de page. Retourne le
   * nouveau critère ou `null` si rien à changer (évite une requête inutile).
   * Les wrappers server-side l'utilisent dans leur `OnServerSidePageChange`.
   * @param pCurrent Critère actuel (typé `TCritere`).
   * @param pEvent Événement `PageChanged` de `<app-grid>`.
   * @returns Nouveau critère (immutable, même type) ou `null` si no-op.
   */
  protected ApplyPageChange(pCurrent: TCritere, pEvent: { Page: number; PageSize: number }): TCritere | null {
    if ((pCurrent.page ?? 1) === pEvent.Page && (pCurrent.pageSize ?? 25) === pEvent.PageSize) {
      return null;
    }
    return { ...pCurrent, page: pEvent.Page, pageSize: pEvent.PageSize } as TCritere;
  }

  /**
   * Helper de mise à jour du critère sur changement de tri. Les wrappers
   * server-side l'utilisent dans leur `OnServerSideSortChange`.
   * @param pCurrent Critère actuel (typé `TCritere`).
   * @param pEvent Événement `SortChanged` de `<app-grid>`.
   * @returns Nouveau critère (immutable, même type).
   */
  protected ApplySortChange(pCurrent: TCritere, pEvent: GridSortEvent): TCritere {
    const lDirection: 'asc' | 'desc' | undefined = pEvent.Direction ?? undefined;
    return { ...pCurrent, orderBy: pEvent.Key || undefined, sortDirection: lDirection } as TCritere;
  }

  /**
   * Helper de mise à jour du critère sur changement de filtre. Reset la page
   * à 1 et conserve le `pageSize` courant. Les wrappers server-side l'utilisent
   * dans leur `OnServerSideFilterChange`.
   * @param pCurrent Critère actuel (pour conserver `pageSize`).
   * @param pCritere Nouveau critère émis par `<app-grid>`.
   * @returns Nouveau critère (immutable, même type).
   */
  protected ApplyFilterChange(pCurrent: TCritere, pCritere: BaseCritereDTO): TCritere {
    return { ...pCritere, page: 1, pageSize: pCurrent.pageSize ?? 25 } as TCritere;
  }
  //#endregion

  //#region Server-side pagination (typé TCritere)
  /**
   * Active le mode server-side. Défaut `false` (mode client historique).
   * Les wrappers server-side positionnent `[ServerSide]="true"` côté template parent.
   */
  @Input() public ServerSide: boolean = true;

  /**
   * Critère initial passé par le parent en mode server-side. Les champs `page`,
   * `pageSize` et `sortDirection` sont imposés si absents. Surchargeable via
   * `BuildCritereFromInit` pour les grilles qui ont des défauts spécifiques
   * (ex: Recrutement injecte `contact: {}`).
   * @param pValue Critère initial.
   */
  @Input() public set CritereInit(pValue: TCritere | null) {
    this._CritereInit = pValue;
    this.Critere.set(this.BuildCritereFromInit(pValue));
  }
  public get CritereInit(): TCritere | null { return this._CritereInit; }
  private _CritereInit: TCritere | null = null;

  /**
   * Construit le critère initial à partir de l'input `CritereInit`. Les
   * wrappers qui ont des défauts métier (ex: Recrutement injecte `contact: {}`)
   * surchargent cette méthode.
   * @param pInit Critère initial fourni par le parent (peut être `null`).
   * @returns Le critère initial typé `TCritere`.
   */
  protected BuildCritereFromInit(pInit: TCritere | null): TCritere {
    const lInit: Partial<TCritere> = (pInit ?? {}) as Partial<TCritere>;
    return {
      ...lInit,
      page: (lInit.page ?? 1) as TCritere['page'],
      pageSize: (lInit.pageSize ?? 25) as TCritere['pageSize'],
      sortDirection: (lInit.sortDirection ?? 'desc') as TCritere['sortDirection']
    } as TCritere;
  }

  /** Critère courant en mode server-side. Mis à jour par les handlers `OnServerSide*Change`. */
  public readonly Critere = signal<TCritere>(this.BuildCritereFromInit(null));
  /** Données chargées en mode server-side. Vides tant que le premier `getAll` n'a pas abouti. */
  public readonly ServerSideData = signal<TDTO[]>([]);
  /** Indicateur de chargement server-side. */
  public readonly ServerSideLoading = signal<boolean>(false);
  /** Message d'erreur server-side (null si OK). */
  public readonly ServerSideErrorMessage = signal<string | null>(null);

  /** Émis après un chargement server-side réussi (tableau retourné). */
  @Output() public readonly ServerSideLoaded = new EventEmitter<TDTO[]>();
  /** Émis en cas d'erreur lors d'un chargement server-side. */
  @Output() public readonly ServerSideError = new EventEmitter<string>();

  //#region Delete popups (state + handlers par défaut)
  /**
   * Ligne en cours de suppression (pour la popup de confirmation).
   * - cm - La popup de suppression simple est gérée par défaut dans la base :
   *      les wrappers n'ont plus besoin de déclarer `RowToDelete` / `ShowDeletePopup`
   *      ni les handlers `OnActionClicked/OnConfirmDelete/OnCancelDelete` côté parent.
   *      Il suffit de brancher `(ActionClicked)="OnActionClicked($event)"` sur la grid.
   *      Idem pour la sélection en lot via `(SelectionChanged)="OnSelectionChanged($event)"`.
   */
  public readonly RowToDelete = signal<TDTO | null>(null);
  /** Indique si la popup de suppression est ouverte. */
  public ShowDeletePopup = false;
  /** Indique si la suppression est en cours (spinner sur le bouton confirmer). */
  public readonly Deleting = signal(false);
  /** Lignes actuellement sélectionnées (pour suppression en lot). */
  public readonly SelectedRows = signal<TDTO[]>([]);
  /** Indique si la popup de suppression en lot est ouverte. */
  public ShowBulkDeletePopup = false;

  /**
   * Handler (ActionClicked) émis par `<app-grid>`. Ouvre la popup de suppression si l'action est 'delete'.
   * Les autres actions (edit, etc.) sont remontées au parent via l'output `ActionClicked`.
   * @param pEvent L'événement d'action.
   */
  public OnActionClicked(pEvent: GridActionEvent<TDTO>): void {
    if (pEvent.Action === 'delete' && pEvent.Row?.id && pEvent.Row.id > 0) {
      this.RowToDelete.set(pEvent.Row);
      this.ShowDeletePopup = true;
      return;
    }
    this.ActionClicked.emit(pEvent);
  }

  /**
   * Confirme la suppression depuis la popup.
   * - cm - Utilise `Service.delete({ id })` exposé par la base. Recharge ensuite
   *      la page courante pour refléter la suppression côté UI.
   */
  public async OnConfirmDelete(): Promise<void> {
    const lRow: TDTO | null = this.RowToDelete();
    if (!lRow || !lRow.id) {
      this.ShowDeletePopup = false;
      this.RowToDelete.set(null);
      return;
    }
    const lService: ServiceBase<TDTO, TCritere> | null = this.Service;
    if (!lService) {
      console.warn('[GridComponentBase.OnConfirmDelete] no service wired for', this.constructor.name);
      this.ShowDeletePopup = false;
      this.RowToDelete.set(null);
      return;
    }
    this.Deleting.set(true);
    try {
      await lService.delete({ id: lRow.id } as unknown as TCritere);
      if (this.ServerSide) { await this.LoadCurrentPage(); }
    } catch (pErr) {
      console.error('[GridComponentBase.OnConfirmDelete] failed:', pErr);
    } finally {
      this.Deleting.set(false);
      this.ShowDeletePopup = false;
      this.RowToDelete.set(null);
    }
  }

  /**
   * Annule la suppression (ferme la popup).
   */
  public OnCancelDelete(): void {
    this.ShowDeletePopup = false;
    this.RowToDelete.set(null);
  }

  /**
   * Mémorise la sélection courante (émise par `<app-grid>` `(SelectionChanged)`).
   * @param pRows Les lignes sélectionnées.
   */
  public OnSelectionChanged(pRows: TDTO[]): void {
    this.SelectedRows.set(pRows ?? []);
  }

  /**
   * Ouvre la popup de confirmation de suppression en lot (déclenché par le slot `gridBulkActions`).
   */
  public OnAskBulkDelete(): void {
    if (this.SelectedRows().length === 0) { return; }
    this.ShowBulkDeletePopup = true;
  }

  /**
   * Annule la suppression en lot.
   */
  public OnCancelBulkDelete(): void {
    this.ShowBulkDeletePopup = false;
  }

  /**
   * Confirme la suppression en lot : boucle sur tous les ids sélectionnés en parallèle via `Promise.allSettled`.
   * - cm - `Promise.allSettled` (PAS `Promise.all`) : si une requête échoue, les autres
   *      sont tentées quand même. Track PostHog via le `Service` (déjà automatique).
   */
  public async OnConfirmBulkDelete(): Promise<void> {
    const lRows: TDTO[] = this.SelectedRows();
    const lIds: number[] = lRows
      .map((pR) => pR.id)
      .filter((pId): pId is number => typeof pId === 'number' && pId > 0);
    const lService: ServiceBase<TDTO, TCritere> | null = this.Service;
    if (lIds.length === 0 || !lService) {
      this.ShowBulkDeletePopup = false;
      return;
    }
    this.Deleting.set(true);
    await Promise.allSettled(
      lIds.map((pId) => lService.delete({ id: pId } as unknown as TCritere))
    );
    this.Deleting.set(false);
    this.ShowBulkDeletePopup = false;
    this.SelectedRows.set([]);
    this.BulkDeleteCompleted.emit({ Count: lIds.length });
    if (this.ServerSide) { await this.LoadCurrentPage(); }
  }

  /**
   * Output émis après une suppression en lot réussie. Le parent peut s'y
   * brancher pour tracker l'événement côté PostHog (`count`).
   */
  @Output() public readonly BulkDeleteCompleted = new EventEmitter<{ Count: number }>();
  /**
   * Output émis pour les actions de ligne non gérées par la base (edit, etc.).
   * Les wrappers ReadOnly peuvent s'y brancher pour no-op.
   */
  @Output() public readonly ActionClicked = new EventEmitter<GridActionEvent<TDTO>>();
  //#endregion

  //#region Effective getters
  /**
   * Données effectivement passées à `<app-grid [Data]>`.
   * - cm - Méthode (et non `computed`) parce qu'elle lit principalement des
   *      @Input primitifs (`this.ServerSide`, `this.Data`). Un `computed` ne
   *      se ré-évalue que quand un Signal qu'il a lu change ; ici, seul
   *      `ServerSideData` est un Signal. Le parent fait `Data = [...]` après
   *      la résolution de la requête API, l'input est mis à jour par Angular
   *      mais le `computed` ne se redéclenche pas. Une méthode est appelée à
   *      chaque change detection cycle et reste synchronisée.
   *      Cf. branche `fix/crm-grid-effective-loading-getter` (août 2026).
   * @returns Les données en server-side ou les données du parent en client.
   */
  public EffectiveData(): BaseDTO[] { return this.ServerSide ? (this.ServerSideData() as BaseDTO[]) : (this.Data as BaseDTO[]); }
  /** Indicateur de chargement effectivement passé à `<app-grid [Loading]>`. */
  public EffectiveLoading(): boolean { return this.ServerSide ? (this.Loading || this.ServerSideLoading()) : this.Loading; }
  /** Message d'erreur effectivement passé à `<app-grid [Error]>`. */
  public EffectiveError(): string | null { return this.ServerSide ? this.ServerSideErrorMessage() : null; }
  //#endregion

  /**
   * Charge la page courante depuis le back. Délègue à `Service.getAll(this.Critere())`.
   * - cm - No-op en mode client (parent gère).
   * - cm - Alimente `ServerSideData/Loading/ErrorMessage` et émet les outputs
   *      `ServerSideLoaded` (longueur) et `ServerSideError` (message).
   *      Le tag console est générique (préfixe par nom de classe).
   */
  public async LoadCurrentPage(): Promise<void> {
    if (!this.ServerSide) { return; }
    this.ServerSideLoading.set(true);
    this.ServerSideErrorMessage.set(null);
    try {
      const lService: ServiceBase<TDTO, TCritere> | null = this.Service;
      if (!lService) {
        console.warn('[GridComponentBase.LoadCurrentPage] no service wired for', this.constructor.name);
        return;
      }
      const lData: TDTO[] = await lService.getAll(this.Critere());
      this.ServerSideData.set(lData ?? []);
      this.ServerSideLoaded.emit(lData ?? []);
    } catch (pErr: unknown) {
      const lMessage: string = pErr instanceof Error ? pErr.message : 'Erreur de chargement server-side.';
      this.ServerSideErrorMessage.set(lMessage);
      this.ServerSideError.emit(lMessage);
      console.error(`[${this.constructor.name}] server-side load failed:`, pErr);
    } finally {
      this.ServerSideLoading.set(false);
    }
  }

  /** Handler (PageChanged) émis par `<app-grid>`. */
  public async OnServerSidePageChange(pEvent: { Page: number; PageSize: number }): Promise<void> {
    const lNext: TCritere | null = this.ApplyPageChange(this.Critere(), pEvent);
    if (!lNext) { return; }
    this.Critere.set(lNext);
    await this.LoadCurrentPage();
  }
  /** Handler (SortChanged) émis par `<app-grid>`. */
  public async OnServerSideSortChange(pEvent: GridSortEvent): Promise<void> {
    this.Critere.set(this.ApplySortChange(this.Critere(), pEvent));
    await this.LoadCurrentPage();
  }
  /** Handler (FilterChanged) émis par `<app-grid>`. */
  public async OnServerSideFilterChange(pCritere: BaseCritereDTO): Promise<void> {
    this.Critere.set(this.ApplyFilterChange(this.Critere(), pCritere));
    await this.LoadCurrentPage();
  }
  //#endregion

  //#region Auto-subscription to <app-grid> events (AfterViewInit)
  /**
   * Subscriptions vers les events du `<app-grid>` enfant pour piloter la pagination
   * server-side de manière générique (sans bindings manuels dans les templates).
   * - cm - Constituées dans `ngAfterViewInit`, nettoyées dans `ngOnDestroy`.
   */
  private _GridSubscriptions: { unsubscribe(): void }[] = [];

  /**
   * S'abonne automatiquement aux outputs `PageChanged`, `SortChanged`, `FilterChanged`
   * du `<app-grid>` enfant résolu via `viewChild(GridComponent)`.
   * - cm - Aucune action requise côté template enfant : la pagination native fonctionne
   *      dès qu'il y a un `<app-grid>` dans le template HTML du wrapper. Les wrappers
   *      qui surchargent `OnServerSidePageChange` / `OnServerSideSortChange` /
   *      `OnServerSideFilterChange` conservent leur override (appelé via `super`).
   */
  public ngAfterViewInit(): void {
    const lGrid: GridComponent<TDTO, TCritere> | undefined = this._Grid();
    if (!lGrid) {
      console.warn('[GridComponentBase.ngAfterViewInit] no <app-grid> found in template for', this.constructor.name);
      return;
    }
    this._SubscribeToGridEvents(lGrid);
  }

  private _SubscribeToGridEvents(pGrid: GridComponent<TDTO, TCritere>): void {
    // On se désabonne d'abord (au cas où ngAfterViewInit serait rappelé)
    for (const lSub of this._GridSubscriptions) { lSub.unsubscribe(); }
    this._GridSubscriptions = [
      pGrid.PageChanged.subscribe((p) => { void this.OnServerSidePageChange(p); }),
      pGrid.SortChanged.subscribe((p) => { void this.OnServerSideSortChange(p); }),
      pGrid.FilterChanged.subscribe((p) => { void this.OnServerSideFilterChange(p); })
    ];
  }

  /** @inheritdoc */
  public ngOnDestroy(): void {
    for (const lSub of this._GridSubscriptions) { lSub.unsubscribe(); }
    this._GridSubscriptions = [];
  }
  //#endregion
}
