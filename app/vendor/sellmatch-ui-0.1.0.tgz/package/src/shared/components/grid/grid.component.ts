import {
  Component,
  Input,
  Output,
  EventEmitter,
  computed,
  signal,
  effect,
  ChangeDetectionStrategy,
  OnInit,
  OnDestroy,
  inject,
  PLATFORM_ID,
  ContentChildren,
  QueryList,
  AfterContentInit,
  TemplateRef,
  ElementRef,
  HostListener,
  ViewChild,
  NgZone
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {NgTemplateOutlet} from '@angular/common';
import {AbstractControl, FormControl, ReactiveFormsModule, ValidationErrors, ValidatorFn} from '@angular/forms';
import {BaseComponent} from '../../../core/base/BaseComponent';
import {InputComponent} from '../../../shared/components/input/input.component';
import {IInputOption} from '../../../shared/components/input/input.types';
import {ScrollIntoVisibleArea} from '../../../shared/components/input/helpers/input-scroll-into-view.helper';
import {ButtonComponent} from '../../../shared/components/button/button.component';
import {TooltipComponent, type TooltipLine} from '../../../shared/components/tooltip/tooltip.component';
import {
  FilterBarComponent,
  FilterFieldConfig,
  FilterFieldType,
  FilterSchemaField
} from '../../../shared/components/FilterBar/filter-bar.component';
import {PaginationComponent} from '../../../shared/components/pagination/pagination.component';
import {BaseCritereDTO} from '../../../core/base/base.critere';
import {GridColumnDirective} from './grid-column.directive';
import {GridSkeletonComponent} from '../../../shared/components/grid-skeleton/grid-skeleton.component';
import {SkeletonComponent} from '../../../shared/components/skeleton/skeleton.component';
import {MessageDisplayComponent} from '../../../shared/components/message-display/message-display.component';
import {GRID_ZOOM, MIN_COLUMN_WIDTH, GridBase} from './grid-base';
import {GridXlsxExportService, ExcelColumnRequest, IExcelExportRequest} from './grid-xlsx-export.service';
import {GridExportComponent} from './grid-export.component';
import {ContextMenuComponent} from '../../../shared/components/context-menu/context-menu.component';
import {AlertService} from '../../../core/services/alert/alert.service';
import {GridZoomService} from '../../../core/services/grid-zoom/GridZoomService';
import {GridPaginationService} from '../../../core/services/grid-pagination/GridPaginationService';
import {TranslateKeyPipe} from '../../../core/services/i18n/TranslateKeyPipe';
// - cm - GridColumn defini dans `./GridColumn` (source unique). Re-exporte ici
//      pour que les consommateurs (`crm-biens.component.ts`, `playground-ai-section.component.ts`)
//      puissent faire `import { GridColumn } from '../../../shared/components/grid/grid.component'`.
import {GridColumn} from './GridColumn';
import {BaseDTO} from "../../../core/base/BaseDTO";

/**
 * État de tri émis lors d'un changement.
 */
export interface GridSortEvent {
  /** Clé de la colonne triée. */
  Key: string;
  /** Direction : `asc`, `desc` ou null (tri désactivé). */
  Direction: 'asc' | 'desc' | null;
}

/**
 * État d'une action émise depuis une ligne.
 * @typeParam TDTO Type de la ligne (DTO).
 */
export interface GridActionEvent<TDTO> {
  /** Identifiant de l'action (ex: `edit`, `delete`). */
  Action: string;
  /** Ligne concernée. */
  Row: TDTO;
}

/**
 * Événement émis après édition inline d'une cellule.
 * @typeParam TDTO Type de la ligne (DTO).
 */
export interface GridCellEditedEvent<TDTO> {
  /** Ligne concernée. */
  Row: TDTO;
  /** Clé de la colonne éditée. */
  Key: string;
  /** Valeur avant édition. */
  OldValue: unknown;
  /** Valeur après édition (typée selon EditorType). */
  NewValue: unknown;
  /** Index de la ligne dans Data (pas SortedData). */
  RowIndex: number;
}

/**
 * Tableau personnalisable type Excel, générique et réutilisable.
 * Coeur de la concurrence : tri, colonnes masquables et réordonnables,
 * en-tête collante, états loading/empty, ligne cliquable, colonne d'actions.
 * @typeParam TDTO Type de la ligne (DTO).
 */
@Component({
  selector: 'app-grid',
  standalone: true,
  imports: [NgTemplateOutlet, ReactiveFormsModule, InputComponent, ButtonComponent, FilterBarComponent, PaginationComponent, TooltipComponent, GridSkeletonComponent, SkeletonComponent, MessageDisplayComponent, ContextMenuComponent, GridExportComponent, TranslateKeyPipe],
  templateUrl: './grid.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: './grid.component.scss'
})
export class GridComponent<TDTO extends BaseDTO, TCritere extends BaseCritereDTO = BaseCritereDTO> extends GridBase<TDTO, TCritere> implements OnInit, OnDestroy, AfterContentInit {

  //#region Properties

  /** Colonnes déclarées en content projection via `<app-grid-column>`. */
  @ContentChildren(GridColumnDirective) ColumnDirectives?: QueryList<GridColumnDirective<TDTO>>;

  /** Texte affiché quand le tableau est vide. */
  @Input() EmptyText = 'Aucune donnée à afficher.';
  /**
   * Clé i18n du texte vide. Si fournie, le grid la traduit via le pipe `tkey` en
   * priorité sur `EmptyText`. Réactif sur les changements de langue.
   */
  @Input() EmptyTextCle?: string;
  /** Active le clic sur une ligne (emit RowClicked). */
  @Input() RowClickable = true;
  /** Libellé de l'action d'édition (masqué si vide). */
  @Input() EditActionLabel = 'Modifier';
  /** Clé i18n du libellé de l'action d'édition. Voir `EmptyTextCle` pour la sémantique. */
  @Input() EditActionLabelCle?: string = 'grid.actions.edit';
  /** Libellé de l'action de suppression (masqué si vide). */
  @Input() DeleteActionLabel = 'Supprimer';
  /** Clé i18n du libellé de l'action de suppression. Voir `EmptyTextCle` pour la sémantique. */
  @Input() DeleteActionLabelCle?: string = 'grid.actions.delete';
  /** Active la zébra sur les lignes. */
  @Input() Zebra = true;
  /** Active l'ajout de ligne direct (comme Excel) : affiche une ligne "Ajouter" en bas du tableau. */
  @Input() AllowAddRow = false;
  /**
   * Ajoute automatiquement une nouvelle ligne vide dès qu'un champ de la dernière ligne est rempli.
   * Permet de ne pas perdre le brouillon en cours. Nécessite AllowAddRow=true et NewRowFactory.
   */
  @Input() AutoAddRow = false;
  /** Factory créant un nouveau DTO vide pour l'ajout de ligne. Requis si AllowAddRow=true. */
  @Input() NewRowFactory: (() => TDTO) | null = null;
  /** Active la barre de filtre intégrée (app-filter-bar) au-dessus du tableau. */
  @Input() Filterable = false;
  /** Clés exclues du schéma (quand FilterSchema est utilisé). */
  @Input() FilterExcludedKeys: string[] = [];
  /** Si true, auto-génère les colonnes depuis les propriétés du premier DTO quand aucune colonne n'est fournie. Défaut: false. */
  @Input() AutoColumns = false;
  /** Clés à exclure de l'auto-génération (ex: ['id', 'createdAt', 'updatedAt']). */
  @Input() ExcludeColumns: string[] = [];
  /** Barre de filtre repliable. Défaut: true. */
  @Input() FilterCollapsible = true;
  /** Barre de filtre repliée au démarrage. Défaut: false (ouverte pour visibilité). */
  @Input() FilterStartCollapsed = false;
  /** Active la sélection de lignes via checkboxes (défaut: false). */
  @Input() Selectable = false;
  /**
   * Contexte logique de la grille pour la persistance de la taille de page.
   * - cm - Permet a chaque page parente (crm-prospection, crm-contacts, etc.)
   * d'avoir sa propre pref de pagination en BDD. La cle finale sera
   * `grid.pageSize.<PaginationContext>` (cf. GridPaginationService).
   * - cm - Valeur par defaut 'default' : une grille qui ne precise rien
   * partage la pref globale. Toutes les grilles SellMatch specifient leur
   * propre contexte (cf. les pages CRM qui passent leur identifiant).
   */
  @Input() PaginationContext: string = 'default';
  /** Active le bouton d'export CSV (défaut: false). */
  @Input() AllowExport = false;
  /** Nom du fichier exporté (défaut: 'export.csv'). Conservé pour rétro-compatibilité : si défini, surcharge le nom horodaté. */
  @Input() ExportFileName = 'export.csv';
  /**
   * Chemin complet de l'endpoint backend d'export XLSX (ex: '/api/Candidats/ExportXlsx').
   * Si défini, le bouton d'export appellera ce endpoint pour générer un fichier XLSX stylisé SellMatch.
   * Si null, l'export reste en CSV (fallback).
   */
  @Input() ExportApiPath: string | null = null;
  /**
   * Nom de l'utilisateur qui exporte (pour les métadonnées XLSX : bandeau d'en-tête + onglet Métadonnées).
   * Si null, le backend utilise 'Utilisateur' par défaut.
   */
  @Input() ExportUserName: string | null = null;
  /**
   * Format d'export proposé dans la toolbar :
   * - 'csv' : un seul bouton "Exporter CSV" (toujours fonctionnel, pas besoin d'ExportApiPath).
   * - 'xlsx' : un seul bouton "Exporter Excel" (nécessite ExportApiPath, fallback CSV si absent).
   * - 'both' : dropdown avec les deux options (CSV toujours dispo, XLSX nécessite ExportApiPath).
   * Défaut : 'xlsx' (le composant choisit dynamiquement selon la présence d'ExportApiPath).
   */
  @Input() ExportFormat: 'csv' | 'xlsx' | 'both' = 'xlsx';
  /** Active le système de zoom (boutons dans la toolbar + raccourcis clavier). Défaut: true. */
  @Input() Zoomable = true;
  /** Active les raccourcis clavier Ctrl+/Ctrl-/Ctrl+0 pour le zoom. Défaut: true. */
  @Input() ZoomKeyboardShortcuts = true;
  /** Active le bouton plein écran dans la toolbar. Défaut: true. */
  @Input() Fullscreenable = true;

  //#region Outputs
  /** Émis quand le tri change. */
  @Output() SortChanged = new EventEmitter<GridSortEvent>();
  /** Émis quand une ligne est cliquée. */
  @Output() RowClicked = new EventEmitter<TDTO>();
  /** Émis quand une action est cliquée sur une ligne. */
  @Output() ActionClicked = new EventEmitter<GridActionEvent<TDTO>>();
  /** Émis quand une cellule est éditée inline. */
  @Output() CellEdited = new EventEmitter<GridCellEditedEvent<TDTO>>();
  /** Émis quand une nouvelle ligne est ajoutée (via la ligne "Ajouter" en bas). */
  @Output() RowAdded = new EventEmitter<TDTO>();
  /** Émis quand les filtres changent (valeurs BaseCritereDTO). Pour filtre serveur si ClientFilter=false. */
  @Output() FilterChanged = new EventEmitter<BaseCritereDTO>();
  /** Émis quand la sélection de lignes change (si Selectable=true). */
  @Output() SelectionChanged = new EventEmitter<TDTO[]>();
  /** Émis quand la page ou la taille de page change (si Paginated=true). */
  @Output() PageChanged = new EventEmitter<{ Page: number; PageSize: number }>();
  /**
   * Émis quand une ligne passe tous les checks de validation (tous les EditorValidator des colonnes éditables
   * retournent null). Le parent doit alors créer la ligne en BDD. Émis une seule fois par ligne (au passage error->valid).
   */
  @Output() RowValidated = new EventEmitter<TDTO>();
  /** Émis quand une ligne devient invalide après édition (au moins un EditorValidator retourne une erreur). */
  @Output() RowInvalid = new EventEmitter<{ Row: TDTO; Errors: Record<string, string> }>();
  /**
   * Émis à la fin d'un export CSV avec les métadonnées de l'opération.
   * Permet au parent de tracker (PostHog custom, logs, toasts) sans intercepter le download.
   */
  @Output() Exported = new EventEmitter<{ Count: number; Filename: string; HasFilter: boolean; HasSort: boolean }>();
  /** Émis quand une colonne précédemment masquée est restaurée (réaffichée) depuis le menu "Colonnes". */
  @Output() ColumnRestored = new EventEmitter<string>();
  /**
   * Émis quand l'utilisateur clique sur le bouton "Réessayer" affiché à côté du message d'erreur.
   * Le parent doit alors relancer le chargement des données (et réinitialiser `Error` à `null`).
   */
  @Output() ErrorRetry = new EventEmitter<void>();
  //#endregion

  /** Clé de tri courante. */
  protected readonly SortKey = signal<string | null>(null);
  /** Direction du tri : asc, desc ou null. */
  protected readonly SortDirection = signal<'asc' | 'desc' | null>(null);
  /** Ordre des clés de colonnes (réordonnancement). */
  protected readonly ColumnOrder = signal<string[]>([]);
  /** Ensemble des clés de colonnes masquées. */
  protected readonly HiddenColumns = signal<Set<string>>(new Set());
  /** Lignes skeleton pour le loading (tableau de 8 indices pour @for). */
  protected readonly SkeletonRows = signal<number[]>([0, 1, 2, 3, 4, 5, 6, 7]);
  /** Clé (TrackBy) de la ligne en cours d'édition inline. */
  protected readonly EditingRowKey = signal<string | null>(null);
  /** Clé de la colonne en cours d'édition inline. */
  protected readonly EditingColKey = signal<string | null>(null);
  /** Valeur courante de l'éditeur inline. */
  protected readonly EditValue = signal<string>('');
  /** Message d'erreur de validation de l'éditeur inline (null si valide). */
  protected readonly EditError = signal<string | null>(null);
  /** FormControl réactif pour l'éditeur inline courant (app-input). Source de vérité pour les éditeurs text/number/date/select. */
  protected readonly EditorControl = signal<FormControl>(new FormControl(''));
  /**
   * Stockage des valeurs en cours d'édition pour le mode ShowEditor (consultation = édition permanente).
   * Map indexée par `${rowKey}|${colKey}` pour gérer N cellules simultanément sans collision
   * (un signal partagé ferait perdre la valeur dès qu'une autre cellule prend le focus).
   * Clé = 'rowKey|colKey', valeur = dernière valeur émise par l'<app-input> via (valueChange).
   * Lu par CommitShowEditorValue au blur pour décider de la valeur à persister.
   */
  protected readonly ShowEditorDraft = signal<Map<string, unknown>>(new Map());
  /** Ensemble des clés (TrackBy) des lignes sélectionnées. */
  protected readonly SelectedKeys = signal<Set<string>>(new Set());
  /** Ensemble des clés (TrackBy) des lignes marquées dirty (modifiées non confirmées). */
  protected readonly DirtyKeys = signal<Set<string>>(new Set());
  /** État de validation de chaque ligne (clé TrackBy -> 'error' | 'valid'). Absent = pristine/non validée. */
  protected readonly RowStates = signal<Map<string, 'error' | 'valid'>>(new Map());
  /** Clés des lignes en cours de sauvegarde API (skeleton overlay). */
  protected readonly SavingRowKeys = signal<Set<string>>(new Set());
  /** Clés des cellules en cours de sauvegarde API (skeleton overlay sur la cellule seule). Format : `rowKey|colKey`. */
  protected readonly SavingCellKeys = signal<Set<string>>(new Set());
  /** Errors par ligne (clé TrackBy -> { colKey: message }). Pour l'affichage inline éventuel. */
  protected readonly RowErrors = signal<Map<string, Record<string, string>>>(new Map());
  /** Requête de recherche courante pour l'éditeur select-search. */
  protected readonly SearchQuery = signal<string>('');
  /** Indique si le dropdown de l'éditeur select-search est ouvert. */
  protected readonly SearchOpen = signal<boolean>(false);
  /** Menu contextuel d'en-tête (clic droit) : position écran + colonne ciblée. */
  protected readonly ContextMenu = signal<{ X: number; Y: number; Column: GridColumn<TDTO> } | null>(null);
  /** Largeurs de colonnes personnalisées par redimensionnement (clé -> largeur CSS). */
  protected readonly ColumnWidths = signal<Record<string, string>>({});
  /** Clé de la colonne en cours de redimensionnement (null si aucun drag). */
  protected readonly ResizingKey = signal<string | null>(null);
  /** Colonnes épinglées : clé de colonne → bord ('left' | 'right'). Vides par défaut. Persistées dans localStorage. */
  protected readonly StickyColumns = signal<Map<string, 'left' | 'right'>>(new Map());
  /** Colonne Actions épinglée à droite (sticky). Vrai par défaut : la colonne Actions reste visible pendant le scroll horizontal, alignée sur le pattern Excel/Outlook. Persisté dans localStorage. */
  protected readonly ActionsSticky = signal<boolean>(true);
  /** Valeurs courantes des filtres. */
  protected readonly FilterValues = signal<BaseCritereDTO>({} as BaseCritereDTO);
  /** Indique si la grille est actuellement en mode plein écran. Synchronisé via l'API Fullscreen standard. */
  protected readonly IsFullscreen = signal<boolean>(false);
  /** Indique si au moins une colonne est actuellement masquée. */
  protected readonly HasHiddenColumns = computed<boolean>(() =>
    this.HiddenColumns().size > 0
  );
  /**
   * Offsets CSS (px) pour les colonnes sticky : clé de colonne → 'left:Npx' | 'right:Npx'.
   * Calculé depuis VisibleColumns dans l'ordre visuel : chaque colonne sticky-left empilée
   * reçoit un `left` croissant = somme des largeurs effectives des colonnes sticky-left
   * qui la précèdent. Idem côté droit pour `right` décroissant (parcours inverse).
   * Les largeurs proviennent de _RenderedWidths (mesurées DOM) sinon Width déclaré (fallback).
   */
  protected readonly StickyOffsets = computed<Map<string, string>>(() => {
    const lCols: GridColumn<TDTO>[] = this.VisibleColumns();
    const lSticky: Map<string, 'left' | 'right'> = this.StickyColumns();
    const lOffsets: Map<string, string> = new Map();
    // - cm - Sticky-left : parcours gauche -> droite, on cumule les largeurs effectives
    let lLeftPx: number = 0;
    for (const lCol of lCols) {
      const lKey: string = String(lCol.Key);
      if (lSticky.get(lKey) === 'left') {
        lOffsets.set(lKey, `left:${lLeftPx}px`);
        lLeftPx += this.GetColumnWidthPx(lCol);
      }
    }

    // - cm - Si la colonne Actions est sticky, les colonnes sticky-right utilisateur démarrent
    // - cm - après sa largeur (96px) pour ne pas se superposer à elle.
    let lRightPx: number = 0;
    if (this.ActionsSticky() && (this.EditActionLabel || this.DeleteActionLabel)) {
      lRightPx = 96;
    }
    for (let i: number = lCols.length - 1; i >= 0; i--) {
      const lCol: GridColumn<TDTO> = lCols[i];
      const lKey: string = String(lCol.Key);
      if (lSticky.get(lKey) === 'right') {
        lOffsets.set(lKey, `right:${lRightPx}px`);
        lRightPx += this.GetColumnWidthPx(lCol);
      }
    }
    return lOffsets;
  });
  /** Colonnes passées via @Input (alternative aux directives). */
  private readonly _InputColumns = signal<GridColumn<TDTO>[]>([]);

  //#endregion

  /** Abonnements aux événements columnsRefresh des directives <app-grid-column>. */
  private _DirectiveSubs: (() => void)[] = [];
  /** Colonnes finales (input OU directives), signal recompute. */

  private readonly _Columns = signal<GridColumn<TDTO>[]>([]);
  //#region Computed
  /** Colonnes ordonnées selon ColumnOrder. */
  protected readonly OrderedColumns = computed<GridColumn<TDTO>[]>(() => {
    const lColumns: GridColumn<TDTO>[] = this._Columns();
    const lOrder: string[] = this.ColumnOrder();
    if (lOrder.length === 0) {
      return lColumns;
    }
    const lMap: Map<string, GridColumn<TDTO>> = new Map(lColumns.map((lCol) => [String(lCol.Key), lCol]));
    const lOrdered: GridColumn<TDTO>[] = lOrder
      .map((lKey) => lMap.get(lKey))
      .filter((lCol): lCol is GridColumn<TDTO> => lCol !== undefined);
    // - cm - Ajoute les colonnes non présentes dans l'ordre sauvegardé
    for (const lCol of lColumns) {
      if (!lOrder.includes(String(lCol.Key))) {
        lOrdered.push(lCol);
      }
    }
    return lOrdered;
  });
  /** Colonnes visibles (non masquées). */
  protected readonly VisibleColumns = computed<GridColumn<TDTO>[]>(() => {
    const lHidden: Set<string> = this.HiddenColumns();
    return this.OrderedColumns().filter((lCol) => !lHidden.has(String(lCol.Key)));
  });
  /** Indique si au moins une colonne est masquable. */
  protected readonly HasHideableColumns = computed<boolean>(() =>
    this.OrderedColumns().some((lCol) => lCol.Hideable !== false)
  );
  protected readonly HiddenColumnsList = computed<GridColumn<TDTO>[]>(() => {
    const lHidden: Set<string> = this.HiddenColumns();
    return this.OrderedColumns().filter((lCol) => lHidden.has(String(lCol.Key)));
  });
  private readonly _Data = signal<TDTO[]>([]);
  /** Données triées côté client selon SortKey/SortDirection. */
  protected readonly SortedData = computed<TDTO[]>(() => {
    const lData: TDTO[] = this._Data();
    const lKey: string | null = this.SortKey();
    const lDirection: 'asc' | 'desc' | null = this.SortDirection();
    if (!lKey || !lDirection) {
      return lData;
    }
    const lSorted: TDTO[] = [...lData];
    lSorted.sort((pA, pB) => {
      const lValueA: unknown = this.GetCellValue(pA, lKey);
      const lValueB: unknown = this.GetCellValue(pB, lKey);
      return this.CompareValues(lValueA, lValueB, lDirection);
    });
    return lSorted;
  });
  private readonly _Loading = signal(false);
  /**
   * Message d'erreur courant (signal-backed input). Null → pas d'erreur affichée.
   * Utilisé pour basculer la grille en état "Error" (masque toolbar/table/pagination).
   */
  private readonly _Error = signal<string | null>(null);
  /** Référence DOM de la cellule en cours d'édition (la <td> cliquée). Permet à FocusEditor de cibler précisément la cellule éditée sans dépendre d'un querySelector qui retourne le premier match du DOM. */
  private readonly _EditingCellRef = signal<HTMLElement | null>(null);
  /** Référence vers l'élément DOM du menu contextuel (pour le clamp viewport). */
  @ViewChild('contextMenu') private _ContextMenuRef?: ElementRef<HTMLElement>;
  /** Position X de départ du drag resize (clientX). */
  private _ResizeStartX = 0;
  /** Position X du bord gauche du th au début du drag resize (px). */
  private _ResizeStartLeft = 0;
  /** Largeur rendue du th au début du drag resize (px), base du calcul delta continu sans saut. */
  private _ResizeStartWidth = 0;
  /** Page courante (signal-backed input). */
  private readonly _Page = signal<number>(1);
  /** Taille de page courante (signal-backed input). */
  private readonly _PageSize = signal<number>(25);
  /** Total lignes serveur (signal-backed input). */
  private readonly _Total = signal<number>(0);
  /** Champs de filtre déclarés via @Input (alternative au schéma). */
  private readonly _FilterFields = signal<FilterFieldConfig[]>([]);
  /** Schéma objet alternatif pour générer les champs de filtre. */
  private readonly _FilterSchema = signal<Record<string, FilterSchemaField> | null>(null);
  /** Champs de filtre effectifs : soit FilterFields (input), soit déduits du FilterSchema. */
  protected readonly EffectiveFilterFields = computed<FilterFieldConfig[]>(() => {
    const lFields: FilterFieldConfig[] = this._FilterFields();
    if (lFields.length > 0) {
      return lFields;
    }
    const lSchema: Record<string, FilterSchemaField> | null = this._FilterSchema();
    if (lSchema) {
      return this.BuildFieldsFromSchema(lSchema, this.FilterExcludedKeys);
    }
    return [];
  });
  /**
   * Service Angular pour l'appel HTTP XLSX (POST /api/{Controller}/ExportXlsx).
   * Injecté comme champ privé pour respecter le contexte d'injection (NG0203 fix).
   * Si null, ExportXlsx() fallback sur ExportCsv().
   */
  private readonly _XlsxExportService: GridXlsxExportService = inject(GridXlsxExportService);
  /**
   * Service d'alertes (popup réutilisable) pour afficher les erreurs techniques sans utiliser alert().
   * Cohérent avec le design system SellMatch (app-popup) et non-bloquant.
   */
  private readonly _Alert: AlertService = inject(AlertService);
  /**
   * Service de persistance du niveau de zoom de la grille (BDD + localStorage).
   * - cm - Source unique de verite pour le zoom : la grille lit `CurrentZoom()`
   * via un `computed` et appelle `ApplyZoom(pLevel)` pour muter. Cf. ThemeService
   * pour le precedent (meme pattern de persistance utilisateur).
   */
  private readonly _GridZoomService: GridZoomService = inject(GridZoomService);
  /**
   * Niveau de zoom courant du tableau (1.0 = 100%). Proxy sur le signal du
   * `GridZoomService` pour permettre la lecture depuis le template (le binding
   * `[style.--grid-zoom]="ZoomLevel()"` dans le HTML reste inchange).
   * - cm - `computed()` au lieu de `signal()` : la valeur vient du service.
   * Toute mutation passe par `ApplyZoom()` (cf. `UpdateZoomState`), qui
   * persiste en localStorage immediat puis en BDD en fire-and-forget.
   */
  protected readonly ZoomLevel = computed<number>(() => this._GridZoomService.CurrentZoom());
  /** Indique si le zoom est au maximum (200%). Désactive le bouton zoom in. */
  protected readonly IsZoomMax = computed<boolean>(() => this.ZoomLevel() >= GRID_ZOOM.Max);
  /** Indique si le zoom est au minimum (50%). Désactive le bouton zoom out. */
  protected readonly IsZoomMin = computed<boolean>(() => this.ZoomLevel() <= GRID_ZOOM.Min);
  /** Indique si le zoom est différent du niveau par défaut (désactive le bouton reset). */
  protected readonly IsZoomModified = computed<boolean>(() => Math.abs(this.ZoomLevel() - GRID_ZOOM.Default) > 0.001);
  /**
   * Service de persistance de la taille de page de la grille (BDD + localStorage).
   * - cm - Source unique de verite pour la pagination cote UI : la grille
   * lit `GetStoredPageSize(PaginationContext)` a son `ngOnInit` et appelle
   * `ApplyPageSize(PaginationContext, pSize)` au changement de taille via
   * le selecteur `app-pagination`. Cf. GridZoomService pour le precedent
   * (meme pattern de persistance utilisateur, scope par contexte logique).
   */
  private readonly _GridPaginationService: GridPaginationService = inject(GridPaginationService);
  /**
   * Largeurs effectives des colonnes mesurées dans le DOM (px), capturées après chaque render.
   * Map clé colonne → largeur réelle. Source de vérité pour le calcul des offsets sticky.
   * Pourquoi mesurer le DOM : avec table-layout: fixed + resize utilisateur, la largeur rendue
   * diffère de la largeur déclarée (Width/ColumnWidths). Calculer un offset sur des largeurs
   * déclarées produit des colonnes qui se chevauchent visuellement.
   */
  private readonly _RenderedWidths = signal<Record<string, number>>({});
  //#region Browser Detection
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));
  /** Référence à l'élément hôte du composant (pour focus l'éditeur inline). */
  private readonly _Host: ElementRef<HTMLElement> = inject(ElementRef<HTMLElement>);
  /** NgZone pour exécuter le clamp du menu contextuel hors zone puis re-rendre dans la zone. */
  private readonly _Zone: NgZone = inject(NgZone);

  /** Constructeur : enregistre l'effet réactif de re-mesure des largeurs dans le contexte d'injection */
  public constructor() {
    super();
    effect((): void => {
      this.VisibleColumns();
      this.ColumnWidths();
      this.StickyColumns();
      this.ActionsSticky();
      this.MeasureRenderedWidths();
    });
  }

  get Columns(): GridColumn<TDTO>[] {
    return this._Columns();
  }

  //#region Inputs
  /** Définition des colonnes du tableau (alternative à `<app-grid-column>`). */
  @Input() set Columns(pColumns: GridColumn<TDTO>[]) {
    this._InputColumns.set(pColumns ?? []);
    this.RefreshColumns();
  }

  get Data(): TDTO[] {
    return this._Data();
  }

  /** Données affichées. */
  @Input() set Data(pData: TDTO[]) {
    this._Data.set(pData ?? []);

    if (this.AutoColumns && this._Columns().length === 0) {
      this.RefreshColumns();
      this.SyncColumnOrder();
    }
  }

  get Loading(): boolean {
    return this._Loading();
  }

  /** Indique le chargement (skeleton). */
  @Input() set Loading(pLoading: boolean) {
    this._Loading.set(pLoading);
  }

  get Error(): string | null {
    return this._Error();
  }

  /**
   * Message d'erreur courant à afficher au-dessus de la grille (état "Error").
   * Si défini, masque la barre d'outils, le tableau (skeleton / lignes / état vide) et
   * la pagination, mais laisse la FilterBar visible pour permettre à l'utilisateur
   * de retenter avec d'autres critères. La zone d'erreur affiche aussi un bouton
   * "Réessayer" qui émet `ErrorRetry`.
   */
  @Input() set Error(pError: string | null) {
    this._Error.set(pError);
  }

  get FilterFields(): FilterFieldConfig[] {
    return this._FilterFields();
  }

  /** Configuration des champs de filtre (FilterFieldConfig[]). Requis si Filterable=true. */
  @Input() set FilterFields(pFields: FilterFieldConfig[]) {
    this._FilterFields.set(pFields ?? []);
  }

  get FilterSchema(): Record<string, FilterSchemaField> | null {
    return this._FilterSchema();
  }

  /** Schéma objet alternatif (génère les champs depuis un critere DTO). Mutuellement exclusif avec FilterFields. */
  @Input() set FilterSchema(pSchema: Record<string, FilterSchemaField> | null) {
    this._FilterSchema.set(pSchema);
  }

  get Page(): number {
    return this._Page();
  }

  /** Page courante (1-based) pour la pagination intégrée. */
  @Input() set Page(pValue: number) {
    this._Page.set(pValue && pValue > 0 ? Math.floor(pValue) : 1);
  }

  get PageSize(): number {
    return this._PageSize();
  }

  /** Taille de page pour la pagination intégrée. */
  @Input() set PageSize(pValue: number) {
    this._PageSize.set(pValue && pValue > 0 ? Math.floor(pValue) : 25);
  }

  get Total(): number {
    return this._Total();
  }

  /** Nombre total de lignes côté serveur pour la pagination intégrée. */
  @Input() set Total(pValue: number) {
    this._Total.set(pValue && pValue > 0 ? Math.floor(pValue) : 0);
  }

  /** Mode server-side activé (cf. setter @Input ServerSide). */
  private _ServerSide: boolean = false;

  public get ServerSide(): boolean {
    return this._ServerSide;
  }

  /**
   * Active le mode server-side : la grille n'applique plus le filtre/tri/page côté client
   * et expose ses événements (PageChanged, FilterChanged, SortChanged) au parent.
   * Défaut: false (mode client historique).
   */
  @Input() set ServerSide(pValue: boolean) {
    this._ServerSide = !!pValue;
    this.ClientFilter = !this._ServerSide;
  }

  /**
   * Nombre de lignes actuellement sélectionnées. Accesseur public
   * privilégié depuis le template (slot [gridBulkActions]) et depuis
   * les handlers côté page parente — évite d'exposer SelectedKeys()
   * qui est protected.
   * @returns Le nombre de lignes cochées.
   */
  public get SelectedCount(): number {
    return this.SelectedKeys().size;
  }

  //#endregion

  /** Fonction de suivi pour le ngFor (perf). */
  @Input() override TrackBy: (pItem: TDTO) => string = (pItem: TDTO): string => String((pItem as Record<string, unknown>)['id'] ?? '');

  /** Clé de persistance localStorage pour les colonnes visibles et l'ordre. */
  @Input() override StorageKey = 'app-grid';
  /** Active la pagination intégrée (footer) avec sélecteur de page limit (défaut: true). */
  @Input() override Paginated = true;
  /** Si true, le filtre est appliqué côté client (FilteredData computed). Si false, émet seulement FilterChanged pour filtre serveur. Défaut: true. */
  @Input() override ClientFilter = true;
  /** Mode de sélection: 'single' ou 'multiple' (défaut: 'multiple'). */
  @Input() override SelectionMode: 'single' | 'multiple' = 'multiple';
  /** Active globalement l'édition inline sur le grid (défaut: false). Une colonne est éditable seulement si `Editable` global ET `col.Editable` sont truthy. */
  @Input() override Editable = false;
  /** Active le marquage visuel des lignes modifiées non confirmées par le parent (défaut: false). */
  @Input() override MarkDirty = false;
  /**
   * Active la validation ligne par ligne (état error/valid). Quand activé, chaque ligne est validée via les
   * EditorValidator des colonnes éditables. Une ligne invalide est marquée en erreur (pas en BDD), une ligne
   * valide est marquée validée et RowValidated est émis pour que le parent la crée en BDD. Défaut: false.
   */
  @Input() override ValidateRows = false;
  /** Indique si la validation d'une ligne exige que tous les champs éditables soient remplis (défaut: false). */
  @Input() override RequireAllFields = false;
  /** Séparateur CSV utilisé lors de l'export (défaut: ','). Mettre ';' pour les locales FR Excel par défaut. */
  @Input() override CsvSeparator: string = ',';
  /** Préfixe du nom de fichier exporté. Le service concatène un timestamp lisible. Ex: 'candidats' → `candidats_2026-08-05_14-30-22.csv`. */
  @Input() override ExportFilenamePrefix: string = 'export';
  /** Si true (défaut), exporte les données filtrées + triées. Si false, exporte `Data` brut sans filtre ni tri. */
  @Input() override ExportOnlyFiltered: boolean = true;
  /** Si true (défaut), ajoute un BOM UTF-8 en début de fichier (Excel FR). Mettre false pour des outils non-Excel. */
  @Input() override ExportIncludeBom: boolean = true;
  /** Données filtrées côté client selon FilterValues et EffectiveFilterFields. */
  protected readonly FilteredData = computed<TDTO[]>(() => {
    const lSorted: TDTO[] = this.SortedData();
    if (!this.ClientFilter) {
      return lSorted;
    }
    const lValues: Record<string, unknown> = this.FilterValues() as Record<string, unknown>;
    const lFields: FilterFieldConfig[] = this.EffectiveFilterFields();
    // - cm - Si aucun filtre actif, retourne les données triées
    const lHasActiveFilter: boolean = lFields.some((lF) => {
      const lV: unknown = lValues[lF.Key];
      return lV !== null && lV !== undefined && lV !== '' && !(lF.Type === 'checkbox' && lV === false);
    });
    if (!lHasActiveFilter) {
      return lSorted;
    }
    return lSorted.filter((pRow) => lFields.every((lF) => {
      const lV: unknown = lValues[lF.Key];
      if (lV === null || lV === undefined || lV === '') {
        return true;
      }
      if (lF.Type === 'checkbox' && lV === false) {
        return true;
      }
      const lCell: unknown = this.GetCellValue(pRow, lF.Key);
      if (lF.Type === 'select') {
        return String(lCell) === String(lV);
      }
      if (lF.Type === 'number') {
        return Number(lCell) === Number(lV);
      }
      if (lF.Type === 'checkbox') {
        return !!lCell === !!lV;
      }
      if (lF.Type === 'date') {
        const lCellTs: number = this.TryGetTimestamp(lCell);
        const lFilterTs: number = this.TryGetTimestamp(lV);
        // - cm - Comparaison même jour (timestamp à minuit)
        const lCellDay: number = Math.floor(lCellTs / 86400000);
        const lFilterDay: number = Math.floor(lFilterTs / 86400000);
        return lCellTs !== 0 && lCellDay === lFilterDay;
      }
      return String(lCell ?? '').toLowerCase().includes(String(lV).toLowerCase());
    }));
  });
  /** Total effectif pour la pagination : filtré côté client si ClientFilter=true, sinon Total (serveur). */
  protected readonly EffectiveTotal = computed<number>(() => {
    if (this.Paginated && this.ClientFilter) {
      return this.FilteredData().length;
    }
    return this._Total();
  });
  /** Index de début de page (1-based) pour la pagination intégrée. */
  protected readonly PageStart = computed<number>(() =>
    this.EffectiveTotal() === 0 ? 0 : (this._Page() - 1) * this._PageSize() + 1
  );
  /** Index de fin de page pour la pagination intégrée. */
  protected readonly PageEnd = computed<number>(() =>
    Math.min(this._Page() * this._PageSize(), this.EffectiveTotal())
  );
  /** Nombre total de pages pour la pagination intégrée. */
  protected readonly TotalPages = computed<number>(() =>
    this._PageSize() > 0 ? Math.max(1, Math.ceil(this.EffectiveTotal() / this._PageSize())) : 1
  );
  /** Données affichées après pagination : slice de FilteredData si pagination client, sinon FilteredData entier. */
  protected readonly PagedData = computed<TDTO[]>(() => {
    const lFiltered: TDTO[] = this.FilteredData();
    if (!this.Paginated || !this.ClientFilter) {
      return lFiltered;
    }
    const lStart: number = (this._Page() - 1) * this._PageSize();
    return lFiltered.slice(lStart, lStart + this._PageSize());
  });
  /** Indique si toutes les lignes visibles sont sélectionnées. */
  protected readonly AllSelected = computed<boolean>(() => {
    const lRows: TDTO[] = this.FilteredData();
    if (lRows.length === 0) {
      return false;
    }
    const lSelected: Set<string> = this.SelectedKeys();
    return lRows.every((lRow) => lSelected.has(this.TrackBy(lRow)));
  });
  /** Indique si au moins une ligne (mais pas toutes) est sélectionnée. */
  protected readonly SomeSelected = computed<boolean>(() => {
    const lRows: TDTO[] = this.FilteredData();
    const lSelected: Set<string> = this.SelectedKeys();
    const lCount: number = lRows.filter((lRow) => lSelected.has(this.TrackBy(lRow))).length;
    return lCount > 0 && lCount < lRows.length;
  });

  //#region Lifecycle
  /** @inheritdoc */
  public ngOnInit(): void {
    // - cm - KAN-GRID-PAGE-SIZE-PERSIST : hydrate la taille de page depuis le
    // service de persistance AVANT le 1er render pour eviter un flash de la
    // grille sur la valeur par defaut (25). GetStoredPageSize lit le
    // localStorage immediat (synchrone), donc aucun flicker visible.
    this._PageSize.set(this._GridPaginationService.GetStoredPageSize(this.PaginationContext));
    this.RefreshColumns();
    this.LoadPersistence();
    if (this._IsBrowser) {

      document.addEventListener('fullscreenchange', this._OnFullscreenChange);
    }
  }

  //#endregion

  //#region CTOR

  /** @inheritdoc */
  public ngAfterContentInit(): void {
    // - cm - Les directives <app-grid-column> sont disponibles ici
    this.RefreshColumns();
    // - cm - Resynchronise l'ordre des colonnes avec les colonnes effectives (directives)
    this.SyncColumnOrder();
    // - cm - S'abonne aux changements d'inputs des directives (notamment EditorOptions asynchrone)
    this.SubscribeDirectiveChanges();
  }

  //#endregion

  /** @inheritdoc */
  public ngOnDestroy(): void {
    // - cm - Annule toute édition inline en cours pour éviter une fuite d'état
    this.CancelEdit();

    this._DirectiveSubs.forEach(pFn => pFn());
    this._DirectiveSubs = [];
    if (this._IsBrowser) {
      document.removeEventListener('fullscreenchange', this._OnFullscreenChange);
    }
  }

  /** @inheritdoc Handler global mousemove : applique la nouvelle largeur pendant le drag. */
  @HostListener('document:mousemove', ['$event'])
  public OnResizeMove(pEvent: MouseEvent): void {
    const lKey: string | null = this.ResizingKey();
    if (!lKey) {
      return;
    }
    pEvent.preventDefault();

    const lDelta: number = pEvent.clientX - this._ResizeStartX;
    const lNewWidth: number = Math.max(MIN_COLUMN_WIDTH, this._ResizeStartWidth + lDelta);
    const lWidths: Record<string, string> = {...this.ColumnWidths()};
    lWidths[lKey] = `${lNewWidth}px`;
    this.ColumnWidths.set(lWidths);
  }

  /** @inheritdoc Handler global mouseup : termine le drag et persiste la largeur. */
  @HostListener('document:mouseup', ['$event'])
  public OnResizeEnd(pEvent: MouseEvent): void {
    if (!this.ResizingKey()) {
      return;
    }
    pEvent.preventDefault();
    this.ResizingKey.set(null);
    this.SavePersistence();
  }

  /** @inheritdoc Handler global keydown : ferme le menu contextuel sur Escape, gère les raccourcis de zoom. */
  @HostListener('document:keydown', ['$event'])
  public OnDocumentKeydown(pEvent: KeyboardEvent): void {
    if (pEvent.key === 'Escape' && this.ContextMenu()) {
      this.CloseContextMenu();
      return;
    }

    if (this.Zoomable && this.ZoomKeyboardShortcuts && (pEvent.ctrlKey || pEvent.metaKey)) {
      const lTarget: EventTarget | null = pEvent.target;
      // - cm - Ne pas intercepter si l'utilisateur édite une cellule ou tape dans un champ
      const lIsEditingInput: boolean = lTarget instanceof HTMLElement && (
        lTarget.tagName === 'INPUT' ||
        lTarget.tagName === 'TEXTAREA' ||
        lTarget.isContentEditable
      );
      if (lIsEditingInput) {
        return;
      }
      if (pEvent.key === '+' || pEvent.key === '=') {
        pEvent.preventDefault();
        this.ZoomIn();
        return;
      }
      if (pEvent.key === '-' || pEvent.key === '_') {
        pEvent.preventDefault();
        this.ZoomOut();
        return;
      }
      if (pEvent.key === '0') {
        pEvent.preventDefault();
        this.ResetZoom();
        return;
      }
    }
  }

  /** Zoom avant (+1 incrément, plafonné au max). */
  public ZoomIn(): void {
    const lCurrent: number = this.ZoomLevel();
    const lNext: number = Math.min(GRID_ZOOM.Max, lCurrent + GRID_ZOOM.Step);
    this.UpdateZoomState(lNext);
    this.PostHog.Capture('grid_zoom_in', {zoomLevel: lNext, storageKey: this.StorageKey});
  }

  /** Zoom arrière (-1 incrément, plafonné au min). */
  public ZoomOut(): void {
    const lCurrent: number = this.ZoomLevel();
    const lNext: number = Math.max(GRID_ZOOM.Min, lCurrent - GRID_ZOOM.Step);
    this.UpdateZoomState(lNext);
    this.PostHog.Capture('grid_zoom_out', {zoomLevel: lNext, storageKey: this.StorageKey});
  }

  /** Réinitialise le zoom au niveau par défaut (100%). */
  public ResetZoom(): void {
    this.UpdateZoomState(GRID_ZOOM.Default);
    this.PostHog.Capture('grid_zoom_reset', {zoomLevel: GRID_ZOOM.Default, storageKey: this.StorageKey});
  }

  //#endregion

  public ZoomPercent(): number {
    return Math.round(this.ZoomLevel() * 100);
  }

  //#endregion

  //#region Columns Menu

  //#region Fullscreen
  /** Bascule le mode plein écran de la grille via l'API Fullscreen standard. */
  public ToggleFullscreen(): void {
    if (!this._IsBrowser) {
      return;
    }
    const lHost: HTMLElement = this._Host.nativeElement;
    if (document.fullscreenElement === lHost) {
      void document.exitFullscreen();
    } else {
      void lHost.requestFullscreen();
    }
    this.PostHog.Capture('grid_fullscreen_toggled', {
      entering: document.fullscreenElement !== lHost,
      storageKey: this.StorageKey
    });
  }

  // - cm - Récupère les lignes actuellement sélectionnées.
  public GetSelectedRows(): TDTO[] {
    return this._Data().filter((pRow) => this.SelectedKeys().has(this.TrackBy(pRow)));
  }

  /** Réinitialise la sélection courante et émet SelectionChanged. */
  public ClearSelection(): void {
    this.SelectedKeys.set(new Set());
    this.SelectionChanged.emit([]);
  }

  //#region Export CSV
  /** Exporte les colonnes visibles et les données courantes en CSV. */
  public ExportCsv(): void {

    const lUseFiltered: boolean = this.ExportOnlyFiltered;
    const lRows: TDTO[] = lUseFiltered ? this.FilteredData() : this._Data();
    const lCols: GridColumn<TDTO>[] = this.VisibleColumns();
    const lSeparator: string = this.CsvSeparator || ',';

    // - cm - Construction des lignes : entête + données, séparateur configurable
    const lHeader: string = lCols.map((lCol) => this.EscapeCsv(lCol.Label ?? '', lSeparator)).join(lSeparator);
    const lLines: string[] = lRows.map((pRow) =>
      lCols.map((lCol) => this.EscapeCsv(this.FormatCell(pRow, lCol), lSeparator)).join(lSeparator)
    );
    const lCsv: string = [lHeader, ...lLines].join('\r\n');

    const lFinalFilename: string = this.ExportFileName && this.ExportFileName !== 'export.csv'
      ? this.ExportFileName
      : this.BuildExportFilename();

    if (!this._IsBrowser) {
      // - cm - SSR : pas de DOM disponible, mais on émet quand même les métadonnées
      this.Exported.emit({
        Count: lRows.length,
        Filename: lFinalFilename,
        HasFilter: lUseFiltered && this.HasActiveFilter(),
        HasSort: this.SortKey() !== null && this.SortDirection() !== null
      });
      return;
    }

    // - cm - BOM UTF-8 optionnel (Excel FR en a besoin par défaut, désactivable pour outils non-Excel)
    const lBom: string = this.ExportIncludeBom ? '\uFEFF' : '';
    const lBlob: Blob = new Blob([lBom + lCsv], {type: 'text/csv;charset=utf-8;'});
    const lUrl: string = URL.createObjectURL(lBlob);
    const lLink: HTMLAnchorElement = document.createElement('a');
    lLink.href = lUrl;
    lLink.download = lFinalFilename;
    document.body.appendChild(lLink);
    lLink.click();
    document.body.removeChild(lLink);
    URL.revokeObjectURL(lUrl);

    this.PostHog.Capture('grid_export_csv', {rows: lRows.length, cols: lCols.length, filename: lFinalFilename});
    this.Exported.emit({
      Count: lRows.length,
      Filename: lFinalFilename,
      HasFilter: lUseFiltered && this.HasActiveFilter(),
      HasSort: this.SortKey() !== null && this.SortDirection() !== null
    });
  }

  /**
   * Exporte les colonnes visibles et les données courantes en XLSX stylisé SellMatch via le backend.
   * Construit une requête ExportXlsxRequest depuis les colonnes visibles et l'ordre utilisateur,
   * envoie via POST vers ExportApiPath et déclenche le téléchargement navigateur.
   * Si ExportApiPath n'est pas défini, fallback sur ExportCsv().
   * Émet Exported avec les métadonnées (Count, Filename, HasFilter, HasSort) à la fin.
   * Tracking PostHog `grid_export_xlsx`.
   * @returns Une promesse résolue quand l'export est terminé (ou rejeté en cas d'erreur API).
   */
  public async ExportXlsx(): Promise<void> {
    // - cm - Fallback : pas d'endpoint API configuré, on bascule sur CSV
    if (!this.ExportApiPath) {
      this.ExportCsv();
      return;
    }

    const lColumns: ExcelColumnRequest[] = this.VisibleColumns().map((lCol) => ({
      Header: lCol.Label ?? '',
      Key: String(lCol.Key),
      Width: this.ParseExcelWidth(lCol.Width),
      Format: lCol.EditorType === 'number' ? '#,##0.00' : lCol.EditorType === 'date' ? 'dd/mm/yyyy' : undefined,
      Bold: false
    }));

    const lRequest: IExcelExportRequest = {
      Title: this.ExportFilenamePrefix || 'export',
      UserName: this.ExportUserName ?? undefined,
      Critere: this.ClientFilter ? null : (this.FilterValues() as Record<string, unknown>),
      Columns: lColumns
    };

    try {

      const lFilename: string = await this.BusyService.run(
        this._XlsxExportService.DownloadXlsxAsync(this.ExportApiPath, lRequest),
        'Export Excel en cours…'
      );
      const lHasFilter: boolean = this.HasActiveFilter();
      const lHasSort: boolean = this.SortKey() !== null && this.SortDirection() !== null;

      this.PostHog.Capture('grid_export_xlsx', {
        rows: this._Data().length,
        cols: lColumns.length,
        filename: lFilename,
        hasFilter: lHasFilter,
        hasSort: lHasSort
      });
      this.Exported.emit({
        Count: this._Data().length,
        Filename: lFilename,
        HasFilter: lHasFilter,
        HasSort: lHasSort
      });
    } catch (pError) {
      // - cm - Erreur API : on NE bascule PAS silencieusement sur CSV (l'utilisateur a choisi XLSX).
      // On logge en console + tracking PostHog + alerte visible.
      // - cm - Important : ne pas appeler ExportCsv() ici, ce serait masquer l'erreur et donner l'impression que XLSX marche.
      // - cm - Si l'utilisateur veut vraiment un CSV, il peut choisir explicitement "CSV" dans le dropdown.
      // - cm - Erreur API : popup réutilisable via AlertService (cohérent design system SellMatch).

      this.PostHog.Capture('grid_export_xlsx_error', {
        error: String(pError),
        apiPath: this.ExportApiPath,
        columns: lColumns.length,
        rows: this._Data().length
      });
      // - cm - Erreur API : popup réutilisable via AlertService.Error (cohérent design system SellMatch).
      // - cm - Pas de fallback CSV silencieux : l'utilisateur a explicitement choisi XLSX.
      const lErrorDetails: string = pError instanceof Error
        ? ` (${pError.name}: ${pError.message})`
        : ` (${String(pError)})`;
      this._Alert.Error(
        `Échec de l'export Excel.`
      );
    }
  }

  //#endregion

  //#region Row saving state
  /** Marque une ligne comme en cours de sauvegarde (skeleton overlay). */
  public SetRowSaving(pRow: TDTO): void {
    const lKey: string = this.TrackBy(pRow);
    const lKeys: Set<string> = new Set(this.SavingRowKeys());
    lKeys.add(lKey);
    this.SavingRowKeys.set(lKeys);
  }

  /** Retire le marquage saving d'une ligne après la sauvegarde. */
  public ClearRowSaving(pRow: TDTO): void {
    const lKey: string = this.TrackBy(pRow);
    const lKeys: Set<string> = new Set(this.SavingRowKeys());
    lKeys.delete(lKey);
    this.SavingRowKeys.set(lKeys);
  }

  /** Marque une cellule comme en cours de sauvegarde (skeleton overlay sur la cellule seule). */
  public SetCellSaving(pRow: TDTO, pColKey: string): void {
    const lKey: string = this.CellKey(pRow, pColKey);
    const lKeys: Set<string> = new Set(this.SavingCellKeys());
    lKeys.add(lKey);
    this.SavingCellKeys.set(lKeys);
  }

  /** Retire le marquage saving d'une cellule après la sauvegarde. */
  public ClearCellSaving(pRow: TDTO, pColKey: string): void {
    const lKey: string = this.CellKey(pRow, pColKey);
    const lKeys: Set<string> = new Set(this.SavingCellKeys());
    lKeys.delete(lKey);
    this.SavingCellKeys.set(lKeys);
  }

  //#region Row validation states
  /** Valide une ligne en exécutant tous les EditorValidator des colonnes éditables. */
  public ValidateRow(pRow: TDTO): Record<string, string> {
    const lErrors: Record<string, string> = {};
    // - cm - Toutes les colonnes éditables participent à la validation, même sans EditorValidator
    const lCols: GridColumn<TDTO>[] = this.VisibleColumns().filter((pC) => pC.Editable);
    for (const lCol of lCols) {
      const lValue: unknown = this.GetCellValue(pRow, String(lCol.Key));
      const lKey: string = String(lCol.Key);
      const lIsEmpty: boolean = lValue === null || lValue === undefined || lValue === '';
      // - cm - RequireAllFields=true : un champ vide est une erreur systématique
      if (this.RequireAllFields && lIsEmpty) {
        lErrors[lKey] = 'Ce champ est requis';
        continue;
      }
      // - cm - Sans RequireAllFields, on ignore les champs vides
      if (lIsEmpty) {
        continue;
      }
      // - cm - Validation métier personnalisée si présente
      if (lCol.EditorValidator) {
        const lError: string | null = lCol.EditorValidator(lValue, pRow);
        if (lError) {
          lErrors[lKey] = lError;
        }
      }
    }
    return lErrors;
  }

  /** Revalide une ligne, met à jour son état (error/valid) et émet RowValidated/RowInvalid selon le changement. */
  public RevalidateRow(pRow: TDTO): void {
    if (!this.ValidateRows) {
      return;
    }
    const lKey: string = this.TrackBy(pRow);
    const lErrors: Record<string, string> = this.ValidateRow(pRow);
    const lStates: Map<string, 'error' | 'valid'> = new Map(this.RowStates());
    const lErrorsMap: Map<string, Record<string, string>> = new Map(this.RowErrors());
    const lPrevState: 'error' | 'valid' | undefined = lStates.get(lKey);

    if (Object.keys(lErrors).length > 0) {
      // - cm - Ligne invalide : état error, pas en BDD
      lStates.set(lKey, 'error');
      lErrorsMap.set(lKey, lErrors);
      this.RowStates.set(lStates);
      this.RowErrors.set(lErrorsMap);
      // - cm - Émet seulement si changement d'état (pristine/valid -> error)
      if (lPrevState !== 'error') {
        this.RowInvalid.emit({Row: pRow, Errors: lErrors});
      }
    } else {
      // - cm - Ligne valide : tous les checks passent
      lStates.set(lKey, 'valid');
      lErrorsMap.delete(lKey);
      this.RowStates.set(lStates);
      this.RowErrors.set(lErrorsMap);

      if (lPrevState !== 'valid') {
        this.RowValidated.emit(pRow);
      }
    }
  }

  protected ResolveStickyOffset(pColumn: GridColumn<TDTO>): string | null {
    return this.StickyOffsets().get(String(pColumn.Key)) ?? null;
  }

  /** Renvoie la valeur `left` en pixels pour une colonne sticky-left, ou null si pas sticky-left. */
  protected StickyLeftPx(pColumn: GridColumn<TDTO>): number | null {
    const lOffset: string | null = this.ResolveStickyOffset(pColumn);
    if (!lOffset) {
      return null;
    }
    const lMatch: RegExpMatchArray | null = lOffset.match(/^left:(\d+(?:\.\d+)?)px$/);
    return lMatch ? Math.round(Number(lMatch[1])) : null;
  }

  /** Renvoie la valeur `right` en pixels pour une colonne sticky-right, ou null si pas sticky-right. */
  protected StickyRightPx(pColumn: GridColumn<TDTO>): number | null {
    const lOffset: string | null = this.ResolveStickyOffset(pColumn);
    if (!lOffset) {
      return null;
    }
    const lMatch: RegExpMatchArray | null = lOffset.match(/^right:(\d+(?:\.\d+)?)px$/);
    return lMatch ? Math.round(Number(lMatch[1])) : null;
  }

  //#region Sort
  /** Active le tri sur une colonne (cycle asc -> desc -> none). */
  protected ToggleSort(pColumn: GridColumn<TDTO>): void {
    if (!pColumn.Sortable) {
      return;
    }
    const lKey: string = String(pColumn.Key);
    if (this.SortKey() !== lKey) {
      this.SortKey.set(lKey);
      this.SortDirection.set('asc');
    } else {
      const lCurrent: 'asc' | 'desc' | null = this.SortDirection();
      if (lCurrent === 'asc') {
        this.SortDirection.set('desc');
      } else if (lCurrent === 'desc') {
        this.SortKey.set(null);
        this.SortDirection.set(null);
      } else {
        this.SortDirection.set('asc');
      }
    }
    this.SortChanged.emit({
      Key: this.SortKey() ?? '',
      Direction: this.SortDirection()
    });
  }

  /**
   * Bascule la visibilité d'une colonne.
   * @param pColumn La colonne.
   */
  /** Bascule ou force la visibilité d'une colonne. */
  protected ToggleColumnVisibility(pColumn: GridColumn<TDTO>, pChecked?: boolean): void {
    if (pColumn.Hideable === false) {
      return;
    }
    const lKey: string = String(pColumn.Key);
    const lHidden: Set<string> = new Set(this.HiddenColumns());
    const lShouldHide: boolean = pChecked !== undefined ? !pChecked : lHidden.has(lKey);
    if (lShouldHide) {
      lHidden.add(lKey);
    } else {
      lHidden.delete(lKey);
    }
    this.HiddenColumns.set(lHidden);
    this.SavePersistence();
  }

  /** Réaffiche une colonne précédemment masquée (la retire de HiddenColumns). */
  protected RestoreColumn(pKey: string): void {
    const lKey: string = String(pKey);
    const lHidden: Set<string> = new Set(this.HiddenColumns());
    if (!lHidden.has(lKey)) {
      // - cm - Pas de colonne masquée correspondante : no-op silencieux
      return;
    }
    lHidden.delete(lKey);
    this.HiddenColumns.set(lHidden);
    this.SavePersistence();
    this.ColumnRestored.emit(lKey);
    this.PostHog.Capture('grid_column_restored', {key: lKey, storageKey: this.StorageKey});
  }

  /** Déplace une colonne vers la gauche dans l'ordre. */
  protected MoveColumnLeft(pIndex: number): void {
    if (pIndex <= 0) {
      return;
    }

    const lOrder: string[] = this.OrderedColumns().map((lCol) => String(lCol.Key));
    const lKey: string = lOrder[pIndex];
    lOrder[pIndex] = lOrder[pIndex - 1];
    lOrder[pIndex - 1] = lKey;
    this.ColumnOrder.set(lOrder);
    this.SavePersistence();
  }

  /** Déplace une colonne vers la droite dans l'ordre. */
  protected MoveColumnRight(pIndex: number): void {

    const lOrder: string[] = this.OrderedColumns().map((lCol) => String(lCol.Key));
    if (pIndex >= lOrder.length - 1) {
      return;
    }
    const lKey: string = lOrder[pIndex];
    lOrder[pIndex] = lOrder[pIndex + 1];
    lOrder[pIndex + 1] = lKey;
    this.ColumnOrder.set(lOrder);
    this.SavePersistence();
  }

  /** Réinitialise l'ordre et la visibilité des colonnes. */
  protected ResetColumns(): void {
    this.ColumnOrder.set(this._Columns().map((lCol) => String(lCol.Key)));
    this.HiddenColumns.set(new Set());
    this.ColumnWidths.set({});
    this.StickyColumns.set(new Map());
    this.ActionsSticky.set(false);
    this.SavePersistence();
  }

  //#region Context menu
  /** Ouvre le menu contextuel d'en-tête au clic droit sur une colonne. */
  protected OnHeaderContextMenu(pEvent: MouseEvent, pColumn: GridColumn<TDTO>): void {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    // - cm - Position initiale = curseur, ajustée après rendu pour rester dans le viewport
    this.ContextMenu.set({X: pEvent.clientX, Y: pEvent.clientY, Column: pColumn});
    this.ClampContextMenuToViewport();
  }

  /** Ferme le menu contextuel d'en-tête. */
  protected CloseContextMenu(): void {
    this.ContextMenu.set(null);
  }

  /** Gère les touches clavier au sein du menu contextuel (Escape ferme). */
  protected OnContextKeydown(pEvent: KeyboardEvent): void {
    if (pEvent.key === 'Escape') {
      pEvent.stopPropagation();
      this.CloseContextMenu();
    }
  }

  /** Force le tri croissant sur une colonne depuis le menu contextuel. */
  protected ContextSortAsc(pColumn: GridColumn<TDTO>): void {
    this.SetSort(pColumn, 'asc');
    this.CloseContextMenu();
  }

  /** Force le tri décroissant sur une colonne depuis le menu contextuel. */
  protected ContextSortDesc(pColumn: GridColumn<TDTO>): void {
    this.SetSort(pColumn, 'desc');
    this.CloseContextMenu();
  }

  /** Annule le tri courant depuis le menu contextuel. */
  protected ContextClearSort(): void {
    this.SortKey.set(null);
    this.SortDirection.set(null);
    this.SortChanged.emit({Key: '', Direction: null});
    this.CloseContextMenu();
  }

  //#endregion

  /** Masque la colonne ciblée depuis le menu contextuel. */
  protected ContextHideColumn(pColumn: GridColumn<TDTO>): void {
    this.ToggleColumnVisibility(pColumn, false);
    this.CloseContextMenu();
  }

  /** Déplace la colonne ciblée vers la gauche depuis le menu contextuel. */
  protected ContextMoveLeft(pColumn: GridColumn<TDTO>): void {
    const lIndex: number = this.OrderedColumns().findIndex((lC) => String(lC.Key) === String(pColumn.Key));
    this.MoveColumnLeft(lIndex);
    this.CloseContextMenu();
  }

  /** Déplace la colonne ciblée vers la droite depuis le menu contextuel. */
  protected ContextMoveRight(pColumn: GridColumn<TDTO>): void {
    const lIndex: number = this.OrderedColumns().findIndex((lC) => String(lC.Key) === String(pColumn.Key));
    this.MoveColumnRight(lIndex);
    this.CloseContextMenu();
  }

  /** Épingle la colonne ciblée à gauche depuis le menu contextuel. */
  protected ContextStickyLeft(pColumn: GridColumn<TDTO>): void {
    this.SetColumnSticky(pColumn, 'left');
    this.CloseContextMenu();
  }

  /** Épingle la colonne ciblée à droite depuis le menu contextuel. */
  protected ContextStickyRight(pColumn: GridColumn<TDTO>): void {
    this.SetColumnSticky(pColumn, 'right');
    this.CloseContextMenu();
  }

  /** Détache la colonne ciblée (retire l'épinglage) depuis le menu contextuel. */
  protected ContextUnsticky(pColumn: GridColumn<TDTO>): void {
    this.ClearColumnSticky(pColumn);
    this.CloseContextMenu();
  }

  /** Ouvre le menu contextuel spécifique à la colonne Actions (clic droit sur l'en-tête Actions). */
  protected OnActionsHeaderContextMenu(pEvent: MouseEvent): void {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    this.ContextMenu.set({X: pEvent.clientX, Y: pEvent.clientY, Column: null as unknown as GridColumn<TDTO>});
    this.ClampContextMenuToViewport();
  }

  /** Épingle la colonne Actions à droite depuis le menu contextuel. */
  protected ContextStickyActions(): void {
    this.ActionsSticky.set(true);
    this.SavePersistence();
    this.CloseContextMenu();
  }

  /** Détache la colonne Actions (retire l'épinglage) depuis le menu contextuel. */
  protected ContextUnstickyActions(): void {
    this.ActionsSticky.set(false);
    this.SavePersistence();
    this.CloseContextMenu();
  }

  // - cm - Indique si une colonne est épinglée à gauche.
  protected IsColumnStickyLeft(pColumn: GridColumn<TDTO>): boolean {
    return this.StickyColumns().get(String(pColumn.Key)) === 'left';
  }

  // - cm - Indique si une colonne est épinglée à droite.
  protected IsColumnStickyRight(pColumn: GridColumn<TDTO>): boolean {
    return this.StickyColumns().get(String(pColumn.Key)) === 'right';
  }

  //#endregion

  //#region Column resize
  /** Résout la largeur effective d'une colonne : largeur redimensionnée prioritaire, sinon Width déclaré. */
  protected ColumnWidth(pColumn: GridColumn<TDTO>): string | undefined {
    const lKey: string = String(pColumn.Key);
    const lWidths: Record<string, string> = this.ColumnWidths();
    if (lWidths[lKey]) {
      return lWidths[lKey];
    }
    return pColumn.Width;
  }

  //#endregion

  /** Démarre le redimensionnement d'une colonne (mousedown sur le handle). */
  protected OnResizeStart(pEvent: MouseEvent, pColumn: GridColumn<TDTO>): void {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    const lTh: HTMLElement | null = (pEvent.currentTarget as HTMLElement).closest('.grid__th') as HTMLElement | null;
    this._ResizeStartX = pEvent.clientX;
    // - cm - Bord gauche et largeur rendue du th : base du calcul delta continu sans saut
    this._ResizeStartLeft = lTh ? lTh.getBoundingClientRect().left : 0;
    this._ResizeStartWidth = lTh ? lTh.getBoundingClientRect().width : 0;

    this.SnapshotColumnWidths();
    this.ResizingKey.set(String(pColumn.Key));
  }

  //#region Row Interactions
  /** Émet l'événement de clic de ligne. */
  protected OnRowClick(pRow: TDTO): void {
    if (!this.RowClickable) {
      return;
    }
    // - cm - Si une édition est en cours sur une autre ligne, on la commit avant de changer de ligne
    if (this.EditingRowKey() && this.EditingRowKey() !== this.TrackBy(pRow)) {
      this.CancelEdit();
    }
    this.RowClicked.emit(pRow);
  }

  /** Gère le clic sur une action de ligne. */
  protected OnAction(pAction: string, pRow: TDTO, pEvent: Event): void {
    pEvent.stopPropagation();
    if (pAction === 'edit' && this.Editable) {
      this.StartRowEdit(pRow);
      return;
    }
    this.ActionClicked.emit({Action: pAction, Row: pRow});
  }

  /** Démarre l'édition inline d'une ligne sur sa première colonne éditable visible. */
  protected StartRowEdit(pRow: TDTO): void {
    const lFirstEditable: GridColumn<TDTO> | undefined = this.VisibleColumns().find((pC) => this.CanEdit(pC));
    if (!lFirstEditable) {
      // - cm - Aucune colonne éditable : émet l'action pour fallback parent
      this.ActionClicked.emit({Action: 'edit', Row: pRow});
      return;
    }
    // - cm - Annule toute édition en cours avant d'en démarrer une nouvelle
    this.CancelEdit();
    this.StartEdit(pRow, lFirstEditable, new Event('click'));
  }

  //#endregion

  protected RowTrackBy(pIndex: number, pItem: TDTO): string {
    return this.TrackBy(pItem) || String(pIndex);
  }

  // - cm - Indique si une cellule est actuellement en édition.
  protected IsEditing(pRow: TDTO, pCol: GridColumn<TDTO>): boolean {
    return this.EditingRowKey() === this.TrackBy(pRow) && this.EditingColKey() === String(pCol.Key);
  }

  /**
   * Démarre l'édition inline d'une cellule.
   * @param pRow La ligne.
   * @param pCol La colonne.
   * @param pEvent L'événement DOM (pour stopper la propagation).
   */
  /** Ajoute une nouvelle ligne vide (comme Excel) via la factory NewRowFactory, */
  protected AddNewRow(): void {
    if (!this.AllowAddRow || !this.NewRowFactory) {
      return;
    }
    const lNewRow: TDTO = this.NewRowFactory();
    // - cm - Ajoute la ligne aux données locales pour l'affichage immédiat
    this._Data.update(pData => [...pData, lNewRow]);
    // - cm - Émet pour que le parent persiste (service.create)
    this.RowAdded.emit(lNewRow);
    // - cm - Valide la nouvelle ligne (vide au départ -> généralement erreur sauf si RequireAllFields=false et aucun validator obligatoire)
    if (this.ValidateRows) {
      this.RevalidateRow(lNewRow);
    }
    // - cm - Met en édition la première colonne éditable de la nouvelle ligne
    const lFirstEditable: GridColumn<TDTO> | undefined = this.VisibleColumns().find(pC => pC.Editable);
    if (lFirstEditable) {
      this.EditingRowKey.set(this.TrackBy(lNewRow));
      this.EditingColKey.set(String(lFirstEditable.Key));
      this.EditValue.set('');
      this.EditError.set(null);

      const lAddValidators: ValidatorFn[] = [];
      if (lFirstEditable.EditorValidator) {
        lAddValidators.push(this.ToValidatorFn(lFirstEditable.EditorValidator, lNewRow));
      }
      this.EditorControl.set(new FormControl(this.InitialControlValue(lFirstEditable, ''), lAddValidators));
      // - cm - AddNewRow n'a pas de currentTarget (event synthétique) : on stocke la cellule DOM
      // - cm - explicitement après render pour que FocusEditor cible la bonne <td>.
      const lNewRowKey: string = this.TrackBy(lNewRow);
      const lFirstColKey: string = String(lFirstEditable.Key);
      this._EditingCellRef.set(null);
      if (this._IsBrowser) {
        setTimeout((): void => {
          const lCell: HTMLElement | null = this._Host.nativeElement.querySelector<HTMLElement>(
            `td[data-row-key="${CSS.escape(lNewRowKey)}"][data-col-key="${CSS.escape(lFirstColKey)}"]`
          );
          this._EditingCellRef.set(lCell);
          this.FocusEditor();
        }, 0);
      }
    }
  }

  //#endregion

  //#region Inline Edit

  /** Démarre l'édition inline d'une cellule. */
  protected StartEdit(pRow: TDTO, pCol: GridColumn<TDTO>, pEvent: Event): void {
    pEvent.stopPropagation();
    if (!this.CanEdit(pCol)) {
      return;
    }

    // - cm - (sinon querySelector retourne la 1ère cellule éditable du DOM = retour à gauche).
    // - cm - On remonte de l'élément cliqué vers la <td> parente qui porte data-row-key/data-col-key.
    const lCellRef: HTMLElement | null = this.ResolveEditingCell(pEvent);
    this._EditingCellRef.set(lCellRef);
    this.EditingRowKey.set(this.TrackBy(pRow));
    this.EditingColKey.set(String(pCol.Key));
    const lValue: unknown = this.GetCellValue(pRow, String(pCol.Key));
    this.EditValue.set(lValue === null || lValue === undefined ? '' : String(lValue));
    this.EditError.set(null);

    const lValidators: ValidatorFn[] = [];
    if (pCol.EditorValidator) {
      lValidators.push(this.ToValidatorFn(pCol.EditorValidator, pRow));
    }
    this.EditorControl.set(new FormControl(this.InitialControlValue(pCol, lValue), lValidators));

    this.SearchOpen.set(pCol.EditorType === 'select-search');
    this.SearchQuery.set('');
    // - cm - Focus l'éditeur après render du DOM
    if (this._IsBrowser) {
      setTimeout((): void => this.FocusEditor(), 0);
    }
  }

  /**
   * Commits la valeur en cours d'édition pour la cellule (ligne, colonne).
   * Si une valeur pré-calculée est fournie (cas d'un select qui émet la valeur
   * via l'événement `(valueChange)` AVANT que le FormControl soit synchro),
   * on s'en sert pour éviter de relire une valeur stale.
   *
   * Le bug typique : SelectOption() appelle onChange(pValue) puis emit(pValue).
   * Mais Forms rappelle writeValue(oldValue) en cycle suivant, ce qui écrase
   * la valeur dans EditorControl(). Conséquence : CommitEdit lisait l'ancienne
   * valeur et l'édition était sans effet (il fallait un 2e clic pour que
   * Forms et la grid se re-synchronisent).
   *
   * @param pRow La ligne.
   * @param pCol La colonne en cours d'édition.
   * @param pPreselectedValue Optionnel : valeur à utiliser directement
   *   (fournie par l'éditeur via `(valueChange)`).
   */
  /** Valide la valeur émise par l'éditeur inline (via `(valueChange)`) puis commit. */
  protected OnEditorValueChange(pRow: TDTO, pCol: GridColumn<TDTO>, pNewValue: unknown): void {
    if (!this.IsEditing(pRow, pCol)) {
      return;
    }
    // - cm - Synchronise EditorControl avec la valeur émise (écrasement immédiat).

    this.EditorControl().setValue(pNewValue, {emitEvent: false});
    this.CommitEdit(pRow, pCol, pNewValue);
  }

  protected OnShowEditorValueChange(pRow: TDTO, pCol: GridColumn<TDTO>, pNewValue: unknown): void {
    this.CommitEdit(pRow, pCol, pNewValue);
  }

  /** Stocke la valeur émise par l'<app-input> en mode ShowEditor (consultation = édition permanente) */
  protected OnShowEditorInput(pRow: TDTO, pCol: GridColumn<TDTO>, pNewValue: unknown): void {
    const lKey: string = `${this.RowKey(pRow)}|${String(pCol.Key)}`;
    this.ShowEditorDraft.update((pMap: Map<string, unknown>): Map<string, unknown> => {
      const lNext: Map<string, unknown> = new Map(pMap);
      lNext.set(lKey, pNewValue);
      return lNext;
    });
  }

  /**
   * Valide et commit l'édition inline d'une cellule.
   * @param pRow La ligne.
   * @param pCol La colonne.
   */

  /** Commit au blur (perte de focus) d'une cellule en mode ShowEditor. */
  protected CommitShowEditorValue(pRow: TDTO, pCol: GridColumn<TDTO>): void {
    const lKey: string = `${this.RowKey(pRow)}|${String(pCol.Key)}`;
    const lDraft: Map<string, unknown> = this.ShowEditorDraft();
    if (!lDraft.has(lKey)) {
      // - cm - Pas de valueChange reçu (cellule pas focusée ou pas tapée) : rien à committer.
      return;
    }
    const lNewValue: unknown = lDraft.get(lKey);

    this.ShowEditorDraft.update((pMap: Map<string, unknown>): Map<string, unknown> => {
      const lNext: Map<string, unknown> = new Map(pMap);
      lNext.delete(lKey);
      return lNext;
    });
    this.OnShowEditorValueChange(pRow, pCol, lNewValue);
  }

  protected CommitEdit(pRow: TDTO, pCol: GridColumn<TDTO>, pPreselectedValue?: unknown): void {
    // - cm - Pas de garde IsEditing ici : en mode ShowEditor l'<app-input> émet
    // - cm - valueChange sans qu'on soit passé par StartEdit. Sans ça, le commit
    // - cm - est silencieusement ignoré et CellEdited n'est jamais émis.
    const lOldValue: unknown = this.GetCellValue(pRow, String(pCol.Key));

    const lIsReactive: boolean = pCol.EditorType !== 'textarea' && pCol.EditorType !== 'select-search';
    const lNewValue: unknown = pPreselectedValue !== undefined
      ? pPreselectedValue
      : (lIsReactive ? this.EditorControl().value : this.ConvertEditValue(pCol));
    const lIsEmpty: boolean = lNewValue === null || lNewValue === undefined || lNewValue === '';

    const lSkipEmptyValidation: boolean = this.RequireAllFields && lIsEmpty;
    if (!lSkipEmptyValidation) {
      if (lIsReactive) {
        // - cm - Validation réactive : le validator DTO est déjà attaché au FormControl via ToValidatorFn
        this.EditorControl().updateValueAndValidity();
        if (this.EditorControl().invalid) {
          const lErrors: ValidationErrors | null = this.EditorControl().errors;
          this.EditError.set(lErrors && typeof lErrors['dto'] === 'string' ? lErrors['dto'] : 'Valeur invalide');
          return;
        }
      } else if (pCol.EditorValidator) {

        const lError: string | null = pCol.EditorValidator(lNewValue, pRow);
        if (lError) {
          this.EditError.set(lError);
          return;
        }
      }
    }
    const lRowIndex: number = this._Data().indexOf(pRow);
    // - cm - Mise à jour locale immédiate de la donnée (optimistic) pour que la cellule
    // - cm - affiche la nouvelle valeur sans attendre le reload du parent.
    if (lRowIndex >= 0) {
      this._Data.update(pData => {
        const lClone: TDTO[] = [...pData];
        const lRow: TDTO = lClone[lRowIndex];
        (lRow as Record<string, unknown>)[String(pCol.Key)] = lNewValue;
        return lClone;
      });
    }
    this.CellEdited.emit({
      Row: pRow,
      Key: String(pCol.Key),
      OldValue: lOldValue,
      NewValue: lNewValue,
      RowIndex: lRowIndex
    });

    if (this.MarkDirty) {
      this.MarkRowDirty(pRow);
    }
    // - cm - Revalide la ligne entière après édition si la validation ligne est activée
    if (this.ValidateRows) {
      this.RevalidateRow(pRow);
    }
    this.PostHog.Capture('grid_cell_edited', {key: String(pCol.Key), type: pCol.EditorType ?? 'text'});
    this.CancelEdit();
    // - cm - Si l'option est activée, ajoute un brouillon vide sous la dernière ligne remplie
    this.MaybeAppendDraftRow(pRow);
  }

  /** Annule l'édition inline en cours. */
  protected CancelEdit(): void {
    this.EditingRowKey.set(null);
    this.EditingColKey.set(null);
    this.EditValue.set('');
    this.EditError.set(null);
    this.EditorControl.set(new FormControl(''));
    this.SearchOpen.set(false);
    this.SearchQuery.set('');
  }

  /** Gère les touches clavier dans l'éditeur inline. */
  protected OnEditorKeydown(pEvent: KeyboardEvent, pRow: TDTO, pCol: GridColumn<TDTO>): void {
    if (pEvent.key === 'Enter') {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.CommitEdit(pRow, pCol);
      // - cm - Après commit, passe à la même colonne sur la ligne suivante (navigation Excel)
      this.EditBelow(pRow, pCol);
    } else if (pEvent.key === 'Escape') {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.CancelEdit();
    } else if (pEvent.key === 'Tab') {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.CommitEdit(pRow, pCol);
      if (pEvent.shiftKey) {
        this.EditPrevious(pRow, pCol);
      } else {
        this.EditNext(pRow, pCol);
      }
    }
  }

  //#region Selection
  /** Bascule la sélection d'une ligne (checkbox ligne). */
  protected ToggleSelectRow(pRow: TDTO, pChecked: boolean): void {
    const lKey: string = this.TrackBy(pRow);
    const lSelected: Set<string> = new Set(this.SelectedKeys());
    if (this.SelectionMode === 'single') {
      lSelected.clear();
    }
    if (pChecked) {
      lSelected.add(lKey);
    } else {
      lSelected.delete(lKey);
    }
    this.SelectedKeys.set(lSelected);
    this.SelectionChanged.emit(this.GetSelectedRows());
  }

  /** Bascule la sélection de toutes les lignes visibles (checkbox en-tête). */
  protected ToggleSelectAll(): void {
    if (this.SelectionMode === 'single') {
      return;
    }
    const lAll: boolean = this.AllSelected();
    const lSelected: Set<string> = new Set();
    if (!lAll) {
      for (const lRow of this.FilteredData()) {
        lSelected.add(this.TrackBy(lRow));
      }
    }
    this.SelectedKeys.set(lSelected);
    this.SelectionChanged.emit(this.GetSelectedRows());
  }

  // - cm - Indique si une ligne est sélectionnée.
  protected IsSelected(pRow: TDTO): boolean {
    return this.SelectedKeys().has(this.TrackBy(pRow));
  }

  //#region Pagination
  /** Navigue vers une page donnée (issu de app-pagination PageChange). */
  protected OnPageChange(pPage: number): void {
    if (pPage < 1 || pPage > this.TotalPages() || pPage === this._Page()) {
      return;
    }
    // - cm - 2026-08-13 KAN-106-GRID-PAGESIZE-SERVERSIDE : on met à jour _Page même en
    //      server-side (ClientFilter=false). Avant, on ne le faisait que si ClientFilter=true,
    //      ce qui causait un bug où le grid restait visuellement sur l'ancienne page
    //      même après un PageChanged correctement émis et traité par le parent.

    this._Page.set(pPage);
    this.PageChanged.emit({Page: this._Page(), PageSize: this._PageSize()});
  }

  /** Change la taille de page et remonte à la première page. */
  protected OnPageSizeChange(pSize: number): void {
    // - cm - 2026-08-13 KAN-106-GRID-PAGESIZE-SERVERSIDE : _PageSize doit être mis à jour
    //      même en server-side. Avant, on ne le faisait que si ClientFilter=true, ce qui
    //      causait un bug : changer le pageSize à 10 affichait toujours 25 dans le grid
    //      (le PageChanged.partenait bien au parent, mais le grid UI restait à 25).
    // - cm - KAN-GRID-PAGE-SIZE-PERSIST : la taille de page est persistee par
    //      contexte logique (PaginationContext) via GridPaginationService.
    //      Le service écrit en localStorage immediat puis en BDD en
    //      fire-and-forget (cf. ThemeService/GridZoomService pour le pattern).
    this._GridPaginationService.ApplyPageSize(this.PaginationContext, pSize);
    this._Page.set(1);
    this._PageSize.set(pSize);
    this.PageChanged.emit({Page: 1, PageSize: pSize});
  }

  /** Handler appelé quand les filtres changent (valeurs BaseCritereDTO). */
  protected OnFilterChange(pValues: BaseCritereDTO): void {
    this.FilterValues.set(pValues);
    this.FilterChanged.emit(pValues);


    const lCount: number = Object.keys(pValues as Record<string, unknown>).length;
    this.PostHog.Capture('grid_filter_changed', {fields: lCount});
  }

  /** Handler appelé quand l'utilisateur réinitialise les filtres. */
  protected OnFilterReset(): void {
    this.FilterValues.set({} as BaseCritereDTO);
    this.FilterChanged.emit({} as BaseCritereDTO);
  }

  /** Handler appelé quand l'utilisateur clique sur le bouton "Réessayer" de la zone d'erreur. */
  protected OnRetryClick(): void {
    this.ErrorRetry.emit();
  }

  //#endregion

  protected IsDirty(pRow: TDTO): boolean {
    return this.MarkDirty && this.DirtyKeys().has(this.TrackBy(pRow));
  }

  // - cm - Indique si une ligne est en cours de sauvegarde.
  protected IsRowSaving(pRow: TDTO): boolean {
    return this.SavingRowKeys().has(this.TrackBy(pRow));
  }

  // - cm - Indique si une cellule est en cours de sauvegarde.
  protected IsCellSaving(pRow: TDTO, pColKey: string): boolean {
    return this.SavingCellKeys().has(this.CellKey(pRow, pColKey));
  }

  /** Indique l'état de validation d'une ligne. */
  protected RowState(pRow: TDTO): 'error' | 'valid' | null {
    if (!this.ValidateRows) {
      return null;
    }
    return this.RowStates().get(this.TrackBy(pRow)) ?? null;
  }

  /** Retourne le message d'erreur d'une cellule si la ligne est en erreur. */
  protected CellError(pRow: TDTO, pCol: GridColumn<TDTO>): string | null {
    if (!this.ValidateRows) {
      return null;
    }
    return this.RowErrors().get(this.TrackBy(pRow))?.[String(pCol.Key)] ?? null;
  }

  // - cm - Indique si une cellule est en erreur.
  protected HasCellError(pRow: TDTO, pCol: GridColumn<TDTO>): boolean {
    return this.CellError(pRow, pCol) !== null;
  }

  //#endregion

  /** Retourne l'erreur d'une cellule sous forme de ligne structurée pour tooltip. */
  protected CellErrorLine(pRow: TDTO, pCol: GridColumn<TDTO>): TooltipLine[] {
    const lMessage: string | null = this.CellError(pRow, pCol);
    return lMessage ? [{Message: lMessage}] : [];
  }

  /** Retourne les erreurs d'une ligne sous forme de lignes structurées pour tooltip. */
  protected RowErrorsTooltipLines(pRow: TDTO): TooltipLine[] {
    const lErrors: Record<string, string> | undefined = this.RowErrors().get(this.TrackBy(pRow));
    if (!lErrors) {
      return [];
    }
    return Object.entries(lErrors).map(([lKey, lMessage]) => {
      const lLabel: string = this.VisibleColumns().find((lCol) => String(lCol.Key) === lKey)?.Label ?? lKey;
      return {Label: lLabel, Message: lMessage};
    });
  }

  //#endregion

  //#region Select-search editor
  /** Options filtrées par la requête de recherche courante. */
  protected FilteredOptions(pCol: GridColumn<TDTO>): IInputOption[] {
    const lOptions = this.NormalizeOptions(pCol);
    const lQuery: string = this.SearchQuery().toLowerCase().trim();
    if (!lQuery) {
      return lOptions;
    }
    return lOptions.filter((lOpt) => lOpt.Label.toLowerCase().includes(lQuery));
  }

  /** Sélectionne une option dans l'éditeur select-search et commit. */
  protected SelectSearchOption(pRow: TDTO, pCol: GridColumn<TDTO>, pValue: string | number | boolean, pEvent: Event): void {
    pEvent.stopPropagation();
    this.EditValue.set(String(pValue));
    this.SearchOpen.set(false);
    this.SearchQuery.set('');
    this.CommitEdit(pRow, pCol);
  }

  /** Handler `fullscreenchange` lié à `document` (stocké pour pouvoir le retirer). */
  private readonly _OnFullscreenChange: () => void = (): void => {
    this.IsFullscreen.set(this._IsBrowser && document.fullscreenElement === this._Host.nativeElement);
  };

  /** Récupère la largeur effective d'une colonne en px pour le calcul des offsets sticky. */
  private GetColumnWidthPx(pColumn: GridColumn<TDTO>): number {
    const lKey: string = String(pColumn.Key);
    // - cm - Priorité 1 : largeur resize utilisateur (mesurée au mousedown, source de vérité post-drag)
    const lWidths: Record<string, string> = this.ColumnWidths();
    const lRaw: string | undefined = lWidths[lKey] ?? pColumn.Width;
    if (lRaw) {
      const lMatch: RegExpMatchArray | null = lRaw.match(/^(\d+(?:\.\d+)?)px$/);
      if (lMatch) {
        return Math.round(Number(lMatch[1]));
      }
      // - cm - Formats type minmax(140px, 1fr) : on prend la valeur min en px
      const lMinMatch: RegExpMatchArray | null = lRaw.match(/(\d+(?:\.\d+)?)px/);
      if (lMinMatch) {
        return Math.round(Number(lMinMatch[1]));
      }
    }

    const lRendered: number | undefined = this._RenderedWidths()[lKey];
    if (typeof lRendered === 'number' && lRendered > 0) {
      return Math.round(lRendered);
    }
    return 180;
  }

  /** Mesure les largeurs effectives des colonnes dans le DOM (th + td 1ère ligne) */
  private MeasureRenderedWidths(): void {
    if (!this._IsBrowser) {
      return;
    }
    queueMicrotask((): void => {
      const lHost: HTMLElement | undefined = this._Host?.nativeElement;
      if (!lHost) {
        return;
      }
      const lThs: NodeListOf<HTMLElement> = lHost.querySelectorAll('.grid__thead .grid__th[data-key]');
      const lFirstRow: NodeListOf<HTMLElement> = lHost.querySelectorAll('.grid__tbody .grid__row:not(.grid__row--empty):first-child .grid__td[data-col-key]');
      const lWidths: Record<string, number> = {};
      lThs.forEach((pTh: HTMLElement): void => {
        const lKey: string | null = pTh.getAttribute('data-key');
        if (lKey) {
          lWidths[lKey] = Math.round(pTh.getBoundingClientRect().width);
        }
      });
      // - cm - Si le th n'est pas trouvé (cas skeleton ou vide), fallback sur la première td
      lFirstRow.forEach((pTd: HTMLElement): void => {
        const lKey: string | null = pTd.getAttribute('data-col-key');
        if (lKey && lWidths[lKey] === undefined) {
          lWidths[lKey] = Math.round(pTd.getBoundingClientRect().width);
        }
      });
      this._RenderedWidths.set(lWidths);
    });
  }

  //#endregion

  /** Resynchronise ColumnOrder avec les colonnes effectives sans perdre l'ordre persisté. */
  private SyncColumnOrder(): void {
    const lCols: GridColumn<TDTO>[] = this._Columns();
    const lValidKeys: Set<string> = new Set(lCols.map((lCol) => String(lCol.Key)));
    const lCurrent: string[] = this.ColumnOrder();
    // - cm - Filtre les clés obsolètes et conserve l'ordre existant
    const lKept: string[] = lCurrent.filter((lKey) => lValidKeys.has(lKey));
    // - cm - Ajoute les nouvelles colonnes non présentes dans l'ordre sauvegardé
    for (const lCol of lCols) {
      const lKey: string = String(lCol.Key);
      if (!lKept.includes(lKey)) {
        lKept.push(lKey);
      }
    }
    this.ColumnOrder.set(lKept);
  }

  /** S'abonne aux événements columnsRefresh de chaque directive <app-grid-column>. */
  private SubscribeDirectiveChanges(): void {
    // - cm - Nettoie les anciens abonnements
    this._DirectiveSubs.forEach(pFn => pFn());
    this._DirectiveSubs = [];
    const lDirectives = this.ColumnDirectives?.toArray() ?? [];
    for (const lDir of lDirectives) {
      const lSub = lDir.columnsRefresh.subscribe(() => this.RefreshColumns());
      this._DirectiveSubs.push(() => lSub.unsubscribe());
    }
  }

  /** Reconstruit la liste des colonnes finales depuis l'input OU les directives. */
  private RefreshColumns(): void {
    const lDirectives = this.ColumnDirectives?.toArray() ?? [];
    if (lDirectives.length > 0) {
      const lCols: GridColumn<TDTO>[] = lDirectives.map(pD => ({
        Key: pD.Key,
        Label: pD.Label,
        LabelCle: pD.LabelCle,
        Sortable: pD.Sortable,
        Hideable: pD.Hideable,
        Width: pD.Width,
        CellClass: pD.CellClass,
        CellTemplate: pD.CellTemplate,
        ShowEditor: pD.ShowEditor,
        Editable: pD.Editable,
        EditorType: pD.EditorType,
        EditorOptions: pD.EditorOptions,
        EditorOptionValueKey: pD.EditorOptionValueKey,
        EditorOptionLabelKey: pD.EditorOptionLabelKey,
        EditorValidator: pD.EditorValidator,
        EditorPlaceholder: pD.EditorPlaceholder,
        EditorPlaceholderCle: pD.EditorPlaceholderCle,
        EditorMin: pD.EditorMin,
        EditorMax: pD.EditorMax,
        EditorStep: pD.EditorStep,
        EditorMaxLength: pD.EditorMaxLength,
        Sticky: pD.Sticky
      }));

      if (this.AutoColumns) {
        const lAuto = this.GenerateAutoColumns();
        const lOverrideMap = new Map(lCols.map(pC => [String(pC.Key), pC]));
        const lMerged: GridColumn<TDTO>[] = lAuto.map(pA => lOverrideMap.get(String(pA.Key)) ?? pA);
        // - cm - Ajoute les colonnes override qui ne sont pas dans l'auto (colonnes calculées)
        for (const lCol of lCols) {
          if (!lMerged.some(pM => String(pM.Key) === String(lCol.Key))) {
            lMerged.push(lCol);
          }
        }
        this._Columns.set(lMerged);
      } else {
        this._Columns.set(lCols);
      }
    } else if (this._InputColumns().length > 0) {
      this._Columns.set(this._InputColumns());
    } else if (this.AutoColumns) {
      // - cm - Auto-génération seule (aucune directive, aucun input)
      this._Columns.set(this.GenerateAutoColumns());
    } else {
      this._Columns.set(this._InputColumns());
    }
  }

  /** Auto-génère les colonnes depuis les propriétés du premier DTO de Data. */
  private GenerateAutoColumns(): GridColumn<TDTO>[] {
    const lData = this._Data();
    if (!lData || lData.length === 0) return [];
    const lFirst = lData[0] as Record<string, unknown>;
    const lExclude = new Set([...(this.ExcludeColumns ?? []), 'id']);
    const lCols: GridColumn<TDTO>[] = [];

    for (const lKey of Object.keys(lFirst)) {
      if (lExclude.has(lKey)) continue;
      const lValue = lFirst[lKey];
      // - cm - Skip les tableaux (collections M:N, One-to-Many)
      if (Array.isArray(lValue)) continue;

      if (lValue === null || lValue === undefined) {
        lCols.push({Key: lKey, Label: this.FormatColumnLabel(lKey), Sortable: true});
        continue;
      }
      // - cm - Navigation (objet) : affiche le libellé si dispo, sinon skip
      if (typeof lValue === 'object') {
        const lNav = lValue as Record<string, unknown>;
        const lDisplayKey = lNav['libelle'] != null ? 'libelle' : lNav['nom'] != null ? 'nom' : lNav['code'] != null ? 'code' : null;
        if (lDisplayKey) {
          lCols.push({Key: `${lKey}.${lDisplayKey}`, Label: this.FormatColumnLabel(lKey), Sortable: false});
        }
        continue;
      }
      // - cm - Propriété simple (string/number/boolean/date)
      lCols.push({Key: lKey, Label: this.FormatColumnLabel(lKey), Sortable: true});
    }
    return lCols;
  }

  //#endregion

  /** Repositionne le menu contextuel après rendu pour éviter qu'il dépasse du viewport */
  private ClampContextMenuToViewport(): void {
    if (!this._IsBrowser) {
      return;
    }
    this._Zone.runOutsideAngular(() => {
      requestAnimationFrame(() => {
        const lEl: HTMLElement | undefined = this._ContextMenuRef?.nativeElement;
        const lCtx = this.ContextMenu();
        if (!lEl || !lCtx) {
          return;
        }
        const lRect: DOMRect = lEl.getBoundingClientRect();
        const lMargin: number = 8;
        let lNewX: number = lCtx.X;
        let lNewY: number = lCtx.Y;
        // - cm - Déborde à droite : décale vers la gauche
        if (lCtx.X + lRect.width > window.innerWidth - lMargin) {
          lNewX = Math.max(lMargin, window.innerWidth - lRect.width - lMargin);
        }
        // - cm - Déborde en bas : flip vers le haut (bas du menu au curseur)
        if (lCtx.Y + lRect.height > window.innerHeight - lMargin) {
          lNewY = Math.max(lMargin, lCtx.Y - lRect.height);
          // - cm - Si flip vers le haut déborde encore en haut, on colle en haut du viewport
          if (lNewY + lRect.height > window.innerHeight - lMargin) {
            lNewY = lMargin;
          }
        }
        if (lNewX !== lCtx.X || lNewY !== lCtx.Y) {
          this._Zone.run(() => {
            this.ContextMenu.set({...lCtx, X: lNewX, Y: lNewY});
          });
        }
      });
    });
  }

  /** Épingle une colonne sur un bord ('left' | 'right') et la déplace au bord correspondant. */
  private SetColumnSticky(pColumn: GridColumn<TDTO>, pSide: 'left' | 'right'): void {
    const lMap: Map<string, 'left' | 'right'> = new Map(this.StickyColumns());
    lMap.set(String(pColumn.Key), pSide);
    this.StickyColumns.set(lMap);

    // - cm - Reorder la colonne au bord correspondant pour éviter la troncation.
    const lOrder: string[] = this.OrderedColumns().map((lCol) => String(lCol.Key));
    const lKey: string = String(pColumn.Key);
    const lCurrentIndex: number = lOrder.indexOf(lKey);
    if (lCurrentIndex !== -1) {
      lOrder.splice(lCurrentIndex, 1);
      if (pSide === 'left') {
        // - cm - Insère après les colonnes déjà sticky-left (empilement naturel gauche -> droite)
        const lStickyLeftCount: number = lOrder.filter((lK) => lMap.get(lK) === 'left').length;
        lOrder.splice(lStickyLeftCount, 0, lKey);
      } else {
        // - cm - Insère avant les colonnes déjà sticky-right (empilement droite -> gauche)
        const lFirstStickyRightIdx: number = lOrder.findIndex((lK) => lMap.get(lK) === 'right');
        if (lFirstStickyRightIdx === -1) {
          lOrder.push(lKey);
        } else {
          lOrder.splice(lFirstStickyRightIdx, 0, lKey);
        }
      }
      this.ColumnOrder.set(lOrder);
    }

    this.SavePersistence();
  }

  //#endregion

  /** Détache une colonne (retire l'épinglage) et la remet à sa position d'origine. */
  private ClearColumnSticky(pColumn: GridColumn<TDTO>): void {
    const lMap: Map<string, 'left' | 'right'> = new Map(this.StickyColumns());
    if (!lMap.delete(String(pColumn.Key))) {
      return;
    }
    this.StickyColumns.set(lMap);

    // - cm - Reconstruit l'ordre depuis l'ordre par défaut (position d'origine dans le template).
    const lDefaultOrder: string[] = this._Columns().map((lCol) => String(lCol.Key));

    const lStickyLeftKeys: string[] = lDefaultOrder.filter((lK) => lMap.get(lK) === 'left');
    const lStickyRightKeys: string[] = lDefaultOrder.filter((lK) => lMap.get(lK) === 'right');
    const lNormalKeys: string[] = lDefaultOrder.filter((lK) => !lMap.has(lK));

    // - cm - Ordre final : [sticky-left dans l'ordre d'origine] + [normales dans l'ordre d'origine] + [sticky-right dans l'ordre d'origine]
    const lNewOrder: string[] = [...lStickyLeftKeys, ...lNormalKeys, ...lStickyRightKeys];
    this.ColumnOrder.set(lNewOrder);

    this.SavePersistence();
  }

  /** Applique le tri sur une colonne avec une direction explicite et émet SortChanged. */
  private SetSort(pColumn: GridColumn<TDTO>, pDirection: 'asc' | 'desc' | null): void {
    if (!pColumn.Sortable) {
      return;
    }
    if (pDirection === null) {
      this.SortKey.set(null);
      this.SortDirection.set(null);
    } else {
      this.SortKey.set(String(pColumn.Key));
      this.SortDirection.set(pDirection);
    }
    this.SortChanged.emit({Key: this.SortKey() ?? '', Direction: this.SortDirection()});
  }

  /** Relève les largeurs rendues de toutes les colonnes visibles via le DOM et les fige dans ColumnWidths. Garde-fou anti-saut initial au redimensionnement. */
  private SnapshotColumnWidths(): void {
    if (!this._IsBrowser) {
      return;
    }
    const lWidths: Record<string, string> = {...this.ColumnWidths()};
    const lThs: NodeListOf<HTMLElement> = this._Host.nativeElement.querySelectorAll('.grid__thead .grid__th[data-key]');
    lThs.forEach((pTh: HTMLElement): void => {
      const lKey: string | null = pTh.getAttribute('data-key');
      if (lKey) {
        lWidths[lKey] = `${Math.round(pTh.getBoundingClientRect().width)}px`;
      }
    });
    this.ColumnWidths.set(lWidths);
  }

  //#endregion

  //#region Cell saving state

  /**
   * Met a jour le niveau de zoom et persiste la preference (BDD + localStorage).
   * - cm - Depuis que le zoom est persiste via `GridZoomService`, on delègue
   * la mutation au service (`ApplyZoom`). Les signaux derives (min/max/modified)
   * sont maintenant des `computed` qui re-agissent automatiquement a
   * `CurrentZoom()`. L'ancien code `set()` sur signaux est obsolete.
   */
  private UpdateZoomState(pLevel: number): void {
    const lClamped: number = Math.max(GRID_ZOOM.Min, Math.min(GRID_ZOOM.Max, pLevel));
    this._GridZoomService.ApplyZoom(lClamped);
  }

  //#region Persistence
  /** Charge la persistance localStorage (ordre + visibilité). */
  private LoadPersistence(): void {
    if (!this._IsBrowser) {
      // - cm - Initialise l'ordre par défaut côté SSR
      this.ColumnOrder.set(this._Columns().map((lCol) => String(lCol.Key)));
      return;
    }
    try {
      const lRaw: {
        Order?: string[];
        Hidden?: string[];
        Widths?: Record<string, string>;
        Sticky?: Record<string, 'left' | 'right'>;
        ActionsSticky?: boolean
      } | null = this.LocalStorage.Restore<{
        Order?: string[];
        Hidden?: string[];
        Widths?: Record<string, string>;
        Sticky?: Record<string, 'left' | 'right'>;
        ActionsSticky?: boolean
      }>(this.PersistenceKey());
      if (lRaw) {
        const lParsed = lRaw;
        if (Array.isArray(lParsed.Order)) {
          this.ColumnOrder.set(lParsed.Order);
        } else {
          this.ColumnOrder.set(this._Columns().map((lCol) => String(lCol.Key)));
        }
        if (Array.isArray(lParsed.Hidden)) {
          this.HiddenColumns.set(new Set(lParsed.Hidden));
        }
        if (lParsed.Widths && typeof lParsed.Widths === 'object') {
          this.ColumnWidths.set({...lParsed.Widths});
        }
        if (lParsed.Sticky && typeof lParsed.Sticky === 'object') {
          const lMap: Map<string, 'left' | 'right'> = new Map();
          for (const [lKey, lSide] of Object.entries(lParsed.Sticky)) {
            if (lSide === 'left' || lSide === 'right') {
              lMap.set(lKey, lSide);
            }
          }
          this.StickyColumns.set(lMap);
        }
        if (typeof lParsed.ActionsSticky === 'boolean') {
          this.ActionsSticky.set(lParsed.ActionsSticky);
        }
      } else {
        this.ColumnOrder.set(this._Columns().map((lCol) => String(lCol.Key)));
      }
    } catch {
      this.ColumnOrder.set(this._Columns().map((lCol) => String(lCol.Key)));
    }
  }

  /** Sauvegarde la persistance localStorage (ordre + visibilité + sticky). */
  private SavePersistence(): void {
    if (!this._IsBrowser) {
      return;
    }
    try {
      const lStickyRecord: Record<string, 'left' | 'right'> = {};
      for (const [lKey, lSide] of this.StickyColumns()) {
        lStickyRecord[lKey] = lSide;
      }
      const lPayload: {
        Order: string[];
        Hidden: string[];
        Widths: Record<string, string>;
        Sticky: Record<string, 'left' | 'right'>;
        ActionsSticky: boolean
      } = {
        Order: this.ColumnOrder(),
        Hidden: [...this.HiddenColumns()],
        Widths: this.ColumnWidths(),
        Sticky: lStickyRecord,
        ActionsSticky: this.ActionsSticky()
      };
      this.LocalStorage.Save(this.PersistenceKey(), lPayload);
    } catch {
      // - cm - Ignore les erreurs quota / mode privé
    }
  }

  //#endregion

  // - cm - Clé de persistance localStorage.
  private PersistenceKey(): string {
    return `app-grid:${this.StorageKey}`;
  }

  /** Ajoute une ligne brouillon vide sous la dernière ligne si un champ a été rempli. */
  private MaybeAppendDraftRow(pRow: TDTO): void {
    if (!this.AllowAddRow || !this.AutoAddRow || !this.NewRowFactory) {
      return;
    }
    const lData: TDTO[] = this._Data();
    const lLastIndex: number = lData.length - 1;
    const lRowIndex: number = lData.indexOf(pRow);
    if (lRowIndex !== lLastIndex || lRowIndex < 0) {
      return;
    }
    if (!this.RowHasEditableContent(pRow)) {
      return;
    }
    const lNewRow: TDTO = this.NewRowFactory();
    this._Data.update(pData => [...pData, lNewRow]);
    if (this.ValidateRows) {
      this.RevalidateRow(lNewRow);
    }
  }

  /** Convertit la valeur d'édition selon le type d'éditeur. */
  private ConvertEditValue(pCol: GridColumn<TDTO>): unknown {
    const lRaw: string = this.EditValue();
    if (pCol.EditorType === 'number') {
      if (lRaw === '') {
        return undefined;
      }
      const lNum: number = Number(lRaw);
      return isNaN(lNum) ? undefined : lNum;
    }
    return lRaw;
  }

  /** Démarre l'édition sur la prochaine colonne éditable de la même ligne (ou ligne suivante). */
  private EditNext(pRow: TDTO, pCol: GridColumn<TDTO>): void {
    const lCols: GridColumn<TDTO>[] = this.VisibleColumns();
    const lSorted: TDTO[] = this.FilteredData();
    const lColIndex: number = lCols.findIndex((lC) => String(lC.Key) === String(pCol.Key));
    // - cm - Cherche la prochaine colonne éditable sur la même ligne
    for (let i: number = lColIndex + 1; i < lCols.length; i++) {
      if (this.CanEdit(lCols[i])) {
        this.StartEdit(pRow, lCols[i], new Event('click'));
        return;
      }
    }
    // - cm - Sinon passe à la ligne suivante, première colonne éditable
    const lRowIndex: number = lSorted.indexOf(pRow);
    if (lRowIndex >= 0 && lRowIndex < lSorted.length - 1) {
      const lNextRow: TDTO = lSorted[lRowIndex + 1];
      for (const lC of lCols) {
        if (this.CanEdit(lC)) {
          this.StartEdit(lNextRow, lC, new Event('click'));
          return;
        }
      }
    }
  }

  /** Déplace l'édition à la même colonne sur la ligne suivante (navigation verticale type Excel). */
  private EditBelow(pRow: TDTO, pCol: GridColumn<TDTO>): void {
    const lData: TDTO[] = this.FilteredData();
    const lRowIndex: number = lData.indexOf(pRow);
    if (lRowIndex < 0 || lRowIndex >= lData.length - 1) {
      return;
    }
    const lNextRow: TDTO = lData[lRowIndex + 1];
    this.StartEdit(lNextRow, pCol, new Event('click'));
  }

  /** Démarre l'édition sur la colonne éditable précédente de la même ligne (ou ligne précédente). */
  private EditPrevious(pRow: TDTO, pCol: GridColumn<TDTO>): void {
    const lCols: GridColumn<TDTO>[] = this.VisibleColumns();
    const lSorted: TDTO[] = this.FilteredData();
    const lColIndex: number = lCols.findIndex((lC) => String(lC.Key) === String(pCol.Key));
    // - cm - Cherche la colonne éditable précédente sur la même ligne
    for (let i: number = lColIndex - 1; i >= 0; i--) {
      if (this.CanEdit(lCols[i])) {
        this.StartEdit(pRow, lCols[i], new Event('click'));
        return;
      }
    }
    // - cm - Sinon passe à la ligne précédente, dernière colonne éditable
    const lRowIndex: number = lSorted.indexOf(pRow);
    if (lRowIndex > 0) {
      const lPrevRow: TDTO = lSorted[lRowIndex - 1];
      for (let i: number = lCols.length - 1; i >= 0; i--) {
        if (this.CanEdit(lCols[i])) {
          this.StartEdit(lPrevRow, lCols[i], new Event('click'));
          return;
        }
      }
    }
  }

  /** Focus l'élément éditeur inline actuellement rendu. */
  private FocusEditor(): void {
    // - cm - 1) Récupère la <td> en cours d'édition (priorité au ref DOM capturé au clic).
    let lCell: HTMLElement | null = this._EditingCellRef();
    // - cm - 2) Fallback : recherche par data-row-key + data-col-key (= AddNewRow, Tab, EditNext/Previous).
    if (!lCell) {
      const lRowKey: string | null = this.EditingRowKey();
      const lColKey: string | null = this.EditingColKey();
      if (lRowKey && lColKey) {
        lCell = this._Host.nativeElement.querySelector<HTMLElement>(
          `td[data-row-key="${CSS.escape(lRowKey)}"][data-col-key="${CSS.escape(lColKey)}"]`
        );
      }
    }
    // - cm - 3) Fallback legacy : premier .grid__editor-host (cas pathologique non attendu).
    if (!lCell) {
      lCell = this._Host.nativeElement.querySelector<HTMLElement>('.grid__editor-host')?.closest<HTMLElement>('td') ?? null;
    }
    if (!lCell) {
      return;
    }
    // - cm - Scroll keyboard-aware : sur mobile, l'ancien `scrollIntoView({ block: 'nearest' })`
    // - cm - considérait la cellule comme "visible" même quand le clavier virtuel Android/iOS
    // - cm - en masquait la moitié basse. On remonte les ancêtres scrollables, on tient compte
    // - cm - de `visualViewport.height` (réduit quand le clavier est visible), et on centre
    // - cm - la cellule dans la zone réellement visible. Re-scroll à 350ms pour suivre

    // - cm - L'<app-input> enfant écoute visualViewport.resize pour suivre l'animation
    // - cm - d'apparition du clavier (200-300ms), donc pas besoin de setTimeout ici.
    this._ScrollCellIntoVisibleArea(lCell, 24);
    // - cm - Cherche l'élément focusable dans la cellule éditée uniquement (pas dans tout le grid).
    const lNative: HTMLElement | null = lCell.querySelector<HTMLElement>('.grid__editor');
    const lHost: HTMLElement | null = lCell.querySelector<HTMLElement>('.grid__editor-host');
    let lTarget: HTMLElement | null = lNative;
    if (!lTarget && lHost) {

      lTarget = lHost.querySelector<HTMLElement>('input, textarea, select, button, .input-field');
    }
    if (!lTarget) {
      return;
    }
    // - cm - preventScroll: true évite que .focus() re-scrolle après notre scrollIntoView (et évite
    // - cm - un éventuel aller-retour si le navigateur décide d'aligner différemment).
    lTarget.focus({preventScroll: true});

    // - cm - (l'utilisateur n'a pas besoin de tout sélectionner à la main). Pas pour les selects.
    this.SelectEditorText(lTarget);
  }

  //#endregion

  //#region Filter
  /** Construit la liste des champs de filtre depuis un schéma objet (critere DTO). */
  private BuildFieldsFromSchema(pSchema: Record<string, FilterSchemaField>, pExcludedKeys: string[]): FilterFieldConfig[] {
    const lDefaultExcluded: string[] = ['id', 'page', 'pagesize', 'sortby', 'sortdirection'];
    const lExcluded: Set<string> = new Set([...lDefaultExcluded, ...pExcludedKeys.map((lK) => lK.toLowerCase())]);
    return Object.keys(pSchema)
      .filter((pKey: string) => !lExcluded.has(pKey.toLowerCase()))
      .map((pKey: string): FilterFieldConfig => {
        const lRaw: FilterSchemaField = pSchema[pKey];
        const lIsMeta: boolean = lRaw !== null && typeof lRaw === 'object' && !Array.isArray(lRaw) && 'Value' in (lRaw as Record<string, unknown>);
        const lMeta: Record<string, unknown> | null = lIsMeta ? (lRaw as Record<string, unknown>) : null;
        const lValue: unknown = lMeta ? lMeta['Value'] : lRaw;
        const lType: FilterFieldType = this.InferFilterType(pKey, lValue);
        const lLabel: string = this.SchemaKeyToLabel(pKey);
        return {
          Key: pKey,
          Label: lLabel,
          Type: lType,
          Placeholder: lType === 'text' || lType === 'number' ? `Filtrer par ${lLabel.toLowerCase()}` : undefined
        };
      });
  }

  /** Infère le type de filtre depuis la clé et la valeur du schéma. */
  private InferFilterType(pKey: string, pValue: unknown): FilterFieldType {
    const lKey: string = pKey.toLowerCase();
    if (typeof pValue === 'boolean') {
      return 'checkbox';
    }
    if (typeof pValue === 'number') {
      return 'number';
    }
    if (pValue instanceof Date) {
      return 'date';
    }
    if (lKey.includes('date') || lKey.endsWith('at') || lKey.endsWith('date')) {
      return 'date';
    }
    return 'text';
  }

  //#endregion
  //#endregion

  /** Construit le nom de fichier d'export avec un timestamp lisible. */
  private BuildExportFilename(): string {
    const lPrefix: string = (this.ExportFilenamePrefix || 'export').trim() || 'export';
    const lNow: Date = new Date();
    const lPad: (pValue: number) => string = (pValue: number): string => String(pValue).padStart(2, '0');
    const lTimestamp: string =
      `${lNow.getFullYear()}-${lPad(lNow.getMonth() + 1)}-${lPad(lNow.getDate())}` +
      `_${lPad(lNow.getHours())}-${lPad(lNow.getMinutes())}-${lPad(lNow.getSeconds())}`;
    return `${lPrefix}_${lTimestamp}.csv`;
  }

  /** Indique si au moins un champ de filtre a une valeur non vide. */
  private HasActiveFilter(): boolean {
    const lValues: Record<string, unknown> = this.FilterValues() as Record<string, unknown>;
    const lFields: FilterFieldConfig[] = this.EffectiveFilterFields();
    return lFields.some((lF) => {
      const lV: unknown = lValues[lF.Key];
      return lV !== null && lV !== undefined && lV !== '' && !(lF.Type === 'checkbox' && lV === false);
    });
  }

  //#region Dirty indicator
  /** Marque une ligne comme modifiée (dirty) non encore confirmée par le parent. */
  private MarkRowDirty(pRow: TDTO): void {
    const lKey: string = this.TrackBy(pRow);
    const lDirty: Set<string> = new Set(this.DirtyKeys());
    if (!lDirty.has(lKey)) {
      lDirty.add(lKey);
      this.DirtyKeys.set(lDirty);
    }
  }

  //#endregion
}
