/**
 * Helpers purs (sans état d'instance) pour les grilles CRUD SellMatch.
 *
 * `FormatPrice` et `FormatDate` sont dans `BaseComponent` (et son dérivé
 * `GridBase`) — les grilles les utilisent via `this.FormatPrice(...)` /
 * `this.FormatDate(...)` sans helper dédié ici. Seules les fonctions vraiment
 * stateless (id temporaire, référence, type-guard adresse) sont exportées.
 *
 * Historique : ces fonctions étaient autrefois dans `BienGridBase` (classe
 * abstraite couplée au module CRM). La migration vers `GridComponentBase`
 * les a sorties pour pouvoir être appelées par n'importe quelle grille sans
 * dépendance d'héritage.
 */

/**
 * Génère un id temporaire négatif pour distinguer une nouvelle ligne avant
 * création en BDD (TrackBy unique dans la grille).
 * @returns L'id temporaire négatif.
 */
export function GenerateTempId(): number {
  return -(Date.now() % 1000000);
}

/**
 * Génère une référence unique au format PREFIX-YYYYMMDDHHmmssRRR.
 * @param pPrefix Préfixe métier (TRX, LOC, PROP, PRJ, OBJ, etc.).
 * @returns La référence générée.
 */
export function GenerateReference(pPrefix: string): string {
  const lNow: Date = new Date();
  const lPad = (pVal: number): string => pVal.toString().padStart(2, '0');
  const lStamp: string =
    lNow.getFullYear().toString() +
    lPad(lNow.getMonth() + 1) +
    lPad(lNow.getDate()) +
    lPad(lNow.getHours()) +
    lPad(lNow.getMinutes()) +
    lPad(lNow.getSeconds());
  const lRand: string = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${pPrefix}-${lStamp}${lRand}`;
}

/**
 * Détermine si une valeur est un AdressesDTO (utilisé par les handlers
 * CellEdited pour éviter d'écraser l'objet avec une string après une édition
 * d'adresse).
 * @param pValue La valeur à tester.
 * @returns True si la valeur est un objet avec une propriété 'city'.
 */
export function IsAdressesDTO(pValue: unknown): pValue is { city?: string } {
  return !!pValue && typeof pValue === 'object' && 'city' in (pValue as Record<string, unknown>);
}
