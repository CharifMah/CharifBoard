import {
  Directive,
  Input,
  Output,
  EventEmitter,
  TemplateRef,
  ContentChild,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import {IInputOption} from '../../../shared/components/input/input.types';

/**
 * Directive de définition d'une colonne du tableau générique, utilisée
 * en content projection dans `<app-grid>` : permet de déclarer les colonnes
 * directement dans le template HTML via des sous-balises `<app-grid-column>`.
 *
 * @example
 * ```html
 * <app-grid [Data]="Items()" [Loading]="Loading()">
 *   <app-grid-column Key="reference" Label="Référence" [Sortable]="true" Width="140px" />
 *   <app-grid-column Key="nom" Label="Nom" [Sortable]="true">
 *     <ng-template #cell let-row>{{ row.prenom }} {{ row.nom }}</ng-template>
 *   </app-grid-column>
 * </app-grid>
 * ```
 */
@Directive({
  selector: 'app-grid-column',
  standalone: true
})
export class GridColumnDirective<TDTO = Record<string, unknown>> implements OnChanges {

    /** Clé d'accès à la valeur (propriété de TDTO ou chemin pointé ex: `contactPrincipal.nom`). */
  @Input() Key: keyof TDTO | string = '';

  /** Libellé affiché dans l'en-tête. */
  @Input() Label: string = '';

  /**
   * Clé i18n (ex: `crm-recrutement.contact`). Si fournie, le grid la traduit via
   * le pipe `tkey` en priorité sur `Label`. Le `columnsRefresh` (cf. ngOnChanges) garantit
   * la mise à jour au switch de langue.
   */
  @Input() LabelCle?: string;

  /** Indique si la colonne est triable (défaut: false). */
  @Input() Sortable = false;

  /** Indique si la colonne est masquable par l'utilisateur (défaut: true). */
  @Input() Hideable = true;

  /** Largeur CSS optionnelle (ex: `180px`, `minmax(140px, 1fr)`). */
  @Input() Width?: string;

  /** Classe CSS additionnelle appliquée aux cellules de cette colonne. Chaîne fixe ou fonction (value, row) → string. */
  @Input() CellClass?: string | ((pValue: unknown, pRow: unknown) => string);

  /** Active l'édition inline sur cette colonne (défaut: false). */
  @Input() Editable = false;

  /** Type d'éditeur: 'text', 'number', 'date', 'select', 'select-search', 'textarea', 'address'. Défaut: 'text'. */
  @Input() EditorType: 'text' | 'number' | 'date' | 'select' | 'select-search' | 'textarea' | 'address' = 'text';

  /** Options pour l'éditeur 'select' et 'select-search': liste { Value, Label } OU DTO bruts (avec EditorOptionValueKey/EditorOptionLabelKey). */
  @Input() EditorOptions?: IInputOption[] | readonly unknown[];

  /** Clé du champ servant de valeur pour les options DTO (ex: 'id'). Si absente, EditorOptions doit être au format {Value,Label}. */
  @Input() EditorOptionValueKey?: string;
  /** Clé du champ servant de libellé pour les options DTO (ex: 'libelle'). Si absente, EditorOptions doit être au format {Value,Label}. */
  @Input() EditorOptionLabelKey?: string;

  /** Validateur optionnel : retourne un message d'erreur ou null si valide. */
  @Input() EditorValidator?: ((pValue: unknown, pRow: TDTO) => string | null) | null;

  /** Placeholder de l'éditeur. */
  @Input() EditorPlaceholder?: string;

  /** Clé i18n du placeholder (rendu via `| tkey` à l'affichage). Voir `LabelCle` pour la sémantique. */
  @Input() EditorPlaceholderCle?: string;

  /** Valeur minimale pour l'éditeur 'number'. */
  @Input() EditorMin?: number;

  /** Valeur maximale pour l'éditeur 'number'. */
  @Input() EditorMax?: number;

  /** Pas (incrément) pour l'éditeur 'number'. */
  @Input() EditorStep?: number;

  /** Longueur maximale (en caractères) pour l'éditeur 'text'. Couplé à `Validators.maxLength`. */
  @Input() EditorMaxLength?: number | null;

  /** Rend la colonne sticky (collée) horizontalement pendant le scroll. Défaut: 'none'. Configurable par clic droit sur l'en-tête. */
  @Input() Sticky: 'left' | 'right' | 'none' = 'none';

  /** Émis quand un @Input de la directive change (pour notifier le grid parent). */
  @Output() readonly columnsRefresh = new EventEmitter<void>();

  /**
   * Détecte les changements sur les @Input et notifie le grid parent
   * pour rafraîchir les colonnes (notamment EditorOptions après chargement asynchrone).
   * @param pChanges Les changements détectés.
   */
  ngOnChanges(pChanges: SimpleChanges): void {
    // - cm - Ignore le premier cycle (ngOnInit du parent s'en charge)
    const lOptionsChanged = pChanges['EditorOptions'] && !pChanges['EditorOptions'].firstChange;
    const lValueKeyChanged = pChanges['EditorOptionValueKey'] && !pChanges['EditorOptionValueKey'].firstChange;
    const lLabelKeyChanged = pChanges['EditorOptionLabelKey'] && !pChanges['EditorOptionLabelKey'].firstChange;
    // - cm - Le `Label` peut être bindé à un pipe `tkey` (`pure: false`) qui change
    // - cm - au changement de langue. Il faut notifier le grid parent pour qu'il
    // - cm - reconstruise la liste `_Columns()` avec le nouveau Label.
    const lLabelChanged = pChanges['Label'] && !pChanges['Label'].firstChange;
    const lLabelCleChanged = pChanges['LabelCle'] && !pChanges['LabelCle'].firstChange;
    const lStickyChanged = pChanges['Sticky'] && !pChanges['Sticky'].firstChange;
    // - cm - Idem pour `EditorPlaceholder` : peut être bindé à un pipe `tkey` qui
    // - cm - change au switch de langue. Sans ce notify, la grid reste sur la valeur
    // - cm - initiale (souvent vide ou clé brute) et le fallback `Saisir ${Label}…`
    // - cm - de grid.component.ts prend le relais visuellement.
    const lPlaceholderChanged = pChanges['EditorPlaceholder'] && !pChanges['EditorPlaceholder'].firstChange;
    const lPlaceholderCleChanged = pChanges['EditorPlaceholderCle'] && !pChanges['EditorPlaceholderCle'].firstChange;
    if (lOptionsChanged || lValueKeyChanged || lLabelKeyChanged || lLabelChanged || lLabelCleChanged || lStickyChanged || lPlaceholderChanged || lPlaceholderCleChanged) {
      this.columnsRefresh.emit();
    }
  }

  /**
   * Template personnalisé pour le rendu de la cellule, défini via
   * `<ng-template #cell let-row>` à l'intérieur de la balise `<app-grid-column>`.
   * Le contexte expose `$implicit` (la valeur) et `row` (la ligne complète).
   */
  @ContentChild('cell', {static: false}) CellTemplate?: TemplateRef<unknown>;
  /** Rend l'éditeur (app-input) directement en consultation au lieu du CellTemplate / label flottant. */
  @Input() ShowEditor = false;
}
