import { Directive, inject, PLATFORM_ID, ElementRef, Input } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import type { GridColumn } from '../../../shared/components/grid/GridColumn';
import type { IInputOption } from '../../../shared/components/input/input.types';
import { ScrollIntoVisibleArea } from '../../../shared/components/input/helpers/input-scroll-into-view.helper';
import {BaseDTO} from "../../../core/base/BaseDTO";
import type {BaseCritereDTO} from "../../../core/base/base.critere";

/**
 * Constantes de zoom par défaut du grid générique.
 */
export const GRID_ZOOM = {
  /** Niveau de zoom par défaut (100%). */
  Default: 1.0,
  /** Niveau de zoom minimum (50%). */
  Min: 0.5,
  /** Niveau de zoom maximum (200%). */
  Max: 2.0,
  /** Incrément de zoom (10%). */
  Step: 0.1
} as const;

/**
 * Largeur minimale (en pixels) d'une colonne lors du redimensionnement à la souris.
 * Garantit qu'une colonne reste utilisable dans un contexte CRM (libellé lisible, filtre accessible).
 * Valeur augmentée depuis 40px (trop faible : colonnes quasi illisibles après resize).
 */
export const MIN_COLUMN_WIDTH = 80;

/**
 * Base partagée du tableau générique.
 *
 * Détient l'état partagé (données, colonnes, TrackBy, configuration) et les accesseurs
 * de valeurs réutilisés par les services spécialisés (`GridSortService`, `GridFilterService`, etc.).
 * Les services dépendent de cette abstraction (polymorphisme) : le composant concret
 * `GridComponent` en fournit l'instance unique.
 *
 * `@Directive()` (sans selector) est nécessaire pour qu'Angular accepte les
 * décorateurs `@Input()` dans une classe abstraite sans composant concret.
 * @typeParam TDTO Type de la ligne (DTO).
 */
@Directive()
export abstract class GridBase<TDTO extends BaseDTO, TCritere extends BaseCritereDTO = BaseCritereDTO> extends BaseComponent {
  //#region Shared State
  /** Fonction de suivi pour le ngFor (perf). */
  public TrackBy: (pItem: TDTO) => string = (pItem: TDTO): string => String((pItem as Record<string, unknown>)['id'] ?? '');
  /** Clé de persistance localStorage pour les colonnes visibles et l'ordre. */
  @Input() public StorageKey: string = 'app-grid';
  /** Flag interne lecture seule. Bindable via `[ReadOnly]` côté parent. */
  protected _ReadOnly: boolean = false;
  /**
   * Mode lecture seule : désactive l'édition inline, l'ajout de ligne, et les actions edit/delete.
   * - cm - Pas de `@Input()` ici. La déclaration est redécorée dans
   *   `GridComponentBase` (classe décorée par `@Directive()`) pour qu'Angular
   *   propage le binding à travers la mixin `GridI18nMixin(...)`. Garder le
   *   `@Input()` ici casserait la propagation (un override ne peut pas
   *   ré-déclarer un décorateur).
   *  Bindable depuis le template parent (ex: `[ReadOnly]="true"` dans crm-agent-chat).
   */
  public set ReadOnly(pValue: boolean) {
    this._ReadOnly = pValue;
  }
  /** Getter : expose le flag lecture seule (utilisé par les templates internes). */
  public get ReadOnly(): boolean {
    return this._ReadOnly;
  }
  /** Active la pagination intégrée (footer). Défaut: false. Prop simple statique (lue par les services sans signal). */
  public Paginated = false;
  /** Si true, le filtre est appliqué côté client. Si false, émet seulement FilterChanged. Défaut: true. Prop simple statique. */
  public ClientFilter = true;
  /** Mode de sélection: 'single' ou 'multiple'. Défaut: 'multiple'. Prop simple statique. */
  public SelectionMode: 'single' | 'multiple' = 'multiple';
  /** Active globalement l'édition inline sur le grid. Défaut: false. Prop simple statique. */
  public Editable = false;
  /** Active le marquage visuel des lignes modifiées non confirmées. Défaut: false. Prop simple statique. */
  public MarkDirty = false;
  /** Active la validation ligne par ligne (état error/valid). Défaut: false. Prop simple statique. */
  public ValidateRows = false;
  /** Indique si la validation exige que tous les champs éditables soient remplis. Défaut: false. Prop simple statique. */
  public RequireAllFields = false;
  /** Séparateur CSV utilisé lors de l'export (défaut: ','). Lit du GridBase pour permettre au GridExportService d'y accéder. */
  public CsvSeparator: string = ',';
  /** Préfixe du nom de fichier exporté. Le service concatène avec un timestamp. Défaut: 'export'. */
  public ExportFilenamePrefix: string = 'export';
  /** Si true, l'export CSV utilise les données filtrées + triées. Si false, exporte `Data` brut. Défaut: true. */
  public ExportOnlyFiltered: boolean = true;
  /** Si false, omet le BOM UTF-8 en début de fichier (utile pour des outils non-Excel). Défaut: true. */
  public ExportIncludeBom: boolean = true;
  /** Flag d'état : mis à jour par le composant pour refléter si un filtre est actif (utilisé par l'export). */
  public HasFilterFlag: boolean = false;
  /** Flag d'état : mis à jour par le composant pour refléter si un tri est actif (utilisé par l'export). */
  public HasSortFlag: boolean = false;
  //#endregion

  //#region Infra

  /** Référence à l'élément hôte du composant (pour focus l'éditeur inline). */
  public readonly Host: ElementRef<HTMLElement> = inject(ElementRef<HTMLElement>);
  //#endregion

  //#region Value Accessors
  /**
   * Récupère la valeur d'une cellule via un chemin pointé.
   * @param pRow La ligne.
   * @param pKey La clé ou le chemin (ex: `contactPrincipal.nom`).
   * @returns La valeur trouvée ou undefined.
   */
  public GetCellValue(pRow: TDTO, pKey: string): unknown {
    if (!pKey || !pRow) {
      return undefined;
    }
    const lSegments: string[] = pKey.split('.');
    let lCurrent: unknown = pRow;
    for (const lSegment of lSegments) {
      if (lCurrent === null || lCurrent === undefined) {
        return undefined;
      }
      lCurrent = (lCurrent as Record<string, unknown>)[lSegment];
    }
    return lCurrent;
  }

  /**
   * Convertit une clé de colonne en chaîne (utilisable dans le template).
   * @param pKey La clé (string ou keyof TDTO).
   * @returns La clé en chaîne.
   */
  public KeyToString(pKey: keyof TDTO | string): string {
    return String(pKey);
  }

  /**
   * Formate la valeur d'une cellule pour l'affichage.
   * @param pRow La ligne.
   * @param pColumn La définition de colonne.
   * @returns Le texte formaté.
   */
  public FormatCell(pRow: TDTO, pColumn: GridColumn<TDTO>): string {
    const lValue: unknown = this.GetCellValue(pRow, String(pColumn.Key));
    if (pColumn.Format) {
      return pColumn.Format(lValue, pRow);
    }
    if (lValue === null || lValue === undefined || lValue === '') {
      return '';
    }
    if (lValue instanceof Date) {
      return this.FormatDate(lValue);
    }
    return String(lValue);
  }

  /**
   * Résout la classe CSS d'une cellule (chaîne fixe ou fonction dynamique).
   * @param pRow La ligne.
   * @param pColumn La définition de colonne.
   * @returns La classe CSS résolue.
   */
  public ResolveCellClass(pRow: TDTO, pColumn: GridColumn<TDTO>): string {
    if (!pColumn.CellClass) {
      return '';
    }
    if (typeof pColumn.CellClass === 'function') {
      const lValue: unknown = this.GetCellValue(pRow, String(pColumn.Key));
      return pColumn.CellClass(lValue, pRow);
    }
    return pColumn.CellClass;
  }

  /**
   * Tente de convertir une valeur en timestamp (date).
   * @param pValue La valeur.
   * @returns Le timestamp ou 0 si non convertible.
   */
  public TryGetTimestamp(pValue: unknown): number {
    if (pValue instanceof Date) {
      return pValue.getTime();
    }
    if (typeof pValue === 'string') {
      const lDate: Date = new Date(pValue);
      if (!isNaN(lDate.getTime()) && /^\d{4}-\d{2}-\d{2}/.test(pValue)) {
        return lDate.getTime();
      }
    }
    return 0;
  }

  /**
   * Wrapper public de tracking PostHog (délègue au PostHog hérité de BaseComponent).
   * @param pEvent Nom de l'événement.
   * @param pProps Propriétés.
   */
  public Capture(pEvent: string, pProps?: Record<string, unknown>): void {
    this.PostHog.Capture(pEvent, pProps);
  }

  /**
   * Formate un nom de propriété camelCase en libellé lisible (ex: 'dateNaissance' → 'Date naissance').
   * @param pKey Le nom de la propriété.
   * @returns Le libellé formaté.
   */
  public FormatColumnLabel(pKey: string): string {
    return pKey
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (pC) => pC.toUpperCase())
      .trim();
  }

  /**
   * Normalise les options d'une colonne en {Value,Label}[].
   * @param pColumn La colonne.
   * @returns Les options normalisées {Value,Label}.
   */
  public NormalizeOptions(pColumn: GridColumn<TDTO>): IInputOption[] {
    const lOpts = pColumn.EditorOptions ?? [];
    if (pColumn.EditorOptionValueKey && pColumn.EditorOptionLabelKey) {
      return lOpts.map((pO): IInputOption => {
        const lRaw = pO as unknown as Record<string, unknown>;
        return {
          Value: lRaw[pColumn.EditorOptionValueKey!] as string | number | boolean,
          Label: String(lRaw[pColumn.EditorOptionLabelKey!] ?? '')
        };
      });
    }
    return lOpts as unknown as IInputOption[];
  }

  /**
   * Getter template exposant les options normalisées {Value,Label} d'une colonne.
   * @param pCol La colonne.
   * @returns Les options normalisées {Value,Label}.
   */
  public NormalizedOptions(pCol: GridColumn<TDTO>): IInputOption[] {
    return this.NormalizeOptions(pCol);
  }

  /**
   * Compare deux valeurs pour le tri. Gère null/undefined/empty en dernier, numbers/booleans/dates/strings.
   * @param pA Première valeur.
   * @param pB Deuxième valeur.
   * @param pDirection Direction du tri.
   * @returns -1, 0 ou 1.
   */
  public CompareValues(pA: unknown, pB: unknown, pDirection: 'asc' | 'desc'): number {
    const lIsNull = (pValue: unknown): boolean => pValue === null || pValue === undefined || pValue === '';
    if (lIsNull(pA) && lIsNull(pB)) { return 0; }
    if (lIsNull(pA)) { return 1; }
    if (lIsNull(pB)) { return -1; }
    let lResult = 0;
    if (typeof pA === 'number' && typeof pB === 'number') {
      lResult = pA - pB;
    } else if (typeof pA === 'boolean' && typeof pB === 'boolean') {
      lResult = (pA ? 1 : 0) - (pB ? 1 : 0);
    } else {
      const lDateA = this.TryGetTimestamp(pA);
      const lDateB = this.TryGetTimestamp(pB);
      if (lDateA !== 0 && lDateB !== 0) {
        lResult = lDateA - lDateB;
      } else {
        lResult = String(pA).localeCompare(String(pB), 'fr', { numeric: true, sensitivity: 'base' });
      }
    }
    return pDirection === 'asc' ? lResult : -lResult;
  }

  /**
   * Échappe une valeur pour le format CSV (RFC 4180) avec un séparateur paramétrable.
   * @param pValue La valeur à échapper.
   * @param pSeparator Le séparateur CSV à utiliser.
   * @returns La valeur échappée.
   */
  public EscapeCsv(pValue: string, pSeparator: string): string {
    const lStr: string = pValue ?? '';
    const lNeedQuote: boolean = lStr.includes(pSeparator) || lStr.includes('"') || /[\r\n]/.test(lStr);
    return lNeedQuote ? `"${lStr.replace(/"/g, '""')}"` : lStr;
  }

  /**
   * Convertit une largeur CSS (ex: '180px') en unité Excel (nombre).
   * @param pCssWidth La largeur CSS.
   * @returns La largeur Excel.
   */
  public ParseExcelWidth(pCssWidth: string | undefined): number {
    if (!pCssWidth) { return 18; }
    const lMatch: RegExpMatchArray | null = pCssWidth.match(/(\d+(?:\.\d+)?)\s*px/);
    if (lMatch && lMatch[1]) {
      return Math.max(8, Math.round(Number(lMatch[1]) / 7));
    }
    return 18;
  }

  /**
   * Convertit une clé camelCase en libellé lisible (pour les champs de filtre).
   * @param pKey La clé.
   * @returns Le libellé formaté.
   */
  public SchemaKeyToLabel(pKey: string): string {
    return pKey
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/_/g, ' ')
      .replace(/^./, (pM: string) => pM.toUpperCase());
  }

  /**
   * Construit la clé interne d'une cellule (rowKey|colKey).
   * @param pRow La ligne.
   * @param pColKey La clé de la colonne.
   * @returns La clé composite.
   */
  public CellKey(pRow: TDTO, pColKey: string): string {
    return `${this.TrackBy(pRow)}|${pColKey}`;
  }

  //#region Inline Edit helpers (purs, sans signaux internes)
  /**
   * Indique si la valeur affichée d'une cellule est vide.
   * @param pRow La ligne.
   * @param pCol La colonne.
   * @returns True si la cellule est vide.
   */
  public IsCellEmpty(pRow: TDTO, pCol: GridColumn<TDTO>): boolean {
    if (pCol.CellTemplate) {
      const lValue: unknown = this.GetCellValue(pRow, String(pCol.Key));
      return lValue === null || lValue === undefined || lValue === '';
    }
    const lValue: string = this.FormatCell(pRow, pCol);
    return lValue === '';
  }

  /**
   * Retourne le placeholder d'une cellule éditable vide.
   * @param pRow La ligne.
   * @param pCol La colonne.
   * @returns Le placeholder.
   */
  public CellPlaceholder(pRow: TDTO, pCol: GridColumn<TDTO>): string {
    if (pCol.EditorPlaceholder) {
      return pCol.EditorPlaceholder;
    }
    if (pCol.EditorPlaceholderCle) {
      // - cm - Tick explicite pour reevaluer au changement de langue (cf. TranslationService.setLanguage bump InstantTick).
      this.Translate.InstantTick();
      const lTranslated: string = this.Translate.translate(pCol.EditorPlaceholderCle, { ns: '' });
      if (lTranslated && lTranslated !== pCol.EditorPlaceholderCle) {
        return lTranslated;
      }
    }
    if (pCol.EditorType === 'date') {
      return 'MM/DD/YYYY';
    }
    return `Saisir ${pCol.Label ?? ''}…`;
  }

  /**
   * Indique si une colonne est éditable.
   * @param pCol La colonne.
   * @returns True si la colonne est éditable.
   */
  public CanEdit(pCol: GridColumn<TDTO>): boolean {
    if (!this.Editable || pCol.Editable !== true) {
      return false;
    }
    return true;
  }

  /**
   * Indique si une colonne est en lecture seule.
   * @param pCol La colonne.
   * @returns True si la colonne est en lecture seule.
   */
  public IsReadOnly(pCol: GridColumn<TDTO>): boolean {
    return this.Editable && pCol.Editable !== true;
  }

  /**
   * Indique si la ligne possède au moins une valeur non vide sur une colonne éditable.
   * @param pRow La ligne.
   * @returns True si la ligne contient du contenu éditable.
   */
  public RowHasEditableContent(pRow: TDTO): boolean {
    // - cm - Acces direct aux colonnes (GridBase n'a pas la notion de VisibleColumns,
    // - cm - on delegue au composant qui override la methode si besoin).
    return this._RowHasEditableContent(pRow);
  }

  /**
   * Hook interne delegue au composant (qui a acces a VisibleColumns).
   * Override dans GridComponent pour utiliser ses colonnes visibles.
   * @param pRow La ligne.
   * @returns True si la ligne contient du contenu éditable.
   */
  protected _RowHasEditableContent(pRow: TDTO): boolean {
    return false;
  }

  /**
   * Résout l'élément DOM <td> à partir d'un événement de clic.
   * @param pEvent L'événement DOM.
   * @returns Le HTMLElement de la <td> ou null.
   */
  public ResolveEditingCell(pEvent: Event): HTMLElement | null {
    const lTarget: HTMLElement | null = (pEvent?.currentTarget as HTMLElement | null) ?? null;
    if (!lTarget) {
      return null;
    }
    return lTarget.closest<HTMLElement>('td[data-row-key][data-col-key]');
  }

  /**
   * Calcule la clé stable d'une ligne pour les maps de draft.
   * @param pRow La ligne.
   * @returns La clé stable.
   */
  public RowKey(pRow: TDTO): string {
    const lId: unknown = (pRow as Record<string, unknown>)['id'];
    return lId === undefined || lId === null ? String(pRow) : String(lId);
  }

  /**
   * Convertit une règle de validation DTO en ValidatorFn Angular.
   * @param pDtoValidator La fonction de validation DTO.
   * @param pRow La ligne courante.
   * @returns Le ValidatorFn Angular.
   */
  public ToValidatorFn(pDtoValidator: (pValue: unknown, pRow: TDTO) => string | null, pRow: TDTO): (pControl: { value: unknown }) => { dto: string } | null {
    return (pControl: { value: unknown }): { dto: string } | null => {
      const lError: string | null = pDtoValidator(pControl.value, pRow);
      return lError ? { dto: lError } : null;
    };
  }

  /**
   * Calcule la valeur initiale du FormControl éditeur selon le type.
   * @param pCol La colonne.
   * @param pRaw La valeur brute de la cellule.
   * @returns La valeur initiale typée.
   */
  public InitialControlValue(pCol: GridColumn<TDTO>, pRaw: unknown): unknown {
    if (pRaw === null || pRaw === undefined) {
      return pCol.EditorType === 'number' ? null : '';
    }
    if (pCol.EditorType === 'number') {
      const lNum: number = Number(pRaw);
      return isNaN(lNum) ? null : lNum;
    }
    if (pCol.EditorType === 'address') {
      return pRaw;
    }
    return String(pRaw);
  }

  /**
   * Scroll une cellule dans la zone visible du viewport en tenant compte des ancêtres scrollables.
   * @param pCell La <td> à rendre visible.
   * @param pBottomMargin Marge de sécurité en bas (px).
   */
  public _ScrollCellIntoVisibleArea(pCell: HTMLElement, pBottomMargin: number = 16): void {
    // - cm - Délègue au helper partagé (defini dans grid.component.ts)
    ScrollIntoVisibleArea(pCell, pBottomMargin);
  }

  /**
   * Sélectionne le texte d'un input/textarea si applicable.
   * @param pTarget L'élément focusé.
   */
  public SelectEditorText(pTarget: HTMLElement): void {
    const lTag: string = pTarget.tagName.toLowerCase();
    if (lTag === 'textarea' || (lTag === 'input' && (pTarget as HTMLInputElement).type !== 'date')) {
      const lInput: HTMLInputElement | HTMLTextAreaElement = pTarget as HTMLInputElement | HTMLTextAreaElement;
      requestAnimationFrame((): void => {
        try {
          lInput.select();
        } catch {
          // - cm - Certains navigateurs jettent si l'élément n'est pas éditable
        }
      });
    }
  }
  //#endregion
}
