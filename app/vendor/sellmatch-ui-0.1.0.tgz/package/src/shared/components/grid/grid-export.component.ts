import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { ButtonComponent } from '../../../shared/components/button/button.component';

@Component({
  selector: 'app-grid-export',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './grid-export.component.html',
  styleUrl: './grid-export.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GridExportComponent {
  @Input() ExportFormat: 'csv' | 'xlsx' | 'both' = 'csv';
  @Input() ExportApiPath: string | null = '';
  @Output() readonly Csv = new EventEmitter<void>();
  @Output() readonly Xlsx = new EventEmitter<void>();
}
