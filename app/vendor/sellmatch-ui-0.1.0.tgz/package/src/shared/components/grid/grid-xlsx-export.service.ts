import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

/**
 * Définition d'une colonne exportée vers le backend XLSX.
 * Le backend résout la valeur via réflexion sur le DTO à partir de {@link Key}.
 */
export interface ExcelColumnRequest {
  /** Libellé affiché dans l'en-tête Excel. */
  Header: string;
  /** Propriété du DTO (supporte les chemins pointés : "contactPrincipal.nom"). */
  Key: string;
  /** Largeur de la colonne en unités Excel (défaut: 18). */
  Width?: number;
  /** Format Excel (ex: "dd/mm/yyyy", "#,##0.00"). */
  Format?: string;
  /** Met la cellule en gras. */
  Bold?: boolean;
}

/**
 * Requête envoyée à l'endpoint backend POST /api/{Controller}/ExportXlsx.
 */
export interface IExcelExportRequest<TCritere = unknown> {
  /** Critères de filtre (null = tout exporter). */
  Critere?: TCritere | null;
  /** Titre du grid (ex: "Candidats"). Sert au nom de fichier et au bandeau d'en-tête XLSX. */
  Title?: string;
  /** Nom de l'utilisateur qui exporte (pour les métadonnées XLSX). */
  UserName?: string;
  /** Colonnes à inclure dans l'ordre d'affichage. */
  Columns?: ExcelColumnRequest[];
}

/**
 * Service Angular responsable de l'appel HTTP vers l'endpoint backend d'export XLSX.
 * Reçoit un Blob, déclenche le téléchargement via URL.createObjectURL.
 */
@Injectable({ providedIn: 'root' })
export class GridXlsxExportService {
  private readonly _Http: HttpClient = inject(HttpClient);

  /**
   * Télécharge un fichier XLSX stylisé SellMatch depuis le backend.
   * @param pApiPath Chemin complet de l'endpoint (ex: '/api/Candidats/ExportXlsx').
   * @param pRequest Requête d'export.
   * @returns Le nom final du fichier téléchargé.
   */
  public async DownloadXlsxAsync(pApiPath: string, pRequest: IExcelExportRequest): Promise<string> {
    const lBlob: Blob = await firstValueFrom(
      this._Http.post(pApiPath, pRequest, { responseType: 'blob' })
    );
    const lFilename: string = this.BuildFilename(pRequest.Title ?? 'export');
    this.TriggerBrowserDownload(lBlob, lFilename);
    return lFilename;
  }

  /**
   * Construit le nom final du fichier : `${prefix}_YYYY-MM-DD_HH-mm-ss.xlsx`.
   * @param pPrefix Préfixe (ex: "candidats").
   * @returns Le nom formaté.
   */
  private BuildFilename(pPrefix: string): string {
    const lNow: Date = new Date();
    const lPad: (pN: number) => string = (pN: number): string => String(pN).padStart(2, '0');
    const lStamp: string = `${lNow.getFullYear()}-${lPad(lNow.getMonth() + 1)}-${lPad(lNow.getDate())}_${lPad(lNow.getHours())}-${lPad(lNow.getMinutes())}-${lPad(lNow.getSeconds())}`;
    return `${pPrefix}_${lStamp}.xlsx`;
  }

  /**
   * Déclenche un téléchargement navigateur depuis un Blob.
   * @param pBlob Le contenu du fichier.
   * @param pFilename Le nom du fichier à télécharger.
   */
  private TriggerBrowserDownload(pBlob: Blob, pFilename: string): void {
    const lUrl: string = URL.createObjectURL(pBlob);
    const lLink: HTMLAnchorElement = document.createElement('a');
    lLink.href = lUrl;
    lLink.download = pFilename;
    document.body.appendChild(lLink);
    lLink.click();
    document.body.removeChild(lLink);
    URL.revokeObjectURL(lUrl);
  }
}
