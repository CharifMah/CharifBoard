/**
 * Définition d'une colonne du tableau générique.
 * Source unique (octobre 2026) : `GridColumn.ts` est importable et ré-exportable
 * par `grid.component.ts` (les consommateurs comme `crm-biens.component.ts` ou
 * `playground-ai-section.component.ts` typent leurs colonnes via `GridColumn<TDTO>`).
 * @typeParam TDTO Type de la ligne (DTO).
 */
import { TemplateRef } from '@angular/core';
import { IInputOption } from '../../../shared/components/input/input.types';

export interface GridColumn<TDTO>
{
  /** Clé d'accès à la valeur (propriété de TDTO ou chemin pointé ex: `contactPrincipal.nom`). */
  Key: keyof TDTO | string;
  /** Libellé affiché dans l'en-tête. */
  Label?: string;
  /**
   * Clé i18n (ex: `crm-recrutement.contact`). Si fournie, le grid la traduit via
   * le pipe `tkey` à l'affichage (réactif sur les changements de langue) en priorité
   * sur `Label`. Cf. `<app-grid-column [LabelCle]>` pour la version directive.
   */
  LabelCle?: string;
  /** Indique si la colonne est triable (défaut: false). */
  Sortable?: boolean;
  /** Indique si la colonne est masquable par l'utilisateur (défaut: true). */
  Hideable?: boolean;
  /** Largeur CSS optionnelle (ex: `180px`, `minmax(140px, 1fr)`). */
  Width?: string;
  /** Formateur personnalisé renvoyant le texte affiché. */
  Format?: (pValue: unknown, pRow: TDTO) => string;
  /** Classe CSS additionnelle appliquée aux cellules de cette colonne (chaîne fixe ou fonction dynamique). */
  CellClass?: string | ((pValue: unknown, pRow: TDTO) => string);
  /** Template personnalisé pour le rendu de la cellule (content projection). */
  CellTemplate?: TemplateRef<unknown> | null;
  /** Rend l'éditeur (app-input) directement en consultation au lieu du CellTemplate / label flottant. Permet de voir que c'est un select sans cliquer. */
  ShowEditor?: boolean;
  /** Active l'édition inline sur cette colonne (défaut: false). */
  Editable?: boolean;
  /** Type d'éditeur: 'text', 'number', 'date', 'select', 'select-search', 'textarea'. Défaut: 'text'. */
  EditorType?: 'text' | 'number' | 'date' | 'select' | 'select-search' | 'textarea' | 'address';
  /** Options pour l'éditeur 'select' et 'select-search': liste { Value, Label } OU DTO bruts (avec EditorOptionValueKey/EditorOptionLabelKey). */
  EditorOptions?: IInputOption[] | readonly unknown[];
  /** Clé du champ servant de valeur pour les options DTO (ex: 'id'). Si absente, EditorOptions doit être au format {Value,Label}. */
  EditorOptionValueKey?: string;
  /** Clé du champ servant de libellé pour les options DTO (ex: 'libelle'). Si absente, EditorOptions doit être au format {Value,Label}. */
  EditorOptionLabelKey?: string;
  /** Validateur optionnel : retourne un message d'erreur ou null si valide. */
  EditorValidator?: ((pValue: unknown, pRow: TDTO) => string | null) | null;
  /** Placeholder de l'éditeur. */
  EditorPlaceholder?: string;
  /** Clé i18n du placeholder de l'éditeur. Rendu via `Translate.translate` dans `GridBase.CellPlaceholder`. */
  EditorPlaceholderCle?: string;
  /** Valeur minimale pour l'éditeur 'number'. */
  EditorMin?: number;
  /** Valeur maximale pour l'éditeur 'number'. */
  EditorMax?: number;
  /** Pas (incrément) pour l'éditeur 'number'. */
  EditorStep?: number;
  /** Longueur maximale (en caractères) pour l'éditeur 'text'. Couplé à `Validators.maxLength`. */
  EditorMaxLength?: number | null;
  /** Rend la colonne sticky (collée) horizontalement pendant le scroll. Défaut: 'none'. Configurable par clic droit sur l'en-tête. */
  Sticky?: 'left' | 'right' | 'none';
}
