import { Component, ContentChild, EventEmitter, Input, Output, TemplateRef, OnChanges, SimpleChanges, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabsComponent, TabItem } from '../tabs/tabs.component';
import { FilterBarComponent, FilterOption } from '../FilterBar/filter-bar.component';
import { BaseCritereDTO } from '../../../core/base/base.critere';
export interface TabConfig {
  Key: string;
  Label: string;
  Count: number;
  Icon?: string;
}

export interface PaginationConfig {
  PageSize: number;
  PageSizeOptions?: number[];
  ShowPageSizeSelector?: boolean;
  ShowFirstLastButtons?: boolean;
  ShowPageInfo?: boolean;
}

@Component({
  selector: 'app-list',
  standalone: true,
  imports: [CommonModule, TabsComponent, FilterBarComponent],
  templateUrl: './list.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./list.component.scss']
})
export class ListComponent<TItem> implements OnChanges {
  @Input() public FilterSchema: Record<string, unknown> | null = null;

  //#region Inputs
  @Input() public Items: TItem[] = [];
  @Input() public Loading: boolean = false;
  @Input() public LoadingMessage: string = 'Chargement...';
  @Input() public EmptyMessage: string = 'Aucun élément';
  @Input() public EmptyIcon: string = 'inbox';
  @Input() public TrackByKey: keyof TItem | null = null;
  @Input() public Tabs: TabConfig[] = [];
  @Input() public ActiveTab: string = '';
  @Input() public TabsVariant: 'default' | 'pills' | 'underline' = 'default';
  @Input() public TabsSize: 'sm' | 'md' | 'lg' = 'sm';
  @Input() public TabsFullWidth: boolean = false;

  // Pagination
  @Input() public Paginated: boolean = true;
  @Input() public PageSize: number = 3;
  @Input() public PageSizeOptions: number[] = [3, 5, 10, 25, 50];
  @Input() public ShowPageSizeSelector: boolean = true;
  @Input() public ShowFirstLastButtons: boolean = true;
  @Input() public ShowPageInfo: boolean = true;

  // Pagination back
  @Input() public ServerSidePagination: boolean = false;
  @Input() public TotalItemsCount: number = 0;

  // Filter bar toggle + config
  @Input() public ShowFilterBar: boolean = false;
  @Input() public ShowSearchFilter: boolean = true;
  @Input() public ShowStatusFilter: boolean = true;
  @Input() public ShowDateRangeFilter: boolean = true;
  @Input() public ShowDeleteToggle: boolean = true;
  @Input() public ShowFilterResetButton: boolean = true;
  @Input() public ShowFilterApplyButton: boolean = true;
  @Input() public FilterSearchPlaceholder: string = 'Rechercher...';
  @Input() public FilterStatusPlaceholder: string = 'Tous les statuts';
  @Input() public FilterStatusOptions: FilterOption[] = [];
  @Input() public FilterInitialValue: BaseCritereDTO = {};

  // Optionnel: filtre local générique
  @Input() public ApplyClientSideFilter: boolean = false;
  @Input() public FilterPredicate: ((pItem: TItem, pFilter: BaseCritereDTO) => boolean) | null = null;
  //#endregion

  //#region Outputs
  @Output() public TabChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() public ItemClick: EventEmitter<TItem> = new EventEmitter<TItem>();
  @Output() public PageChange: EventEmitter<number> = new EventEmitter<number>();
  @Output() public PageSizeChange: EventEmitter<number> = new EventEmitter<number>();

  @Output() public FilterChange: EventEmitter<BaseCritereDTO> = new EventEmitter<BaseCritereDTO>();
  @Output() public FilterReset: EventEmitter<void> = new EventEmitter<void>();
  @Output() public DeleteModeChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  //#endregion

  //#region Internal State
  private _CurrentPage: number = 1;
  public CurrentFilter: BaseCritereDTO = {};
  //#endregion

  //#region Templates
  @ContentChild('itemTemplate', { static: false }) public ItemTemplate!: TemplateRef<{ $implicit: TItem; index: number }>;
  @ContentChild('emptyTemplate', { static: false }) public EmptyTemplate!: TemplateRef<unknown>;
  @ContentChild('loadingTemplate', { static: false }) public LoadingTemplate!: TemplateRef<unknown>;
  @ContentChild('headerTemplate', { static: false }) public HeaderTemplate!: TemplateRef<unknown>;
  @ContentChild('filterTemplate', { static: false }) public FilterTemplate!: TemplateRef<unknown>;
  @ContentChild('paginationTemplate', { static: false }) public PaginationTemplate!: TemplateRef<unknown>;
  //#endregion

  //#region Lifecycle
  ngOnChanges(pChanges: SimpleChanges): void {
    if (pChanges['Items'] && !pChanges['Items'].firstChange) {
      this._AdjustCurrentPage();
    }

    if (pChanges['TotalItemsCount'] && !pChanges['TotalItemsCount'].firstChange) {
      this._AdjustCurrentPage();
    }

    if (pChanges['PageSize'] && !pChanges['PageSize'].firstChange) {
      this._CurrentPage = 1;
    }

    if (pChanges['ActiveTab'] && !pChanges['ActiveTab'].firstChange) {
      this._CurrentPage = 1;
    }

    if (pChanges['FilterInitialValue']) {
      this.CurrentFilter = { ...(this.FilterInitialValue || {}) };
      this._CurrentPage = 1;
    }
  }
  //#endregion

  //#region Private Methods

  private _AdjustCurrentPage(): void {
    const lMaxPage = this.TotalPages || 1;
    if (this._CurrentPage > lMaxPage) {
      this._CurrentPage = lMaxPage;
    }
  }
  //#endregion

  //#region Getters - Tabs
  public get TabItems(): TabItem[] {
    return this.Tabs.map((pTab: TabConfig) => ({
      id: pTab.Key,
      label: pTab.Label,
      badge: pTab.Count,
      icon: pTab.Icon
    }));
  }
  //#endregion

  //#region Getters - Filtering
  public get FilteredItems(): TItem[] {
    // En mode pagination back, les filtres sont généralement traités côté parent/API
    if (this.ServerSidePagination) {
      return this.Items;
    }

    if (!this.ShowFilterBar || !this.ApplyClientSideFilter || !this.FilterPredicate) {
      return this.Items;
    }

    return this.Items.filter((pItem: TItem) => this.FilterPredicate!(pItem, this.CurrentFilter));
  }
  //#endregion

  //#region Getters - Pagination
  public get CurrentPage(): number {
    return this._CurrentPage;
  }

  public get TotalItems(): number {
    if (this.ServerSidePagination) {
      return this.TotalItemsCount || 0;
    }

    return this.FilteredItems?.length || 0;
  }

  public get TotalPages(): number {
    return Math.ceil(this.TotalItems / this.PageSize) || 1;
  }

  public get StartIndex(): number {
    if (this.TotalItems === 0) return 0;
    return (this._CurrentPage - 1) * this.PageSize + 1;
  }

  public get EndIndex(): number {
    return Math.min(this._CurrentPage * this.PageSize, this.TotalItems);
  }

  public get IsFirstPage(): boolean {
    return this._CurrentPage === 1;
  }

  public get IsLastPage(): boolean {
    return this._CurrentPage >= this.TotalPages;
  }

  public get DisplayedItems(): TItem[] {
    if (!this.Paginated) {
      return this.FilteredItems;
    }

    // En mode back, Items est déjà paginé par l'API
    if (this.ServerSidePagination) {
      return this.Items;
    }

    const lStartIndex = (this._CurrentPage - 1) * this.PageSize;
    const lEndIndex = lStartIndex + this.PageSize;
    return this.FilteredItems.slice(lStartIndex, lEndIndex);
  }

  public get VisiblePages(): number[] {
    const lPages: number[] = [];
    const lMaxVisible = 5;
    let lStart = Math.max(1, this._CurrentPage - Math.floor(lMaxVisible / 2));
    const lEnd = Math.min(this.TotalPages, lStart + lMaxVisible - 1);

    if (lEnd - lStart + 1 < lMaxVisible) {
      lStart = Math.max(1, lEnd - lMaxVisible + 1);
    }

    for (let i = lStart; i <= lEnd; i++) {
      lPages.push(i);
    }

    return lPages;
  }

  public get PaginationContext(): object {
    return {
      currentPage: this._CurrentPage,
      totalPages: this.TotalPages,
      totalItems: this.TotalItems,
      pageSize: this.PageSize,
      startIndex: this.StartIndex,
      endIndex: this.EndIndex,
      isFirstPage: this.IsFirstPage,
      isLastPage: this.IsLastPage
    };
  }

  public get HasItems(): boolean {
    return this.DisplayedItems.length > 0;
  }

  public get ShowPagination(): boolean {
    return this.Paginated && this.TotalItems > 0;
  }
  //#endregion

  //#region Public Methods - Tabs
  public OnTabChange(pTabId: string): void {
    this._CurrentPage = 1;
    this.TabChange.emit(pTabId);
  }

  public OnItemClick(pItem: TItem): void {
    this.ItemClick.emit(pItem);
  }

  public TrackByFn(pIndex: number, pItem: TItem): unknown {
    if (this.TrackByKey && pItem) {
      return pItem[this.TrackByKey];
    }
    return pIndex;
  }
  //#endregion

  //#region Public Methods - Filter
  public OnFilterChange(pFilter: BaseCritereDTO): void {
    this.CurrentFilter = pFilter || {};
    this._CurrentPage = 1;
    this.FilterChange.emit(this.CurrentFilter);
  }

  public OnFilterReset(): void {
    this.CurrentFilter = {};
    this._CurrentPage = 1;
    this.FilterReset.emit();
  }

  public OnDeleteModeChange(pEnabled: boolean): void {
    this.DeleteModeChange.emit(pEnabled);
  }
  //#endregion

  //#region Public Methods - Pagination
  public GoToPage(pPage: number): void {
    if (pPage >= 1 && pPage <= this.TotalPages && pPage !== this._CurrentPage) {
      this._CurrentPage = pPage;
      this.PageChange.emit(pPage);
    }
  }

  public GoToFirstPage(): void {
    this.GoToPage(1);
  }

  public GoToLastPage(): void {
    this.GoToPage(this.TotalPages);
  }

  public GoToPreviousPage(): void {
    this.GoToPage(this._CurrentPage - 1);
  }

  public GoToNextPage(): void {
    this.GoToPage(this._CurrentPage + 1);
  }

  public OnPageSizeChange(pEvent: Event): void {
    const lSelect = pEvent.target as HTMLSelectElement;
    const lNewSize = parseInt(lSelect.value, 10);
    this._CurrentPage = 1;
    this.PageSize = lNewSize;
    this.PageSizeChange.emit(lNewSize);
  }

  public TrackByPage(pIndex: number, pPage: number): number {
    return pPage;
  }
  //#endregion
}
