import { Component, Input, Output, EventEmitter, ElementRef, AfterViewInit, inject, Inject, PLATFORM_ID, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';

import { RouterModule } from '@angular/router';
export type ButtonVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'xl';
export type ButtonType = 'button' | 'submit' | 'reset';
// - cm - Palette de gradient anime plein bouton au hover (ou permanent si [gradient]="...").
// - cm - - default : palette officielle violet-clair -> rose -> cyan.
// - cm - - sunset  : orange -> rose corail -> fuchsia.
// - cm - - ocean   : cyan -> bleu -> indigo.
// - cm - - neon    : lime -> cyan -> violet.
// - cm - - aurora  : vert -> bleu -> violet -> rose (4 stops).
export type ButtonGradient = 'default' | 'sunset' | 'ocean' | 'neon' | 'aurora';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  standalone: true,
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [RouterModule]
})
export class ButtonComponent extends BaseComponent implements AfterViewInit, OnDestroy
{
  @Input() variant: ButtonVariant = 'primary';
  @Input() size: ButtonSize = 'md';
  @Input() type: ButtonType = 'button';
  @Input() fullWidth = false;
  @Input() disabled = false;
  @Input() loading = false;
  @Input() icon: string | null = null;
  @Input() iconPosition: 'left' | 'right' = 'left';
  @Input() rounded = false;
  @Input() outline = false;
  @Input() ariaLabel: string | null = null;
  @Input() circle: boolean = false;
  @Input() active: boolean = false;
  /**
   * Style CSS inline appliqué au `<span class="material-icons">` interne.
   * Utile pour piloter une transformation dynamique (ex: rotation du compass
   * selon le bearing de la carte). Vide = aucun style inline.
   */
  @Input() iconStyle: string | null = null;
  @Input() routerLink: string | null = null;
  // - cm - Classe appliquee quand la route est active (deleguee a la directive routerLinkActive sur le bouton interne)
  @Input() routerLinkActive: string | null = null;
  // - cm - Options de matching de la route active (ex: { exact: boolean })
  @Input() routerLinkActiveOptions: { exact: boolean } | null = null;
  /** Délai avant l'animation d'entrée CSS (ms). -1 = pas d'animation */
  @Input() animDelay: number = -1;
  /** Déclencheur : 'auto' = immédiat avec animDelay, 'scroll' = au scroll */
  @Input() animTrigger: 'auto' | 'scroll' | 'none' = 'auto';
  @Output() ButtonClick = new EventEmitter<MouseEvent>();
  @Input() toggleable: boolean = false;        // Active le mode "bascule automatique"
    @Output() activeChange = new EventEmitter<boolean>(); // Permet le two-way binding [(active)]
    // - cm - Palette de gradient anime plein bouton (voir ButtonGradient).
    // - cm - Si defini, le bouton affiche en permanence le gradient choisi au lieu du bg variant.
    @Input() gradient: ButtonGradient | null = null;

  private readonly _ElementRef: ElementRef = inject(ElementRef);
  private readonly _IsBrowser: boolean;
  private _TrackingName: string | null = null;
  private _Observer: IntersectionObserver | null = null;

  constructor(@Inject(PLATFORM_ID) pPlatformId: object)
  {
    super();
    this._IsBrowser = isPlatformBrowser(pPlatformId);
  }

  ngAfterViewInit(): void
  {
    if (!this._IsBrowser) return;

    // - cm - Tracking
    const lText: string = (this._ElementRef.nativeElement as HTMLElement).textContent?.trim() ?? '';
    if (lText)
    {
      this._TrackingName = this.BuildTrackingName(lText);
    }

    // - cm - Animation d'entrée
    if (this.animTrigger === 'scroll')
    {
      this._Hide(this._ElementRef.nativeElement);
      this._SetupScrollReveal();
    }
    else if (this.animTrigger === 'auto' && this.animDelay >= 0)
    {
      this._Hide(this._ElementRef.nativeElement);
      setTimeout(() => this._PlayEnter(), this.animDelay);
    }
  }

  ngOnDestroy(): void
  {
    this._Observer?.disconnect();
  }

  async onClick(pEvent: MouseEvent): Promise<void>
  {
    // Ne rien faire si désactivé ou en chargement
    if (this.disabled || this.loading)
    {
      return;
    }

    // --- Gestion du basculement automatique ---
    // On bascule uniquement si toggleable est true ET qu'il n'y a PAS de routerLink
    // (pour éviter un conflit avec la navigation qui gère déjà l'état actif)
    if (this.toggleable && !this.routerLink)
    {
      this.active = !this.active;
      this.activeChange.emit(this.active);
    }

    // --- Émission de l'événement clic pour le parent ---
    this.ButtonClick.emit(pEvent);

    // --- Tracking (inchangé) ---
    if (this._TrackingName)
    {
      this.PostHog.Capture(this._TrackingName);
    }
  }

  get classes(): string {
      const classes = [
        'btn',
        `btn-${this.variant}`,
        `btn-${this.size}`,
        this.fullWidth ? 'btn-full-width' : '',
        this.rounded ? 'btn-rounded' : '',
        this.outline ? `btn-outline-${this.variant}` : '',
        this.disabled || this.loading ? 'btn-disabled' : '',
        this.icon ? 'btn-with-icon' : '',
        this.circle ? 'btn-circle' : '',
        this.active ? 'btn-active' : '',
        this.gradient ? `btn-gradient-${this.gradient}` : ''
      ];

      return classes.filter(Boolean).join(' ');
    }

  //#region Animation
  private _SetupScrollReveal(): void
  {
    const lEl = this._ElementRef.nativeElement;
    this._Hide(lEl);

    this._Observer = new IntersectionObserver(
      (pEntries: IntersectionObserverEntry[]) =>
      {
        for (const lEntry of pEntries)
        {
          if (lEntry.isIntersecting)
          {
            this._Observer?.unobserve(lEl);
            const lDelay = this.animDelay >= 0 ? this.animDelay : 200;
            setTimeout(() => this._Show(lEl), lDelay);
            break;
          }
        }
      },
      { threshold: 0.15 }
    );
    this._Observer.observe(lEl);
  }

  private _PlayEnter(): void
  {
    this._Show(this._ElementRef.nativeElement);
  }

  private _Hide(pEl: HTMLElement): void
  {
    pEl.style.opacity = '0';
    pEl.style.transform = 'translateY(30px)';
    pEl.style.transition = 'none';
  }

  private _Show(pEl: HTMLElement): void
  {
    pEl.style.transition = 'opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
    pEl.style.opacity = '1';
    pEl.style.transform = 'translateY(0)';
  }
  //#endregion
}
