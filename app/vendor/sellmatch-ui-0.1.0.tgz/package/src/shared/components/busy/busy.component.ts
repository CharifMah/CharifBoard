// busy.component.ts
import { Component, OnInit, OnDestroy, inject, PLATFORM_ID, ChangeDetectionStrategy } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-busy',
  standalone: true,
  templateUrl: './busy.component.html',
  styleUrls: ['./busy.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: []
})
export class BusyComponent extends BaseComponent implements OnInit, OnDestroy
{
  isVisible = false;
  message = '';
  private subscription = new Subscription();
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  ngOnInit(): void
  {
    // Initialiser le composant avec l'état actuel du service
    this.subscription = this.BusyService.busy$.subscribe(state =>
    {
      this.isVisible = state.show;
      this.message = state.message;

      if (this._IsBrowser) // - cm - SSR-safe
      {
        if (this.isVisible)
        {
          document.body.classList.add('busy-active');
        } else
        {
          document.body.classList.remove('busy-active');
        }
      }
    });
  }

  ngOnDestroy(): void
  {
    if (this._IsBrowser) // - cm - SSR-safe
    {
      document.body.classList.remove('busy-active');
    }
    this.subscription.unsubscribe();
  }
}
