import { isPlatformBrowser } from '@angular/common';
import { Component, inject, OnInit, PLATFORM_ID, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../../../shared/components/button/button.component';

interface ICookieConsentValue {
  //#region Property

  /**
   * Choix de consentement de l'utilisateur.
    */
    Value: 'accepted' | 'refused';

    /**
    * Date ISO du choix de consentement.
    */
    Date: string;

  /**
   * Version du consentement affiche.
   */
  Version: string;

  //#endregion
}

/**
 * Bandeau de consentement cookies pour le tracking PostHog.
 */
@Component({
  selector: 'app-cookie-consent',
  standalone: true,
  imports: [ButtonComponent],
  templateUrl: './cookie-consent.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./cookie-consent.component.scss']
})
export class CookieConsentComponent extends BaseComponent implements OnInit {
  //#region Property

  /**
   * Indique si le bandeau doit etre affiche.
   */
  public IsVisible: boolean = false;

  /**
   * Indique si l'execution est cote navigateur.
   */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /**
   * Cle de stockage du consentement cookies.
   */
  private readonly _StorageKey: string = 'sellmatch_cookie_consent';

  /**
   * Version courante du consentement cookies.
   */
  private readonly _ConsentVersion: string = '1.0';

  //#endregion

  //#region Methods

  /**
   * Detecte le consentement deja enregistre au chargement du composant.
   */
  public ngOnInit(): void {
    if (!this._IsBrowser) return;

    const lConsentValue: ICookieConsentValue | null = this.GetConsentValue();
    this.IsVisible = lConsentValue === null || lConsentValue.Version !== this._ConsentVersion;

    if (lConsentValue?.Value === 'accepted') {
      this.PostHog.SetTrackingEnabled(true);
      this.PostHog.CaptureAnonymousProfile('cookie_consent_restored');
    }
    else {
      this.PostHog.SetTrackingEnabled(false);
    }
  }

  /**
   * Accepte les cookies analytics et enrichit le profil anonyme.
   */
  public Accept(): void {
    if (!this._IsBrowser) return;

    this.SetConsentValue('accepted');
    this.PostHog.SetTrackingEnabled(true);
    this.PostHog.CaptureAnonymousProfile('cookie_consent_accepted');
    this.IsVisible = false;
  }

  /**
   * Refuse les cookies analytics et desactive le tracking.
   */
  public Refuse(): void {
    if (!this._IsBrowser) return;

    this.SetConsentValue('refused');
    this.PostHog.Capture('cookie_consent_refused');
    this.PostHog.SetTrackingEnabled(false);
    this.IsVisible = false;
  }

  /**
   * Recupere le consentement cookies stocke.
   * @returns Consentement cookies ou null
   */
  private GetConsentValue(): ICookieConsentValue | null {
    const lStoredConsent: string | null = window.localStorage.getItem(this._StorageKey);

    if (!lStoredConsent) return null;

    if (lStoredConsent === 'accepted' || lStoredConsent === 'refused') {
      return {
        Value: lStoredConsent,
        Date: '',
        Version: '0.0'
      };
    }

    try {
      return JSON.parse(lStoredConsent) as ICookieConsentValue;
    }
    catch {
      return null;
    }
  }

  /**
   * Stocke le consentement cookies avec date et version.
   * @param pValue Choix de consentement utilisateur
   */
  private SetConsentValue(pValue: 'accepted' | 'refused'): void {
    const lConsentValue: ICookieConsentValue = {
      Value: pValue,
      Date: new Date().toISOString(),
      Version: this._ConsentVersion
    };

    window.localStorage.setItem(this._StorageKey, JSON.stringify(lConsentValue));
  }

  //#endregion
}
