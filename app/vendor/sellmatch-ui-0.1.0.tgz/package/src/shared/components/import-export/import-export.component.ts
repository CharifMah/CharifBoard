import { Component, Input, Output, EventEmitter, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../button/button.component';
import { ImportExportService, ImportResult } from '../../../core/services/ImportExport/ImportExportService';

/**
 * Composant réutilisable d'import/export CSV pour les pages CRM.
 */
@Component({
  selector: 'app-import-export',
  standalone: true,
  templateUrl: './import-export.component.html',
  styleUrls: ['./import-export.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [CommonModule, ButtonComponent]
})
export class ImportExportComponent extends BaseComponent {
  private readonly _importExportService: ImportExportService = inject(ImportExportService);

  /** Entité cible (opportunities, users, etc.) */
  @Input() public Entity: string = 'opportunities';
  /** Texte du bouton d'import */
  @Input() public ImportLabel: string = 'Importer';
  /** Texte du bouton d'export */
  @Input() public ExportLabel: string = 'Exporter';
  /** Extensions acceptées pour l'import */
  @Input() public Accept: string = '.csv';
  /** Nom du fichier exporté */
  @Input() public ExportFileName: string = 'export.csv';

  @Output() public ImportSuccess = new EventEmitter<ImportResult>();
  @Output() public ImportError = new EventEmitter<string>();
  @Output() public ExportSuccess = new EventEmitter<void>();
  @Output() public ExportError = new EventEmitter<string>();

  public IsImporting = false;
  public IsExporting = false;

  /**
   * Déclenche l'ouverture du sélecteur de fichier.
   */
  public TriggerFileInput(): void {
    const lInput = document.getElementById(this.FileInputId) as HTMLInputElement;
    lInput?.click();
  }

  /**
   * Gère la sélection d'un fichier CSV.
   * @param pEvent Événement de changement du input file
   */
  public async OnFileSelected(pEvent: Event): Promise<void> {
    const lInput = pEvent.target as HTMLInputElement;
    const lFile = lInput.files?.[0];

    if (!lFile) {
      return;
    }

    // - cm - Réinitialise le champ pour permettre la re-sélection du même fichier
    lInput.value = '';

    this.IsImporting = true;
    this.PostHog.Capture(this.BuildTrackingName('import_fichier_selectionne', 'tracking'));

    try {
      const lResult = await this._importExportService.importOpportunities(lFile);

      if (lResult.errors > 0) {
        this.ImportError.emit(`${lResult.errors} erreur(s) lors de l'import.`);
      } else {
        this.ImportSuccess.emit(lResult);
      }
    } catch (lError: any) {
      const lMessage = lError?.response?.data?.message ?? lError?.message ?? "Erreur lors de l'import.";
      this.ImportError.emit(lMessage);
    } finally {
      this.IsImporting = false;
    }
  }

  /**
   * Exporte les données au format CSV.
   */
  public async Export(): Promise<void> {
    this.IsExporting = true;
    this.PostHog.Capture(this.BuildTrackingName('export_donnees', 'tracking'));

    try {
      const lBlob = await this._importExportService.exportOpportunities();
      this._importExportService.downloadBlob(lBlob, this.ExportFileName);
      this.ExportSuccess.emit();
    } catch (lError: any) {
      const lMessage = lError?.response?.data?.message ?? lError?.message ?? "Erreur lors de l'export.";
      this.ExportError.emit(lMessage);
    } finally {
      this.IsExporting = false;
    }
  }

  /**
   * Identifiant unique du input file caché.
   */
  public get FileInputId(): string {
    return `import-export-input-${this.Entity}`;
  }
}
