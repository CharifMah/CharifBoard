import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';
import { BaseComponent } from '../../../core/base/BaseComponent';

/**
 * Composant générique de graphique ECharts.
 * Encapsule l'initialisation, le redimensionnement automatique et le cycle de vie d'une instance ECharts.
 */
@Component({
  selector: 'app-chart',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<div #chartContainer class="app-chart__container"></div>`,
  styleUrl: './chart.component.scss'
})
export class ChartComponent extends BaseComponent implements AfterViewInit, OnChanges, OnDestroy {
  //#region Attribute

  /** Instance ECharts sous-jacente (null tant que le conteneur n'est pas rendu). */
  private _ChartInstance: echarts.ECharts | null = null;

  /** Référence du conteneur DOM du graphique. */
  private _ChartContainerRef?: ElementRef<HTMLDivElement>;

  /** Observer pour redimensionner le graphique quand la taille du conteneur change. */
  private _ResizeObserver?: ResizeObserver;

  //#endregion

  //#region Property

  /** Option ECharts à afficher (reactive : toute mise à jour reconfigure le graphique). */
  @Input()
  public set Option(pOption: EChartsOption | null | undefined) {
    this._Option = pOption ?? null;
    if (this._ChartInstance && this._Option) {
      this._ChartInstance.setOption(this._Option, { notMerge: true });
    } else if (this._ChartInstance && !this._Option) {
      this._ChartInstance.clear();
    }
  }
  public get Option(): EChartsOption | null {
    return this._Option;
  }
  private _Option: EChartsOption | null = null;

  /** Hauteur du conteneur en pixels (défaut 320). */
  @Input()
  public Height: number = 320;

  /**
   * Émis quand l'utilisateur clique sur une barre du graphique.
   * La payload contient l'index de la donnée cliquée (dataIndex).
   */
  @Output()
  public readonly BarClick = new EventEmitter<number>();

  /** Référence du conteneur DOM du graphique (via template #chartContainer). */
  @ViewChild('chartContainer')
  public set ChartContainerRef(pChartContainerRef: ElementRef<HTMLDivElement> | undefined) {
    this._ChartContainerRef = pChartContainerRef;
    this.InitChart();
  }
  public get ChartContainerRef(): ElementRef<HTMLDivElement> | undefined {
    return this._ChartContainerRef;
  }

  //#endregion

  //#region Methods

  /**
   * Initialise l'instance ECharts si le conteneur est disponible et pas déjà initialisé.
   */
  private InitChart(): void {
    const lChartContainer: HTMLDivElement | undefined = this._ChartContainerRef?.nativeElement;
    if (!lChartContainer || this._ChartInstance) return;

    this._ChartInstance = echarts.init(lChartContainer);

    // - cm - Bind du clic sur les barres : émet l'index de la donnée cliquée
    this._ChartInstance.on('click', 'series', (pParams: any) => {
      if (pParams && typeof pParams.dataIndex === 'number') {
        this.BarClick.emit(pParams.dataIndex);
      }
    });

    // - cm - Observer pour redimensionner automatiquement le graphique
    this._ResizeObserver = new ResizeObserver((): void => this._ChartInstance?.resize());
    this._ResizeObserver.observe(lChartContainer);

    // - cm - Application de l'option initiale si déjà disponible
    if (this._Option) {
      this._ChartInstance.setOption(this._Option, { notMerge: true });
    }
  }

  /** @inheritdoc */
  public ngAfterViewInit(): void {
    // - cm - Init différé pour s'assurer que le conteneur est rendu
    this.InitChart();
  }

  /** @inheritdoc */
  public ngOnChanges(pChanges: SimpleChanges): void {
    if (pChanges['Height'] && this._ChartInstance) {
      this._ChartInstance.resize();
    }
  }

  /** @inheritdoc */
  public ngOnDestroy(): void {
    // - cm - ECharts.dispose() retire automatiquement tous les listeners d'événements
    this._ResizeObserver?.disconnect();
    this._ResizeObserver = undefined;
    this._ChartInstance?.dispose();
    this._ChartInstance = null;
  }

  //#endregion
}