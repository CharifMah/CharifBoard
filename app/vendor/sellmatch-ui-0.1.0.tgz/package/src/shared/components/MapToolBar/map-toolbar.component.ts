import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { EMapStyle } from '../map-card/EMapStyle';
import { EMapLightMode } from '../map-card/EMapLightMode';
import { ButtonComponent } from '../../../shared/components/button/button.component';

@Component({
  selector: 'app-map-toolbar',
  standalone: true,
  templateUrl: './map-toolbar.component.html',
  styleUrls: ['./map-toolbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ButtonComponent]
})
export class ToolbarComponent
{
  //#region Inputs (état de la carte)
  @Input() ShowLeft: boolean = true;
  @Input() ShowRight: boolean = true;
  @Input() LeftCollapsed: boolean = false;
  @Input() RightCollapsed: boolean = false;
  @Input() IsFullscreen: boolean = false;
  @Input() Is3DEnabled: boolean = false;
  @Input() Show3DBuildings: boolean = true;
  @Input() CompassBearing: number = 0;
  @Input() CurrentStyle!: EMapStyle;
  @Input() CurrentLightMode!: EMapLightMode;

  @Input() Styles: { Value: EMapStyle; Label: string; Icon: string }[] = [];
  @Input() LightModes: { Value: EMapLightMode; Label: string; Icon: string }[] = [];
  //#endregion

  //#region Outputs (événements)
  @Output() ZoomIn = new EventEmitter<void>();
  @Output() ZoomOut = new EventEmitter<void>();
  @Output() Toggle3D = new EventEmitter<void>();
  @Output() Toggle3DBuildings = new EventEmitter<void>();
  @Output() ResetBearing = new EventEmitter<void>();
  @Output() ToggleFullscreen = new EventEmitter<void>();
  @Output() ToggleTheme = new EventEmitter<void>(); // conservé si nécessaire
  @Output() StyleChange = new EventEmitter<EMapStyle>();
  @Output() LightModeChange = new EventEmitter<EMapLightMode>();
  @Output() ToggleLeft = new EventEmitter<void>();
  @Output() ToggleRight = new EventEmitter<void>();
  //#endregion

  // Méthodes utilisées par le template pour émettre
  onZoomIn() { this.ZoomIn.emit(); }
  onZoomOut() { this.ZoomOut.emit(); }
  onToggle3D() { this.Toggle3D.emit(); }
  onToggle3DBuildings() { this.Toggle3DBuildings.emit(); }
  onResetBearing() { this.ResetBearing.emit(); }
  onToggleFullscreen() { this.ToggleFullscreen.emit(); }
  onToggleTheme() { this.ToggleTheme.emit(); }
  onStyleChange(style: EMapStyle) { this.StyleChange.emit(style); }
  onLightModeChange(mode: EMapLightMode) { this.LightModeChange.emit(mode); }
  onToggleLeft() { this.ToggleLeft.emit(); }
  onToggleRight() { this.ToggleRight.emit(); }
}
