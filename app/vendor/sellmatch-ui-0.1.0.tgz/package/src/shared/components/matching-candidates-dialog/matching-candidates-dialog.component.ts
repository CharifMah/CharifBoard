import {
  Component,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter,
  inject,
  signal,
  computed,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { PopupComponent } from '../../../shared/components/popup/popup.component';
import { MatchingService } from '../../../core/crm/services/matching/matching.service';
import { PropositionMatchDTO } from '../../../core/crm/dto/matching/proposition-match.dto';

/**
 * Dialog affichant la liste detaillee des candidats acquereurs / locataires
 * potentiels pour un bien donne (Transaction ou Location).
 *
 * S'appuie sur :
 * - <see cref="MatchingService"/> pour recuperer les propositions cote API.
 * - <see cref="PopupComponent"/> pour la mise en page modale.
 *
 * Usage cote parent :
 * ```html
 * <app-matching-candidates-dialog
 *   [isOpen]="ShowMatching()"
 *   [bienId]="SelectedTransaction()?.id ?? 0"
 *   [kind]="matchingKindAcquisition"
 *   (closed)="CloseMatching()">
 * </app-matching-candidates-dialog>
 * ```
 *
 * @see MatchingService
 * @see MatchingController
 */
@Component({
  selector: 'app-matching-candidates-dialog',
  standalone: true,
  imports: [CommonModule, PopupComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './matching-candidates-dialog.component.html',
  styleUrl: './matching-candidates-dialog.component.scss'
})
export class MatchingCandidatesDialogComponent extends BaseComponent implements OnChanges {
  //#region Attribute

  /** Cle de matching pour les acquereurs (constante exportee). */
  public static readonly KIND_ACQUISITION: 'acquisition' = 'acquisition';
  /** Cle de matching pour les locataires. */
  public static readonly KIND_LOCATION: 'location' = 'location';

  //#endregion

  //#region Inputs

  /** Etat d'ouverture du dialog (lie au bouton qui l'a ouvert). */
  @Input({ required: true }) public isOpen: boolean = false;

  /** Identifiant du bien source (Transaction.id ou Location.id). */
  @Input({ required: true }) public bienId: number = 0;

  /**
   * Type de matching a executer.
   * - 'acquisition' : candidats acquereurs (recherches de type 'achat').
   * - 'location' : candidats locataires (recherches de type 'location').
   */
  @Input({ required: true }) public kind: 'acquisition' | 'location' = 'acquisition';

  //#endregion

  //#region Outputs

  /** Emis a la fermeture du dialog (overlay click, bouton X, ESC). */
  @Output() public readonly closed = new EventEmitter<void>();

  //#endregion

  //#region State (signaux)

  /** Liste des candidats recuperes (tableau vide = aucun match). */
  public readonly Candidates = signal<PropositionMatchDTO[]>([]);

  /** Indique un chargement en cours. */
  public readonly Loading = signal<boolean>(false);

  /** Message d'erreur eventuel. */
  public readonly Error = signal<string | null>(null);

  /** Compteur derive pour affichage ("X candidats trouves"). */
  public readonly Count = computed<number>(() => this.Candidates().length);

  //#endregion

  //#region CTOR

  /**
   * Constructeur : injecte le service MatchingService et capture le PostHog.
   */
  public constructor() {
    super();
  }

  //#endregion

  //#region Lifecycle

  /**
   * Reagit a l'ouverture : declenche le chargement des candidats.
   * On re-charge aussi si l'id du bien change pendant que le dialog est ouvert.
   * @param pChanges Les changements detectes par Angular.
   */
  public ngOnChanges(pChanges: SimpleChanges): void {
    // - cm - Chargement initial a l'ouverture (isOpen passe de false a true)
    //      ou quand le bienId/kind change pendant que le dialog est visible.
    if ((pChanges['isOpen']?.currentValue === true) ||
        (this.isOpen && (pChanges['bienId'] || pChanges['kind']))) {
      void this.LoadCandidates();
    }
  }

  //#endregion

  //#region Methods

  /**
   * Charge les candidats depuis l'API MatchingService.
   * Convertit la cle de kind ('acquisition' / 'location') en EMatchingKind-like.
   */
  private async LoadCandidates(): Promise<void> {
    if (!this.bienId || this.bienId <= 0) {
      this.Candidates.set([]);
      this.Error.set('Identifiant de bien invalide.');
      return;
    }

    this.Loading.set(true);
    this.Error.set(null);

    try {
      const lResult: PropositionMatchDTO[] = this.kind === 'location'
        ? await this._MatchingService.ProposeLocatairesAsync(this.bienId)
        : await this._MatchingService.ProposeAcquereursAsync(this.bienId);
      this.Candidates.set(Array.isArray(lResult) ? lResult : []);

      // - cm - Tracking PostHog : telemetrie d'usage du matching pour mesure d'adoption V2 §5.
      this.PostHog.Capture(`crm_matching_${this.kind}_view`, {
        bienId: this.bienId,
        count: this.Candidates().length
      });
    } catch (lErr) {
      this.Error.set('Impossible de recuperer les candidats. Reessayez.');
      // - cm - Erreur silencieuse cote log, message user-friendly.
      console.error('Erreur matching dialog', lErr);
    } finally {
      this.Loading.set(false);
    }
  }

  /**
   * Ferme le dialog : delegue au parent via (closed).
   * - cm - La fermeture du <app-popup> declenche l'evenement (closed)
   *      automatiquement (overlay click + X button + ESC).
   */
  public OnClose(): void {
    this.closed.emit();
  }

  /**
   * Recharge les candidats (bouton "Actualiser").
   */
  public OnRefresh(): void {
    void this.LoadCandidates();
  }

  //#endregion

  //#region Services

  /** Service Angular consommant les endpoints de matching acquereur/locataire. */
  private readonly _MatchingService: MatchingService = inject(MatchingService);

  //#endregion
}
