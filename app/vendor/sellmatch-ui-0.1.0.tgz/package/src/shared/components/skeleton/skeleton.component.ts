import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

/**
 * Composant skeleton générique réutilisable.
 * Affiche un bloc shimmer (animation de chargement) qu'on peut placer n'importe où.
 *
 * @example
 * ```html
 * <!-- Barre skeleton simple -->
 * <app-skeleton />
 *
 * <!-- Barre skeleton avec largeur et hauteur personnalisées -->
 * <app-skeleton Width="60%" Height="20px" />
 *
 * <!-- Petit skeleton (checkbox, icône) -->
 * <app-skeleton Size="sm" />
 * ```
 */
@Component({
  selector: 'app-skeleton',
  standalone: true,
  templateUrl: './skeleton.component.html',
  styleUrl: './skeleton.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SkeletonComponent {
  /** Largeur CSS du skeleton (défaut: '80%'). */
  @Input() public Width = '80%';

  /** Hauteur CSS du skeleton (défaut: '16px'). */
  @Input() public Height = '16px';

  /** Tailur prédéfinie : 'sm' pour petit (40px large), sinon taille normale. */
  @Input() public Size: 'default' | 'sm' = 'default';
}