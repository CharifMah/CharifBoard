import {
  ChangeDetectionStrategy,
  Component,
  ContentChild,
  EventEmitter,
  inject,
  Input,
  Output,
  PLATFORM_ID,
  TemplateRef
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../../../shared/components/button/button.component';

/**
 * Compteur d'instances pour générer des identifiants uniques (ARIA).
 */
let lSectionCardInstanceCounter: number = 0;


/**
 * Composant carte section réutilisable.
 *
 * Deux modes :
 * - Mode statique (`Collapsible = false`, defaut) : header h2 + contenu visible en permanence.
 * - Mode repliable (`Collapsible = true`) : header cliquable (chevron + bouton) + corps
 *   anime via transition max-height/opacity. Supporte le slot `header-title` pour
 *   remplacer `Title` et le slot `header-actions` pour des boutons contextuels.
 *
 * Accessibilite : `aria-expanded`, `aria-controls`, header focusable.
 * Compatible `prefers-reduced-motion` (transitions retirees).
 *
 * @example
 * ```html
 * <app-section-card Title="Mes biens" Icon="apartment" [Collapsible]="true"
 *   [Collapsed]="false" (CollapsedChange)="onToggle($event)">
 *   <div slot="header-title"><h3>Carte</h3></div>
 *   <div slot="header-actions">
 *     <app-button variant="ghost" size="sm" icon="edit" />
 *   </div>
 *   <p>Contenu</p>
 * </app-section-card>
 * ```
 */
@Component({
  selector: 'app-section-card',
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  templateUrl: './section-card.component.html',
  styleUrls: ['./section-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager
})
export class SectionCardComponent extends BaseComponent
{
  //#region Attribute
  /** Identifiant de plateforme (browser vs SSR). */
  private readonly _PlatformId: object = inject(PLATFORM_ID);

  /**
   * Drapeau interne mis a jour via le setter de `_HeaderTitleSlot` pour indiquer
   * si le slot `header-title` a ete projete par le consommateur.
   */
  private _hasHeaderTitleSlot: boolean = false;

  /**
   * Reference vers l'eventuel contenu projete dans le slot `header-title`.
   * Le setter met a jour `_hasHeaderTitleSlot` pour permettre au template
   * de masquer le titre par defaut (`Title`) lorsque le slot est utilise.
   */
  @ContentChild('[slot=header-title]')
  private set _HeaderTitleSlot(pValue: unknown | undefined)
  {
    this._hasHeaderTitleSlot = !!pValue;
  }
  //#endregion

  //#region Property
  /** Titre affiche dans l'en-tete de la carte (masque si slot `header-title` projete). */
  @Input() Title: string = '';
  /** Icone Material Icons affichee a gauche du titre. Si vide, aucune icone n'est rendue. */
  @Input() Icon: string = '';
  /** Lien de navigation vers la page "Voir tout". Si null et pas de handler, le bouton est masque. */
  @Input() SeeAllLink: string | null = null;
  /** Libelle du bouton "Voir tout" (defaut : "Voir tout"). */
  @Input() SeeAllLabel: string = 'Voir tout';
  /** Force l'affichage du bouton "Voir tout" meme sans handler observe (null = auto). */
  @Input() ShowSeeAll: boolean = false;
  /** Active ou desactive la fonctionnalite de pliage (chevron + clic header). */
  @Input() Collapsible: boolean = false;
  /** Etat courant plie/deplie. Peut etre force depuis l'exterieur. */
  @Input() Collapsed: boolean = false;
  /**
   * Template optionnel pour injecter des actions supplementaires dans l'en-tete.
   * @deprecated Preferez le slot ng-content `header-actions` (plus flexible).
   */
  @Input() HeaderActions: TemplateRef<unknown> | null = null;
  /** Emis au clic sur "Voir tout" quand aucun SeeAllLink n'est defini. */
  @Output() SeeAllClick: EventEmitter<MouseEvent> = new EventEmitter<MouseEvent>();
  /** Emis a chaque changement d'etat plie/deplie (peut etre intercepte par le parent). */
  @Output() CollapsedChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  /** Identifiant unique de l'instance (ARIA + cle). */
  public readonly InstanceId: string = `section-card-${++lSectionCardInstanceCounter}`;
  /** ID de la zone de contenu, derive de `InstanceId`. Utilise par `aria-controls`. */
  public readonly ContentId: string = `${this.InstanceId}-content`;
  /**
   * Indique si un slot `header-title` a ete projete par le consommateur.
   * Lorsqu'il est present, le titre par defaut (`Title`) est masque pour eviter
   * un doublon visuel avec le contenu projete.
   */
  public get HasHeaderTitleSlot(): boolean
  {
    return this._hasHeaderTitleSlot;
  }
  //#endregion

  //#region Methods
  /**
   * Bascule l'etat plie/deplie. Sans effet si `Collapsible` est `false`.
   * Emet `CollapsedChange` a chaque changement.
   */
  public ToggleCollapsed(): void
  {
    if (!this.Collapsible)
    {
      return;
    }
    this.Collapsed = !this.Collapsed;
    this.CollapsedChange.emit(this.Collapsed);
  }

  /**
   * Handler de clic sur "Voir tout" : stoppe la propagation pour ne pas replier la carte.
   * @param pEvent L'evenement de clic souris
   */
  public OnSeeAllClick(pEvent: MouseEvent): void
  {
    pEvent.stopPropagation();
    this.SeeAllClick.emit(pEvent);
  }

  /**
   * Indique si le bouton "Voir tout" doit etre affiche.
   */
  public get HasSeeAll(): boolean
  {
    if (this.ShowSeeAll !== null)
    {
      return this.ShowSeeAll;
    }
    return this.SeeAllLink !== null || this.SeeAllClick.observed;
  }
  //#endregion
}
