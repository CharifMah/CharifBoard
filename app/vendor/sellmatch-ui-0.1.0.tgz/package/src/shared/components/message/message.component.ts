import { Component, inject, OnInit, OnDestroy, ViewChild, ElementRef, ChangeDetectionStrategy } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ChatService } from '../../../core/services/Chats/ChatService';
import { ConversationsDTO } from '../../../core/sellmatchdb/dto/conversations/conversations.dto';
import { MessagesDTO } from '../../../core/sellmatchdb/dto/messages/messages.dto';
import { ListComponent } from "../List/list.component";
import { ConversationItemComponent } from "../../../components/ConversationItem/conversation-item.component";
import { PopupComponent } from '../popup/popup.component';
import { BadgeComponent } from "../badge/badge.component";
import { ProfilCardComponent } from "../../../components/profil-card/profil-card.component";
import { ButtonComponent } from '../button/button.component';

@Component({
  selector: 'app-message',
  standalone: true,
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [FormsModule, ListComponent, ConversationItemComponent, PopupComponent, BadgeComponent, ProfilCardComponent, ButtonComponent]
})
export class MessageComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild('messagesContainer') private messagesContainer!: ElementRef;

  private chatService = inject(ChatService);
  private destroy$ = new Subject<void>();
  private typingTimeout?: number;
  public ShowDeletePopup: boolean = false;
  // État
  conversations: ConversationsDTO[] = [];
  selectedConversation: ConversationsDTO | null = null;
  messages: MessagesDTO[] = [];
  newMessage = '';
  isLoading = false;
  isSending = false;
  connectionError: string | null = null;
  accessError: string | null = null;
  typingUsers = new Map<number, string>();
  IsOpenPopup: any;

  // Rôle de l'utilisateur

  get isConnected(): boolean {
    return this.chatService.isConnected;
  }

  //#region Methods

  ngOnInit(): void {
    this.setupSignalR();
    this.connectToChat();
  }

  ngOnDestroy(): void {
    if (this.selectedConversation?.id) {
      this.chatService.leaveConversation(this.selectedConversation.id).catch(console.error);
    }
    this.chatService.disconnect();
    this.destroy$.next();
    this.destroy$.complete();
  }

  public onConfirmed() {
    if (this.selectedConversation?.professional?.id && this.selectedConversation?.opportunityId) {
      this.chatService.deleteConversation(
        this.selectedConversation.professional.id,
        this.selectedConversation.opportunityId
      );
      this.PostHog.Capture(this.BuildTrackingName('message_conversation_supprimee', 'tracking'), { conversationId: this.selectedConversation.id });
    }
  }

  private setupSignalR(): void {
    // Connexion
    this.chatService.connectionState$
      .pipe(takeUntil(this.destroy$))
      .subscribe(state => {
        if (state === 'Connected') {
          this.connectionError = null;
          this.accessError = null;
          this.loadConversations();
        } else if (state === 'Error') {
          this.connectionError = 'Erreur de connexion';
          this.isLoading = false;
        }
      });

    // Messages
    this.chatService.messageReceived$
      .pipe(takeUntil(this.destroy$))
      .subscribe(msg => {
        if (msg) this.handleNewMessage(msg);
      });

    // Conversations
    this.chatService.conversations$
      .pipe(takeUntil(this.destroy$))
      .subscribe(convs => {
        if (convs?.length) {
          this.conversations = convs;
          this.isLoading = false;

          // Sélectionner automatiquement la première conversation
          if (!this.selectedConversation && convs.length > 0) {
            this.selectConversation(convs[0]);
          }
        }
        else if (convs && convs.length === 0) {
          this.conversations = [];
          this.isLoading = false;
          this.selectedConversation = null;
          this.messages = [];
        }
      });

    // Messages chargés
    this.chatService.messagesLoaded$
      .pipe(takeUntil(this.destroy$))
      .subscribe(msgs => {
        if (msgs) {
          this.messages = this.sortMessages(msgs);
          this.scrollToBottom();
        }
      });

    // Lecture
    this.chatService.messageRead$
      .pipe(takeUntil(this.destroy$))
      .subscribe(data => {
        if (data) this.markAsRead(data.messageId, data.readAt);
      });

    // Typing
    this.chatService.userTyping$
      .pipe(takeUntil(this.destroy$))
      .subscribe(data => {
        if (data?.conversationId === this.selectedConversation?.id) {
          this.handleTyping(data);
        }
      });

    // Erreurs d'accès
    this.chatService.accessError$
      .pipe(takeUntil(this.destroy$))
      .subscribe(error => {
        this.accessError = error;
        console.error('Erreur d\'accès:', error);
      });
  }

  private async connectToChat(): Promise<void> {
    this.isLoading = true;
    try {
      await this.chatService.connect();
    } catch (error) {
      console.error('Erreur connexion:', error);
      this.connectionError = 'Connexion impossible';
      this.isLoading = false;
    }
  }

  private async loadConversations(): Promise<void> {
    try {
      await this.chatService.getConversations();
    } catch (error: any) {
      console.error('Erreur chargement:', error);
      this.accessError = error.message || 'Erreur lors du chargement des conversations';
      this.isLoading = false;
    }
  }

  private handleNewMessage(msg: any): void {
    const message: MessagesDTO = {
      id: msg.id,
      conversationId: msg.conversationId,
      senderId: msg.senderId,
      content: msg.content,
      createdAt: msg.timestamp || msg.createdAt,
      readAt: msg.readAt,
      sender: msg.sender || { id: msg.senderId, username: msg.senderName }
    };

    // Conversation active
    if (msg.conversationId === this.selectedConversation?.id) {
      if (!this.isDuplicate(message)) {
        this.messages = this.sortMessages([...this.messages, message]);
        this.scrollToBottom();

        // Marquer lu si ce n'est pas notre message
        if (message.senderId?.toString() !== this.CurrentUserId && message.id) {
          this.chatService.markAsRead(message.id).catch(console.error);
        }
      }
    }

    // Mettre à jour la liste des conversations
    this.updateConversationList(msg);
  }

  private isDuplicate(msg: MessagesDTO): boolean {
    return this.messages.some(m =>
      m.id === msg.id ||
      (m.content === msg.content &&
        m.senderId === msg.senderId &&
        Math.abs(new Date(m.createdAt!).getTime() - new Date(msg.createdAt!).getTime()) < 1000)
    );
  }

  private sortMessages(msgs: MessagesDTO[]): MessagesDTO[] {
    return [...msgs].sort((a, b) =>
      new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime()
    );
  }

  private updateConversationList(msg: any): void {
    const idx = this.conversations.findIndex(c => c.id === msg.conversationId);
    if (idx === -1) return;

    const conv = { ...this.conversations[idx] };
    const newMsg: MessagesDTO = {
      id: msg.id,
      conversationId: msg.conversationId,
      senderId: msg.senderId,
      content: msg.content,
      createdAt: msg.timestamp || msg.createdAt,
      sender: { id: msg.senderId, username: msg.senderName }
    };

    conv.messages = [...(conv.messages || []), newMsg];
    conv.updatedAt = new Date().toISOString();

    // Remonter en première position
    this.conversations = [
      conv,
      ...this.conversations.filter(c => c.id !== msg.conversationId)
    ];
  }

  private markAsRead(messageId: number, readAt: Date): void {
    this.messages = this.messages.map(m =>
      m.id === messageId ? { ...m, readAt: new Date(readAt) } : m
    );
  }

  private handleTyping(data: { userId: number; userName: string }): void {
    if (data.userId.toString() == this.CurrentUserId) return;

    this.typingUsers.set(data.userId, data.userName);
    setTimeout(() => this.typingUsers.delete(data.userId), 3000);
  }

  async selectConversation(conv: ConversationsDTO): Promise<void> {
    if (this.selectedConversation?.id === conv.id) return;

    // Quitter l'ancienne conversation
    if (this.selectedConversation?.id) {
      await this.chatService.leaveConversation(this.selectedConversation.id).catch(console.error);
    }

    this.selectedConversation = conv;
    this.messages = [];
    this.typingUsers.clear();
    this.accessError = null;

    try {
      await this.chatService.joinConversation(conv.id!);
      await this.chatService.getMessages(conv.id!);
      this.PostHog.Capture(this.BuildTrackingName('message_conversation_ouverte', 'tracking'), { conversationId: conv.id });
    } catch (error: any) {
      console.error('Erreur sélection:', error);
      this.accessError = error.message || 'Erreur lors de la sélection de la conversation';
      this.selectedConversation = null;
    }
  }

  async sendMessage(): Promise<void> {
    const content = this.newMessage.trim();
    if (!content || !this.selectedConversation?.id || this.isSending || !this.isConnected) {
      return;
    }

    this.isSending = true;
    const backup = content;
    this.newMessage = '';

    try {
      await this.chatService.sendMessage(this.selectedConversation.id, content);
      this.PostHog.Capture(this.BuildTrackingName('message_envoye', 'tracking'), { conversationId: this.selectedConversation.id });
    } catch (error: any) {
      console.error('Erreur envoi:', error);
      this.accessError = error.message || 'Erreur lors de l\'envoi du message';
      this.newMessage = backup;
    } finally {
      this.isSending = false;
    }
  }

  onInput(): void {
    if (!this.selectedConversation?.id || !this.isConnected) return;

    clearTimeout(this.typingTimeout);
    this.typingTimeout = window.setTimeout(() => {
      this.chatService.sendTypingIndicator(this.selectedConversation!.id!).catch(console.error);
    }, 300);
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      const el = this.messagesContainer?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    }, 100);
  }

  async reconnect(): Promise<void> {
    this.connectionError = null;
    this.accessError = null;
    this.isLoading = true;
    await this.connectToChat();
    this.PostHog.Capture(this.BuildTrackingName('message_reconnexion', 'tracking'));
  }

  // ===== HELPERS VUE =====

  isOwnMessage(msg: MessagesDTO): boolean {
    return msg.senderId?.toString() == this.CurrentUserId;
  }

  getSenderName(msg: MessagesDTO): string {
    if (msg.sender) {
      return `${msg.sender.firstName || ''} ${msg.sender.lastName || ''}`.trim() ||
        msg.sender.username ||
        'Utilisateur';
    }
    return 'Utilisateur';
  }

  getUnreadCount(conv: ConversationsDTO): number {
    return conv.messages?.filter(m => !m.readAt && m.senderId?.toString() !== this.CurrentUserId).length || 0;
  }

  getLastMessage(conv: ConversationsDTO): string {
    const msgs = conv.messages;
    if (!msgs?.length) return 'Aucun message';

    const last = [...msgs].sort((a, b) =>
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    )[0];

    const content = last.content || '';
    return content.length > 50 ? content.substring(0, 50) + '...' : content;
  }

  getLastMessageTime(conv: ConversationsDTO): string {
    const msgs = conv.messages;
    if (!msgs?.length) return '';

    const last = [...msgs].sort((a, b) =>
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    )[0];

    return this.FormatDate(last.createdAt);
  }

  getConversationTitle(conv: ConversationsDTO): string {
    if (conv.opportunity?.address) {
      return conv.opportunity.address.street ?? '';
    }

    if (conv.opportunity?.propertyType) {
      return conv.opportunity.propertyType;
    }

    return `Conversation #${conv.id}`;
  }

  getTypingText(): string {
    const users = Array.from(this.typingUsers.values());
    if (!users.length) return '';
    if (users.length === 1) return `${users[0]} écrit...`;
    return `${users.length} personnes écrivent...`;
  }

  shouldShowDateSeparator(index: number): boolean {
    if (index === 0) return true;
    const current = this.messages[index];
    const prev = this.messages[index - 1];
    if (!current.createdAt || !prev.createdAt) return false;

    return new Date(current.createdAt).toDateString() !== new Date(prev.createdAt).toDateString();
  }

  trackByConvId(index: number, conv: ConversationsDTO): number {
    return conv.id!;
  }

  trackByMsgId(index: number, msg: MessagesDTO): number {
    return msg.id!;
  }
  //#endregion
}
