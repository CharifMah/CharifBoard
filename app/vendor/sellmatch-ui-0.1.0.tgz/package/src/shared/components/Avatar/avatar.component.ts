import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';

@Component({
  selector: 'app-avatar',
  standalone: true,
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [CommonModule]
})
export class AvatarComponent extends BaseComponent implements OnChanges {
  @Input() avatarUrl: string | undefined = undefined;
  @Input() size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' = 'md';
  @Input() border: boolean = false;
  @Input() borderColor: string = 'primary';
  @Input() status: 'online' | 'offline' | 'busy' | 'away' | 'none' = 'none';
  @Input() alt: string = 'Avatar';
  @Output() onClick = new EventEmitter<MouseEvent>();

  imageError: boolean = false;
  currentImageUrl: string | undefined = undefined;

  constructor() {
    super();
  }

  /**
   * Gère le clic sur l'avatar et tracke l'événement.
   * @param pEvent L'événement souris
   */
  public OnClick(pEvent: MouseEvent): void {
    this.PostHog.Capture(this.BuildTrackingName('avatar_clique', 'tracking'));
    this.onClick.emit(pEvent);
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Réinitialiser l'erreur et mettre à jour l'URL quand avatarUrl change
    if (changes['avatarUrl']) {
      this.imageError = false;
      this.currentImageUrl = this.avatarUrl;
    }
  }

  onImageError(): void {
    this.imageError = true;
    this.PostHog.Capture(this.BuildTrackingName('avatar_erreur_chargement', 'tracking'), { url: this.currentImageUrl });
  }

  get sizeClass(): string {
    return `avatar-${this.size}`;
  }

  get statusSizeClass(): string {
    return `status-${this.size}`;
  }

  get statusClass(): string {
    if (this.status === 'none') return '';
    return `status-${this.status}`;
  }

  get borderClass(): string {
    if (!this.border) return 'border-none';
    return `border-${this.borderColor}`;
  }

  get showImage(): boolean {
    return !!this.currentImageUrl && !this.imageError;
  }

  get showFallback(): boolean {
    return !this.currentImageUrl || this.imageError;
  }
}