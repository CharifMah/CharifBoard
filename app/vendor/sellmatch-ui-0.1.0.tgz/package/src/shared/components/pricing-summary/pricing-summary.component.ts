import { Component, ChangeDetectionStrategy, OnInit, OnDestroy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BaseComponent } from '../../../core/base/BaseComponent';
import { BadgeComponent } from '../../../shared/components/badge/badge.component';
import { SubscriptionPlansDTO } from '../../../core/sellmatchdb/dto/subscription-plans/subscription-plans.dto';
import { SubscriptionPlansService } from '../../../core/sellmatchdb/services/subscription-plans/subscription-plans.service';

/**
 * Composant partagé d'affichage des plans d'abonnement SellMatch.
 * - cm - Lit les plans via SubscriptionPlansService (SubscriptionPlansController
 *   est override [AllowAnonymous] sur GetAll pour permettre aux prospects non
 *   logués de voir les prix marketing). Aucun CTA checkout embarqué :
 *   le composant est purement informatif, l'utilisateur navigue vers /pricing
 *   pour payer. Réutilisé sur la home (côté public) et la page /pricing.
 */
@Component({
  selector: 'app-pricing-summary',
  standalone: true,
  imports: [CommonModule, BadgeComponent],
  templateUrl: './pricing-summary.component.html',
  styleUrl: './pricing-summary.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PricingSummaryComponent extends BaseComponent implements OnInit, OnDestroy
{
  //#region Attributes

  private readonly _Plans = inject(SubscriptionPlansService);

  /** Plans chargés depuis l'API, triés par displayOrder. */
  public readonly Plans = signal<SubscriptionPlansDTO[]>([]);
  /** Erreur de chargement (rare : pas d'auth ou backend HS). */
  public readonly Error = signal<string | null>(null);
  /** Indique un chargement en cours. */
  public readonly Loading = signal(false);

  //#endregion

  //#region Lifecycle

  public async ngOnInit(): Promise<void>
  {
    await this.LoadPlans();
  }

  public ngOnDestroy(): void
  {
    // no-op : rien à cleanup manuellement.
  }

  //#endregion

  //#region Methods

  /** Charge les plans actifs depuis SubscriptionPlansController.GetAll. */
  private async LoadPlans(): Promise<void>
  {
    this.Loading.set(true);
    this.Error.set(null);
    try
    {
      const lPlans = await this._Plans.getAll({ isActive: true });
      const lSorted = [...lPlans].sort(
        (a: SubscriptionPlansDTO, b: SubscriptionPlansDTO) =>
          (a.displayOrder ?? 999) - (b.displayOrder ?? 999)
      );
      this.Plans.set(lSorted);
    }
    catch (pError: any)
    {
      this.Error.set(pError?.message ?? 'Impossible de charger les plans.');
    }
    finally
    {
      this.Loading.set(false);
    }
  }

  /** True si le plan est l'ÉcoMandat (paiement unique 4,99€). */
  public IsEcoMandat(pPlan: SubscriptionPlansDTO): boolean
  {
    return !!pPlan?.isOneShot || pPlan?.key === 'ecomandat';
  }

  /** Prix principal à afficher. Pour les abonnements : mensuel HT par défaut. */
  public FormatPlanPrice(pPlan: SubscriptionPlansDTO): string
  {
    if (!pPlan) return '-';
    if (pPlan.isOneShot)
    {
      return pPlan.priceOneShotTtc != null ? `${pPlan.priceOneShotTtc.toFixed(2)} €` : '-';
    }
    return pPlan.priceMonthlyHt != null ? `${pPlan.priceMonthlyHt.toFixed(2)} € HT` : '-';
  }

  /** Label de la période ("/mois" pour abonnements, "Paiement unique" pour ÉcoMandat). */
  public FormatPeriodLabel(pPlan: SubscriptionPlansDTO): string
  {
    if (!pPlan) return '';
    if (pPlan.isOneShot) return 'Paiement unique';
    return '/mois';
  }

  //#endregion
}
