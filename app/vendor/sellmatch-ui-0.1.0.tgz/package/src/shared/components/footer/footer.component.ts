import { Component, ChangeDetectionStrategy, computed, Signal } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BaseComponent } from '../../../core/base/BaseComponent';
import { ImageComponent } from '../image/image.component';
import { APP_GIT_SHA } from '../../../environments/version';


@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterModule, ImageComponent],
  templateUrl: './footer.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent extends BaseComponent
{
  //#region Properties
  /** Annee courante affichee dans le copyright du footer. */
  public readonly currentYear: number = new Date().getFullYear();

  // - cm - SHA git court du commit de build, injecte par scripts/bump-version.js
  // - cm - (git rev-parse --short HEAD + suffixe '-dirty' si working tree modifie).
  // - cm - Permet d'identifier en un coup d'oeil quel build est deploye en prod/recette
  // - cm - en consultant le footer de la page.
  public readonly gitSha: string = APP_GIT_SHA;

  /**
   * Liste des villes pour les liens SEO de longue trainee dans le footer.
   * Les noms de villes ne sont volontairement PAS traduits (referencement local).
   */
  public readonly EstimationVilles: { slug: string; nom: string }[] = [
    { slug: 'paris', nom: 'Paris' },
    { slug: 'marseille', nom: 'Marseille' },
    { slug: 'lyon', nom: 'Lyon' },
    { slug: 'toulouse', nom: 'Toulouse' },
    { slug: 'nice', nom: 'Nice' },
    { slug: 'nantes', nom: 'Nantes' },
    { slug: 'bordeaux', nom: 'Bordeaux' },
    { slug: 'lille', nom: 'Lille' },
    { slug: 'montpellier', nom: 'Montpellier' },
    { slug: 'strasbourg', nom: 'Strasbourg' }
  ];
  //#endregion

  //#region i18n computed (reactifs sur InstantTick)
  /**
   * Lit la valeur d'une cle i18n en s'abonnant au tick de chargement.
   * - cm - Pattern identique a NavbarComponent : on appelle InstantTick() pour
   * que le computed se re-invalide a chaque chargement de JSON ou changement
   * de langue. Pas de NG0600 car InstantTick est un signal Angular distinct
   * des signaux internes de ngx-translate.
   * @param pKey Cle i18n a resoudre (ex: 'footer.brand.tagline')
   * @param pParams Parametres optionnels d'interpolation (ex: { year: 2026 })
   */
  private TranslateKey(pKey: string, pParams?: object): string
  {
    this.Translate.InstantTick(); // - cm - Abonnement reactif au tick
    return this.Translate.translate(pKey, pParams);
  }

  /** Tagline de la marque (sous le logo). */
  public readonly Tagline: Signal<string> = computed<string>(() => this.TranslateKey('footer.brand.tagline'));

  // - cm - Libelles de la colonne "SellMatch"
  /** Titre de la colonne SellMatch. */
  public readonly SellmatchTitle: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.title'));
  /** Lien Accueil de la colonne SellMatch. */
  public readonly SellmatchHome: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.home'));
  /** Lien Estimation immobiliere de la colonne SellMatch. */
  public readonly SellmatchEstimation: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.estimation'));
  /** Lien Inscription vendeur de la colonne SellMatch. */
  public readonly SellmatchSignupSeller: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.signupSeller'));
  /** Lien Inscription professionnel de la colonne SellMatch. */
  public readonly SellmatchSignupPro: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.signupPro'));
  /** Lien Connexion de la colonne SellMatch. */
  public readonly SellmatchLogin: Signal<string> = computed<string>(() => this.TranslateKey('footer.sellmatch.login'));

  // - cm - Libelles de la colonne "Ressources"
  /** Titre de la colonne Ressources. */
  public readonly ResourcesTitle: Signal<string> = computed<string>(() => this.TranslateKey('footer.resources.title'));
  /** Lien Blog de la colonne Ressources. */
  public readonly ResourcesBlog: Signal<string> = computed<string>(() => this.TranslateKey('footer.resources.blog'));
  /** Lien FAQ de la colonne Ressources. */
  public readonly ResourcesFaq: Signal<string> = computed<string>(() => this.TranslateKey('footer.resources.faq'));
  /** Lien Contact de la colonne Ressources. */
  public readonly ResourcesContact: Signal<string> = computed<string>(() => this.TranslateKey('footer.resources.contact'));
  /** Lien Vendre son bien de la colonne Ressources. */
  public readonly ResourcesSell: Signal<string> = computed<string>(() => this.TranslateKey('footer.resources.sell'));

  // - cm - Libelle de la colonne "Estimation par ville" (titre uniquement, les villes ne sont pas traduites)
  /** Titre de la colonne Estimation par ville. */
  public readonly EstimationTitle: Signal<string> = computed<string>(() => this.TranslateKey('footer.estimation.title'));

  // - cm - Libelles de la colonne "Legal"
  /** Titre de la colonne Legal. */
  public readonly LegalTitle: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.title'));
  /** Lien CGU de la colonne Legal. */
  public readonly LegalCgu: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.cgu'));
  /** Lien CGV de la colonne Legal. */
  public readonly LegalCgv: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.cgv'));
  /** Lien Confidentialite de la colonne Legal. */
  public readonly LegalPrivacy: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.privacy'));
  /** Lien Mentions legales de la colonne Legal. */
  public readonly LegalMentions: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.mentions'));
  /** Lien Cookies de la colonne Legal. */
  public readonly LegalCookies: Signal<string> = computed<string>(() => this.TranslateKey('footer.legal.cookies'));

  /** Ligne de copyright interpolee avec l'annee courante. */
  public readonly Copyright: Signal<string> = computed<string>(() => this.TranslateKey('footer.copyright', { year: this.currentYear }));
  /** Libelle de build affiche dans le footer : SHA git court du commit deploye. */
  public readonly VersionLabel: Signal<string> = computed<string>(() => this.TranslateKey('footer.version', { version: this.gitSha }));
  //#endregion

  //#region Methods
  /**
   * Retourne la route du dashboard selon le role de l'utilisateur connecte.
   * @returns La route du dashboard pro ou vendeur
   */
  getDashboardRoute(): string
  {
    if (this.UsersService.IsProfessionnel() || this.UsersService.isAdmin())
    {
      return this.RouteUtils.GetRoute(this.Routes.DASHBOARD_PRO);
    }
    return this.RouteUtils.GetRoute(this.Routes.DASHBOARD_VENDEUR);
  }

  /**
   * Deconnecte l'utilisateur courant et trace l'evenement PostHog.
   */
  onLogout(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('footer_deconnexion', 'tracking'));
    this.UsersService.logout();
  }
  //#endregion
}
