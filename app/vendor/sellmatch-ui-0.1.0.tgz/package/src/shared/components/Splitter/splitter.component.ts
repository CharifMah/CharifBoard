import { Component, Input, Output, EventEmitter, ElementRef, HostListener, ContentChildren, QueryList, AfterContentInit, Directive, inject, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../../core/base/BaseComponent';


@Directive({
  selector: 'app-splitter-panel',
  standalone: true
})
export class SplitterPanelDirective
{
  @Input() public Size: number | null = null;
  @Input() public MinSize: number = 0;
  @Input() public MaxSize: number = 100;
  @Input() public Collapsible: boolean = false;

  public Collapsed: boolean = false;
  public ActualSize: number = 0;
}

@Component({
  selector: 'app-splitter',
  standalone: true,
  templateUrl: './splitter.component.html',
  styleUrls: ['./splitter.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: []
})
export class SplitterComponent extends BaseComponent implements AfterContentInit
{
  //#region Inputs
  @Input() public Direction: 'horizontal' | 'vertical' = 'horizontal';
  @Input() public GutterSize: number = 8;
  @Input() public Disabled: boolean = false;
  @Input() public ShowCollapseButtons: boolean = false;
  @Input() public MinPanelSize: number = 50;
  @Input() public Sizes: number[] = [];
  //#endregion

  //#region Outputs
  @Output() public SizesChange: EventEmitter<number[]> = new EventEmitter<number[]>();
  @Output() public DragStart: EventEmitter<number> = new EventEmitter<number>();
  @Output() public DragEnd: EventEmitter<number[]> = new EventEmitter<number[]>();
  @Output() public PanelCollapse: EventEmitter<{ index: number; collapsed: boolean }> = new EventEmitter();
  //#endregion

  //#region Content Children
  @ContentChildren(SplitterPanelDirective) public Panels!: QueryList<SplitterPanelDirective>;
  //#endregion

  //#region Internal State
  public PanelSizes: number[] = [];
  public CollapsedPanels: boolean[] = [];
  public IsDragging: boolean = false;
  public IsMobileView: boolean = false;

  private _CurrentGutterIndex: number = -1;
  private _StartPosition: number = 0;
  private _StartSizes: number[] = [];
  private _ContainerSize: number = 0;
  private _SavedSizes: Map<number, number> = new Map();
  private _ElementRef: ElementRef = inject(ElementRef);
  //#endregion

  //#region Lifecycle
  ngAfterContentInit(): void
  {
    this._CheckMobileView();
    this._InitializeSizes();

    this.Panels.changes.subscribe(() =>
    {
      this._InitializeSizes();
    });
  }

  /** Détecte le mode mobile/tablette pour adapter le splitter */
  @HostListener('window:resize')
  public OnResize(): void
  {
    this._CheckMobileView();
  }
  //#endregion

  //#region Getters
  public get IsHorizontal(): boolean
  {
    // - cm - En mobile, force le mode vertical indépendamment de l'input
    if (this.IsMobileView && this.Direction === 'horizontal')
    {
      return false;
    }

    return this.Direction === 'horizontal';
  }

  public get GutterCount(): number
  {
    return Math.max(0, this.PanelSizes.length - 1);
  }

  public get ContainerClass(): string
  {
    const lDirection = this.IsHorizontal ? 'horizontal' : 'vertical';
    return `splitter-container splitter-${lDirection}`;
  }
  //#endregion

  //#region Public Methods - Panel Styles
  public GetPanelStyle(pIndex: number): Record<string, string>
  {
    if (this.CollapsedPanels[pIndex])
    {
      return this.IsHorizontal
        ? { 'width': '0', 'overflow': 'hidden' }
        : { 'height': '0', 'overflow': 'hidden' };
    }

    const lSize = `calc(${this.PanelSizes[pIndex]}% - ${this._GetGutterOffset()}px)`;

    return this.IsHorizontal
      ? { 'width': lSize }
      : { 'height': lSize };
  }

  public GetGutterStyle(): Record<string, string>
  {
    return this.IsHorizontal
      ? { 'width': `${this.GutterSize}px`, 'cursor': 'col-resize' }
      : { 'height': `${this.GutterSize}px`, 'cursor': 'row-resize' };
  }
  //#endregion

  //#region Public Methods - Drag Events
  public OnGutterMouseDown(pEvent: MouseEvent, pGutterIndex: number): void
  {
    if (this.Disabled) return;

    pEvent.preventDefault();
    this.PostHog.Capture(this.BuildTrackingName('splitter_drag_debut', 'tracking'), { index: pGutterIndex, direction: this.Direction });
    this._StartDrag(pEvent, pGutterIndex);
  }

  public OnGutterTouchStart(pEvent: TouchEvent, pGutterIndex: number): void
  {
    if (this.Disabled) return;

    this._StartDrag(pEvent, pGutterIndex);
  }

  @HostListener('document:mousemove', ['$event'])
  public OnMouseMove(pEvent: MouseEvent): void
  {
    if (!this.IsDragging) return;

    pEvent.preventDefault();
    this._OnDrag(pEvent);
  }

  @HostListener('document:touchmove', ['$event'])
  public OnTouchMove(pEvent: TouchEvent): void
  {
    if (!this.IsDragging) return;

    this._OnDrag(pEvent);
  }

  @HostListener('document:mouseup')
  @HostListener('document:touchend')
  public OnDragEnd(): void
  {
    if (!this.IsDragging) return;

    this.IsDragging = false;
    this._CurrentGutterIndex = -1;
    this.PostHog.Capture(this.BuildTrackingName('splitter_drag_fin', 'tracking'), { tailles: this.PanelSizes });
    this.DragEnd.emit([...this.PanelSizes]);
  }
  //#endregion

  //#region Public Methods - Collapse
  public ToggleCollapse(pIndex: number): void
  {
    if (!this._CanCollapse(pIndex)) return;

    const lIsCollapsed = this.CollapsedPanels[pIndex];

    if (lIsCollapsed)
    {
      this._ExpandPanel(pIndex);
    }
    else
    {
      this._CollapsePanel(pIndex);
    }

    this.PostHog.Capture(this.BuildTrackingName('splitter_collapse', 'tracking'), { index: pIndex, reduit: this.CollapsedPanels[pIndex] });
    this.PanelCollapse.emit({ index: pIndex, collapsed: this.CollapsedPanels[pIndex] });
  }

  public CanCollapse(pIndex: number): boolean
  {
    return this._CanCollapse(pIndex);
  }

  public IsCollapsed(pIndex: number): boolean
  {
    return this.CollapsedPanels[pIndex] || false;
  }
  //#endregion

  //#region Public Methods - Resize
  public SetSizes(pSizes: number[]): void
  {
    if (pSizes.length !== this.PanelSizes.length) return;

    this.PanelSizes = [...pSizes];
    this._NormalizeSizes();
    this.SizesChange.emit([...this.PanelSizes]);
  }

  public ResetSizes(): void
  {
    this._InitializeSizes();
    this.SizesChange.emit([...this.PanelSizes]);
  }
  //#endregion

  //#region Private Methods - Initialization
  private _InitializeSizes(): void
  {
    const lPanelCount = this.Panels?.length || this.Sizes.length || 2;

    if (this.Sizes.length === lPanelCount)
    {
      this.PanelSizes = [...this.Sizes];
    }
    else if (this.Panels && this.Panels.length > 0)
    {
      const lPanelArray = this.Panels.toArray();
      const lDefinedSizes = lPanelArray.filter(p => p.Size !== null);

      if (lDefinedSizes.length > 0)
      {
        let lRemainingSize = 100;
        let lUndefinedCount = 0;

        lPanelArray.forEach(p =>
        {
          if (p.Size !== null)
          {
            lRemainingSize -= p.Size;
          }
          else
          {
            lUndefinedCount++;
          }
        });

        const lDefaultSize = lUndefinedCount > 0 ? lRemainingSize / lUndefinedCount : 0;

        this.PanelSizes = lPanelArray.map(p => p.Size ?? lDefaultSize);
      }
      else
      {
        this.PanelSizes = lPanelArray.map(() => 100 / lPanelCount);
      }
    }
    else
    {
      this.PanelSizes = Array(lPanelCount).fill(100 / lPanelCount);
    }

    this.CollapsedPanels = Array(this.PanelSizes.length).fill(false);
    this._NormalizeSizes();
  }

  private _NormalizeSizes(): void
  {
    const lTotal = this.PanelSizes.reduce((pSum, pSize) => pSum + pSize, 0);

    if (Math.abs(lTotal - 100) > 0.1)
    {
      const lFactor = 100 / lTotal;
      this.PanelSizes = this.PanelSizes.map(pSize => pSize * lFactor);
    }
  }
  //#endregion

  //#region Private Methods - Drag
  private _StartDrag(pEvent: MouseEvent | TouchEvent, pGutterIndex: number): void
  {
    this.IsDragging = true;
    this._CurrentGutterIndex = pGutterIndex;
    this._StartPosition = this._GetPositionFromEvent(pEvent);
    this._StartSizes = [...this.PanelSizes];
    this._ContainerSize = this._GetContainerSize();

    this.DragStart.emit(pGutterIndex);
  }

  private _OnDrag(pEvent: MouseEvent | TouchEvent): void
  {
    const lCurrentPosition = this._GetPositionFromEvent(pEvent);
    const lDelta = lCurrentPosition - this._StartPosition;

    this._CalculateNewSizes(lDelta);
    this.SizesChange.emit([...this.PanelSizes]);
  }

  private _GetPositionFromEvent(pEvent: MouseEvent | TouchEvent): number
  {
    if (pEvent instanceof TouchEvent)
    {
      return this.IsHorizontal
        ? pEvent.touches[0].clientX
        : pEvent.touches[0].clientY;
    }

    return this.IsHorizontal ? pEvent.clientX : pEvent.clientY;
  }

  private _GetContainerSize(): number
  {
    const lRect = this._ElementRef.nativeElement.getBoundingClientRect();
    return this.IsHorizontal ? lRect.width : lRect.height;
  }

  private _CalculateNewSizes(pDelta: number): void
  {
    const lDeltaPercent = (pDelta / this._ContainerSize) * 100;

    let lNewSize1 = this._StartSizes[this._CurrentGutterIndex] + lDeltaPercent;
    let lNewSize2 = this._StartSizes[this._CurrentGutterIndex + 1] - lDeltaPercent;

    // Get min/max from panels or use defaults
    const lPanelArray = this.Panels?.toArray() || [];
    const lPanel1 = lPanelArray[this._CurrentGutterIndex];
    const lPanel2 = lPanelArray[this._CurrentGutterIndex + 1];

    const lMinPercent = (this.MinPanelSize / this._ContainerSize) * 100;

    const lMin1 = lPanel1?.MinSize ?? lMinPercent;
    const lMin2 = lPanel2?.MinSize ?? lMinPercent;
    const lMax1 = lPanel1?.MaxSize ?? 100;
    const lMax2 = lPanel2?.MaxSize ?? 100;

    // Apply constraints
    if (lNewSize1 < lMin1)
    {
      lNewSize1 = lMin1;
      lNewSize2 = this._StartSizes[this._CurrentGutterIndex] + this._StartSizes[this._CurrentGutterIndex + 1] - lMin1;
    }

    if (lNewSize2 < lMin2)
    {
      lNewSize2 = lMin2;
      lNewSize1 = this._StartSizes[this._CurrentGutterIndex] + this._StartSizes[this._CurrentGutterIndex + 1] - lMin2;
    }

    if (lNewSize1 > lMax1)
    {
      lNewSize1 = lMax1;
      lNewSize2 = this._StartSizes[this._CurrentGutterIndex] + this._StartSizes[this._CurrentGutterIndex + 1] - lMax1;
    }

    if (lNewSize2 > lMax2)
    {
      lNewSize2 = lMax2;
      lNewSize1 = this._StartSizes[this._CurrentGutterIndex] + this._StartSizes[this._CurrentGutterIndex + 1] - lMax2;
    }

    this.PanelSizes[this._CurrentGutterIndex] = lNewSize1;
    this.PanelSizes[this._CurrentGutterIndex + 1] = lNewSize2;
  }

  private _GetGutterOffset(): number
  {
    const lTotalGutters = this.GutterCount;
    return (this.GutterSize * lTotalGutters) / this.PanelSizes.length;
  }
  //#endregion

  //#region Private Methods - Collapse
  private _CanCollapse(pIndex: number): boolean
  {
    if (!this.ShowCollapseButtons) return false;

    const lPanelArray = this.Panels?.toArray() || [];
    return lPanelArray[pIndex]?.Collapsible || false;
  }

  private _CollapsePanel(pIndex: number): void
  {
    this._SavedSizes.set(pIndex, this.PanelSizes[pIndex]);
    this.CollapsedPanels[pIndex] = true;

    // Redistribute size to adjacent panel
    const lAdjacentIndex = pIndex === 0 ? 1 : pIndex - 1;
    this.PanelSizes[lAdjacentIndex] += this.PanelSizes[pIndex];
    this.PanelSizes[pIndex] = 0;
  }

  private _ExpandPanel(pIndex: number): void
  {
    const lSavedSize = this._SavedSizes.get(pIndex) || (100 / this.PanelSizes.length);
    const lAdjacentIndex = pIndex === 0 ? 1 : pIndex - 1;

    this.CollapsedPanels[pIndex] = false;
    this.PanelSizes[pIndex] = lSavedSize;
    this.PanelSizes[lAdjacentIndex] -= lSavedSize;

    this._SavedSizes.delete(pIndex);
  }
  //#endregion

  //#region Private Methods - Responsive
  /** Vérifie si la fenêtre est en mode mobile et met à jour IsMobileView */
  private _CheckMobileView(): void
  {
    this.IsMobileView = window.innerWidth <= 768;
  }
  //#endregion
}
