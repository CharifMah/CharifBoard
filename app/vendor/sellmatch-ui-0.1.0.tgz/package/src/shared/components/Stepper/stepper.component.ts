import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../../core/base/BaseComponent';

/** Interface définissant la structure d'une étape du Stepper. */
export interface IStepItem
{
  /** Identifiant unique de l'étape (commence à 1). */
  Id: number;
  /** Libellé affiché sous l'indicateur de progression. */
  Label: string;
  /** Condition à remplir pour que l'étape soit considérée comme validée/accessibile. */
  Condition: boolean;
}

@Component({
  selector: 'app-stepper',
  standalone: true,
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: []
})
export class StepperComponent extends BaseComponent implements OnInit, OnChanges
{
  /** Liste des étapes à afficher dans le stepper. */
  @Input() Steps: IStepItem[] = [];
  /** Étape actuellement active (commence à 1). */
  @Input() CurrentStep: number = 1;
  /** Événement émis lorsqu'une étape cliquée est autorisée. */
  @Output() StepClick = new EventEmitter<number>();

  //#region Properties

  /** Indique si le stepper a déjà été initialisé (évite de tracker au premier ngOnChanges) */
  private _Initialized: boolean = false;

  //#endregion

  constructor () 
  {
    super();
  }

  /**
   * Initialise le composant et tracke l'affichage du stepper.
   */
  public ngOnInit(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('stepper_affiche', 'tracking'), {
      etapes: this.Steps.length,
      etapeCourante: this.CurrentStep
    });
    this._Initialized = true;
  }

  /**
   * Détecte les changements sur les inputs et tracke les changements d'étape.
   * @param pChanges Les changements détectés
   */
  public ngOnChanges(pChanges: SimpleChanges): void
  {
    if (!this._Initialized) // - cm - Ignorer le premier appel avant ngOnInit
    {
      return;
    }

    if (pChanges['CurrentStep'] && !pChanges['CurrentStep'].firstChange) // - cm - Changement d'étape non initial
    {
      const lEtape: IStepItem | undefined = this.Steps.find(pS => pS.Id === this.CurrentStep);

      this.PostHog.Capture(this.BuildTrackingName('etape_changee', 'tracking'), {
        etape: this.CurrentStep,
        libelle: lEtape?.Label ?? 'inconnue'
      });
    }
  }

  /**
   * Gère le clic ou l'interaction clavier sur une étape et vérifie si l'accès est autorisé via sa Condition.
   * @param pStep L'étape cliquée
   */
  public OnStepClick(pStep: IStepItem): void
  {
    if (pStep.Condition) // - cm - Autorise le clic seulement si la condition est remplie
    {
      this.PostHog.Capture(this.BuildTrackingName(pStep.Label, 'etape'));
      this.StepClick.emit(pStep.Id);
    }
  }
}
