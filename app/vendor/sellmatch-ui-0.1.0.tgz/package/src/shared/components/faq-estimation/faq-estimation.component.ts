import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../../core/base/BaseComponent';

/** Question/réponse d'estimation immobilière */
interface IFaqEstimationItem
{
  Question: string;
  Answer: string;
}

/**
 * Composant partagé affichant les questions fréquentes sur l'estimation immobilière.
 * Utilisé à la fois dans la page FAQ et dans la page d'estimation publique.
 * @param pVariant 'accordion' pour la FAQ (accordéon interactif) | 'details' pour l'estimation (balises details natives pour SEO)
 */
@Component({
  selector: 'app-faq-estimation',
  standalone: true,
  imports: [],
  templateUrl: './faq-estimation.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./faq-estimation.component.scss']
})
export class FaqEstimationComponent extends BaseComponent
{
  //#region Inputs
  /** Variante d'affichage : 'accordion' (FAQ) ou 'details' (estimation SEO) */
  @Input() public Variant: 'accordion' | 'details' = 'accordion';
  //#endregion

  //#region Properties
  /** Liste des questions/réponses d'estimation immobilière */
  public readonly FaqItems: IFaqEstimationItem[] = [
    {
      Question: "L'estimation immobilière SellMatch est-elle vraiment gratuite ?",
      Answer: "Oui, l'estimation est entièrement gratuite et sans engagement. Vous obtenez une fourchette de prix basée sur les données officielles DVF+ sans avoir à vous inscrire ni communiquer vos coordonnées."
    },
    {
      Question: "Qu'est-ce que la base DVF+ et pourquoi est-elle fiable ?",
      Answer: "DVF+ (Demandes de Valeurs Foncières) est la base officielle de l'administration fiscale française. Elle contient les prix réels de toutes les transactions immobilières réalisées en France, contrairement aux annonces qui affichent des prix souhaités et non des prix constatés."
    },
    {
      Question: "Combien de temps prend l'estimation ?",
      Answer: "L'estimation prend environ 2 minutes. Il suffit de saisir l'adresse du bien, son type, sa surface et son état pour obtenir une fourchette de prix fiable."
    },
    {
      Question: "Dois-je m'inscrire pour obtenir mon estimation ?",
      Answer: "Non, aucune inscription n'est requise pour obtenir votre estimation. Vous pouvez estimer votre bien en toute confidentialité. L'inscription n'est nécessaire que si vous souhaitez créer un dossier vendeur pour comparer les professionnels."
    },
    {
      Question: "L'estimation en ligne remplace-t-elle l'expertise d'un professionnel ?",
      Answer: "Non, l'estimation en ligne donne un ordre de grandeur indicatif basé sur les transactions réelles. Elle ne remplace pas l'expertise d'un agent immobilier ou d'un notaire qui analyse la spécificité du bien, son environnement immédiat et le marché local."
    },
    {
      Question: "Mes données sont-elles confidentielles ?",
      Answer: "Oui, vos données restent confidentielles et protégées (RGPD). Les informations saisies servent uniquement à calculer une estimation à partir des transactions comparables. SellMatch ne vend ni ne transmet vos coordonnées sans votre accord."
    },
    {
      Question: "L'estimation est-elle disponible pour toute la France ?",
      Answer: "Oui, l'estimation utilise les données DVF+ qui couvrent l'ensemble du territoire français. La précision dépend du nombre de transactions récentes dans la zone de votre bien : plus il y a de ventes comparables, plus l'estimation est fiable."
    },
    {
      Question: "Que faire après avoir obtenu mon estimation ?",
      Answer: "Après votre estimation, vous pouvez créer un dossier vendeur sur SellMatch pour comparer les propositions d'agences et de mandataires de votre secteur. Vous restez anonyme jusqu'à ce que vous choisissiez un professionnel."
    },
    {
      Question: "Puis-je estimer plusieurs biens ?",
      Answer: "Oui, vous pouvez estimer autant de biens que vous le souhaitez. Chaque estimation est indépendante et basée sur les transactions DVF+ autour de l'adresse saisie."
    },
    {
      Question: "Le prix au m² est-il le même partout ?",
      Answer: "Non, le prix au m² varie considérablement selon la commune, le quartier, le type de bien et l'état. C'est pourquoi notre outil croise votre adresse avec les ventes réelles DVF+ proches pour obtenir un prix au m² local et pertinent."
    }
  ];

  /** Index de la question ouverte (mode accordion) */
  public ExpandedIndex: number | null = null;
  //#endregion

  //#region Methods
  /** Bascule l'ouverture d'une question (mode accordion) */
  public Toggle(pIndex: number): void
  {
    this.ExpandedIndex = this.ExpandedIndex === pIndex ? null : pIndex;
  }

  /** Vérifie si une question est ouverte (mode accordion) */
  public IsExpanded(pIndex: number): boolean
  {
    return this.ExpandedIndex === pIndex;
  }
  //#endregion
}