// shared/components/help-card/help-card.component.ts
import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

import { BaseComponent } from '../../../core/base/BaseComponent';
import { ButtonComponent } from '../button/button.component';

@Component({
  selector: 'app-help-card',
  templateUrl: './help-card.component.html',
  standalone: true,
  styleUrls: ['./help-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [ButtonComponent]
})
export class HelpCardComponent extends BaseComponent
{
  @Input() title = 'Besoin d\'aide ?';
  @Input() message = 'Notre équipe est disponible pour vous accompagner dans vos démarches.';
  @Input() buttonText = 'Contacter le support';
  
  @Output() contactClick = new EventEmitter<void>();

  public ShowSupport: boolean = false;

  constructor()
  {
    super();
  }

  onContactClick(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('support_contact', 'tracking'));
    this.ShowSupport = true;
    this.contactClick.emit();
  }


}
