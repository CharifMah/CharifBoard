import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, NgZone, OnDestroy, PLATFORM_ID, ViewChild, computed, effect, inject, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { PopupComponent } from '../../../shared/components/popup/popup.component';
import { TutorialService } from '../../../core/services/tutorial/tutorial.service';
import { ETutorialPlacement, ITutorialStep } from '../../../core/services/tutorial/tutorial.types';

/**
 * Custom action shape expected by <app-popup [customActions]>.
 * - cm - Mirrors the popup's `customActions` input signature so we can pass a strongly-typed
 *         array from the tutorial overlay without using `any`.
 */
export interface ITutorialPopupAction {
  text: string;
  icon?: string;
  class?: string;
  disabled?: boolean;
  loading?: boolean;
  onClick: () => void;
}

/**
 * Constant identifier used to mark the spotlight element appended to `document.body`.
 * Allows safe lookup / removal when the tutorial closes.
 */
const SPOTLIGHT_ID: string = 'tutorial-spotlight';

/**
 * Global stylesheet id injected into `document.head` while the tutorial is active.
 * Holds all rules that must reach the popup rendered in a CDK portal (outside the
 * component's scoped styles).
 */
const TUTORIAL_STYLE_ID: string = 'tutorial-global-styles';

/**
 * CSS source injected at runtime via <style id="tutorial-global-styles">.
 *
 * Justification:
 *  1. The popup lives in a DomPortalOutlet (popup-portal-container inside body), so
 *     ::ng-deep doesn't reach it :host -> portal.
 *  2. The default theme uses --sm-card-background: rgba(255, 255, 255, 0.85) which
 *     lets the spotlight's box-shadow bleed through : we must force an opaque white
 *     background and a clean shadow stack so the popup always reads as a solid card.
 *  3. The SellMatch palette is purple / pink (#9c27b0 / #f06292) and we drop the previous
 *     blue (#3B82F6 / #8B5CF6) which didn't match the design system.
 */
const TUTORIAL_STYLE_CSS: string = `
  /* - cm - Overlay (parent .popup-overlay): fully transparent, no blur, no click capture.
  The spotlight is the only dimming source.
  - cm - Z-index : l'overlay SCSS a z-index 10000, ce qui cree un contexte de stacking. Le
  popup-container a l'interieur ne depasse pas ce contexte, donc son z-index inline (100002)
  est en realite limite a 10000. Le spotlight (100001) se retrouve AU-DESSUS de la popup.
  On force l'overlay a z-index 100003 pour creer un contexte au-dessus du spotlight.
  On lui donne aussi position: fixed non static pour eviter les conflits. */
  .tutorial-active .popup-portal-container .popup-overlay,
  body > .popup-portal-container > .popup-overlay {
    background: transparent !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    animation: none !important;
    pointer-events: none !important;
    z-index: 100003 !important;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
  }
  /* - cm - The popup card itself : re-enable pointer events + fully opaque background so
  the spotlight box-shadow doesn't bleed through. */
  .tutorial-active .popup-portal-container .popup-container,
  body > .popup-portal-container > .popup-overlay > .popup-container {
    pointer-events: auto !important;
    background-color: #FFFFFF !important;
    background-image: none !important;
    border-radius: 20px !important;
    border: none !important;
    animation-name: none !important;
    box-shadow:
      0 32px 80px rgba(76, 29, 149, 0.35),
      0 12px 32px rgba(156, 39, 176, 0.22),
      0 0 0 1px rgba(156, 39, 176, 0.10) !important;
  }
  /* - cm - Decorative top stripe in primary -> accent gradient, rounded top corners. */
  .tutorial-active .popup-portal-container .popup-container::before,
  body > .popup-portal-container > .popup-overlay > .popup-container::before {
    background: linear-gradient(90deg, #9c27b0 0%, #f06292 100%) !important;
    height: 4px !important;
    border-radius: 20px 20px 0 0 !important;
  }
  /* - cm - Header : opaque white with subtle purple-tinted bottom border. */
  .tutorial-active .popup-portal-container .popup-container .popup-header,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-header {
    background: #FFFFFF !important;
    background-image: none !important;
    border-bottom: 1px solid rgba(156, 39, 176, 0.10) !important;
    padding: 20px 20px 14px !important;
  }
  .tutorial-active .popup-portal-container .popup-container .popup-icon,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-icon {
    background: linear-gradient(135deg, rgba(156, 39, 176, 0.18), rgba(240, 98, 146, 0.18)) !important;
    color: #9c27b0 !important;
    width: 44px !important;
    height: 44px !important;
    font-size: 22px !important;
  }
  .tutorial-active .popup-portal-container .popup-container .popup-titles .popup-title,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-titles .popup-title {
    color: #1F0935 !important;
    font-size: 18px !important;
    font-weight: 700 !important;
    line-height: 1.3 !important;
  }
  /* - cm - Subtitle (utilise comme pill de compteur d'etape). Style discret : primary
  background, petit padding, coin arrondi, on l'aligne a gauche du titre. */
  .tutorial-active .popup-portal-container .popup-container .popup-titles .popup-subtitle,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-titles .popup-subtitle {
    display: inline-block !important;
    color: #9c27b0 !important;
    background: rgba(156, 39, 176, 0.10) !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    line-height: 1 !important;
    padding: 4px 10px !important;
    border-radius: 999px !important;
    margin-top: 4px !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
    font-variant-numeric: tabular-nums !important;
  }
  /* - cm - Body : opaque white background, comfortable padding. */
  .tutorial-active .popup-portal-container .popup-container .popup-body,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-body {
    background: #FFFFFF !important;
    background-image: none !important;
    padding: 16px 20px !important;
  }
  .tutorial-active .popup-portal-container .popup-container .tutorial-overlay__desc,
  body > .popup-portal-container > .popup-overlay > .popup-container .tutorial-overlay__desc {
    color: #2D2D44 !important;
    font-size: 15px !important;
    line-height: 1.55 !important;
    margin: 0 !important;
  }
  /* - cm - Footer : pale lilac opaque background, subtle top border. */
  .tutorial-active .popup-portal-container .popup-container .popup-footer,
  body > .popup-portal-container > .popup-overlay > .popup-container .popup-footer {
    background: #FAF8FC !important;
    background-image: none !important;
    border-top: 1px solid rgba(156, 39, 176, 0.10) !important;
    padding: 14px 20px !important;
    gap: 12px !important;
  }
  .tutorial-active .popup-portal-container .popup-container .tutorial-overlay__counter,
  body > .popup-portal-container > .popup-overlay > .popup-container .tutorial-overlay__counter {
    display: inline-flex !important;
    align-items: center !important;
  }
  /* - cm - Step pill "1 / 5" in lilac. */
  .tutorial-active .popup-portal-container .popup-container .tutorial-overlay__step-pill,
  body > .popup-portal-container > .popup-overlay > .popup-container .tutorial-overlay__step-pill {
    display: inline-flex;
    align-items: center;
    padding: 4px 10px;
    border-radius: 999px;
    background: rgba(156, 39, 176, 0.10);
    color: #7B1FA2;
    font-weight: 600;
    font-size: 12px;
    letter-spacing: 0.02em;
  }
  /* - cm - Buttons (Passer / Précédent / Suivant) : on laisse app-button appliquer ses styles
  natifs (variant light/primary + outline). On n'override PAS : le user veut garder le style
  standard des boutons SellMatch. Le gradient primary est deja applique par app-button variant=primary. */
  /* - cm - Spotlight element : purple outline, dim everything else via 9999px box-shadow. */
  .tutorial-active #tutorial-spotlight,
  body > #tutorial-spotlight {
    z-index: 100001 !important;
    outline: 3px solid #9c27b0 !important;
    outline-offset: 0 !important;
    box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.55) !important;
    border-radius: 10px !important;
  }
  /* - cm - Mobile (≤ 768px) : the popup becomes a bottom sheet, full width.
  _PositionPopup handles left/top, this resets width/max-width/radius to suit the sheet. */
  @media (max-width: 768px) {
    .tutorial-active .popup-portal-container .popup-container,
    body > .popup-portal-container > .popup-overlay > .popup-container {
      width: calc(100vw - 24px) !important;
      max-width: calc(100vw - 24px) !important;
      border-radius: 18px !important;
    }
    .tutorial-active .popup-portal-container .popup-container::before,
    body > .popup-portal-container > .popup-overlay > .popup-container::before {
      border-radius: 18px 18px 0 0 !important;
    }
  }
  /* - cm - Respect prefers-reduced-motion : no animations or transitions. */
  @media (prefers-reduced-motion: reduce) {
    .tutorial-active .popup-portal-container .popup-container,
    body > #tutorial-spotlight {
      transition: none !important;
      animation: none !important;
    }
  }
`;

/**
 * Rectangular shape of a DOM element (result of `getBoundingClientRect`).
 */
interface IRect {
  /** Y coordinate of the top-left corner (viewport). */
  top: number;
  /** X coordinate of the top-left corner (viewport). */
  left: number;
  /** Width in pixels. */
  width: number;
  /** Height in pixels. */
  height: number;
}

/**
 * Computed style used to position the tooltip card.
 */
interface ITooltipStyle {
  /** Top position (px) from the top of the viewport. */
  top: number;
  /** Left position (px) from the left of the viewport. */
  left: number;
  /** Max width in pixels (useful for responsive). */
  maxWidth: number;
}

/**
 * Standalone component rendering the tutorial overlay.
 *
 * Responsibilities:
 * - Read the tutorial state from `TutorialService` (signals).
 * - Measure the position / size of the target (`ITutorialStep.Selector`) on each step or
 *   window change.
 * - Render the "spotlight" (cut-out frame over the target) and the tooltip card.
 * - Manage focus (a11y) and Escape-driven dismissal.
 *
 * The component does NOT change views itself: it triggers `OnViewChange` through the
 * service and waits ~300 ms after navigation before re-measuring.
 *
 * Performance notes:
 * - Uses `OnPush` change detection: signals drive the view, manual `markForCheck` after measure.
 * - Scroll/resize listeners are throttled via `requestAnimationFrame` (max 1 measure / frame).
 * - Scroll/resize listeners are `passive` and registered outside Angular zone for zero jank.
 * - DOM lookups (`.content-wrapper`) are cached to avoid repeated `querySelector` calls.
 * - A `MutationObserver` on the target re-measures when the DOM mutates inside it.
 * - CSS transitions on the spotlight are temporarily disabled during fast scroll/resize bursts.
 */
@Component({
  selector: 'app-tutorial-overlay',
  imports: [PopupComponent],
  templateUrl: './tutorial-overlay.component.html',
  styleUrl: './tutorial-overlay.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TutorialOverlayComponent extends BaseComponent implements OnDestroy {
  //#region Attributes
  /** Tutorial service (singleton). */
  public readonly Tutorial: TutorialService = inject(TutorialService);

  /** Change detector (OnPush). */
  private readonly _Cdr: ChangeDetectorRef = inject(ChangeDetectorRef);

  /** Zone service (used to leave the Angular zone for scroll-driven measures). */
  private readonly _Zone: NgZone = inject(NgZone);

  /** Reference to the tooltip wrapper (for a11y focus). */
  @ViewChild('tooltipEl', { static: false }) private _TooltipEl?: ElementRef<HTMLDivElement>;

  /** Reference to the "Next" / "Finish" button (for a11y focus). */
  @ViewChild('nextBtn', { static: false }) private _NextBtn?: ElementRef<HTMLButtonElement>;

  /** SSR-safe flag. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Delay after navigation before re-measuring (ms) — lets the view paint. */
  private readonly _MeasureDelayMs: number = 300;

  /** Padding around the target for the spotlight (darkens the edges slightly). */
  private readonly _SpotlightPadding: number = 4;

  /** Internal gap between the tooltip card and the target. */
  private readonly _TooltipGap: number = 12;

  /** Max width of the tooltip card. */
  private readonly _TooltipMaxWidth: number = 360;

  /** Max height of the tooltip card. */
  private readonly _TooltipMaxHeight: number = 480;

  /** Counter used to cancel successive re-measurement timers. */
  private _MeasureTimer: ReturnType<typeof setTimeout> | null = null;

  /** rAF id used to coalesce scroll/resize bursts into a single measure per frame. */
  private _RafId: number | null = null;

  /** Cached `.content-wrapper` element (resolved lazily, invalidated if detached). */
  private _ContentWrapper: HTMLElement | null = null;

  /** Cached spotlight element appended to `document.body` (created lazily on first measure). */
  private _SpotlightEl: HTMLDivElement | null = null;

  /** `MutationObserver` watching the current target for size / structure changes. */
  private _MutationObserver: MutationObserver | null = null;

  /** Currently observed target element (tracked to disconnect when it changes). */
  private _ObservedTarget: HTMLElement | null = null;

  /** Set to true while we are inside a scroll/resize burst to skip CSS transitions. */
  private _IsMeasuringFast: boolean = false;

  /** DestroyRef for automatic cleanup. */
  private readonly _DestroyRef: DestroyRef = inject(DestroyRef);

  /** Bound passive scroll handler (kept as a field for clean add/remove). */
  private readonly _OnScrollPassive: () => void;

  /** Bound passive resize handler (kept as a field for clean add/remove). */
  private readonly _OnResizePassive: () => void;
  //#endregion

  //#region Properties
  /** Current target rect (kept for backward compat with the old spotlight API; unused by the popup). */
  public readonly CurrentRect = signal<IRect | null>(null);

  /** Computed style for the tooltip card (kept for backward compat; unused by the popup). */
  public readonly CurrentTooltipStyle = signal<ITooltipStyle | null>(null);

  /** Computed: current index +1 for 1-based display. */
  public readonly DisplayIndex = computed<number>(() => this.Tutorial.CurrentStepIndex() + 1);

  /** Computed: true if the current step is the last one (button label = "Terminer"). */
  public readonly IsLast = computed<boolean>(() => this.Tutorial.IsLastStep());

  /** Computed: true if there is a previous step (enables the "Précédent" button). */
  public readonly HasPrev = computed<boolean>(() => !this.Tutorial.IsFirstStep());

  /**
   * Localized "Tip" label (renders in the tip block above).
   * - cm - 2026-08-13 : i18n via TutorialService.GetUiLabel('tipLabel').
   */
  public readonly TipLabel = computed<string>(() => this.Tutorial.GetUiLabel('tipLabel'));

  /**
   * Localized "Learn more" label (renders in the link block above).
   * - cm - 2026-08-13 : i18n via TutorialService.GetUiLabel('linkLabel').
   */
  public readonly LinkLabel = computed<string>(() => this.Tutorial.GetUiLabel('linkLabel'));

  /**
   * Custom actions bound to the generic popup: Passer / Précédent / Suivant|Terminer.
   * - cm - 2026-08-13 : button labels are now resolved via TutorialService.GetUiLabel()
   *         so they auto-translate on language change.
   */
  public readonly StepActions = computed<ITutorialPopupAction[]>(() => {
    const lIsLast: boolean = this.IsLast();
    const lHasPrev: boolean = this.HasPrev();
    const lSkip: string = this.Tutorial.GetUiLabel('skip');
    const lPrev: string = this.Tutorial.GetUiLabel('previous');
    const lNext: string = this.Tutorial.GetUiLabel('next');
    const lFinish: string = this.Tutorial.GetUiLabel('finish');
    return [
      {
        text: lSkip,
        icon: 'close',
        class: 'btn-skip',
        onClick: (): void => this.Tutorial.Skip()
      },
      {
        text: lPrev,
        icon: 'arrow_back',
        class: 'btn-prev',
        disabled: !lHasPrev,
        onClick: (): void => this.Tutorial.Prev()
      },
      {
        text: lIsLast ? lFinish : lNext,
        icon: lIsLast ? 'check' : 'arrow_forward',
        class: 'btn-next',
        onClick: (): void => this.Tutorial.Next()
      }
    ];
  });
  //#endregion

  //#region Methods
  /**
   * Handles the popup close event (X button, ESC).
   * Forwards to `Tutorial.Skip()` so the flow is marked as done and dismissed.
   */
  public OnPopupClosed(): void {
    this.Tutorial.Skip();
  }
  //#endregion

  //#region Lifecycle
  /**
   * Initialization: installs the reactive effects, cleanup, and passive scroll/resize listeners.
   */
  public constructor() {
    super();
    // - cm - Bind once so add/remove use the same reference
    this._OnScrollPassive = () => this._RequestMeasureFrame();
    this._OnResizePassive = () => this._RequestMeasureFrame();

    // - cm - On each step change, refocus the primary action button (Suivant / Terminer) in the
    // generic popup. The popup lives in a CDK portal, so we query it by class .btn-next.
    // - cm - We delay slightly to let the popup re-render with the new step content.
    effect(() => {
      const lIndex: number = this.Tutorial.CurrentStepIndex();
      const lActive: boolean = this.Tutorial.IsActive();
      if (!lActive) {
        return;
      }
      // - cm - Read the index so this effect re-runs on every step change.
      void lIndex;
      // - cm - Defer the measure so the view triggered by OnViewChange has time to render.
      // _ScheduleMeasure waits _MeasureDelayMs (300ms) before probing the DOM, which lets the
      // target element exist in the new view before we try to measure it.
      this._ScheduleMeasure();
      setTimeout(() => {
        if (!this._IsBrowser) return;
        // - cm - The popup renders the localized "Suivant" / "Terminer" button with class .btn-next
        // (customActions className). Fallback: any visible button whose text matches the localized
        // "next" or "finish" label (resolved via TutorialService.GetUiLabel, lowercased).
        const lContainer: HTMLElement | null = document.querySelector('.popup-container');
        if (!lContainer) return;
        const lNextText: string = this.Tutorial.GetUiLabel('next').trim().toLowerCase();
        const lFinishText: string = this.Tutorial.GetUiLabel('finish').trim().toLowerCase();
        const lNext: HTMLButtonElement | null =
          lContainer.querySelector<HTMLButtonElement>('.btn-next')
          ?? Array.from(lContainer.querySelectorAll<HTMLButtonElement>('button')).find(
            (pBtn: HTMLButtonElement): boolean => {
              const lText: string = pBtn.textContent?.trim().toLowerCase() ?? '';
              return lText.startsWith(lNextText) || lText.startsWith(lFinishText);
            }
          )
          ?? null;
        if (lNext) {
          lNext.focus({ preventScroll: true });
        }
      }, 50);
    });

    // - cm - Reset legacy signals AND clean up the spotlight when the tutorial closes.
    // The popup is repositioned by us, so we also need to remove the DOM element we injected
    // (the spotlight frame) and detach the MutationObserver. We also remove the
    // `tutorial-active` body class and the global <style id="tutorial-global-styles">
    // so the rest of the page goes back to normal.
    effect(() => {
      const lActive: boolean = this.Tutorial.IsActive();
      if (!lActive) {
        this.CurrentRect.set(null);
        this.CurrentTooltipStyle.set(null);
        this._DisconnectMutationObserver();
        this._RemoveSpotlight();
        this._RemoveGlobalStyles();
        if (this._IsBrowser && document.body) {
          document.body.classList.remove('tutorial-active');
        }
      } else {
        // - cm - Inject styles FIRST so the popup (rendered right after) picks them up,
        // including the opaque-white override that finally kills the spotlight bleed.
        this._InjectGlobalStyles();
        if (this._IsBrowser && document.body) {
          document.body.classList.add('tutorial-active');
        }
      }
    });

    // - cm - Passive scroll/resize listeners outside Angular zone for zero jank during scroll.
    // We use addEventListener manually because @HostListener cannot mark the listener as passive
    // and runs inside the zone, which would force change detection on every scroll tick.
    if (this._IsBrowser) {
      this._Zone.runOutsideAngular(() => {
        window.addEventListener('scroll', this._OnScrollPassive, { passive: true });
        window.addEventListener('resize', this._OnResizePassive, { passive: true });
      });
    }

    // - cm - Cleanup timers, observers, listeners and DOM injections on destroy
    this._DestroyRef.onDestroy(() => {
      if (this._MeasureTimer !== null) {
        clearTimeout(this._MeasureTimer);
        this._MeasureTimer = null;
      }
      if (this._RafId !== null) {
        cancelAnimationFrame(this._RafId);
        this._RafId = null;
      }
      this._DisconnectMutationObserver();
      this._RemoveSpotlight();
      if (this._IsBrowser) {
        window.removeEventListener('scroll', this._OnScrollPassive);
        window.removeEventListener('resize', this._OnResizePassive);
      }
    });
  }

  /**
   * Manual cleanup hook (kept explicit in addition to DestroyRef for IDE/reader clarity).
   */
  public ngOnDestroy(): void {
    // - cm - All teardown is already wired via DestroyRef in the constructor
  }
  //#endregion

  //#region Event Handlers
  /**
   * Closes the tutorial via the Escape key (a11y).
   * Bound at the document level by the host element via `document:keydown.escape`.
   * @param pEvent The keyboard event.
   */
  public OnEscape(pEvent: Event): void {
    // - cm - Cast Event -> KeyboardEvent (the host listener `keydown.escape` guarantees the type at runtime)
    const lKbEvent: KeyboardEvent = pEvent as KeyboardEvent;
    if (this.Tutorial.IsActive()) {
      // - cm - We do NOT stop propagation here: the user may have other popups
      // listening to Escape as well. The main popup component manages its own priority.
      this.Tutorial.Skip();
    }
  }

  /**
   * Click on the darkened backdrop: the tutorial is NOT closed (this is
   * explicitly wanted). We just stop the click from propagating.
   * @param pEvent The click event.
   */
  public OnOverlayClick(pEvent: MouseEvent): void {
    pEvent.stopPropagation();
    // - cm - No accidental closure: only Skip / Close / Finish exits the tutorial
  }

  /**
   * PostHog tracking for the FAB launcher click.
   */
  public OnLauncherClick(): void {
    this.PostHog.Capture('tutorial_launcher_clicked');
  }
  //#endregion

  //#region Helpers
  /**
   * Schedules a measurement after a short delay (lets the DOM paint after a
   * step / view change). Cancels any previous pending timer.
   */
  private _ScheduleMeasure(): void {
    if (!this._IsBrowser) return; // - cm - SSR: no-op
    if (this._MeasureTimer !== null) {
      clearTimeout(this._MeasureTimer);
    }
    this._MeasureTimer = setTimeout(() => {
      this._MeasureTimer = null;
      this._Measure();
      // - cm - Focus on the "Next" button for keyboard accessibility
      queueMicrotask(() => this._NextBtn?.nativeElement.focus());
    }, this._MeasureDelayMs);
  }

  /**
   * Coalesces scroll/resize bursts into a single `requestAnimationFrame` callback.
   * Avoids spamming `_Measure()` on every pixel of a fast scroll or window drag.
   * Runs outside Angular zone, so we manually `markForCheck` once the measure is done.
   */
  private _RequestMeasureFrame(): void {
    if (!this._IsBrowser) return;
    if (!this.Tutorial.IsActive()) return;
    if (this._RafId !== null) return; // - cm - Already scheduled for the next frame
    this._IsMeasuringFast = true;
    this._RafId = requestAnimationFrame(() => {
      this._RafId = null;
      this._Measure();
      // - cm - Re-enable transitions after the current scroll/resize burst ends
      requestAnimationFrame(() => {
        this._IsMeasuringFast = false;
      });
    });
  }

  /**
   * Measures the target position and computes the tooltip card style.
   * If no selector (or element not found), the spotlight covers the full viewport.
   */
  private _Measure(): void {
    if (!this._IsBrowser) return; // - cm - SSR: no-op

    const lStep: ITutorialStep | null = this.Tutorial.CurrentStep();
    if (!lStep) return;

    const lRect: IRect | null = this._ResolveTargetRect(lStep);
    this.CurrentRect.set(lRect);

    const lStyle: ITooltipStyle = this._ComputeTooltipStyle(lRect, lStep);
    this.CurrentTooltipStyle.set(lStyle);

    // - cm - (Re)attach the MutationObserver to the target so we react to size / DOM changes
    this._AttachMutationObserver(lStep);

    // - cm - Repositionne la popup et le spotlight dans le meme frame pour rester synchro.
    // On ne repositionne PAS la popup si l'utilisateur l'a draggee / redimensionnee
    // manuellement (on detecte via les classes CSS .dragging / .resizing du popup).
    this._PositionPopup(lRect, lStep);
    this._UpdateSpotlight(lRect, lStep);

    // - cm - OnPush: signal writes trigger the view, markForCheck keeps CD deterministic
    this._Cdr.markForCheck();
  }

  /**
   * Resolves the target rectangle:
   * - If the selector is valid and the element is in the DOM, use its rect (+ padding).
   * - Otherwise, fall back to the `content-wrapper` (main app content area), otherwise the viewport.
   * @param pStep The current step.
   * @returns The rectangle, or null if there is nothing to measure.
   */
  private _ResolveTargetRect(pStep: ITutorialStep): IRect | null {
    // - cm - Mode center (pas de selector explicite) : on essaie de spotlighter le contenu
    // principal de la page (main / content-wrapper). Si trouve, on spotlight CE contenu
    // (le user voit clairement QUOI regarder). Sinon, fallback sur le viewport plein
    // (cas playground scrollable ou page publique sans layout dashboard).
    if (!pStep.Selector || pStep.Placement === 'center') {
      const lMainRect: IRect | null = this._ResolveMainContentRect();
      if (lMainRect !== null) {
        return lMainRect;
      }
      return null;
    }

    if (pStep.Selector) {
      const lEl: HTMLElement | null = document.querySelector(pStep.Selector);
      if (lEl) {
        const lRaw: DOMRect = lEl.getBoundingClientRect();
        return {
          top: lRaw.top - this._SpotlightPadding,
          left: lRaw.left - this._SpotlightPadding,
          width: lRaw.width + (this._SpotlightPadding * 2),
          height: lRaw.height + (this._SpotlightPadding * 2)
        };
      }
    }

    // - cm - Selector fourni mais element introuvable : fallback sur le contenu principal
    // (qui sert aussi d'indicateur visuel sur dashboards), sinon viewport plein.
    const lMainRect: IRect | null = this._ResolveMainContentRect();
    if (lMainRect !== null) {
      return lMainRect;
    }
    return {
      top: 0,
      left: 0,
      width: window.innerWidth,
      height: window.innerHeight
    };
  }

  /**
   * Tries to locate the main content area of the current page (used in dashboards
   * and CRM layout). The selectors are tried in order; the first visible match wins.
   * Returns null when no candidate is large enough to be the main content (e.g.
   * playground scrollable area, public pages).
   */
  private _ResolveMainContentRect(): IRect | null {
    if (!this._IsBrowser) return null;
    const lSelectors: string[] = [
      'main.main-content',       // CRM, Pro, Vendeur dashboards
      '.content-wrapper',        // DashboardLayout wrapper
      'main[role="main"]',       // Generic ARIA main
      '.tutorial-main-content'   // Custom hook
    ];
    for (const pSel of lSelectors) {
      const lEl: HTMLElement | null = document.querySelector<HTMLElement>(pSel);
      if (!lEl) continue;
      const lRect: DOMRect = lEl.getBoundingClientRect();
      // - cm - Ignore les candidats trop petits (sous 200x150) ou hors viewport
      if (lRect.width < 200 || lRect.height < 150) continue;
      if (lRect.bottom < 0 || lRect.right < 0) continue;
      // - cm - Si l'element est partiellement hors viewport, le spotlight suit getBoundingClientRect
      // (coordonnees viewport). Le box-shadow 9999px du spotlight assombrit correctement le reste.
      return {
        top: lRect.top - this._SpotlightPadding,
        left: lRect.left - this._SpotlightPadding,
        width: lRect.width + (this._SpotlightPadding * 2),
        height: lRect.height + (this._SpotlightPadding * 2)
      };
    }
    return null;
  }

  /**
   * Attaches a `MutationObserver` to the current target so the spotlight auto-recalibrates
   * when the target's size, children, or attributes change (lazy content, animations, etc.).
   * Disconnects any previously attached observer first.
   * @param pStep The current step.
   */
  private _AttachMutationObserver(pStep: ITutorialStep): void {
    if (!this._IsBrowser || typeof MutationObserver === 'undefined') return;

    const lEl: HTMLElement | null = pStep.Selector ? document.querySelector(pStep.Selector) : null;
    if (lEl !== null && lEl === this._ObservedTarget) return; // - cm - Already observing the right node

    this._DisconnectMutationObserver();
    if (lEl === null) return;

    this._ObservedTarget = lEl;
    this._MutationObserver = new MutationObserver(() => this._RequestMeasureFrame());
    // - cm - Observe only what matters for layout: child list + style/class/subtree attributes
    this._MutationObserver.observe(lEl, {
      childList: true,
      attributes: true,
      subtree: true,
      attributeFilter: ['style', 'class', 'hidden', 'open']
    });
  }

  /**
   * Disconnects and clears the current `MutationObserver`.
   */
  private _DisconnectMutationObserver(): void {
    if (this._MutationObserver !== null) {
      this._MutationObserver.disconnect();
      this._MutationObserver = null;
    }
    this._ObservedTarget = null;
  }

  /**
   * Computes the optimal position of the tooltip card based on the target rect
   * and the requested placement, with auto-flip if it would overflow.
   * @param pRect Target rectangle (viewport coords).
   * @param pStep The current step (for Placement).
   * @returns The computed style for the tooltip.
   */
  private _ComputeTooltipStyle(pRect: IRect | null, pStep: ITutorialStep): ITooltipStyle {
    const lPlacement: ETutorialPlacement = pStep.Placement ?? 'bottom';

    // - cm - On mobile (or placement=center), pin to bottom full-width
    const lIsMobile: boolean = this._IsMobile();
    if (lIsMobile || lPlacement === 'center') {
      return {
        top: window.innerHeight - this._TooltipMaxHeight - 16,
        left: 16,
        maxWidth: window.innerWidth - 32
      };
    }

    if (!pRect) {
      // - cm - No target: center vertically / horizontally
      return {
        top: Math.max(16, (window.innerHeight - this._TooltipMaxHeight) / 2),
        left: Math.max(16, (window.innerWidth - this._TooltipMaxWidth) / 2),
        maxWidth: this._TooltipMaxWidth
      };
    }

    const lGap: number = this._TooltipGap;
    const lW: number = this._TooltipMaxWidth;

    // - cm - Try the requested placement; if it overflows, flip to the opposite side
    let lTop: number = pRect.top + pRect.height + lGap;
    let lLeft: number = pRect.left;

    if (lPlacement === 'top') {
      lTop = pRect.top - this._TooltipMaxHeight - lGap;
      lLeft = pRect.left;
    } else if (lPlacement === 'left') {
      lTop = pRect.top;
      lLeft = pRect.left - lW - lGap;
    } else if (lPlacement === 'right') {
      lTop = pRect.top;
      lLeft = pRect.left + pRect.width + lGap;
    }

    // - cm - Auto-flip horizontally if overflows to the right
    if (lLeft + lW > window.innerWidth - 16) {
      lLeft = Math.max(16, window.innerWidth - lW - 16);
    }
    // - cm - Auto-flip horizontally if overflows to the left
    if (lLeft < 16) {
      lLeft = 16;
    }
    // - cm - Auto-flip vertically if overflows at the bottom
    if (lTop + this._TooltipMaxHeight > window.innerHeight - 16) {
      lTop = Math.max(16, window.innerHeight - this._TooltipMaxHeight - 16);
    }
    // - cm - Auto-flip vertically if overflows at the top
    if (lTop < 16) {
      lTop = 16;
    }

    return {
      top: lTop,
      left: lLeft,
      maxWidth: lW
    };
  }

  /**
   * Detects whether the current viewport is mobile (uses the same breakpoint as the SCSS).
   * @returns true if the viewport width <= $mobile-breakpoint.
   */
  private _IsMobile(): boolean {
    if (!this._IsBrowser) return false;
    return window.innerWidth <= 768; // - cm - Aligned with $mobile-breakpoint
  }

  /**
   * Public getter for the template. While `true`, the CSS skips transitions on the
   * spotlight so a fast scroll does not trigger expensive repaints.
   * @returns true if a scroll/resize burst is currently being measured.
   */
  public get IsMeasuringFast(): boolean {
    return this._IsMeasuringFast;
  }

  /**
   * Positions the generic popup container next to the target rect according to
   * `step.Placement`. The popup lives in a DomPortalOutlet outside the Angular component
   * scope, so we mutate its inline `left` / `top` directly.
   *
   * - `top` / `bottom` / `left` / `right`: popup appears on the requested side of the
   *   target, with auto-flip if it would overflow the viewport.
   * - `center` or no selector: popup is centered in the viewport (desktop) or pinned
   *   at the bottom (mobile, bottom sheet).
   *
   * @param pRect The measured target rect (viewport coords, including spotlight padding).
   * @param pStep The current tutorial step.
   */
  private _PositionPopup(pRect: IRect | null, pStep: ITutorialStep): void {
    if (!this._IsBrowser) return;

    const lContainer: HTMLElement | null = document.querySelector<HTMLElement>('.popup-container');
    if (!lContainer) return; // - cm - Popup pas encore rendue (premier tick)

    // - cm - Recupere la taille reelle de la popup pour les calculs de placement.
    const lPopupRect: DOMRect = lContainer.getBoundingClientRect();
    const lPopupWidth: number = lPopupRect.width || 420;
    const lPopupHeight: number = lPopupRect.height || 280;

    const lPlacement: ETutorialPlacement = pStep.Placement ?? 'bottom';
    const lGap: number = this._TooltipGap;
    const lPadding: number = 20;
    const lIsMobile: boolean = this._IsMobile();

    let lTop: number;
    let lLeft: number;

    // - cm - Mode mobile : la popup est ancree en bas (bottom sheet), pleine largeur.
    // On garde uniquement un padding sur les cotes.
    if (lIsMobile) {
      lTop = Math.max(lPadding, window.innerHeight - lPopupHeight - 12);
      lLeft = 12;
      lContainer.style.position = 'fixed';
      lContainer.style.transform = 'none';
      lContainer.style.margin = '0';
      lContainer.style.zIndex = '100002';
      lContainer.style.maxWidth = 'none';
      lContainer.style.width = `${window.innerWidth - 24}px`;
      lContainer.style.left = `${lLeft}px`;
      lContainer.style.top = `${lTop}px`;
      return;
    }

    if (lPlacement === 'center' || !pRect) {
      // - cm - Mode centre (pas de selector ou placement=center) : on centre la popup.
      lTop = Math.max(lPadding, (window.innerHeight - lPopupHeight) / 2);
      lLeft = Math.max(lPadding, (window.innerWidth - lPopupWidth) / 2);
    } else {
      // - cm - Position de base selon le placement demande.
      const lTargetRight: number = pRect.left + pRect.width;
      switch (lPlacement) {
        case 'top':
          lTop = pRect.top - lPopupHeight - lGap;
          lLeft = pRect.left + (pRect.width - lPopupWidth) / 2;
          break;
        case 'left':
          lTop = pRect.top + (pRect.height - lPopupHeight) / 2;
          lLeft = pRect.left - lPopupWidth - lGap;
          break;
        case 'right':
          lTop = pRect.top + (pRect.height - lPopupHeight) / 2;
          lLeft = lTargetRight + lGap;
          break;
        case 'bottom':
        default:
          lTop = pRect.top + pRect.height + lGap;
          lLeft = pRect.left + (pRect.width - lPopupWidth) / 2;
          break;
      }

      // - cm - Auto-flip horizontal : on tente le cote oppose en priorite avant de clamper.
      if (lLeft + lPopupWidth > window.innerWidth - lPadding) {
        if (lPlacement === 'right') {
          const lFlippedLeft: number = pRect.left - lPopupWidth - lGap;
          if (lFlippedLeft >= lPadding) {
            lLeft = lFlippedLeft;
          } else {
            lLeft = Math.max(lPadding, window.innerWidth - lPopupWidth - lPadding);
          }
        } else if (lPlacement === 'left') {
          const lFlippedLeft: number = lTargetRight + lGap;
          if (lFlippedLeft + lPopupWidth <= window.innerWidth - lPadding) {
            lLeft = lFlippedLeft;
          } else {
            lLeft = Math.max(lPadding, window.innerWidth - lPopupWidth - lPadding);
          }
        } else if (lPlacement === 'bottom' || lPlacement === 'top') {
          const lAltLeft: number = lTargetRight + lGap;
          const lAltLeftMirror: number = pRect.left - lPopupWidth - lGap;
          if (lAltLeft + lPopupWidth <= window.innerWidth - lPadding) {
            lLeft = lAltLeft;
          } else if (lAltLeftMirror >= lPadding) {
            lLeft = lAltLeftMirror;
            lTop = pRect.top + (pRect.height - lPopupHeight) / 2;
          } else {
            lLeft = Math.max(lPadding, window.innerWidth - lPopupWidth - lPadding);
          }
        } else {
          lLeft = Math.max(lPadding, window.innerWidth - lPopupWidth - lPadding);
        }
      }
      if (lLeft < lPadding) {
        lLeft = lPadding;
      }

      // - cm - Auto-flip vertical : pour rester au plus proche de l'element, on aligne le
      // bottom de la popup avec le bottom de l'element (pour left/right) au lieu de clamper
      // en bas du viewport (ce qui eloignerait visuellement la popup de l'element cible).
      if (lTop + lPopupHeight > window.innerHeight - lPadding) {
        if (lPlacement === 'bottom') {
          lTop = pRect.top - lPopupHeight - lGap;
        } else if (lPlacement === 'top') {
          lTop = pRect.top + pRect.height + lGap;
        } else {
          const lAltTop: number = pRect.top + pRect.height - lPopupHeight;
          if (lAltTop >= lPadding) {
            lTop = lAltTop;
          } else {
            lTop = Math.max(lPadding, window.innerHeight - lPopupHeight - lPadding);
          }
        }
      }
      if (lTop < lPadding) {
        if (lPlacement === 'top') {
          lTop = pRect.top + pRect.height + lGap;
        } else {
          lTop = lPadding;
        }
      }
      // - cm - Re-clamp final pour garantir la visibilite.
      lTop = Math.max(lPadding, lTop);
      lLeft = Math.max(lPadding, lLeft);
    }

    // - cm - Annule le centrage flex du parent overlay et force la position fixed.
    // Les styles SCSS du popup-container (max-width 420px) ne s'appliquent pas dans le
    // portal CDK, donc on les force en inline ici pour fiabiliser le rendu.
    lContainer.style.position = 'fixed';
    lContainer.style.transform = 'none';
    lContainer.style.margin = '0';
    lContainer.style.zIndex = '100002';
    lContainer.style.maxWidth = '440px';
    lContainer.style.width = 'min(440px, calc(100vw - 32px))';
    lContainer.style.left = `${lLeft}px`;
    lContainer.style.top = `${lTop}px`;
  }

  /**
   * Updates or creates the spotlight element (a fixed-position div appended to
   * `document.body`) that visually highlights the target. Uses a giant `box-shadow`
   * around a 2px primary outline to dim the rest of the page.
   * @param pRect The measured target rect (viewport coords, including spotlight padding).
   * @param pStep The current step (used to decide the full-viewport fallback).
   */
  private _UpdateSpotlight(pRect: IRect | null, pStep: ITutorialStep): void {
    if (!this._IsBrowser) return;
    const lEl: HTMLDivElement | null = this._EnsureSpotlight();
    if (!lEl) return;

    // - cm - Si pas de rect du tout : on couvre tout le viewport avec un fond opaque sombre
    // (mode center classique sans contenu principal detecte). Si on A un rect (cas center avec
    // main-content detecte), on tombe dans le mode spotlight cible ci-dessous pour mettre
    // en valeur le contenu principal de la page.
    if (!pRect) {
      lEl.style.top = '0';
      lEl.style.left = '0';
      lEl.style.width = `${window.innerWidth}px`;
      lEl.style.height = `${window.innerHeight}px`;
      lEl.style.background = 'rgba(15, 23, 42, 0.55)';
      lEl.style.outline = 'none';
      lEl.style.outlineOffset = '0';
      lEl.style.borderRadius = '0';
      lEl.style.boxShadow = 'none';
      lEl.classList.toggle('is-measuring-fast', this._IsMeasuringFast);
      return;
    }

    // - cm - Mode spotlight cible : cadre primary + assombrissement tout autour.
    // L'outline / box-shadow / z-index sont fixes dans _EnsureSpotlight, on ne les redefinit
    // pas ici pour eviter une race avec le CSS global (id #tutorial-global-styles).
    lEl.style.top = `${pRect.top}px`;
    lEl.style.left = `${pRect.left}px`;
    lEl.style.width = `${pRect.width}px`;
    lEl.style.height = `${pRect.height}px`;
    lEl.style.background = 'transparent';
    lEl.style.borderRadius = '10px';
    lEl.classList.toggle('is-measuring-fast', this._IsMeasuringFast);
  }

  /**
   * Creates the spotlight element lazily and caches it. Returns null on SSR.
   * @returns The cached spotlight div, or null if not in a browser context.
   */
  private _EnsureSpotlight(): HTMLDivElement | null {
    if (!this._IsBrowser) return null;
    if (this._SpotlightEl && this._SpotlightEl.isConnected) {
      return this._SpotlightEl;
    }
    // - cm - On reutilise un eventuel element existant (evite les doublons apres HMR)
    const lExisting: HTMLElement | null = document.getElementById(SPOTLIGHT_ID);
    if (lExisting instanceof HTMLDivElement) {
      this._SpotlightEl = lExisting;
      return lExisting;
    }
    const lEl: HTMLDivElement = document.createElement('div');
    lEl.id = SPOTLIGHT_ID;
    lEl.className = 'tutorial-spotlight';
    lEl.setAttribute('aria-hidden', 'true');
    // - cm - Styles critiques en inline : le spotlight est injecte dans document.body (hors du
    // scope Angular du composant tuto), donc le SCSS du composant ne s'y applique pas. On force
    // position fixed (coords viewport), pointer-events none (laisse passer les clics) et z-index
    // eleve (au-dessus du popup-overlay a 10000) pour rester visible par-dessus l'overlay.
    lEl.style.position = 'fixed';
    lEl.style.pointerEvents = 'none';
    lEl.style.zIndex = '100001';
    lEl.style.borderRadius = '8px';
    // - cm - Cadre primary plus epais (3px) + box-shadow assombrissant le reste de la page.
    // Le popup-overlay du popup generique est rendu transparent (overlayOpacity=0) pour eviter
    // le double assombrissement : seul le spotlight gere le voile. La couleur primary du
    // projet est purple #9c27b0 (coherent avec le design system SellMatch, pas du bleu).
    lEl.style.outline = '3px solid #9c27b0';
    lEl.style.outlineOffset = '0';
    lEl.style.boxShadow = '0 0 0 9999px rgba(15, 23, 42, 0.55)';
    lEl.style.transition = 'top 180ms ease-out, left 180ms ease-out, width 180ms ease-out, height 180ms ease-out';
    document.body.appendChild(lEl);
    this._SpotlightEl = lEl;
    return lEl;
  }

  /**
   * Removes the spotlight element from the DOM and clears the cached reference.
   * Safe to call multiple times.
   */
  private _RemoveSpotlight(): void {
    if (!this._IsBrowser) return; // - cm - SSR: no-op (evite ReferenceError: document is not defined)
    if (this._SpotlightEl && this._SpotlightEl.parentElement) {
      this._SpotlightEl.parentElement.removeChild(this._SpotlightEl);
    }
    this._SpotlightEl = null;
  }

  /**
   * Injects the global tutorial stylesheet (id #tutorial-global-styles) into <head>.
   * Holds every rule that must reach the popup rendered in a CDK portal. Idempotent
   * : updates the existing <style> if it's already there.
   */
  private _InjectGlobalStyles(): void {
    if (!this._IsBrowser) return;
    let lStyle: HTMLStyleElement | null = document.getElementById(TUTORIAL_STYLE_ID) as HTMLStyleElement | null;
    if (!lStyle) {
      lStyle = document.createElement('style');
      lStyle.id = TUTORIAL_STYLE_ID;
      document.head.appendChild(lStyle);
    }
    lStyle.textContent = TUTORIAL_STYLE_CSS;
  }

  /**
   * Removes the global tutorial stylesheet from <head>. Safe to call multiple times.
   */
  private _RemoveGlobalStyles(): void {
    if (!this._IsBrowser) return;
    const lStyle: HTMLElement | null = document.getElementById(TUTORIAL_STYLE_ID);
    if (lStyle && lStyle.parentElement) {
      lStyle.parentElement.removeChild(lStyle);
    }
  }
  //#endregion
}
