import { Component, Input, OnInit, OnDestroy, Output, EventEmitter, inject, ChangeDetectionStrategy, signal, effect, ElementRef, viewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { BaseComponent } from '../../../core/base/BaseComponent';
import { UserSubscriptionsService } from '../../../core/sellmatchdb/services/user-subscriptions/user-subscriptions.service';
import { SubscriptionPlansService } from '../../../core/sellmatchdb/services/subscription-plans/subscription-plans.service';
import { OpportunitiesDTO, SubscriptionPlansDTO } from '../../../core/sellmatchdb/dto';
import { environment } from '../../../environments/environment';

interface IEmbeddedCheckoutInit { clientSecret: string; }

/**
 * Composant de paiement Stripe Embedded Checkout pour le flow ÉcoMandat.
 * Branche directement sur SubscriptionController (moderne) via UserSubscriptionsService.
 * Crée la souscription one-shot (ÉcoMandat) en BDD, monte le checkout Stripe
 * et émet l'événement de succès/erreur au parent.
 *
 * Le parent doit fournir `opportunity` (données du bien à lier au mandat).
 * Le `planKey` par défaut est "ecomandat" (paiement unique 4,99€).
 */
@Component({
  selector: 'app-stripe',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stripe.component.html',
  styleUrls: ['./stripe.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StripeComponent extends BaseComponent implements OnInit, OnDestroy
{
  //#region Attributes

  /** Clé du plan SellMatch (par défaut "ecomandat"). */
  @Input() planKey: string = 'ecomandat';

  /** Période de facturation (monthly, yearly, one_shot). Auto-détectée pour ÉcoMandat. */
  @Input() billingPeriod: 'monthly' | 'yearly' | 'one_shot' = 'one_shot';

  /** Devise. */
  @Input() currency: string = 'eur';

  /** Description affichée côté Stripe (cosmétique). */
  @Input() description: string = '';

  /** Données de l'opportunité (dossier) à lier au paiement. */
  @Input() opp: OpportunitiesDTO = {};

  /** Clé publique Stripe (override possible). */
  @Input() publishableKey: string = environment.publishableKey;

  //#endregion

  //#region Outputs

  /** Émis après confirmation du paiement par Stripe. */
  @Output() paymentSuccess = new EventEmitter<{ sessionId: string; opportunity: OpportunitiesDTO; planKey: string; }>();

  /** Émis en cas d'erreur lors du paiement. */
  @Output() paymentError = new EventEmitter<any>();

  //#endregion

  //#region Signals

  /** Indique si l'initialisation est en cours. */
  public readonly Loading = signal(false);

  /** Message d'erreur à afficher. */
  public readonly ErrorMessage = signal<string | null>(null);

  /** Plan actuellement chargé. */
  public readonly Plan = signal<SubscriptionPlansDTO | null>(null);

  //#endregion

  //#region Internal

  private readonly _Subscriptions = inject(UserSubscriptionsService);
  private readonly _Plans = inject(SubscriptionPlansService);
  private readonly _Router = inject(Router);

  /** Référence au conteneur DOM du checkout Stripe. */
  private readonly _CheckoutElementRef = viewChild<ElementRef<HTMLDivElement>>('checkoutElement');

  /** Instance Stripe.js singleton. */
  private _Stripe: any | null = null;

  /** Promise de chargement de Stripe.js (singleton). */
  private _StripeScriptPromise: Promise<void> | null = null;

  /** Instance EmbedCheckout courante. */
  private _EmbeddedCheckout: any | null = null;

  //#endregion

  //#region CTOR

  public constructor()
  {
    super();

    // - cm - Effect : réagit aux changements de Plan (chargé en ngOnInit)
    // pour initialiser le checkout Embedded. Token d'obsolescence pour gérer
    // les changements rapides (rare en pratique, mais safe).
    let lLatestToken = 0;

    effect(() =>
    {
      const lPlan = this.Plan();
      if (!lPlan) return;

      lLatestToken++;
      const lMyToken = lLatestToken;

      void (async () =>
      {
        await this.DisposeEmbeddedCheckout();
        if (lMyToken !== lLatestToken) return;

        const lContainer = this._CheckoutElementRef()?.nativeElement;
        if (!lContainer) return;

        await this.InitCheckout(lPlan, lContainer);

        if (lMyToken !== lLatestToken)
        {
          await this.DisposeEmbeddedCheckout();
        }
      })();
    });
  }

  //#endregion

  //#region Lifecycle

  public async ngOnInit(): Promise<void>
  {
    await this.LoadPlan();
  }

  public ngOnDestroy(): void
  {
    void this.DisposeEmbeddedCheckout();
  }

  //#endregion

  //#region Methods

  /**
   * Charge le plan depuis la BDD (par planKey).
   */
  private async LoadPlan(): Promise<void>
  {
    this.Loading.set(true);
    this.ErrorMessage.set(null);

    try
    {
      const lPlans = await this._Plans.getAll({ isActive: true });
      const lPlan = lPlans.find(p => p.key === this.planKey);

      if (!lPlan)
      {
        throw new Error(`Plan "${this.planKey}" introuvable.`);
      }

      this.Plan.set(lPlan);
    }
    catch (pError: any)
    {
      this.ErrorMessage.set(pError?.message ?? 'Erreur de chargement du plan.');
      this.PostHog.Capture(this.BuildTrackingName('ecomandat_plan_load_error', 'tracking'), { planKey: this.planKey, error: this.ErrorMessage() });
    }
    finally
    {
      this.Loading.set(false);
    }
  }

  /**
   * Crée la souscription en BDD et initialise le checkout Stripe Embedded.
   * @param pPlan Le plan à souscrire.
   * @param pContainer Conteneur DOM hôte.
   */
  private async InitCheckout(pPlan: SubscriptionPlansDTO, pContainer: HTMLElement): Promise<void>
  {
    try
    {
      const lUserId = parseInt(this.CurrentUserId ?? '0', 10);
      if (!lUserId)
      {
        throw new Error('Utilisateur non authentifié.');
      }

      // - cm - ÉcoMandat = one_shot, sinon utilise billingPeriod fourni par le parent.
      const lPeriod: 'monthly' | 'yearly' | 'one_shot' = pPlan.isOneShot ? 'one_shot' : this.billingPeriod;

      // - cm - SubscriptionController (moderne) : crée la souscription BDD + la session Stripe Embedded.
      const lCreated = await this._Subscriptions.create({
        userId: lUserId,
        planId: pPlan.id,
        billingPeriod: lPeriod,
      });

      if (!lCreated?.stripeSubscriptionId)
      {
        throw new Error('Réponse invalide du serveur (clientSecret manquant).');
      }

      const lClientSecret = lCreated.stripeSubscriptionId;
      const lSessionId = lCreated.stripeCustomerId ?? null;

      // - cm - Stocker le sessionId pour l'émettre au succès.
      this._SessionId = lSessionId;

      // - cm - Charger Stripe.js si pas déjà fait.
      if (!this._Stripe)
      {
        await this.LoadStripeScript();
        this._Stripe = (window as any).Stripe(this.publishableKey);
      }
      const lStripe = this._Stripe;

      const lCheckout = await lStripe.initEmbeddedCheckout({ clientSecret: lClientSecret });
      lCheckout.mount(pContainer);
      this._EmbeddedCheckout = lCheckout;

      this.PostHog.Capture(this.BuildTrackingName('ecomandat_checkout_mount', 'tracking'), { planKey: pPlan.key });
    }
    catch (pError: any)
    {
      const lMessage = pError?.message ?? 'Erreur lors de l\'initialisation du paiement.';
      this.ErrorMessage.set(lMessage);
      console.error('Stripe embedded init error:', pError);
      this.PostHog.Capture(this.BuildTrackingName('ecomandat_checkout_error', 'tracking'), { planKey: pPlan.key, error: lMessage });
      this.paymentError.emit(pError);
    }
  }

  private _SessionId: string | null = null;

  /**
   * Libère l'instance Stripe Embedded Checkout courante.
   */
  private async DisposeEmbeddedCheckout(): Promise<void>
  {
    if (this._EmbeddedCheckout)
    {
      try
      {
        await this._EmbeddedCheckout.unmount();
      }
      catch (pError: any)
      {
        console.warn('Stripe Embedded unmount warn:', pError);
      }
      this._EmbeddedCheckout = null;
    }
  }

  /**
   * Charge le script Stripe.js (singleton).
   */
  private LoadStripeScript(): Promise<void>
  {
    if (this._StripeScriptPromise)
    {
      return this._StripeScriptPromise;
    }

    this._StripeScriptPromise = new Promise((pResolve, pReject) =>
    {
      if ((window as any).Stripe)
      {
        pResolve();
        return;
      }

      const lScript = document.createElement('script');
      lScript.src = 'https://js.stripe.com/v3/';
      lScript.async = true;
      lScript.onload = () => pResolve();
      lScript.onerror = () =>
      {
        this._StripeScriptPromise = null;
        pReject(new Error('Impossible de charger Stripe.js'));
      };
      document.body.appendChild(lScript);
    });

    return this._StripeScriptPromise;
  }

  /**
   * Émet le succès du paiement. À appeler depuis le parent après confirmation.
   */
  public OnPaymentSuccess(): void
  {
    this.PostHog.Capture(this.BuildTrackingName('ecomandat_payment_success', 'tracking'), {
      planKey: this.Plan()?.key,
      sessionId: this._SessionId,
    });
    this.paymentSuccess.emit({
      sessionId: this._SessionId ?? '',
      opportunity: this.opp,
      planKey: this.Plan()?.key ?? '',
    });
  }

  //#endregion
}
