
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ChangeDetectionStrategy, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { InputComponent } from '../input/input.component';
import { ButtonComponent } from '../button/button.component';
import { SectionCardComponent } from '../../../shared/components/section-card/section-card.component';
import { BaseCritereDTO } from '../../../core/base/base.critere';
import { AdressesDTO } from '../../../core/sellmatchdb/dto';
import { AdressesService } from '../../../core/sellmatchdb/services/adresses/adresses.service';
import { TranslateKeyPipe } from '../../../core/services/i18n/TranslateKeyPipe';

export type FilterFieldType = 'text' | 'number' | 'select' | 'multi-select' | 'date' | 'checkbox' | 'address';

export interface FilterOption
{
  Label: string;
  Value: string | number | boolean;
}

export interface FilterFieldConfig
{
  Key: string;
  Label?: string;
  /**
   * Clé i18n du libellé. Si fournie, le filter-bar la traduit via le pipe `tkey`
   * en priorité sur `Label`. Permet d'éviter les 17 signaux `ColXxx` dans chaque
   * grille (cf. pattern recrutement-grid refactorisé).
   */
  LabelCle?: string;
  Type: FilterFieldType;
  Placeholder?: string;
  /**
   * Clé i18n du placeholder. Voir `LabelCle` pour la sémantique.
   */
  PlaceholderCle?: string;
  Options?: FilterOption[];
  DefaultValue?: unknown;
  Visible?: boolean;
  Disabled?: boolean;
  /** Longueur max en caractères (passée à `<app-input [maxLength]>`). */
  MaxLength?: number | null;
}

export interface FilterSchemaFieldMeta
{
  Value: unknown;
  Label?: string;
  Type?: FilterFieldType;
  Placeholder?: string;
  Options?: FilterOption[];
  DefaultValue?: unknown;
  Visible?: boolean;
  Disabled?: boolean;
}

export type FilterSchemaField = unknown | FilterSchemaFieldMeta;

@Component({
  selector: 'app-filter-bar',
  standalone: true,
  templateUrl: './filter-bar.component.html',
  styleUrls: ['./filter-bar.component.scss'],
  changeDetection: ChangeDetectionStrategy.Eager,
  imports: [FormsModule, InputComponent, ButtonComponent, SectionCardComponent, TranslateKeyPipe]
})
export class FilterBarComponent extends BaseComponent implements OnChanges, OnInit
{
  private readonly _AddressService = inject(AdressesService);

  @Input() public Fields: FilterFieldConfig[] = [];
  @Input() public SchemaObject: Record<string, FilterSchemaField> | null = null;
  @Input() public ExcludedKeys: string[] = [];

  @Input() public ShowResetButton: boolean = true;
  @Input() public ShowApplyButton: boolean = false;
  @Input() public InitialValue: BaseCritereDTO = {} as BaseCritereDTO;

  @Input() public Collapsible: boolean = true;
  @Input() public StartCollapsed: boolean = true;

  @Output() public FilterChange: EventEmitter<BaseCritereDTO> = new EventEmitter<BaseCritereDTO>();
  @Output() public ResetClick: EventEmitter<void> = new EventEmitter<void>();
  @Output() public DeleteModeChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  public EffectiveFields: FilterFieldConfig[] = [];
  public Values: BaseCritereDTO = {} as BaseCritereDTO;
  public IsCollapsed: boolean = false;

  private get _valuesRecord(): Record<string, unknown>
  {
    return this.Values as Record<string, unknown>;
  }

  ngOnInit(): void
  {
    this.IsCollapsed = this.Collapsible ? this.StartCollapsed : false;
  }

  ngOnChanges(pChanges: SimpleChanges): void
  {
    if (pChanges['Fields'] || pChanges['SchemaObject'] || pChanges['InitialValue'] || pChanges['ExcludedKeys'])
    {
      this._BuildEffectiveFields();
      this._BuildValues();
    }

    if (pChanges['Collapsible'] || pChanges['StartCollapsed'])
    {
      this.IsCollapsed = this.Collapsible ? this.StartCollapsed : false;
    }
  }

  /**
   * Gère le changement d'état plié/déplié émis par `app-section-card`.
   * Met à jour l'état local et envoie un événement PostHog pour le tracking UX.
   * @param pCollapsed Le nouvel état plié (`true`) ou déplié (`false`)
   */
  public OnCollapsedChange(pCollapsed: boolean): void
  {
    if (!this.Collapsible) return;
    this.IsCollapsed = pCollapsed;
    this.PostHog.Capture(this.BuildTrackingName(pCollapsed ? 'filtres_replier' : 'filtres_deplier', 'tracking'));
  }

  public OnFieldValueChange(pFieldKey: string, pValue: unknown): void
  {
    const lField: FilterFieldConfig | undefined = this.EffectiveFields.find((f: FilterFieldConfig) => f.Key === pFieldKey);
    if (lField?.Type === 'address' && pValue && typeof pValue === 'object')
    {
      const lAddress: AdressesDTO = pValue as AdressesDTO;
      this._valuesRecord[pFieldKey] = lAddress.city ?? '';
    }
    else
    {
      this._valuesRecord[pFieldKey] = pValue;
    }
    this.OnAnyFieldChanged(pFieldKey);
  }

  public OnAnyFieldChanged(pFieldKey: string): void
  {
    if (pFieldKey.toLowerCase() === 'deletemode')
    {
      this.DeleteModeChange.emit(!!this._valuesRecord[pFieldKey]);
    }

    if (!this.ShowApplyButton)
    {
      this._EmitFilters();
    }
  }

  public Apply(): void
  {
    this._EmitFilters();
    this.PostHog.Capture(this.BuildTrackingName('filtres_appliquer', 'tracking'));
  }

  public Reset(): void
  {
    const lResetValues: BaseCritereDTO = {} as BaseCritereDTO;
    const lResetRecord = lResetValues as Record<string, unknown>;

    for (const lField of this.EffectiveFields)
    {
      if (lField.Type === 'checkbox')
      {
        lResetRecord[lField.Key] = lField.DefaultValue ?? false;
        continue;
      }

      if (lField.Type === 'multi-select')
      {
        lResetRecord[lField.Key] = lField.DefaultValue ?? [];
        continue;
      }

      lResetRecord[lField.Key] = lField.DefaultValue ?? null;
    }

    this.Values = lResetValues;
    this.ResetClick.emit();
    this.DeleteModeChange.emit(false);
    this._EmitFilters();
    this.PostHog.Capture(this.BuildTrackingName('filtres_reinitialiser', 'tracking'));
  }

  public ClearField(pField: FilterFieldConfig): void
  {
    if (pField.Type === 'checkbox')
    {
      this._valuesRecord[pField.Key] = pField.DefaultValue ?? false;
    }
    else if (pField.Type === 'multi-select')
    {
      this._valuesRecord[pField.Key] = pField.DefaultValue ?? [];
    }
    else
    {
      this._valuesRecord[pField.Key] = pField.DefaultValue ?? null;
    }

    this.OnAnyFieldChanged(pField.Key);
    this.PostHog.Capture(this.BuildTrackingName('filtre_effacer', 'tracking'), { field: pField.Key });
  }

  public get SortByField(): FilterFieldConfig | null
  {
    return this.EffectiveFields.find((f: FilterFieldConfig) => f.Key.toLowerCase() === 'sortby') ?? null;
  }

  public get SortDirectionField(): FilterFieldConfig | null
  {
    return this.EffectiveFields.find((f: FilterFieldConfig) => f.Key.toLowerCase() === 'sortdirection') ?? null;
  }

  public get NonSortFields(): FilterFieldConfig[]
  {
    return this.EffectiveFields.filter((f: FilterFieldConfig) => !this._IsSortField(f));
  }

  public OnQuickSortByChange(pValue: unknown): void
  {
    const lSortByField = this.SortByField;
    if (!lSortByField) return;

    this._valuesRecord[lSortByField.Key] = pValue;
    this._EmitFilters();
  }

  public OnQuickSortDirectionToggle(pEvent: MouseEvent): void
  {
    pEvent.stopPropagation();

    const lSortDirectionField = this.SortDirectionField;
    if (!lSortDirectionField) return;

    const lCurrent: string = String(this._valuesRecord[lSortDirectionField.Key] ?? 'desc').toLowerCase();
    this._valuesRecord[lSortDirectionField.Key] = lCurrent === 'asc' ? 'desc' : 'asc';

    this._EmitFilters();
    this.PostHog.Capture(this.BuildTrackingName('tri_direction', 'tracking'), { direction: this._valuesRecord[lSortDirectionField.Key] });
  }

  public GetSortDirectionLabel(): string
  {
    const lSortDirectionField = this.SortDirectionField;
    if (!lSortDirectionField) return 'Descendant';

    const lCurrent: unknown = this._valuesRecord[lSortDirectionField.Key];
    return String(lCurrent).toLowerCase() === 'asc' ? 'Ascendant' : 'Descendant';
  }

  public get ActiveFiltersCount(): number
  {
    let lCount = 0;

    for (const lField of this.EffectiveFields)
    {
      if (this._IsSortField(lField)) continue;
      if (this._IsFieldActive(lField)) lCount++;
    }

    return lCount;
  }

  public get ActiveFields(): FilterFieldConfig[]
  {
    return this.EffectiveFields.filter(
      (f: FilterFieldConfig) => !this._IsSortField(f) && this._IsFieldActive(f)
    );
  }

  public GetFieldDisplayValue(pField: FilterFieldConfig): string
  {
    const lValue: unknown = this._valuesRecord[pField.Key];

    if (pField.Type === 'checkbox')
    {
      return lValue ? 'Oui' : 'Non';
    }

    if (pField.Type === 'select')
    {
      const lOpt = (pField.Options || []).find((o: FilterOption) => o.Value === lValue);
      return lOpt?.Label ?? String(lValue ?? '');
    }

    if (pField.Type === 'multi-select')
    {
      const lValues: unknown[] = Array.isArray(lValue) ? lValue : [];
      if (lValues.length === 0) return '';
      if (lValues.length === 1)
      {
        const lOpt = (pField.Options || []).find((o: FilterOption) => o.Value === lValues[0]);
        return lOpt?.Label ?? String(lValues[0]);
      }
      return `${lValues.length} sélections`;
    }

    if (pField.Type === 'address')
    {
      if (lValue && typeof lValue === 'object')
      {
        return this._AddressService.BuildLabel(lValue);
      }
      return String(lValue ?? '');
    }

    return String(lValue ?? '');
  }

  private _BuildEffectiveFields(): void
  {
    if (this.Fields?.length > 0)
    {
      this.EffectiveFields = this.Fields
        .filter((f: FilterFieldConfig) => !this.ExcludedKeys.includes(f.Key))
        .filter((f: FilterFieldConfig) => f.Visible !== false);
      return;
    }

    if (!this.SchemaObject || typeof this.SchemaObject !== 'object')
    {
      this.EffectiveFields = [];
      return;
    }

    this.EffectiveFields = Object.keys(this.SchemaObject)
      .filter((pKey: string) => !this.ExcludedKeys.includes(pKey))
      .map((pKey: string): FilterFieldConfig =>
      {
        const lRaw: FilterSchemaField = this.SchemaObject?.[pKey];
        const lMeta: FilterSchemaFieldMeta | null = this._IsSchemaMeta(lRaw) ? lRaw : null;
        const lValue: unknown = lMeta ? lMeta.Value : lRaw;

        const lLabel: string = lMeta?.Label ?? this._ToLabel(pKey);
        const lType: FilterFieldType = lMeta?.Type ?? this._InferType(pKey, lValue);

        return {
          Key: pKey,
          Label: lLabel,
          Type: lType,
          Placeholder: lMeta?.Placeholder ?? (
            lType === 'text' || lType === 'number'
              ? `Filtrer par ${lLabel.toLowerCase()}`
              : undefined
          ),
          Options: lMeta?.Options,
          DefaultValue: lMeta?.DefaultValue,
          Visible: lMeta?.Visible ?? true,
          Disabled: lMeta?.Disabled ?? false
        };
      })
      .filter((f: FilterFieldConfig) => f.Visible !== false);
  }

  private _BuildValues(): void
  {
    const lValues: BaseCritereDTO = {} as BaseCritereDTO;
    const lValuesRecord = lValues as Record<string, unknown>;
    const lInitialRecord = (this.InitialValue ?? {}) as Record<string, unknown>;

    for (const lField of this.EffectiveFields)
    {
      const lInitial: unknown = lInitialRecord[lField.Key];

      // InitialValue prioritaire (même si null)
      if (Object.prototype.hasOwnProperty.call(lInitialRecord, lField.Key))
      {
        lValuesRecord[lField.Key] = lInitial;
        continue;
      }

      // DefaultValue ensuite
      if (lField.DefaultValue !== undefined)
      {
        lValuesRecord[lField.Key] = lField.DefaultValue;
        continue;
      }

      if (lField.Type === 'select')
      {
        lValuesRecord[lField.Key] = null;
        continue;
      }

      if (lField.Type === 'multi-select')
      {
        lValuesRecord[lField.Key] = [];
        continue;
      }

      lValuesRecord[lField.Key] = lField.Type === 'checkbox' ? false : null;
    }

    this.Values = lValues;
  }

  private _EmitFilters(): void
  {
    const lCleaned: BaseCritereDTO = {} as BaseCritereDTO;
    const lCleanedRecord = lCleaned as Record<string, unknown>;

    for (const lField of this.EffectiveFields)
    {
      const lValue: unknown = this._valuesRecord[lField.Key];

      if (lField.Type === 'checkbox')
      {
        lCleanedRecord[lField.Key] = !!lValue;
        continue;
      }

      if (lField.Type === 'multi-select')
      {
        const lValues: unknown[] = Array.isArray(lValue) ? [...lValue] : [];
        lCleanedRecord[lField.Key] = lValues;
        continue;
      }

      const lIsNullish = lValue == null;
      const lIsEmptyString = typeof lValue === 'string' && lValue.trim() === '';

      if (!lIsNullish && !lIsEmptyString)
      {
        lCleanedRecord[lField.Key] = lValue;
      }
    }

    this.FilterChange.emit(lCleaned);

    if (Object.prototype.hasOwnProperty.call(lCleanedRecord, 'deleteMode'))
    {
      this.DeleteModeChange.emit(!!lCleanedRecord['deleteMode']);
    }
  }

  private _IsFieldActive(pField: FilterFieldConfig): boolean
  {
    const lValue: unknown = this._valuesRecord[pField.Key];

    if (pField.Type === 'checkbox') return !!lValue;
    if (pField.Type === 'multi-select') return Array.isArray(lValue) && lValue.length > 0;
    if (lValue == null) return false;
    if (typeof lValue === 'string') return lValue.trim() !== '';
    return true;
  }

  private _IsSortField(pField: FilterFieldConfig): boolean
  {
    const lKey = pField.Key.toLowerCase();
    return lKey === 'sortby' || lKey === 'sortdirection';
  }

  private _InferType(pKey: string, pValue: unknown): FilterFieldType
  {
    const lKey = pKey.toLowerCase();

    if (typeof pValue === 'boolean') return 'checkbox';
    if (typeof pValue === 'number') return 'number';
    if (lKey.includes('date') || lKey.endsWith('at')) return 'date';

    return 'text';
  }
  public GetValue(pKey: string): unknown
  {
    return (this.Values as Record<string, unknown>)[pKey];
  }

  public GetBooleanValue(pKey: string): boolean
  {
    return !!(this.Values as Record<string, unknown>)[pKey];
  }
  private _ToLabel(pKey: string): string
  {
    return pKey
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/_/g, ' ')
      .replace(/^./, (m: string) => m.toUpperCase());
  }

  private _IsSchemaMeta(pValue: FilterSchemaField): pValue is FilterSchemaFieldMeta
  {
    if (pValue == null || typeof pValue !== 'object') return false;
    return Object.prototype.hasOwnProperty.call(pValue as object, 'Value');
  }
}
