import { Component, Input, Inject, PLATFORM_ID, ChangeDetectionStrategy } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

import { BaseComponent } from '../../../core/base/BaseComponent';

@Component({
  selector: 'app-scroll-indicator',
  standalone: true,
  imports: [],
  templateUrl: './scroll-indicator.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./scroll-indicator.component.scss']
})
export class ScrollIndicatorComponent extends BaseComponent
{
  /** Texte affiché au-dessus de la flèche */
  @Input() label: string = 'Découvrir';
  /** ID de l'élément vers lequel scroller */
  @Input() targetId: string = '';
  /** Durée totale du scroll en ms */
  @Input() duration: number = 1200;

  private readonly _IsBrowser: boolean;

  constructor(@Inject(PLATFORM_ID) pPlatformId: object)
  {
    super();
    this._IsBrowser = isPlatformBrowser(pPlatformId);
  }

  /**
   * Déclenche un scroll progressif et accéléré vers l'élément cible.
   */
  OnClick(): void
  {
    if (!this._IsBrowser || !this.targetId) return;

    this.PostHog.Capture(this.BuildTrackingName('scroll_indicator_clique', 'tracking'), { cible: this.targetId });

    const lTarget: HTMLElement | null = document.getElementById(this.targetId);
    if (!lTarget) return;

    const lStartY: number = window.scrollY || window.pageYOffset;
    const lTargetRect: DOMRect = lTarget.getBoundingClientRect();
    const lDistance: number = lTargetRect.top + lStartY - lStartY;
    const lStartTime: number = performance.now();

    // - cm - Easing personnalisé : accélération progressive (départ lent, fin rapide et freinage doux)
    const lEasing = (pT: number): number =>
    {
      // - cm - Custom ease-in-out avec accélération marquée
      return pT < 0.5
        ? 2 * pT * pT
        : 1 - Math.pow(-2 * pT + 2, 2) / 2;
    };

    const lAnimate = (pCurrentTime: number): void =>
    {
      const lElapsed: number = pCurrentTime - lStartTime;
      const lProgress: number = Math.min(lElapsed / this.duration, 1);
      const lEased: number = lEasing(lProgress);

      window.scrollTo(0, lStartY + lDistance * lEased);

      if (lProgress < 1)
      {
        requestAnimationFrame(lAnimate);
      }
    };

    requestAnimationFrame(lAnimate);
  }
}