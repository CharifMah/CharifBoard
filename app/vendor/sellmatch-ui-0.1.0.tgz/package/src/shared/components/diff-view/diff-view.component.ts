import { Component, Input, Signal, WritableSignal, computed, signal, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { BadgeComponent } from '../../../shared/components/badge/badge.component';

/**
 * Action représentée par la diff.
 * - `insert` : création d'une ligne (before = null).
 * - `update` : modification d'une ligne (before = état précédent, after = nouvel état).
 * - `delete` : suppression d'une ligne (after = null).
 */
export type EDiffAction = 'insert' | 'update' | 'delete';

/**
 * Diff générique affichable par {@link DiffViewComponent}.
 * Représente le résultat d'un outil (ex: Create* MCP) sous forme avant / après.
 */
export interface DiffRecord {
  /** Action effectuée (insert / update / delete). */
  Action: EDiffAction;
  /** Table ou entité concernée (ex: contacts, properties). */
  Table: string;
  /** État avant l'action (null pour un insert). */
  Before: unknown;
  /** État après l'action (null pour un delete). */
  After: unknown;
  /** Résumé lisible (ex: "+1 ligne dans contacts (id: 42)"). */
  Summary: string;
}

/**
 * Ligne d'un diff inline (style git / VS Code).
 */
export interface DiffLine {
  /** Marqueur de ligne : '+' ajout, '-' suppression, ' ' contexte. */
  Marker: '+' | '-' | ' ';
  /** Contenu textuel de la ligne. */
  Content: string;
}

/**
 * Mode d'affichage de la diff.
 * - `cards` : carte simple avec les infos essentielles (par défaut, le plus lisible).
 * - `table` : tableau clé/valeur de l'enregistrement créé.
 * - `inline` : diff technique style git avec marqueurs +/-.
 */
export type EDiffViewMode = 'cards' | 'table' | 'inline';

/**
 * Section d'une carte de diff (mode 'cards' / 'table').
 */
export interface DiffCardSection {
  /** Titre de la section (ex: "Contact", "Tags associés"). */
  Title: string;
  /** Lignes clé/valeur à afficher. */
  Rows: DiffCardRow[];
}

/**
 * Ligne clé/valeur d'une carte de diff.
 */
export interface DiffCardRow {
  /** Nom du champ. */
  Key: string;
  /** Valeur formatée. */
  Value: string;
}

/**
 * Composant générique d'affichage d'une diff (avant / après).
 * Réutilisable partout où un outil renvoie une diff structurée
 * (outils MCP Create*, imports IA, etc.).
 * Affiche un en-tête (action + table + résumé) puis un diff inline style git/VS Code
 * avec marqueurs +/- sur fond coloré.
 */
@Component({
  selector: 'app-diff-view',
  standalone: true,
  imports: [BadgeComponent],
  templateUrl: './diff-view.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: './diff-view.component.scss'
})
export class DiffViewComponent extends BaseComponent {
  //#region Inputs
  /** La diff à afficher. Si null, le composant ne rend rien. */
  @Input() public set Record(pValue: DiffRecord | null) {
    this._Record.set(pValue);
  }
  public get Record(): DiffRecord | null {
    return this._Record();
  }

  /** Indique si le bloc "Avant" doit être affiché même vide (défaut: false). */
  @Input() public ShowEmptyBefore: boolean = false;

  /** Indique si le bloc "Après" doit être affiché même vide (défaut: false). */
  @Input() public ShowEmptyAfter: boolean = false;

  /** Hauteur max (px) du bloc de code diff (défaut: 240). */
  @Input() public MaxHeight: number = 240;

  /** Mode d'affichage de la diff : cards (par défaut), table, inline. */
  @Input() public Mode: EDiffViewMode = 'cards';
  //#endregion

  //#region Internal State
  /** Signal interne portant la diff courante. */
  private readonly _Record: WritableSignal<DiffRecord | null> = signal<DiffRecord | null>(null);

  /** Signal en lecture seule exposé au template (null si aucune diff). */
  public readonly Current: Signal<DiffRecord | null> = this._Record.asReadonly();
  //#endregion

  //#region Properties
  /** Computed : JSON indenté du bloc "Avant". */
  public readonly BeforeJson: Signal<string> = computed<string>(() => this.FormatJson(this._Record()?.Before));

  /** Computed : JSON indenté du bloc "Après". */
  public readonly AfterJson: Signal<string> = computed<string>(() => this.FormatJson(this._Record()?.After));

  /** Computed : indique si le bloc "Avant" doit être rendu. */
  public readonly HasBefore: Signal<boolean> = computed<boolean>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec) return false;
    return this.ShowEmptyBefore || lRec.Before !== null && lRec.Before !== undefined;
  });

  /** Computed : indique si le bloc "Après" doit être rendu. */
  public readonly HasAfter: Signal<boolean> = computed<boolean>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec) return false;
    return this.ShowEmptyAfter || lRec.After !== null && lRec.After !== undefined;
  });

  /** Computed : badge type selon l'action (insert = success, update = warning, delete = error). */
  public readonly BadgeType: Signal<'success' | 'warning' | 'error'> = computed<'success' | 'warning' | 'error'>(() => {
    const lAction: EDiffAction | undefined = this._Record()?.Action;
    if (lAction === 'insert') return 'success';
    if (lAction === 'update') return 'warning';
    return 'error';
  });

  /** Computed : libellé d'action localisé (Insertion / Modification / Suppression). */
  public readonly ActionLabel: Signal<string> = computed<string>(() => {
    const lAction: EDiffAction | undefined = this._Record()?.Action;
    if (lAction === 'insert') return 'Insertion';
    if (lAction === 'update') return 'Modification';
    if (lAction === 'delete') return 'Suppression';
    return 'Action';
  });

  /** Computed : icône Material selon l'action. */
  public readonly ActionIcon: Signal<string> = computed<string>(() => {
    const lAction: EDiffAction | undefined = this._Record()?.Action;
    if (lAction === 'insert') return 'add_circle';
    if (lAction === 'update') return 'edit';
    if (lAction === 'delete') return 'remove_circle';
    return 'change_circle';
  });

  /** Computed : ligne d'en-tête "@@ table" du diff inline. */
  public readonly DiffHeader: Signal<string> = computed<string>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec) return '';
    return `@@ ${lRec.Table}`;
  });

  /** Computed : lignes du diff inline style git/VS Code. */
  public readonly DiffLines: Signal<DiffLine[]> = computed<DiffLine[]>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec) return [];

    const lLines: DiffLine[] = [];
    const lBeforeObj: Record<string, unknown> = this.AsRecord(lRec.Before);
    const lAfterObj: Record<string, unknown> = this.AsRecord(lRec.After);

    if (lRec.Action === 'insert') {
      for (const lKey of Object.keys(lAfterObj)) {
        lLines.push({ Marker: '+', Content: `${lKey}: ${this.FormatValue(lAfterObj[lKey])}` });
      }
      return lLines;
    }

    if (lRec.Action === 'delete') {
      for (const lKey of Object.keys(lBeforeObj)) {
        lLines.push({ Marker: '-', Content: `${lKey}: ${this.FormatValue(lBeforeObj[lKey])}` });
      }
      return lLines;
    }

    // - cm - Update : affiche les lignes communes en contexte, puis les différences +/-
    const lAllKeys: Set<string> = new Set<string>([...Object.keys(lBeforeObj), ...Object.keys(lAfterObj)]);
    for (const lKey of lAllKeys) {
      const lBeforeValue: unknown = lBeforeObj[lKey];
      const lAfterValue: unknown = lAfterObj[lKey];
      const lBeforeText: string = this.FormatValue(lBeforeValue);
      const lAfterText: string = this.FormatValue(lAfterValue);

      if (lBeforeText !== lAfterText) {
        if (lKey in lBeforeObj) {
          lLines.push({ Marker: '-', Content: `${lKey}: ${lBeforeText}` });
        }
        if (lKey in lAfterObj) {
          lLines.push({ Marker: '+', Content: `${lKey}: ${lAfterText}` });
        }
      } else {
        lLines.push({ Marker: ' ', Content: `${lKey}: ${lAfterText}` });
      }
    }

    return lLines;
  });

  /** Computed : indique si l'objet after est un objet simple (pas une structure composite contact/tags). */
  public readonly IsSimpleObject: Signal<boolean> = computed<boolean>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec || lRec.After === null || lRec.After === undefined) return false;
    if (typeof lRec.After !== 'object' || Array.isArray(lRec.After)) return false;
    const lKeys: string[] = Object.keys(lRec.After);
    // - cm - Composite = plusieurs clés racine (ex: contact + tags) ou présence d'arrays
    if (lKeys.length > 1) return false;
    const lFirstValue: unknown = (lRec.After as Record<string, unknown>)[lKeys[0]];
    return typeof lFirstValue === 'object' && lFirstValue !== null && !Array.isArray(lFirstValue);
  });

  /** Computed : sections de carte/tableau pour les modes 'cards' et 'table'. */
  public readonly CardSections: Signal<DiffCardSection[]> = computed<DiffCardSection[]>(() => {
    const lRec: DiffRecord | null = this._Record();
    if (!lRec || lRec.After === null || lRec.After === undefined) return [];
    const lAfter: Record<string, unknown> = this.AsRecord(lRec.After);

    // - cm - Si after est simple (DTO plat), on l'affiche dans une seule section nommée par la table
    if (this.IsSimpleObject()) {
      return [{
        Title: this.Capitalize(lRec.Table),
        Rows: this.BuildRows(lAfter)
      }];
    }

    // - cm - Si after est composite (contact+tags, affaire+contacts+tags...), une section par clé
    const lSections: DiffCardSection[] = [];
    for (const lKey of Object.keys(lAfter)) {
      const lValue: unknown = lAfter[lKey];
      if (lValue === null || lValue === undefined) continue;

      if (Array.isArray(lValue)) {
        if (lValue.length === 0) continue;
        // - cm - Tableau de liaisons : une ligne par élément avec les champs clés
        const lRows: DiffCardRow[] = [];
        for (const lItem of lValue) {
          const lItemRows: DiffCardRow[] = this.BuildRows(this.AsRecord(lItem));
          if (lRows.length > 0) lRows.push({ Key: '', Value: '' }); // - cm - Séparateur visuel entre éléments
          lRows.push(...lItemRows);
        }
        if (lRows.length > 0) {
          lSections.push({ Title: `${this.Capitalize(lKey)} (${lValue.length})`, Rows: lRows });
        }
      } else if (typeof lValue === 'object') {
        lSections.push({ Title: this.Capitalize(lKey), Rows: this.BuildRows(lValue as Record<string, unknown>) });
      }
    }
    return lSections;
  });
  //#endregion

  //#region Methods
  /**
   * Formate une valeur en JSON indenté pour l'affichage.
   * @param pValue La valeur à formater.
   * @returns Le JSON indenté, ou une chaîne vide si null/undefined.
   */
  public FormatJson(pValue: unknown): string {
    if (pValue === null || pValue === undefined) return '';
    try {
      return JSON.stringify(pValue, null, 2);
    } catch (lError: unknown) {
      // - cm - Sérialisation impossible (référence circulaire...) : fallback texte
      void lError;
      return String(pValue);
    }
  }

  /**
   * Construit les lignes clé/valeur d'un objet pour les modes carte/tableau.
   * Ignore les champs null/undefined/vides techniques et les collections vides.
   * @param pObj L'objet à parcourir
   * @returns Les lignes clé/valeur formatées
   */
  private BuildRows(pObj: Record<string, unknown>): DiffCardRow[] {
    const lRows: DiffCardRow[] = [];
    for (const lKey of Object.keys(pObj)) {
      const lValue: unknown = pObj[lKey];
      if (lValue === null || lValue === undefined) continue;
      if (lValue === '' && lKey !== 'reference') continue; // - cm - On garde les références vides mais pas les autres strings vides
      if (Array.isArray(lValue) && lValue.length === 0) continue;
      lRows.push({ Key: this.FormatKey(lKey), Value: this.FormatValue(lValue) });
    }
    return lRows;
  }

  /**
   * Formate un nom de champ technique en libellé lisible.
   * Ex: "prenom" -> "Prénom", "adresseVille" -> "Adresse ville", "createdAt" -> "Créé le".
   * @param pKey Le nom du champ
   * @returns Le libellé formaté
   */
  private FormatKey(pKey: string): string {
    const lSpecial: Record<string, string> = {
      id: 'ID',
      reference: 'Référence',
      prenom: 'Prénom',
      nom: 'Nom',
      email: 'Email',
      telephone1: 'Téléphone',
      telephone2: 'Téléphone 2',
      adresseRue: 'Adresse',
      adresseCp: 'Code postal',
      adresseVille: 'Ville',
      intitule: 'Intitulé',
      prixAffiche: 'Prix affiché',
      surfaceHabitable: 'Surface habitable',
      budgetMax: 'Budget max',
      surfaceMin: 'Surface min',
      createdAt: 'Créé le',
      updatedAt: 'Mis à jour le'
    };
    if (lSpecial[pKey]) return lSpecial[pKey];
    // - cm - camelCase -> mots séparés avec majuscule initiale
    const lWords: string = pKey.replace(/([A-Z])/g, ' $1').toLowerCase().trim();
    return lWords.charAt(0).toUpperCase() + lWords.slice(1);
  }

  /**
   * Met la première lettre d'une chaîne en majuscule.
   * @param pValue La chaîne à capitaliser
   * @returns La chaîne capitalisée
   */
  private Capitalize(pValue: string): string {
    if (!pValue) return pValue;
    return pValue.charAt(0).toUpperCase() + pValue.slice(1);
  }

  /**
   * Convertit une valeur inconnue en objet Record utilisable pour le diff.
   * @param pValue La valeur à convertir.
   * @returns Un objet Record, ou un objet vide si la valeur n'est pas un objet.
   */
  private AsRecord(pValue: unknown): Record<string, unknown> {
    if (pValue === null || pValue === undefined) return {};
    if (typeof pValue === 'object' && !Array.isArray(pValue)) return pValue as Record<string, unknown>;
    return { value: pValue };
  }

  /**
   * Formate une valeur simple en texte pour une ligne de diff.
   * @param pValue La valeur à formater.
   * @returns Le texte formaté.
   */
  private FormatValue(pValue: unknown): string {
    if (pValue === null) return 'null';
    if (pValue === undefined) return 'undefined';
    if (typeof pValue === 'string') return pValue;
    if (typeof pValue === 'number' || typeof pValue === 'boolean') return String(pValue);
    try {
      return JSON.stringify(pValue);
    } catch (lError: unknown) {
      void lError;
      return String(pValue);
    }
  }
  //#endregion
}