import {
  Component,
  effect,
  ElementRef,
  inject,
  input,
  NgZone,
  output,
  signal,
  ViewChild
} from '@angular/core';

/**
 * Composant générique de menu contextuel réutilisable, indépendant de la grille SellMatch.
 *
 * Le menu est piloté par un signal `Position` ({ X, Y } en coordonnées écran, ou null).
 * Quand Position est non-null, le menu s'affiche à ces coordonnées (avec clamp viewport).
 * L'événement `Close` est émis quand l'utilisateur clique sur le backdrop, fait Escape,
 * ou clique sur un item du menu (le contenu projeté via ng-content doit appeler Close lui-même).
 *
 * Usage :
 * ```html
 * <app-context-menu [Position]="CtxPos()" (Close)="CtxPos.set(null)">
 *   <button class="context-menu__item" (click)="DoAction()">Action</button>
 * </app-context-menu>
 * ```
 */
@Component({
  selector: 'app-context-menu',
  templateUrl: './context-menu.component.html',
  styleUrl: './context-menu.component.scss',
  standalone: true
})
export class ContextMenuComponent {
  //#region Inputs

  /** Position écran du menu (clientX/clientY). Si null, le menu est fermé. */
  public readonly Position = input<{ X: number; Y: number } | null>(null);

  //#endregion

  //#region Outputs

  /** Émis quand l'utilisateur clique sur le backdrop, fait Escape, ou clique sur un item. */
  public readonly Close = output<void>();

  //#endregion

  //#region Attributes

  /** Position clampée (après ajustement viewport). Source de vérité pour le rendu. */
  private readonly _ClampedPosition = signal<{ X: number; Y: number } | null>(null);

  /** Référence DOM du menu (pour mesurer sa taille lors du clamp). */
  @ViewChild('menuEl') private _MenuRef?: ElementRef<HTMLElement>;

  /** NgZone injecté pour le clamp (runOutsideAngular + run). */
  private readonly _Zone: NgZone = inject(NgZone);

  //#endregion

  //#region Properties

  /** Indique si le menu est actuellement ouvert (Position non-null). */
  public readonly IsOpen = signal<boolean>(false);

  //#endregion

  //#region CTOR

  /**
   * Constructeur : abonne le clamp à chaque changement de Position.
   */
  public constructor() {
    effect((): void => {
      const lPos = this.Position();
      if (lPos) {
        this.IsOpen.set(true);
        this._ClampedPosition.set({ ...lPos });
        this.ClampToViewport();
      } else {
        this.IsOpen.set(false);
        this._ClampedPosition.set(null);
      }
    });
  }

  //#endregion

  //#region Methods

  /**
   * Repositionne le menu après rendu pour éviter qu'il ne dépasse du viewport.
   * Flip vers le haut si déborde en bas, recentrage si déborde à droite.
   */
  private ClampToViewport(): void {
    if (typeof window === 'undefined') {
      return;
    }
    this._Zone.runOutsideAngular((): void => {
      requestAnimationFrame((): void => {
        const lEl: HTMLElement | undefined = this._MenuRef?.nativeElement;
        const lPos = this._ClampedPosition();
        if (!lEl || !lPos) {
          return;
        }
        const lRect: DOMRect = lEl.getBoundingClientRect();
        const lMargin: number = 8;
        let lNewX: number = lPos.X;
        let lNewY: number = lPos.Y;

        // - cm - Déborde à droite : décale vers la gauche
        if (lPos.X + lRect.width > window.innerWidth - lMargin) {
          lNewX = Math.max(lMargin, window.innerWidth - lRect.width - lMargin);
        }
        // - cm - Déborde en bas : flip vers le haut (bas du menu au curseur)
        if (lPos.Y + lRect.height > window.innerHeight - lMargin) {
          lNewY = Math.max(lMargin, lPos.Y - lRect.height);
          // - cm - Si flip vers le haut déborde encore en haut, on colle en haut du viewport
          if (lNewY + lRect.height > window.innerHeight - lMargin) {
            lNewY = lMargin;
          }
        }
        if (lNewX !== lPos.X || lNewY !== lPos.Y) {
          this._Zone.run((): void => {
            this._ClampedPosition.set({ X: lNewX, Y: lNewY });
          });
        }
      });
    });
  }

  /**
   * Gère le clic sur le backdrop : émet Close.
   */
  public OnBackdropClick(): void {
    this.Close.emit();
  }

  /**
   * Gère les touches clavier au sein du menu (Escape ferme).
   * @param pEvent L'événement clavier.
   */
  public OnKeydown(pEvent: KeyboardEvent): void {
    if (pEvent.key === 'Escape') {
      pEvent.stopPropagation();
      this.Close.emit();
    }
  }

  /** Position clampée pour le rendu (exposée au template). */
  public readonly RenderPosition = this._ClampedPosition.asReadonly();

  //#endregion
}
