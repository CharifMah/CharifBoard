import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { InputComponent } from '../../../shared/components/input/input.component';

/**
 * Composant de pagination réutilisable.
 *
 * Affiche un footer de pagination complet : sélecteur de page limit, info "X–Y sur Z",
 * boutons première/précédente, numéros de pages avec ellipsis, boutons suivante/dernière.
 * Utilise les composants réutilisables `app-input` (select) et `app-button` du projet.
 *
 * @example
 * ```html
 * <app-pagination
 *   [CurrentPage]="Page()"
 *   [TotalItems]="Total()"
 *   [PageSize]="PageSize()"
 *   [PageSizeOptions]="[10, 25, 50, 100]"
 *   (PageChange)="OnPageChange($event)"
 *   (PageSizeChange)="OnPageSizeChange($event)" />
 * ```
 */
@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [ButtonComponent, InputComponent],
  templateUrl: './pagination.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: './pagination.component.scss'
})
export class PaginationComponent {
  //#region Inputs
  /** Page courante (1-based). */
  @Input() set CurrentPage(pValue: number) {
    this._CurrentPage = pValue && pValue > 0 ? Math.floor(pValue) : 1;
  }
  get CurrentPage(): number {
    return this._CurrentPage;
  }
  private _CurrentPage = 1;

  /** Nombre total d'éléments (toutes pages confondues). */
  @Input() set TotalItems(pValue: number) {
    this._TotalItems = pValue && pValue > 0 ? Math.floor(pValue) : 0;
  }
  get TotalItems(): number {
    return this._TotalItems;
  }
  private _TotalItems = 0;

  /** Taille de page courante. */
  @Input() set PageSize(pValue: number) {
    this._PageSize = pValue && pValue > 0 ? Math.floor(pValue) : 25;
  }
  get PageSize(): number {
    return this._PageSize;
  }
  private _PageSize = 25;

  /** Options de taille de page pour le sélecteur. */
  @Input() public PageSizeOptions: number[] = [10, 25, 50, 100];

  /** Affiche le sélecteur de page limit (défaut: true). */
  @Input() public ShowPageSizeSelector = true;

  /** Affiche les boutons première/dernière page (défaut: true). */
  @Input() public ShowFirstLastButtons = true;

  /** Affiche l'info "X–Y sur Z" (défaut: true). */
  @Input() public ShowPageInfo = true;
  //#endregion

  //#region Outputs
  /** Émis quand la page change (1-based). */
  @Output() public PageChange = new EventEmitter<number>();

  /** Émis quand la taille de page change. */
  @Output() public PageSizeChange = new EventEmitter<number>();
  //#endregion

  //#region Computed
  /** Nombre total de pages. */
  public get TotalPages(): number {
    return this._PageSize > 0 ? Math.max(1, Math.ceil(this._TotalItems / this._PageSize)) : 1;
  }

  /** Index de début (1-based) de la page courante. */
  public get StartIndex(): number {
    if (this._TotalItems === 0) {
      return 0;
    }
    return (this._CurrentPage - 1) * this._PageSize + 1;
  }

  /** Index de fin (1-based) de la page courante. */
  public get EndIndex(): number {
    return Math.min(this._CurrentPage * this._PageSize, this._TotalItems);
  }

  /** Indique si on est sur la première page. */
  public get IsFirstPage(): boolean {
    return this._CurrentPage <= 1;
  }

  /** Indique si on est sur la dernière page. */
  public get IsLastPage(): boolean {
    return this._CurrentPage >= this.TotalPages;
  }

  /** Options de taille de page formatées pour app-input select ({ Label, Value }). */
  public get SelectOptions(): { Label: string; Value: number }[] {
    return this.PageSizeOptions.map((lSize) => ({ Label: String(lSize), Value: lSize }));
  }

  /**
   * Liste des numéros de pages visibles (fenêtre coulissante de 5 pages).
   * @returns Le tableau des numéros de pages à afficher.
   */
  public get VisiblePages(): number[] {
    const lPages: number[] = [];
    const lMaxVisible = 5;
    let lStart = Math.max(1, this._CurrentPage - Math.floor(lMaxVisible / 2));
    const lEnd = Math.min(this.TotalPages, lStart + lMaxVisible - 1);

    // - cm - Ajuste pour toujours afficher lMaxVisible pages si possible
    if (lEnd - lStart + 1 < lMaxVisible) {
      lStart = Math.max(1, lEnd - lMaxVisible + 1);
    }

    for (let lI = lStart; lI <= lEnd; lI++) {
      lPages.push(lI);
    }
    return lPages;
  }
  //#endregion

  //#region Methods
  /**
   * TrackBy pour les numéros de pages (perf ngFor).
   * @param pIndex Index.
   * @param pPage Numéro de page.
   * @returns Clé de suivi.
   */
  public TrackByPage(pIndex: number, pPage: number): number {
    return pPage;
  }

  /**
   * Navigue vers une page donnée si valide et différente.
   * @param pPage Le numéro de page cible (1-based).
   */
  public GoToPage(pPage: number): void {
    if (pPage >= 1 && pPage <= this.TotalPages && pPage !== this._CurrentPage) {
      this._CurrentPage = pPage;
      this.PageChange.emit(this._CurrentPage);
    }
  }

  /** Navigue vers la première page. */
  public GoToFirstPage(): void {
    this.GoToPage(1);
  }

  /** Navigue vers la dernière page. */
  public GoToLastPage(): void {
    this.GoToPage(this.TotalPages);
  }

  /** Navigue vers la page précédente. */
  public GoToPreviousPage(): void {
    this.GoToPage(this._CurrentPage - 1);
  }

  /** Navigue vers la page suivante. */
  public GoToNextPage(): void {
    this.GoToPage(this._CurrentPage + 1);
  }

  /**
   * Gère le changement de taille de page depuis app-input (valueChange).
   * @param pValue La nouvelle taille de page.
   */
  public OnPageSizeChange(pValue: number | string | boolean): void {
    const lValue = Number(pValue);
    if (lValue && lValue > 0) {
      this._PageSize = lValue;
      // - cm - Remet sur la première page après changement de taille
      this._CurrentPage = 1;
      this.PageSizeChange.emit(lValue);
      this.PageChange.emit(1);
    }
  }
  //#endregion
}