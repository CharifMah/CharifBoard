import { CommonModule } from '@angular/common';
import {
  Component, Input, ChangeDetectionStrategy, ElementRef,
  ViewChild, TemplateRef, ViewContainerRef, Renderer2, inject,
  DestroyRef
} from '@angular/core';
import { PortalModule, DomPortalOutlet, TemplatePortal } from '@angular/cdk/portal';
import { BaseComponent } from '../../../core/base/BaseComponent';

export type TooltipPosition = 'top' | 'right' | 'bottom' | 'left';
export type TooltipVariant = 'dark' | 'light' | 'primary' | 'error';

/**
 * Ligne structurée affichée dans un tooltip.
 */
export interface TooltipLine {
  /** Libellé optionnel mis en avant (ex: nom de colonne). */
  Label?: string;
  /** Message principal. */
  Message: string;
}

@Component({
  selector: 'app-tooltip',
  standalone: true,
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, PortalModule]
})
export class TooltipComponent extends BaseComponent
{
  //#region Inputs
  @Input()
  public Text: string = '';

  @Input()
  public Lines: TooltipLine[] = [];

  @Input()
  public Position: TooltipPosition = 'top';

  @Input()
  public Variant: TooltipVariant = 'dark';

  @Input()
  public Disabled: boolean = false;

  @Input()
  public MaxWidth: number = 260;

  @Input()
  public AriaLabel: string = '';

  /** Template personnalisé affiché dans la bulle (ex: carte, HTML riche). */
  @Input()
  public Template?: TemplateRef<unknown>;

  /** Contexte passé au Template personnalisé. */
  @Input()
  public Context: Record<string, unknown> = {};
  //#endregion

  //#region Attributes
  @ViewChild('bubbleTemplate', { static: false }) private _BubbleTemplate!: TemplateRef<unknown>;
  private _ElementRef: ElementRef<HTMLElement> = inject(ElementRef<HTMLElement>);
  private _ViewContainerRef: ViewContainerRef = inject(ViewContainerRef);
  private _Renderer: Renderer2 = inject(Renderer2);
  private _PortalOutlet: DomPortalOutlet | null = null;
  private _BodyContainer: HTMLElement | null = null;
  private _Portal: TemplatePortal<unknown> | null = null;
  private _IsVisible: boolean = false;
  private _WindowScrollCleanup: (() => void) | null = null;
  private _WindowResizeCleanup: (() => void) | null = null;
  private _DestroyRef: DestroyRef = inject(DestroyRef);
  private _HideTimer: ReturnType<typeof setTimeout> | null = null;
  //#endregion

  //#region Properties
  public get HasTooltip(): boolean
  {
    return !this.Disabled && (this.Text.trim().length > 0 || this.Lines.length > 0 || !!this.Template);
  }

  /** Indique si le tooltip contient du contenu interactif (template). */
  public get IsInteractive(): boolean
  {
    return !!this.Template;
  }

  public get TooltipAriaLabel(): string
  {
    if (this.AriaLabel.trim().length > 0)
    {
      return this.AriaLabel;
    }
    if (this.Text.trim().length > 0)
    {
      return this.Text;
    }
    return this.Lines.map((lLine) => `${lLine.Label ? `${lLine.Label} : ` : ''}${lLine.Message}`).join('. ');
  }

  public get HostClasses(): string[]
  {
    return [
      'tooltip',
      `tooltip--${this.Position}`,
      `tooltip--${this.Variant}`,
      this.Disabled ? 'tooltip--disabled' : '',
      this.IsInteractive ? 'tooltip--interactive' : ''
    ].filter(Boolean);
  }

  public get BubbleClasses(): string[]
  {
    return [
      'tooltip__bubble',
      'tooltip__bubble--portal',
      this.IsInteractive ? 'tooltip__bubble--interactive' : ''
    ].filter(Boolean);
  }

  public get IsVisible(): boolean
  {
    return this._IsVisible;
  }
  //#endregion

  //#region CTOR
  constructor()
  {
    super();
    this._DestroyRef.onDestroy(() => this.Hide());
  }
  //#endregion

  //#region Visibility
  /**
   * Affiche la bulle dans un portail body et la positionne en fixed.
   */
  Show(): void
  {
    if (!this.HasTooltip || this._IsVisible) { return; }
    this.ClearHideTimer();
    this._IsVisible = true;
    this.AttachBubble();
    this.PositionBubble();
    this.AttachPositionListeners();
  }

  /**
   * Masque et détache la bulle du body.
   * En mode interactif, un petit délai permet de passer du trigger à la bulle sans clignotement.
   */
  Hide(): void
  {
    if (!this._IsVisible) { return; }
    this.ClearHideTimer();
    if (this.IsInteractive)
    {
      this._HideTimer = setTimeout(() => this.DoHide(), 120);
      return;
    }
    this.DoHide();
  }

  /**
   * Annule le masquage différé (appelé au survol de la bulle interactive).
   */
  OnBubbleEnter(): void
  {
    this.ClearHideTimer();
  }

  /**
   * Déclenche le masquage quand la souris quitte la bulle interactive.
   */
  OnBubbleLeave(): void
  {
    this.Hide();
  }

  private DoHide(): void
  {
    if (!this._IsVisible) { return; }
    this._IsVisible = false;
    this.DetachBubble();
    this.ClearPositionListeners();
  }

  private ClearHideTimer(): void
  {
    if (this._HideTimer)
    {
      clearTimeout(this._HideTimer);
      this._HideTimer = null;
    }
  }
  //#endregion

  //#region Portal
  /**
   * Attache la bulle au body via un portail CDK pour sortir de tout ancêtre overflow hidden.
   */
  private AttachBubble(): void
  {
    if (!this._BubbleTemplate) { return; }
    if (!this._BodyContainer)
    {
      this._BodyContainer = this._Renderer.createElement('div');
      this._Renderer.addClass(this._BodyContainer, 'tooltip-portal-container');
      this._Renderer.appendChild(document.body, this._BodyContainer);
    }
    const lBodyContainer: HTMLElement | null = this._BodyContainer;
    if (!lBodyContainer) { return; }
    if (!this._PortalOutlet)
    {
      this._PortalOutlet = new DomPortalOutlet(lBodyContainer, undefined, undefined);
    }
    if (!this._PortalOutlet.hasAttached())
    {
      this._Portal = new TemplatePortal<unknown>(this._BubbleTemplate, this._ViewContainerRef);
      this._PortalOutlet.attach(this._Portal);
    }
  }

  /**
   * Détache la bulle du portail body.
   */
  private DetachBubble(): void
  {
    if (this._PortalOutlet?.hasAttached())
    {
      this._PortalOutlet.detach();
    }
  }
  //#endregion

  //#region Positioning
  /**
   * Calcule et applique la position fixed de la bulle selon la position demandée et le viewport.
   */
  private PositionBubble(): void
  {
    if (!this._BodyContainer) { return; }
    const lBubble: HTMLElement | null = this._BodyContainer.querySelector('.tooltip__bubble');
    if (!lBubble) { return; }
    const lHostRect: DOMRect = this._ElementRef.nativeElement.getBoundingClientRect();
    const lBubbleRect: DOMRect = lBubble.getBoundingClientRect();
    const lSpacing: number = 10;
    let lTop: number = 0;
    let lLeft: number = 0;
    let lTransform: string = '';

    switch (this.Position)
    {
      case 'top':
        lTop = lHostRect.top - lBubbleRect.height - lSpacing;
        lLeft = lHostRect.left + lHostRect.width / 2;
        lTransform = 'translateX(-50%)';
        break;
      case 'bottom':
        lTop = lHostRect.bottom + lSpacing;
        lLeft = lHostRect.left + lHostRect.width / 2;
        lTransform = 'translateX(-50%)';
        break;
      case 'left':
        lTop = lHostRect.top + lHostRect.height / 2;
        lLeft = lHostRect.left - lBubbleRect.width - lSpacing;
        lTransform = 'translateY(-50%)';
        break;
      case 'right':
        lTop = lHostRect.top + lHostRect.height / 2;
        lLeft = lHostRect.right + lSpacing;
        lTransform = 'translateY(-50%)';
        break;
    }

    this._Renderer.setStyle(lBubble, 'position', 'fixed');
    this._Renderer.setStyle(lBubble, 'top', `${lTop}px`);
    this._Renderer.setStyle(lBubble, 'left', `${lLeft}px`);
    this._Renderer.setStyle(lBubble, 'transform', lTransform);
    this._Renderer.setStyle(lBubble, 'z-index', '10000');
  }

  /**
   * Attache les listeners de scroll/resize pour maintenir la bulle alignée au host.
   */
  private AttachPositionListeners(): void
  {
    this.ClearPositionListeners();
    this._WindowScrollCleanup = this._Renderer.listen('window', 'scroll', () => this.PositionBubble());
    this._WindowResizeCleanup = this._Renderer.listen('window', 'resize', () => this.PositionBubble());
  }

  /**
   * Nettoie les listeners de positionnement.
   */
  private ClearPositionListeners(): void
  {
    if (this._WindowScrollCleanup)
    {
      this._WindowScrollCleanup();
      this._WindowScrollCleanup = null;
    }
    if (this._WindowResizeCleanup)
    {
      this._WindowResizeCleanup();
      this._WindowResizeCleanup = null;
    }
  }
  //#endregion
}
