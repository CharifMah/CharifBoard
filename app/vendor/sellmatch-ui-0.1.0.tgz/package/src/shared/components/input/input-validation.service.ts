import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors, ValidatorFn, Validators, FormControl } from '@angular/forms';
import { IInputErrorContext, IInputValidationContext, InputType } from './input.types';

/**
 * Service responsable de la construction des validateurs et des messages d'erreur du composant app-input.
 * Stateless : chaque méthode reçoit le contexte du composant appelant.
 */
@Injectable()
export class InputValidationService {
  //#region Validators
  /**
   * Construit la liste des validateurs Angular pour un app-input selon son type et ses inputs.
   * @param pCtx Contexte de validation (type, min, max, required, etc.).
   * @returns La liste des validateurs à appliquer.
   */
  public BuildValidators(pCtx: IInputValidationContext): ValidatorFn[] {
    const lValidators: ValidatorFn[] = [];
    if (pCtx.required) lValidators.push(Validators.required);

    switch (pCtx.type) {
      case 'number':
        if (pCtx.min !== '' && pCtx.min !== null) lValidators.push(Validators.min(Number(pCtx.min)));
        if (pCtx.max !== '' && pCtx.max !== null) lValidators.push(Validators.max(Number(pCtx.max)));
        if (pCtx.maxLength !== null) lValidators.push(this.MaxDigitsValidator(pCtx.maxLength));
        break;
      case 'email':
        lValidators.push(Validators.email);
        if (pCtx.maxLength) lValidators.push(Validators.maxLength(pCtx.maxLength));
        break;
      case 'tel':
        lValidators.push(Validators.pattern(/^[+0-9\s\-(). ]*$/));
        if (pCtx.maxLength) lValidators.push(Validators.maxLength(pCtx.maxLength));
        break;
      case 'text':
      case 'password':
      case 'search':
        if (pCtx.minLength) lValidators.push(Validators.minLength(pCtx.minLength));
        if (pCtx.maxLength) lValidators.push(Validators.maxLength(pCtx.maxLength));
        break;
      case 'date':
        if (pCtx.min !== '') lValidators.push(this.DateMinValidator(String(pCtx.min)));
        if (pCtx.max !== '') lValidators.push(this.DateMaxValidator(String(pCtx.max)));
        break;
    }

    if (Array.isArray(pCtx.customValidators)) lValidators.push(...pCtx.customValidators);
    else if (pCtx.customValidators) lValidators.push(pCtx.customValidators);

    return lValidators;
  }

  /**
   * Validateur limitant le nombre de chiffres d'une valeur numérique.
   * @param pMaxDigits Nombre de chiffres autorisés.
   * @returns Le validateur Angular.
   */
  private MaxDigitsValidator(pMaxDigits: number): ValidatorFn {
    return (pCtrl: AbstractControl): ValidationErrors | null => {
      if (pCtrl.value === null || pCtrl.value === undefined || pCtrl.value === '') return null;
      const lDigits = String(Math.floor(Math.abs(Number(pCtrl.value)))).replace(/\D/g, '');
      return lDigits.length > pMaxDigits
        ? { maxDigits: { requiredDigits: pMaxDigits, actualDigits: lDigits.length } }
        : null;
    };
  }

  /**
   * Validateur de date minimale.
   * @param pMinDate Date minimale (ISO string).
   * @returns Le validateur Angular.
   */
  private DateMinValidator(pMinDate: string): ValidatorFn {
    return (pCtrl: AbstractControl): ValidationErrors | null =>
      pCtrl.value && new Date(pCtrl.value) < new Date(pMinDate)
        ? { dateMin: { min: pMinDate, actual: pCtrl.value } }
        : null;
  }

  /**
   * Validateur de date maximale.
   * @param pMaxDate Date maximale (ISO string).
   * @returns Le validateur Angular.
   */
  private DateMaxValidator(pMaxDate: string): ValidatorFn {
    return (pCtrl: AbstractControl): ValidationErrors | null =>
      pCtrl.value && new Date(pCtrl.value) > new Date(pMaxDate)
        ? { dateMax: { max: pMaxDate, actual: pCtrl.value } }
        : null;
  }
  //#endregion

  //#region Standalone validation
  /**
   * Calcule les erreurs d'un app-input utilisé en mode standalone (sans FormControl parent),
   * en exécutant la même chaîne de validateurs que BuildValidators sur un FormControl éphémère.
   * Permet d'afficher required/email/pattern/min/max/minlength/maxlength/maxDigits quand l'input
   * est piloté via [(value)]/valueChange (ex. playground, popups, formulaires ad hoc).
   * @param pType Type de l'input.
   * @param pValue Valeur courante (internalValue).
   * @param pCtx Contexte de validation (required, min, max, minLength, maxLength, customValidators).
   * @returns Erreurs Angular ou null si valide.
   */
  public BuildStandaloneErrors(
    pType: InputType,
    pValue: unknown,
    pCtx: IInputValidationContext
  ): ValidationErrors | null {
    // - cm - En mode select / multi-select / select-search / checkbox, la "valeur" est l'option/état
    // (null/undefined/"" = non sélectionné). Le validateur required posé par BuildValidators
    // gère déjà le cas null. Les validateurs textuels (email, pattern, minlength, maxlength)
    // retournent naturellement null sur chaîne vide, donc on n'a rien à filtrer.
    const lControl = new FormControl(pValue);
    const lValidators = this.BuildValidators({ ...pCtx, type: pType });
    lControl.setValidators(lValidators);
    // - cm - Indispensable : setValidators seul ne recalcule pas `lControl.errors`.
    // Sans updateValueAndValidity, la propriété reste à `null` (état initial du FormControl)
    // et les validateurs (required, email, minLength, etc.) ne se déclenchent jamais
    // en mode standalone (sans FormControl parent). emitEvent:false évite une cascade
    // de statusChanges inutile (le FormControl est éphémère, local à cet appel).
    lControl.updateValueAndValidity({ emitEvent: false });
    return lControl.errors;
  }
  //#endregion

  //#region Error messages
  /**
   * Construit le message d'erreur complet à partir des erreurs du contrôle.
   * @param pCtx Contexte des messages d'erreur personnalisés.
   * @param pErrors Erreurs Angular (null si valide).
   * @returns Le message formaté, ou chaîne vide si aucune erreur.
   */
  public BuildErrorMessage(pCtx: IInputErrorContext, pErrors: ValidationErrors | null): string {
    if (!pErrors) return '';
    return Object.keys(pErrors)
      .map(pKey => this.BuildSingleErrorMessage(pCtx, pKey, pErrors[pKey]))
      .join(' / ');
  }

  /**
   * Construit le message pour une erreur donnée, avec valeurs dynamiques.
   * @param pCtx Contexte des messages personnalisés.
   * @param pKey Clé de l'erreur.
   * @param pError Objet d'erreur Angular.
   * @returns Le message formaté.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Angular ValidationErrors uses any
  private BuildSingleErrorMessage(pCtx: IInputErrorContext, pKey: string, pError: any): string {
    // - cm - Message personnalisé fourni par le parent via errorMessages
    if (pCtx.errorMessages[pKey]) return pCtx.errorMessages[pKey];

    switch (pKey) {
      case 'required':
        return 'Ce champ est requis';
      case 'email':
        return 'Adresse email invalide';
      case 'pattern':
        return 'Format invalide';
      case 'minlength':
        return `Minimum ${pError.requiredLength} caractères`;
      case 'maxlength':
        // - cm - Affiche la longueur actuelle vs la limite pour guider l'utilisateur
        return `Maximum ${pError.requiredLength} caractères (saisi : ${pError.actualLength ?? '?'} )`;
      case 'maxDigits':
        return `Maximum ${pError.requiredDigits} chiffres autorisés`;
      case 'min':
        return `Valeur minimum : ${pError.min}`;
      case 'max':
        return `Valeur maximum : ${pError.max}`;
      case 'dateMin':
        return `Date minimum : ${pError.min}`;
      case 'dateMax':
        return `Date maximum : ${pError.max}`;
      case 'dto':
        // - cm - Message dynamique fourni par un validator DTO (adapter ToValidatorFn de la grid)
        return typeof pError === 'string' ? pError : 'Valeur invalide';
      default:
        return 'Valeur invalide';
    }
  }
  //#endregion
}
