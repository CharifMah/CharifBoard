// - cm - Helper pur : scroll keyboard-aware (vertical) + scroll horizontal pour grid.
// - cm - Pas de dépendance Angular : testable en isolation (Node.js + jsdom).
// - cm - Cf. context/frontend/ pour les conventions sellmatch.

/**
 * Scroll un élément DOM dans la zone réellement visible du viewport, en tenant
 * compte du clavier virtuel mobile (visualViewport) et des ancêtres scrollables
 * (axes X + Y) entre l'élément et `<html>`.
 *
 * **Axe vertical** : le clavier mobile (Android/iOS) réduit `visualViewport.height`.
 * Sans keyboard-aware, l'élément est techniquement "visible" (window.innerHeight
 * n'a pas changé) mais caché par le clavier. On utilise donc `visualViewport.height`
 * et `visualViewport.offsetTop` pour mesurer la zone réellement visible.
 *
 * **Axe horizontal** : la grid CRM a `.grid__scroll { overflow-x: auto }` pour
 * gérer les nombreuses colonnes (transactions, contacts, etc.). Une cellule dans
 * une colonne scrollée hors viewport horizontal doit être ramenée dans la zone
 * visible en ajustant `scrollLeft` du premier ancêtre scrollable.
 *
 * **Exception sticky** : si la cellule est dans une colonne `is-sticky-left` ou
 * `is-sticky-right` (grid SellMatch), elle est garantie visible horizontalement
 * via `position: sticky`. On saute alors le scroll horizontal — sans ça, le centrage
 * tire toute la table et fait disparaître la colonne sticky du viewport (août 2026,
 * KAN-grid sticky-right edit scroll bug).
 *
 * Stratégie :
 * 1. Mesure la zone visible = `visualViewport` (minus offset) sur mobile, sinon
 *    `window.innerHeight/Width` sur desktop.
 * 2. Pour chaque axe (X, Y), remonte l'arbre DOM et trouve le PREMIER ancêtre
 *    scrollable (`overflow-*: auto/scroll` avec scrollHeight/Width > clientHeight).
 * 3. Vertical : on ne scrolle que si l'élément sort vraiment de la zone visible
 *    (moitié basse + dépasse en haut + sort en bas, pour suivre le clavier virtuel).
 * 4. Horizontal : on ne scrolle que si l'élément sort vraiment à gauche ou à droite.
 *    Pas de re-centrage systématique : quand l'utilisateur a scrollé pour voir
 *    une cellule, on la laisse à sa position pour ne pas perturber la saisie.
 *
 * **Pourquoi un helper pur** : réutilisable hors `<app-input>` (popups, dialogs,
 * grid, etc.). `grid._ScrollCellIntoVisibleArea` dupliquait initialement la logique ;
 * elle délègue désormais à ce helper.
 *
 * @param pElement L'élément à rendre visible.
 * @param pBottomMargin Marge de sécurité en bas (px) — évite de coller au clavier.
 * @param pRightMargin Marge de sécurité à droite (px) — évite les faux positifs.
 * @returns True si un scroll a été appliqué, false si déjà visible.
 */
export function ScrollIntoVisibleArea(
  pElement: HTMLElement,
  pBottomMargin: number = 16,
  pRightMargin: number = 16
): boolean
{
  if (!pElement || !pElement.isConnected)
  {
    return false;
  }

  // - cm - 1) Calcule la zone visible du viewport (suit le clavier virtuel mobile).
  // - cm - visualViewport.height/width sont réduits sur mobile quand le clavier est visible.
  // - cm - Sur desktop, visualViewport.height == window.innerHeight.
  const lVisualVp: VisualViewport | null =
    (typeof window !== 'undefined' && (window as any).visualViewport)
      ? (window as any).visualViewport
      : null;
  const lViewportHeight: number = lVisualVp?.height ?? window.innerHeight;
  const lViewportWidth: number = lVisualVp?.width ?? window.innerWidth;
  const lViewportTop: number = lVisualVp?.offsetTop ?? 0;
  const lViewportLeft: number = lVisualVp?.offsetLeft ?? 0;
  const lViewportBottom: number = lViewportTop + lViewportHeight;
  const lViewportRight: number = lViewportLeft + lViewportWidth;

  // - cm - 2) Récupère le rectangle de l'élément dans le viewport (getBoundingClientRect).
  const lRect: DOMRect = pElement.getBoundingClientRect();
  const lElTop: number = lRect.top;
  const lElBottom: number = lRect.bottom;
  const lElLeft: number = lRect.left;
  const lElRight: number = lRect.right;

  let lScrolled: boolean = false;

  // - cm - 3) AXE VERTICAL : remonte l'arbre DOM, trouve le PREMIER ancêtre scrollable
  // - cm - verticalement, calcule le delta pour centrer l'élément dans la zone visible.
  const lVertScrollable: HTMLElement | null = FindFirstScrollableAncestor(
    pElement, 'overflowY', lViewportTop, lViewportBottom
  );
  if (lVertScrollable)
  {
    const lRectScrollable: DOMRect = lVertScrollable.getBoundingClientRect();
    const lVisibleTop: number = Math.max(lRectScrollable.top, lViewportTop);
    const lVisibleBottom: number = Math.min(lRectScrollable.bottom, lViewportBottom) - pBottomMargin;
    const lViewportMid: number = (lVisibleTop + lVisibleBottom) / 2;
    // - cm - Quick check assoupli (Brave mobile bug, août 2026) : on scroll si l'élément
    // - cm - est dans la moitié BASSE (clavier probable), MAIS on scroll aussi si
    // - cm - l'élément est sous la ligne médiane du viewport (même en moitié haute).
    // - cm - Cela garantit un scroll dès la moindre descente dans la zone visible,
    // - cm - même avant l'apparition du clavier. Le listener visualViewport.resize
    // - cm - re-tire après l'apparition du clavier et re-centre.
    const lElCenter: number = (lElTop + lElBottom) / 2;
    const lBelowMid: boolean = lElCenter >= lViewportMid;
    const lOutsideTop: boolean = lElTop < lVisibleTop;
    // - cm - 3 critères de scroll : (a) moitié basse, (b) dépasse en haut, (c) sort en bas.
    const lExitsBottom: boolean = lElBottom > lVisibleBottom;
    if (lBelowMid || lOutsideTop || lExitsBottom)
    {
      const lTargetCenter: number = (lVisibleTop + lVisibleBottom) / 2;
      const lDelta: number = lElCenter - lTargetCenter;
      const lNewScrollTop: number = lVertScrollable.scrollTop + lDelta;
      lVertScrollable.scrollTop = Math.max(
        0,
        Math.min(lNewScrollTop, lVertScrollable.scrollHeight - lVertScrollable.clientHeight)
      );
      lScrolled = true;
    }
  }

  // - cm - 4) AXE HORIZONTAL : ne scrolle que si l'élément sort vraiment de la zone
  // - cm - visible (à gauche ou à droite). On ne re-centre PAS systématiquement :
  // - cm - quand l'utilisateur a scrollé horizontalement pour voir une cellule dans
  // - cm - la moitié droite, on la laisse à sa position pour ne pas perturber la
  // - cm - saisie en pleine édition (août 2026, KAN-grid-edit-no-horizontal-jump).
  // - cm - Skip si la cellule est dans une colonne sticky (left/right) : elle est
  // - cm - garantie visible via `position: sticky`. On remonte les ancêtres <td>/<th>
  // - cm - pour détecter la classe CSS posée par la grid.
  if (!IsInStickyColumn(pElement))
  {
    const lHorScrollable: HTMLElement | null = FindFirstScrollableAncestor(
      pElement, 'overflowX', lViewportLeft, lViewportRight
    );
    if (lHorScrollable)
    {
      const lRectScrollable: DOMRect = lHorScrollable.getBoundingClientRect();
      const lVisibleLeft: number = Math.max(lRectScrollable.left, lViewportLeft);
      const lVisibleRight: number = Math.min(lRectScrollable.right, lViewportRight) - pRightMargin;
      const lOutsideLeft: boolean = lElLeft < lVisibleLeft;
      const lOutsideRight: boolean = lElRight > lVisibleRight;
      if (lOutsideLeft || lOutsideRight)
      {
        const lTargetCenter: number = (lVisibleLeft + lVisibleRight) / 2;
        const lElCenter: number = (lElLeft + lElRight) / 2;
        const lDelta: number = lElCenter - lTargetCenter;
        const lNewScrollLeft: number = lHorScrollable.scrollLeft + lDelta;
        lHorScrollable.scrollLeft = Math.max(
          0,
          Math.min(lNewScrollLeft, lHorScrollable.scrollWidth - lHorScrollable.clientWidth)
        );
        lScrolled = true;
      }
    }
  }

  return lScrolled;
}

/**
 * Détecte si l'élément est dans une colonne sticky (gauche ou droite) de la grid SellMatch.
 * Une cellule sticky est garantie visible horizontalement via `position: sticky`, donc
 * tout scroll horizontal serait nuisible (ferait sortir la colonne sticky du viewport).
 * Remonte les ancêtres jusqu'à trouver un <td> ou <th> avec classe `is-sticky-left`
 * ou `is-sticky-right` posée par la grid.
 *
 * @param pElement Élément à tester (typiquement la <td> ou son enfant éditeur).
 * @returns True si l'élément est dans une colonne sticky.
 */
function IsInStickyColumn(pElement: HTMLElement): boolean
{
  let lCurrent: HTMLElement | null = pElement;
  while (lCurrent && lCurrent !== document.documentElement)
  {
    if (lCurrent.classList?.contains('is-sticky-left') || lCurrent.classList?.contains('is-sticky-right'))
    {
      return true;
    }
    lCurrent = lCurrent.parentElement;
  }
  return false;
}

/**
 * Remonte l'arbre DOM depuis l'élément et retourne le PREMIER ancêtre scrollable
 * sur l'axe demandé (Y ou X). "Scrollable" = `overflow-y: auto/scroll` ET
 * `scrollHeight > clientHeight` (axe Y) ou `overflow-x: auto/scroll` ET
 * `scrollWidth > clientWidth` (axe X).
 *
 * @param pElement Élément de départ.
 * @param pAxis 'overflowY' ou 'overflowX'.
 * @param pViewportStart Début du viewport (offsetTop ou offsetLeft).
 * @param pViewportEnd Fin du viewport (height+offsetTop ou width+offsetLeft).
 * @returns Le premier ancêtre scrollable, ou null si aucun.
 */
function FindFirstScrollableAncestor(
  pElement: HTMLElement,
  pAxis: 'overflowY' | 'overflowX',
  pViewportStart: number,
  pViewportEnd: number
): HTMLElement | null
{
  let lCurrent: HTMLElement | null = pElement.parentElement;
  while (lCurrent && lCurrent !== document.documentElement)
  {
    const lStyle: CSSStyleDeclaration = getComputedStyle(lCurrent);
    const lOverflow: string = pAxis === 'overflowY' ? lStyle.overflowY : lStyle.overflowX;
    if (lOverflow === 'auto' || lOverflow === 'scroll')
    {
      if (pAxis === 'overflowY' && lCurrent.scrollHeight > lCurrent.clientHeight)
      {
        return lCurrent;
      }
      if (pAxis === 'overflowX' && lCurrent.scrollWidth > lCurrent.clientWidth)
      {
        return lCurrent;
      }
    }
    lCurrent = lCurrent.parentElement;
  }
  // - cm - Référencer les paramètres non utilisés pour calmer le linter TS6133.
  void pViewportStart;
  void pViewportEnd;
  return null;
}