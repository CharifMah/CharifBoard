import {
  Component,
  ChangeDetectionStrategy,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  ElementRef,
  inject
} from '@angular/core';
import { FormControl, NgControl, ValidatorFn } from '@angular/forms';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { AdressesDTO } from '../../../core/sellmatchdb/dto';
import { IInputOption, InputType } from './input.types';

/**
 * Classe de base abstraite pour le composant app-input.
 * Centralise les @Input, @Output et l'état partagé entre tous les modes d'édition.
 * Le composant concret hérite de cette base et délègue la logique métier aux services dédiés.
 */
@Component({
  changeDetection: ChangeDetectionStrategy.Eager,
  template: ''
})
export abstract class InputBase extends BaseComponent {
  //#region Inputs
  @Input() value: any = '';
  /** Émet la valeur lors d'un changement two-way binding. */
  @Output() valueChange = new EventEmitter<any>();
  @Input() label: string = '';
  @Input() placeholder: string = '';
  @Input() type: InputType = 'text';
  @Input() hint: string = '';
  @Input() suffix: string = '';
  @Input() prefix: string = '';
  @Input() min: number | string = '';
  @Input() max: number | string = '';
  @Input() step: number | string = '';
  @Input() required: boolean = false;
  @Input() readonly: boolean = false;
  @Input() disabled: boolean = false;
  @Input() showCharCount: boolean = false;
  @Input() maxLength: number | null = null;
  @Input() minLength: number | null = null;
  @Input() autofocus: boolean = false;
  @Input() name: string = '';
  @Input() id: string = '';
  @Input() autocomplete: string = '';
  @Input() iconLeft: string = '';
  @Input() iconRight: string = '';
  @Input() customValidators: ValidatorFn | ValidatorFn[] = [];
  @Input() errorMessages: Record<string, string> = {};
  /** Affiche les erreurs dès la saisie (sans attendre la perte de focus). Opt-in, utilisé par la grid inline. */
  @Input() immediateValidation: boolean = false;
  @Input() isAddressAutocomplete: boolean = false;
  // - cm - Support mode select / select-search
  @Input() options: IInputOption[] = [];
  @Input() placeholderOption: string = 'Tous';
  // - cm - Support mode checkbox
  @Input() checked: boolean = false;
  /** État indeterminate de la checkbox (pour les en-têtes "tout sélectionner"). */
  @Input() indeterminate: boolean = false;
  /** Rendu compact (sans bordure/marge) pour intégration dans des cellules de grille ou menus denses. */
  @Input() compact: boolean = false;
  /** Taille du champ : 'sm' (compact, hauteur 32px), 'md' (défaut 40px), 'lg' (48px). Réutilisable. */
  @Input() size: 'sm' | 'md' | 'lg' = 'md';
  @Output() inputBlurred = new EventEmitter<Event>();
  @Output() inputFocused = new EventEmitter<Event>();
  @Output() iconRightClick = new EventEmitter<void>();
  @Output() iconLeftClick = new EventEmitter<void>();
  //#endregion

  //#region State
  /** Valeur interne du CVA. */
  public internalValue: any = '';
  /** FormControl lié quand app-input est utilisé avec [formControl] / ngModel. */
  public control: FormControl | null = null;
  public touched: boolean = false;
  public passwordVisible: boolean = false;
  public addressSuggestions: AdressesDTO[] = [];
  /** Convertit une valeur en chaîne pour la comparaison dans le template (select custom). */
  protected readonly Str = (pValue: unknown): string => String(pValue);
  public isSearching: boolean = false;
  /** Timeout de debounce pour l'autocomplétion d'adresse. */
  public searchTimeout: ReturnType<typeof setTimeout> | null = null;
  public searchControl = new FormControl('');
  /** Requête de saisie courante pour le mode select-search (combobox filtrante). */
  public searchQuery: string = '';
  /** Indique si le dropdown du mode select-search est ouvert. */
  public searchOpen: boolean = false;
  /** Indique si le dropdown du mode select (custom) est ouvert. */
  public selectOpen: boolean = false;
  /** Indique si le dropdown du mode multi-select est ouvert. */
  public multiSelectOpen: boolean = false;
  /** Styles inline appliqués au dropdown du mode multi-select. */
  public multiSelectDropdownStyles: Record<string, string> = {};
  /** Référence au wrapper du select custom (positionnement du dropdown). */
  @ViewChild('selectWrapper', { static: false }) protected readonly _SelectWrapper!: ElementRef<HTMLElement>;

  /** Contrôle Angular lié (optionnel). */
  protected readonly _NgControl = inject(NgControl, { self: true, optional: true });
  //#endregion

  //#region CVA stubs
  /** Callback CVA enregistré par le FormControlDirective. */
  public onChange = (_: any): void => { };
  /** Callback CVA "touched" enregistré par le FormControlDirective. */
  public onTouched = (): void => { };
  //#endregion
}
