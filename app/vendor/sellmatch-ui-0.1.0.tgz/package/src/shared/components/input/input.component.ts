import
{
  Component, inject,
  OnInit, AfterViewInit, OnChanges, SimpleChanges,
  ChangeDetectionStrategy,
  OnDestroy,
  ElementRef, ViewChild
} from '@angular/core';

import
{
  ControlValueAccessor, FormControl,
  FormsModule, ReactiveFormsModule,
  ValidationErrors, Validators
} from '@angular/forms';
import { OverlayModule, Overlay, CdkOverlayOrigin, ConnectedPosition } from '@angular/cdk/overlay';
import { AdressesDTO } from '../../../core/sellmatchdb/dto';
import { InputBase } from './input-base';
import { InputValidationService } from './input-validation.service';
import { AdressesService } from '../../../core/sellmatchdb/services/adresses/adresses.service';
import { InputDropdownPositionService } from './input-dropdown-position.service';
import { ButtonComponent } from '../../../shared/components/button/button.component';
import { IInputOption, IInputOptionVisual } from './input.types';
import {
  HasOptionVisual as _HasOptionVisualHelper,
  OptionVariant as _OptionVariantHelper,
  ResolveOptionVisual as _ResolveOptionVisualHelper,
  ResolveSelectedOptionVisual,
  ResolveSelectedLabel
} from './helpers/input-select.helper';
import {
  NormalizeMultiSelectValue as _NormalizeMultiSelectValue,
  MultiSelectSummary,
  IsMultiSelected as _IsMultiSelected,
  ToggleMultiSelectOption as _ToggleMultiSelectOption
} from './helpers/input-multi-select.helper';
import {
  FilterSearchOptions,
  SearchLabel
} from './helpers/input-select-search.helper';
import { ScrollIntoVisibleArea } from './helpers/input-scroll-into-view.helper';

@Component({
  selector: 'app-input',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, OverlayModule, ButtonComponent],
  templateUrl: './input.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrls: ['./input.component.scss'],
  providers: [InputValidationService, InputDropdownPositionService]
})
export class InputComponent extends InputBase
  implements OnInit, AfterViewInit, OnChanges, OnDestroy, ControlValueAccessor
{
  //#region Services
  /**
   * Service d'adresses (public pour permettre l'appel à BuildLabel depuis le template
   * lors du rendu des suggestions d'autocomplétion).
   */
  public readonly _AddressService = inject(AdressesService);
  private readonly _ValidationService = inject(InputValidationService);
  private readonly _PositionService = inject(InputDropdownPositionService);
  /** Service CDK Overlay (utilisé via la directive cdkConnectedOverlay dans le template). */
  private readonly _Overlay = inject(Overlay);
  /** Référence à l'élément hôte du composant (utilisée pour le scroll keyboard-aware). */
  private readonly _Host = inject(ElementRef<HTMLElement>);
  /** Handler de l'événement visualViewport.resize (clavier mobile qui s'ouvre/ferme). */
  private _VisualViewportResizeHandler: (() => void) | null = null;
  //#endregion

  //#region CTOR
  constructor()
  {
    super();
    if (this._NgControl)
    {
      this._NgControl.valueAccessor = this;
      this.control = this._NgControl.control as FormControl;
    }
  }
  //#endregion

  //#region Lifecycle
  ngOnInit(): void
  {
    if (!this.id) this.id = `input-${Math.random().toString(36).substring(2, 9)}`;
    if (this.type === 'password' && !this.iconRight) this.iconRight = 'visibility_off';

    if (this.isAddressAutocomplete && this.internalValue)
    {
      this.searchControl.setValue(this._AddressService.BuildLabel(this.internalValue), { emitEvent: false });
    }

    if (this.type === 'select-search' && this.internalValue)
    {
      this.searchQuery = SearchLabel(this.internalValue, this.options);
    }

    if (this.type === 'multi-select')
    {
      this.internalValue = this.NormalizeMultiSelectValue(this.internalValue);
    }

    this.syncSearchControlValidators();
  }

  ngAfterViewInit(): void
  {
    if (this._NgControl?.control)
      this.applyReactiveValidators();
    // - cm - Initialise la largeur du popup d'adresse après le rendu du DOM.
    // - cm - microtask (Promise.resolve) attend que le browser ait fait le layout
    // - cm - (flex, min-width:0) pour que getBoundingClientRect().width retourne la
    // - cm - vraie largeur de l'input dans sa cellule de grid. Sans ça,
    // - cm - addressOverlayWidth reste à 0 jusqu'au premier focus, et le popup
    // - cm - s'ouvre étroit la première fois. On utilise une microtask et pas un
    // - cm - setTimeout(0) pour rester cohérent avec la règle "pas de timeout en dur".
    if (this.isAddressAutocomplete)
    {
      void Promise.resolve().then(() => this.UpdateAddressOverlayWidth());
    }
  }

  /**
   * Nettoie les ressources à la destruction du composant.
   */
  ngOnDestroy(): void
  {
    // - cm - Libère les listeners de positionnement du dropdown
    this._PositionService.Clear();
    // - cm - Détache le listener visualViewport.resize (sécurité : le composant
    // - cm - peut être détruit pendant qu'il a le focus, ex. navigation away).
    this._DetachVisualViewportListener();
  }

  /**
   * Détecte les changements sur les inputs du composant.
   * @param pChanges Les changements détectés
   */
  ngOnChanges(pChanges: SimpleChanges): void
  {
    // - cm - Synchronise la valeur externe [value] vers internalValue (binding two-way sans formControl)
    if (pChanges['value'])
    {
      this.internalValue = pChanges['value'].currentValue;
      if (this.type === 'checkbox')
      {
        this.checked = !!this.internalValue;
      }
      if (this.type === 'select-search')
      {
        this.searchQuery = SearchLabel(this.internalValue, this.options);
      }

      if (this.type === 'multi-select')
      {
        this.internalValue = this.NormalizeMultiSelectValue(this.internalValue);
      }

      if (this.isAddressAutocomplete)
      {
        this.searchControl.setValue(this._AddressService.BuildLabel(this.internalValue), { emitEvent: false });
      }
    }

    // - cm - Synchronise l'état disabled du FormControl avec l'input
    if (pChanges['disabled'])
    {
      const lControl = this._NgControl?.control;
      if (lControl)
      {
        pChanges['disabled'].currentValue ? lControl.disable() : lControl.enable();
      }
      if (this.isAddressAutocomplete)
      {
        pChanges['disabled'].currentValue ? this.searchControl.disable() : this.searchControl.enable();
      }
    }

    const lConstraintKeys = ['min', 'max', 'maxLength', 'minLength', 'required', 'customValidators'];
    const lHasConstraintChange = lConstraintKeys.some(k => pChanges[k]);
    if (!lHasConstraintChange && !pChanges['disabled']) return;
    if (this._NgControl?.control)
    {
      this.applyReactiveValidators();
    }
    if (pChanges['required'] && this.isAddressAutocomplete)
    {
      this.syncSearchControlValidators();
    }
  }
  //#endregion

  //#region Date picker placeholder
  /** Indique si le date picker natif est actif (focus) pour un input de type date. */
  private _IsDatePickerActive = false;

  /**
   * Retourne le placeholder effectif, avec valeur par défaut MM/DD/YYYY pour les champs date vides.
   * @returns Le placeholder à afficher.
   */
  protected get EffectivePlaceholder(): string
  {
    if (this.type === 'date' && !this.placeholder) return 'MM/DD/YYYY';
    return this.placeholder;
  }

  /**
   * Indique si le champ doit être en lecture seule pour forcer l'ouverture du date picker natif
   * quand le placeholder est affiché (type date vide sans focus).
   * @returns True si le champ est en mode placeholder date.
   */
  protected IsDatePlaceholderReadonly(): boolean
  {
    return this.type === 'date' && !this._IsDatePickerActive && !this.internalValue;
  }
  //#endregion

  //#region CVA
  writeValue(pValue: any): void
  {
    this.internalValue = pValue;

    // - cm - Sync checkbox state
    if (this.type === 'checkbox')
    {
      this.checked = !!pValue;
    }

    if (this.isAddressAutocomplete)
    {
      // cm - On affiche TOUJOURS une string, jamais l'objet (sinon [object Object]).
      this.searchControl.setValue(this._AddressService.BuildLabel(pValue), { emitEvent: false });
    }

    if (this.type === 'select-search')
    {
      this.searchQuery = SearchLabel(pValue, this.options);
    }

    if (this.type === 'multi-select')
    {
      this.internalValue = this.NormalizeMultiSelectValue(pValue);
    }
  }

  registerOnChange(pFn: any): void { this.onChange = pFn; }
  registerOnTouched(pFn: any): void { this.onTouched = pFn; }
  setDisabledState(pIsDisabled: boolean): void { this.disabled = pIsDisabled; }
  //#endregion

  //#region Text / number / date
  /**
   * Gère la saisie des inputs standards et applique les limitations de longueur.
   * @param pEvent L'événement input.
   */
  onInputEvent(pEvent: Event): void
  {
    if (this.maxLength === null) return;

    const lTarget = pEvent.target as HTMLInputElement;

    // Cas spécifique : nombres → on limite le nombre de chiffres
    if (this.type === 'number')
    {
      const lRawValue = lTarget.value;
      const lDigits = lRawValue.replace(/\D/g, '');
      if (lDigits.length > this.maxLength)
      {
        lTarget.value = lRawValue.slice(0, this.maxLength);
      }
      return;
    }

    // Cas textuels → on limite le nombre de caractères
    if (this.isTextLike() && lTarget.value.length > this.maxLength)
    {
      lTarget.value = lTarget.value.slice(0, this.maxLength);

      // On resynchronise le modèle et le FormControl avec la valeur tronquée
      this.internalValue = lTarget.value;
      this.onChange(this.internalValue);
      this.valueChange.emit(this.internalValue);
    }
  }

  /**
   * Bloque la frappe au-delà de la limite de caractères.
   * @param pEvent L'événement keydown.
   */
  onKeyDown(pEvent: KeyboardEvent): void
  {
    if (this.maxLength === null) return;

    const lTarget = pEvent.target as HTMLInputElement;

    const lAllowedKeys = [
      'Backspace', 'Delete', 'Tab', 'Enter', 'Escape',
      'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'
    ];

    // On laisse passer les touches de navigation/suppression et les raccourcis (Ctrl/Cmd)
    if (lAllowedKeys.includes(pEvent.key) || pEvent.ctrlKey || pEvent.metaKey) return;

    // Si une partie du texte est sélectionnée, la frappe remplacera la sélection → on laisse passer
    const lHasSelection = lTarget.selectionStart !== lTarget.selectionEnd;
    if (lHasSelection) return;

    if (this.type === 'number')
    {
      // Pour les nombres on autorise aussi le point et le signe moins
      if (pEvent.key === '.' || pEvent.key === '-') return;
      const lDigits = lTarget.value.replace(/\D/g, '');
      if (lDigits.length >= this.maxLength) pEvent.preventDefault();
    }
    else if (this.isTextLike())
    {
      if (lTarget.value.length >= this.maxLength) pEvent.preventDefault();
    }
  }

  /**
   * Propage les changements de modèle avec formatage maxLength.
   * @param pNewValue La nouvelle valeur saisie.
   */
  onModelChange(pNewValue: any): void
  {
    let lFormattedValue = pNewValue;

    // Limitation pour les nombres (sur le nombre de chiffres)
    if (this.type === 'number' && this.maxLength !== null && lFormattedValue !== null && lFormattedValue !== undefined)
    {
      const lDigits = String(lFormattedValue).replace(/\D/g, '');
      if (lDigits.length > this.maxLength)
      {
        lFormattedValue = Number(String(lFormattedValue).slice(0, this.maxLength));
      }
    }

    // Limitation pour les types textuels (sur le nombre de caractères)
    if (this.isTextLike() && this.maxLength !== null && typeof lFormattedValue === 'string')
    {
      if (lFormattedValue.length > this.maxLength)
      {
        lFormattedValue = lFormattedValue.slice(0, this.maxLength);
      }
    }

    this.internalValue = this.type === 'number'
      ? (lFormattedValue === '' || lFormattedValue === null ? null : Number(lFormattedValue))
      : lFormattedValue;

    this.onChange(this.internalValue);
    this.valueChange.emit(this.internalValue);
  }

  /**
   * Détermine si le type courant est un champ textuel (soumis à maxLength caractères).
   * @returns True si le type est textuel.
   */
  private isTextLike(): boolean
  {
    return this.type === 'text'
      || this.type === 'email'
      || this.type === 'password'
      || this.type === 'tel'
      || this.type === 'search'
      || this.type === 'textarea';
  }

  /**
   * Retourne le type HTML effectif (gère le password visible).
   * @returns Le type d'input HTML.
   */
  getInputType(): string
  {
    if (this.type === 'password' && this.passwordVisible) return 'text';
    // - cm - Type texte quand le date picker est vide et sans focus pour afficher le placeholder MM/DD/YYYY
    if (this.type === 'date' && !this._IsDatePickerActive && !this.internalValue) return 'text';
    return this.type;
  }
  //#endregion

  //#region Focus / blur / icons
  /**
   * Gère la perte de focus du champ.
   * @param pEvent L'événement blur.
   */
  onInputBlur(pEvent: Event): void
  {
    this.touched = true;
    this.onTouched();
    // - cm - Ferme l'autocomplétion d'adresse au blur (évite une liste orpheline)
    if (this.isAddressAutocomplete)
    {
      this.CloseAddressOverlay();
    }
    // - cm - Réactive le placeholder MM/DD/YYYY quand un date picker vide perd le focus
    if (this.type === 'date' && !this.internalValue)
    {
      this._IsDatePickerActive = false;
    }
    // - cm - Détache le listener visualViewport.resize (le clavier n'est plus pertinent hors focus).
    this._DetachVisualViewportListener();
    this.inputBlurred.emit(pEvent);
    this.PostHog.Capture(this.BuildTrackingName('input_blur', 'tracking'), { field: this.name || this.id });
  }

  /**
   * Gagne le focus du champ.
   * @param pEvent L'événement focus.
   */
  onInputFocus(pEvent: Event): void
  {
    // - cm - Active le date picker natif au focus d'un champ date
    if (this.type === 'date')
    {
      this._IsDatePickerActive = true;
    }
    // - cm - Recalcule la largeur du popup d'adresse au focus : l'input peut avoir
    // - cm - été rendu dans une cellule de grid dont la largeur a changé (resize de
    // - cm - colonne, scroll horizontal, ajout/retrait de colonnes sticky). Sans
    // - cm - ce recalcul, addressOverlayWidth reste à 0 (valeur initiale) ou à une
    // - cm - valeur stale, et le CDK Overlay s'ouvre avec une largeur étroite vide.
    if (this.isAddressAutocomplete)
    {
      this.UpdateAddressOverlayWidth();
    }
    // - cm - Scroll keyboard-aware : sur mobile, l'apparition du clavier virtuel
    // - cm - (Android/iOS) peut masquer l'input. On remonte les ancêtres scrollables,
    // - cm - on tient compte de `visualViewport.height` (réduit quand le clavier est
    // - cm - visible), et on centre l'élément hôte dans la zone réellement visible.
    // - cm - Quick check (helper) : si déjà entièrement visible, on ne scrolle pas
    // - cm - (évite les micro-scrolls inutiles sur desktop).
    this._ScrollHostIntoVisibleArea();
    // - cm - Branche un listener sur visualViewport.resize : le clavier mobile anime
    // - cm - son apparition sur 200-300ms, et l'événement resize tire quand la zone
    // - cm - visible change (clavier qui s'ouvre, ferme, ou se déplace). On re-scrolle
    // - cm - à chaque tire pour suivre l'animation, sans timer fixe. Le listener
    // - cm - est nettoyé au blur et au ngOnDestroy.
    this._AttachVisualViewportListener();
    this.inputFocused.emit(pEvent);
    this.PostHog.Capture(this.BuildTrackingName('input_focus', 'tracking'), { field: this.name || this.id });
  }

  /**
   * Branche un listener visualViewport.resize qui re-scrolle l'élément hôte
   * à chaque changement de viewport visuel (clavier mobile). No-op si déjà branché
   * ou si visualViewport n'est pas supporté (vieux navigateurs desktop).
   */
  private _AttachVisualViewportListener(): void
  {
    if (this._VisualViewportResizeHandler)
    {
      return;
    }
    if (typeof window === 'undefined' || !(window as any).visualViewport)
    {
      return;
    }
    this._VisualViewportResizeHandler = (): void => this._ScrollHostIntoVisibleArea();
    (window as any).visualViewport.addEventListener('resize', this._VisualViewportResizeHandler);
  }

  /**
   * Détache le listener visualViewport.resize s'il était branché. Idempotent.
   */
  private _DetachVisualViewportListener(): void
  {
    if (!this._VisualViewportResizeHandler)
    {
      return;
    }
    if (typeof window !== 'undefined' && (window as any).visualViewport)
    {
      (window as any).visualViewport.removeEventListener('resize', this._VisualViewportResizeHandler);
    }
    this._VisualViewportResizeHandler = null;
  }

  /**
   * Délègue au helper pur pour scroller l'élément hôte dans la zone visible
   * keyboard-aware. Marge bas de 16px (padding standard) pour éviter de coller
   * l'input au clavier. Émet en silence si déjà visible ou non connecté au DOM.
   */
  private _ScrollHostIntoVisibleArea(): void
  {
    ScrollIntoVisibleArea(this._Host.nativeElement, 16);
  }

  /**
   * Gère le clic sur l'icône droite.
   */
  onIconRightClicked(): void
  {
    if (this.type === 'password')
    {
      this.passwordVisible = !this.passwordVisible;
      this.iconRight = this.passwordVisible ? 'visibility' : 'visibility_off';
    }
    else
    {
      this.iconRightClick.emit();
    }
    this.PostHog.Capture(this.BuildTrackingName('icon_right', 'tracking'), { field: this.name || this.id });
  }

  /**
   * Gère le clic sur l'icône gauche.
   */
  onIconLeftClicked(): void
  {
    this.iconLeftClick.emit();
    this.PostHog.Capture(this.BuildTrackingName('icon_left', 'tracking'), { field: this.name || this.id });
  }
  //#endregion

  //#region Checkbox
  /**
   * Gère le changement d'état d'une checkbox.
   * @param pChecked L'état coché/décoché
   */
  onCheckboxChange(pChecked: boolean): void
  {
    this.checked = pChecked;
    this.internalValue = pChecked;
    this.onChange(pChecked);
    this.valueChange.emit(pChecked);
  }
  //#endregion

  //#region Textarea
  /**
   * Gère la saisie d'un textarea : auto-grow de la hauteur + application de la limite maxLength.
   * @param pEvent L'événement input.
   */
  onTextareaInput(pEvent: Event): void
  {
    this.autoGrow(pEvent);
    this.onInputEvent(pEvent);
  }

  /**
   * Ajuste la hauteur d'un textarea selon son contenu (auto-grow).
   * @param pEvent L'événement input.
   */
  private autoGrow(pEvent: Event): void
  {
    const lEl: HTMLTextAreaElement = pEvent.target as HTMLTextAreaElement;
    lEl.style.height = 'auto';
    lEl.style.height = `${lEl.scrollHeight}px`;
  }
  //#endregion

  //#region Address autocomplete
  /** Référence à l'input d'autocomplétion d'adresse (origine de l'overlay). */
  @ViewChild('addressInput', { static: false }) protected readonly _AddressInput!: ElementRef<HTMLInputElement>;

  /**
   * Positions de l'overlay d'autocomplétion (sous l'input par défaut, décalé de 2px).
   * - cm - Le CDK Overlay essaie chaque position dans l'ordre et prend la première
   * - cm - qui rentre entièrement dans le viewport. L'ordre ci-dessous couvre :
   * - cm -   1. sous l'input, aligné à gauche (cas par défaut)
   * - cm -   2. sous l'input, aligné à droite de l'input (fallback si l'input est
   * - cm -      près du bord gauche du viewport et que la largeur du popup
   * - cm -      (>= addressOverlayMinWidth = 280px) déborde à gauche)
   * - cm -   3. au-dessus de l'input, aligné à gauche (pas de place en bas)
   * - cm -   4. au-dessus de l'input, aligné à droite (pas de place en bas ET à gauche)
   * - cm - Sans les fallbacks 2 et 4, un input collé au bord gauche coupait le
   * - cm - popup à gauche (item tronqué, icône pin invisible). Reproductible
   * - cm - sur la page CRM /contacts avec le filtre ADRESSE en 1re colonne.
   */
  public readonly AddressOverlayPositions: ConnectedPosition[] = [
    {
      originX: 'start',
      originY: 'bottom',
      overlayX: 'start',
      overlayY: 'top',
      offsetY: 2
    },
    {
      originX: 'end',
      originY: 'bottom',
      overlayX: 'end',
      overlayY: 'top',
      offsetY: 2
    },
    {
      originX: 'start',
      originY: 'top',
      overlayX: 'start',
      overlayY: 'bottom',
      offsetY: -2
    },
    {
      originX: 'end',
      originY: 'top',
      overlayX: 'end',
      overlayY: 'bottom',
      offsetY: -2
    }
  ];

  /** Largeur de l'overlay d'adresse, synchronisée avec l'input. */
  public addressOverlayWidth: number = 0;

  /**
   * Largeur minimale du popup d'adresse, en pixels.
   * Garantit qu'une cellule de grid étroite ou un container flex avec min-width:0
   * ne rendent pas le popup "tout resserré" : on force au moins 280px pour garder
   * les libellés d'adresse lisibles (rue, code postal, ville) même quand l'input
   * source est très étroit (ex : cellule de grid 1/12 d'un FilterBar 12-cols).
   * - cm - Lié à [cdkConnectedOverlayMinWidth] dans input.component.html.
   */
  public readonly addressOverlayMinWidth: number = 280;

  /** Indique si une recherche a été lancée et n'a pas abouti à des résultats (utilisé pour le message "Aucun résultat"). */
  public hasSearched: boolean = false;

  /**
   * Recalcule la largeur de l'overlay pour correspondre à l'input.
   */
  private UpdateAddressOverlayWidth(): void
  {
    const lInput = this._AddressInput?.nativeElement;
    if (!lInput) return;
    // - cm - Largeur réelle de l'input (bounding rect). Dans une cellule de grid,
    // - cm - l'input est contraint par la largeur de la colonne — getBoundingClientRect
    // - cm - retourne la largeur effective après layout (flex, min-width:0, etc.).
    const lWidth: number = lInput.getBoundingClientRect().width;
    // - cm - Largeur effective de l'overlay : on prend le max entre la largeur de
    // - cm - l'input (alignement parfait quand l'input est large) et la largeur
    // - cm - minimale lisible (280px). Cela évite qu'une cellule de grid étroite
    // - cm - (< 280px) rende le popup "tout resserré" : le popup s'étend alors
    // - cm - au-delà de la cellule pour rester lisible. La sécurité ceinture est
    // - cm - aussi côté SCSS (.cdk-overlay-pane .suggestions-list { min-width: 280px })
    // - cm - pour le cas où le pane CDK est attaché avec une largeur 0 (valeur par
    // - cm - défaut) avant que ce recalcul ne soit appelé — sans ce filet, le pane
    // - cm - héritait de la largeur intrinsèque de son contenu (≈ 15px) et le popup
    // - cm - s'affichait comme une fine bande verticale.
    if (lWidth > 0)
    {
      this.addressOverlayWidth = Math.max(lWidth, this.addressOverlayMinWidth);
    }
    else
    {
      const lWrapper: HTMLElement | null = lInput.closest('.autocomplete-wrapper') ?? lInput.closest('.input-wrapper');
      const lFallback: number = lWrapper?.getBoundingClientRect().width ?? 0;
      this.addressOverlayWidth = lFallback > 0 ? Math.max(lFallback, this.addressOverlayMinWidth) : this.addressOverlayMinWidth;
    }
  }

  /**
   * Déclenche la recherche d'adresses après un debounce.
   * @param pValue Texte saisi.
   */
  onAddressInput(pValue: string): void
  {
    // - cm - Mise à jour visuelle uniquement, pas de propagation du modèle
    this.addressSuggestions = [];

    // - cm - Recalcule la largeur du popup dès la première frappe : dans une grid,
    // - cm - l'input peut avoir été rendu avec une largeur différente depuis le
    // - cm - dernier focus (resize de colonne, scroll horizontal). Sans ce recalcul,
    // - cm - le popup s'ouvre avec la largeur stale du dernier UpdateAddressOverlayWidth.
    this.UpdateAddressOverlayWidth();

    if (!pValue || pValue.length < 3)
    {
      this.hasSearched = false;
      this.isSearching = false;
      return;
    }

    if (this.searchTimeout) clearTimeout(this.searchTimeout);
    this.hasSearched = true;
    this.searchTimeout = setTimeout(async () =>
    {
      this.isSearching = true;
      this.addressSuggestions = await this._AddressService.SearchAsync(pValue);
      this.UpdateAddressOverlayWidth();
      this.isSearching = false;
    }, 300);
  }

  /**
   * Ouvre ou ferme la liste de suggestions d'adresses au clic sur le bouton dédié.
   * Si la liste est fermée et qu'une recherche est possible (≥3 caractères saisis),
   * relance immédiatement la recherche pour rafraîchir les résultats.
   */
  OnToggleAddressList(): void
  {
    if (!this.isAddressAutocomplete)
    {
      return;
    }

    // - cm - Si la liste est déjà ouverte (résultats OU chargement en cours), on la ferme.
    if (this.addressSuggestions.length > 0 || this.isSearching)
    {
      this.CloseAddressOverlay();
      return;
    }

    // - cm - Liste fermée : on tente de rouvrir avec la valeur courante du champ.
    const lValue: string = (this.searchControl.value ?? '').toString();
    if (!lValue || lValue.length < 3)
    {
      return; // - cm - Pas de recherche possible, on laisse la liste fermée.
    }

    if (this.searchTimeout) clearTimeout(this.searchTimeout);
    this.hasSearched = true;
    this.searchTimeout = setTimeout(async () =>
    {
      this.isSearching = true;
      this.addressSuggestions = await this._AddressService.SearchAsync(lValue);
      this.UpdateAddressOverlayWidth();
      this.isSearching = false;
    }, 0);
  }

  /**
   * Gère le mousedown sur une suggestion d'adresse pour empêcher le blur de fermer la liste avant le clic.
   * @param pEvent L'événement souris.
   * @param pAddress L'adresse sélectionnée.
   */
  OnAddressItemMouseDown(pEvent: MouseEvent, pAddress: AdressesDTO): void
  {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    this.SelectAddress(pAddress);
  }

  /**
   * Sélectionne une adresse et propage la valeur.
   * Le DTO arrive déjà complet avec les coordonnées (Mapbox /forward renvoie tout en une fois).
   * @param pAddress L'adresse sélectionnée.
   */
  SelectAddress(pAddress: AdressesDTO): void
  {
    this.internalValue = pAddress;
    this.searchControl.setValue(this._AddressService.BuildLabel(pAddress), { emitEvent: false });
    this.onChange(pAddress);
    this.valueChange.emit(pAddress);
    this.hasSearched = false;
    this.CloseAddressOverlay();

    this.PostHog.Capture(this.BuildTrackingName('adresse_selectionnee', 'tracking'), {
      city: pAddress.city,
      postalCode: pAddress.postcode
    });
  }

  /**
   * Ferme la liste de suggestions d'adresse et réinitialise l'état de recherche.
   */
  CloseAddressOverlay(): void
  {
    this.addressSuggestions = [];
    this.hasSearched = false;
    if (this.searchTimeout)
    {
      clearTimeout(this.searchTimeout);
      this.searchTimeout = null;
    }
    this.isSearching = false;
  }

  /**
   * Retourne l'icône Material Icons correspondant au type de feature Mapbox.
   * Permet d'afficher un badge visuel distinct par catégorie (adresse, rue, ville, code postal).
   * @param pAddress L'adresse pour laquelle retourner l'icône.
   * @returns Le nom de l'icône Material Icons.
   */
  GetIconForAddressType(pAddress: AdressesDTO): string
  {
    switch ((pAddress.type ?? '').toLowerCase())
    {
      case 'address': return 'home';
      case 'street': return 'signpost';
      case 'place': return 'location_city';
      case 'locality': return 'place';
      case 'neighborhood': return 'holiday_village';
      case 'district': return 'map';
      case 'postcode': return 'markunread_mailbox';
      case 'region': return 'public';
      case 'country': return 'flag';
      default: return 'place';
    }
  }

  /**
   * Indique si la valeur courante du champ est suffisante (>= 3 caractères) pour déclencher une recherche.
   * Utilisé par le template pour garder l'overlay ouvert pendant que la recherche est en cours.
   * - cm - Extrait dans une méthode typée car Angular strict mode refuse les unions string|boolean|null dans le template.
   * @returns True si la valeur courante fait au moins 3 caractères.
   */
  HasSearchableValue(): boolean
  {
    const lValue: string | null | undefined = this.searchControl.value;
    return !!lValue && typeof lValue === 'string' && lValue.length >= 3;
  }
  //endregion

  //#region Select-search
  /**
   * Options filtrées par la requête de recherche courante (mode select-search).
   * @returns Les options dont le libellé contient la requête.
   */
  filteredSearchOptions(): IInputOption[]
  {
    return FilterSearchOptions(this.options, this.searchQuery);
  }

  /**
   * Gère la saisie dans le champ de recherche du mode select-search.
   * @param pEvent L'événement input.
   */
  onSearchInput(pEvent: Event): void
  {
    this.searchQuery = (pEvent.target as HTMLInputElement).value;
    this.searchOpen = true;
  }

  /**
   * Gère le mousedown sur un item du select-search pour empêcher le blur de fermer la liste avant le clic.
   * @param pEvent L'événement souris.
   * @param pValue La valeur de l'option.
   */
  OnSelectSearchItemMouseDown(pEvent: MouseEvent, pValue: string | number | boolean): void
  {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    this.SelectSearchOption(pValue);
  }

  /**
   * Sélectionne une option du mode select-search et propage la valeur.
   * Affiche le libellé de l'option dans le champ au lieu de vider la query.
   * @param pValue La valeur sélectionnée.
   */
  SelectSearchOption(pValue: string | number | boolean): void
  {
    this.internalValue = pValue;
    this.searchQuery = SearchLabel(pValue, this.options);
    this.searchOpen = false;
    this.onChange(pValue);
    this.valueChange.emit(pValue);
  }

  /**
   * Retourne le libellé d'une option select-search à partir de sa valeur.
   * @param pValue Valeur sélectionnée.
   * @returns Le libellé associé, ou la valeur en string.
   */
  private SearchLabel(pValue: string | number | boolean): string
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-select-search.helper.ts)
    return SearchLabel(pValue, this.options);
  }

  /**
   * Gère les touches clavier du mode select-search.
   * Enter sélectionne la première option filtrée, Escape ferme le dropdown.
   * @param pEvent L'événement clavier.
   */
  onSearchKeydown(pEvent: KeyboardEvent): void
  {
    if (pEvent.key === 'Escape')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.searchOpen = false;
    }
    else if (pEvent.key === 'Enter')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      const lFirst: IInputOption | undefined = this.filteredSearchOptions()[0];
      if (lFirst)
      {
        this.SelectSearchOption(lFirst.Value);
      }
    }
  }

  /**
   * Gère la perte de focus du champ de recherche (mode select-search).
   * @param pEvent L'événement blur.
   */
  onSearchBlur(pEvent: Event): void
  {
    this.searchOpen = false;
    this.onInputBlur(pEvent);
  }
  //#endregion

  //#region Custom Select
  /** Styles inline appliqués au dropdown pour le positionnement fixed. */
  public selectDropdownStyles: Record<string, string> = {};

  /**
   * Ouvre/ferme le dropdown du select custom.
   */
  toggleSelect(): void
  {
    if (this.disabled || this.readonly)
    {
      return;
    }
    this.SetSelectOpen(!this.selectOpen);
  }

  /**
   * Gère le mousedown sur un item du dropdown pour empêcher le blur de fermer la liste avant le clic.
   * @param pEvent L'événement souris.
   * @param pValue La valeur de l'option (null pour le placeholder).
   */
  OnSelectItemMouseDown(pEvent: MouseEvent, pValue: string | number | boolean | null): void
  {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    this.SelectOption(pValue);
  }

  /**
   * Sélectionne une option du select custom et propage la valeur.
   * @param pValue La valeur sélectionnée.
   */
  SelectOption(pValue: string | number | boolean | null): void
  {
    this.internalValue = pValue;
    this.SetSelectOpen(false);
    this.onChange(pValue);
    this.valueChange.emit(pValue);
  }

  /**
   * Ouvre ou ferme le dropdown et positionne la liste en fixed pour éviter tout tronçonnage
   * par un ancêtre overflow hidden.
   * @param pOpen True pour ouvrir, false pour fermer
   */
  private SetSelectOpen(pOpen: boolean): void
  {
    if (this.selectOpen === pOpen)
    {
      return;
    }
    this.selectOpen = pOpen;

    if (pOpen)
    {
      this.RepositionSelectDropdown();
      this._PositionService.Attach(this._SelectWrapper, () => this.RepositionSelectDropdown());
    }
    else
    {
      this._PositionService.Clear();
      this.selectDropdownStyles = {};
    }
  }

  /**
   * Recalcule la position fixed du dropdown par rapport au champ.
   */
  private RepositionSelectDropdown(): void
  {
    if (!this._SelectWrapper?.nativeElement)
    {
      return;
    }
    this.selectDropdownStyles = this._PositionService.Position(this._SelectWrapper, 240);
  }

  /**
   * Gère les touches clavier du select custom.
   * Escape ferme le dropdown, Enter/Space bascule l'ouverture.
   * @param pEvent L'événement clavier.
   */
  onSelectKeydown(pEvent: KeyboardEvent): void
  {
    if (pEvent.key === 'Escape')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.SetSelectOpen(false);
    }
    else if (pEvent.key === 'Enter' || pEvent.key === ' ')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.toggleSelect();
    }
  }

  /**
   * Gère la perte de focus du select custom (ferme le dropdown).
   * @param pEvent L'événement blur.
   */
  onSelectBlur(pEvent: Event): void
  {
    this.SetSelectOpen(false);
    this.onInputBlur(pEvent);
  }

  /**
   * Retourne le libellé affiché pour la valeur courante du select custom.
   * @returns Le libellé ou le placeholder si aucune valeur.
   */
  get selectedLabel(): string
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-select.helper.ts)
    return ResolveSelectedLabel(this.internalValue, this.options, this.placeholderOption);
  }

  /**
   * Indique si une option porte des métadonnées visuelles (Icon/Color) à afficher en pastille.
   * Les options sans Icon ni Color gardent l'ancien rendu texte brut.
   * @param pOpt L'option à tester.
   * @returns True si l'option doit être rendue comme pastille colorée.
   */
  public HasOptionVisual(pOpt: IInputOption): boolean {
    // - cm - Délègue au helper pur (voir ./helpers/input-select.helper.ts)
    return _HasOptionVisualHelper(pOpt);
  }

  /**
   * Détermine la variante visuelle à appliquer pour une option (soft par défaut).
   * @param pOpt L'option.
   * @returns La variante ('soft' | 'solid' | 'outline').
   */
  public OptionVariant(pOpt: IInputOption): string {
    // - cm - Délègue au helper pur (voir ./helpers/input-select.helper.ts)
    return _OptionVariantHelper(pOpt);
  }

  /**
   * Icône Material résolue pour une option (forme imbriquée `style` prioritaire,
   * sinon forme plate legacy `Icon`).
   * @param pOpt L'option.
   * @returns Le nom d'icône ou undefined.
   */
  public OptionIcon(pOpt: IInputOption): string | undefined {
    return _ResolveOptionVisualHelper(pOpt).Icon;
  }

  /**
   * Couleur CSS résolue pour une option (forme imbriquée `style` prioritaire,
   * sinon forme plate legacy `Color`).
   * @param pOpt L'option.
   * @returns La couleur ou undefined.
   */
  public OptionColor(pOpt: IInputOption): string | undefined {
    return _ResolveOptionVisualHelper(pOpt).Color;
  }

  /**
   * Métadonnées visuelles résolues pour la valeur courante du select custom (bouton fermé).
   * Retourne null si la valeur courante n'a pas de pastille (placeholder ou option sans visuel),
   * auquel cas le template retombe sur le rendu texte classique.
   * @returns Les métadonnées visuelles ou null.
   */
  public SelectedOptionVisual(): IInputOptionVisual | null {
    // - cm - Délègue au helper pur (voir ./helpers/input-select.helper.ts)
    return ResolveSelectedOptionVisual(this.internalValue, this.options);
  }
  //#endregion

  //#region Multi-select
  /**
   * Normalise une valeur brute en tableau pour le mode multi-select.
   * @param pValue Valeur brute.
   * @returns Un tableau (vide si aucune sélection).
   */
  private NormalizeMultiSelectValue(pValue: unknown): unknown[]
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-multi-select.helper.ts)
    return _NormalizeMultiSelectValue(pValue);
  }

  /**
   * Retourne le libellé résumé du multi-select.
   * @returns Le placeholder si vide, sinon le nombre de sélections.
   */
  get multiSelectSummary(): string
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-multi-select.helper.ts)
    return MultiSelectSummary(this.internalValue, this.placeholderOption);
  }

  /**
   * Indique si le multi-select n'a aucune sélection.
   * @returns True si aucune option n'est sélectionnée.
   */
  get IsMultiSelectEmpty(): boolean
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-multi-select.helper.ts)
    return _NormalizeMultiSelectValue(this.internalValue).length === 0;
  }

  /**
   * Bascule l'ouverture du dropdown du mode multi-select.
   */
  toggleMultiSelect(): void
  {
    if (this.disabled || this.readonly)
    {
      return;
    }
    this.SetMultiSelectOpen(!this.multiSelectOpen);
  }

  /**
   * Ouvre ou ferme le dropdown du mode multi-select.
   * @param pOpen True pour ouvrir.
   */
  private SetMultiSelectOpen(pOpen: boolean): void
  {
    if (this.multiSelectOpen === pOpen)
    {
      return;
    }
    this.multiSelectOpen = pOpen;

    if (pOpen)
    {
      this.RepositionMultiSelectDropdown();
      this._PositionService.Attach(this._SelectWrapper, () => this.RepositionMultiSelectDropdown());
    }
    else
    {
      this._PositionService.Clear();
      this.multiSelectDropdownStyles = {};
    }
  }

  /**
   * Recalcule la position fixed du dropdown du mode multi-select.
   */
  private RepositionMultiSelectDropdown(): void
  {
    if (!this._SelectWrapper?.nativeElement)
    {
      return;
    }
    this.multiSelectDropdownStyles = this._PositionService.Position(this._SelectWrapper, 240);
  }

  /**
   * Gère le mousedown sur un item du multi-select pour empêcher le blur de fermer la liste avant le clic.
   * @param pEvent L'événement souris.
   * @param pValue La valeur de l'option.
   */
  OnMultiSelectItemMouseDown(pEvent: MouseEvent, pValue: string | number | boolean): void
  {
    pEvent.preventDefault();
    pEvent.stopPropagation();
    this.ToggleMultiSelectOption(pValue);
  }

  /**
   * Ajoute ou retire une option du tableau de sélections.
   * @param pValue La valeur à basculer.
   */
  ToggleMultiSelectOption(pValue: string | number | boolean): void
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-multi-select.helper.ts)
    this.internalValue = _ToggleMultiSelectOption(pValue, this.internalValue);
    this.onChange(this.internalValue);
    this.valueChange.emit(this.internalValue);
  }

  /**
   * Indique si une valeur est sélectionnée.
   * @param pValue La valeur à tester.
   * @returns True si sélectionnée.
   */
  IsMultiSelected(pValue: string | number | boolean): boolean
  {
    // - cm - Délègue au helper pur (voir ./helpers/input-multi-select.helper.ts)
    return _IsMultiSelected(pValue, this.internalValue);
  }

  /**
   * Gère les touches clavier du multi-select.
   * @param pEvent L'événement clavier.
   */
  onMultiSelectKeydown(pEvent: KeyboardEvent): void
  {
    if (pEvent.key === 'Escape')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.SetMultiSelectOpen(false);
    }
    else if (pEvent.key === 'Enter' || pEvent.key === ' ')
    {
      pEvent.preventDefault();
      pEvent.stopPropagation();
      this.toggleMultiSelect();
    }
  }

  /**
   * Gère la perte de focus du multi-select (ferme le dropdown).
   * @param pEvent L'événement blur.
   */
  onMultiSelectBlur(pEvent: Event): void
  {
    this.SetMultiSelectOpen(false);
    this.onInputBlur(pEvent);
  }
  //#endregion

  //#region Validation helpers
  private applyReactiveValidators(): void
  {
    const lControl = this._NgControl?.control;
    if (!lControl) return;
    lControl.setValidators(this._ValidationService.BuildValidators(this));
    lControl.updateValueAndValidity({ emitEvent: false });
  }

  private syncSearchControlValidators(): void
  {
    const lValidators = this.required ? [Validators.required] : [];
    this.searchControl.setValidators(lValidators);
    this.searchControl.updateValueAndValidity();
  }

  /**
   * Retourne les erreurs actuelles du champ.
   * Trois modes sont gérés :
   *  1. Autocomplete adresse : on valide `searchControl` (le ngModel interne est en standalone).
   *  2. immediateValidation (grid inline, playground) : on recalcule via `BuildStandaloneErrors`
   *     car le `[ngModel] standalone` interne n'exécute pas les validateurs `required`/`email`/etc.
   *     Sans ce fallback, `_NgControl.errors` reste `null` et aucune erreur ne s'affiche
   *     même quand l'input est requis et vide.
   *  3. FormControl parent (réactif) : on lit les erreurs du contrôle.
   *  4. Standalone (sans FormControl ni immediateValidation) : on recalcule via `BuildStandaloneErrors`.
   * @returns Les erreurs Angular ou null.
   */
  getErrors(): ValidationErrors | null
  {
    // - cm - immediateValidation : affiche les erreurs dès la saisie (sans attendre le blur), utilisé par la grid inline
    if (!this.touched && !this.immediateValidation) return null;
    // - cm - En mode autocomplete, on masque l'erreur tant que l'utilisateur saisit ou que des suggestions sont visibles
    if (this.isAddressAutocomplete && this.addressSuggestions.length > 0) return null;
    // - cm - En mode autocomplete, on valide le searchControl (et non le ngControl parent)
    if (this.isAddressAutocomplete) return this.searchControl.errors ?? null;
    // - cm - En mode immediateValidation, le [ngModel] interne est en standalone : _NgControl.errors
    // resterait null. On force le recalcul des validateurs (required, email, pattern, etc.)
    // pour que les erreurs s'affichent dans le playground, la grid inline, etc.
    if (this.immediateValidation)
    {
      return this._ValidationService.BuildStandaloneErrors(this.type, this.internalValue, this);
    }
    if (this._NgControl) return this._NgControl.errors ?? null;
    // - cm - Mode standalone (pas de FormControl parent) : on recalcule les erreurs depuis les inputs
    return this._ValidationService.BuildStandaloneErrors(this.type, this.internalValue, this);
  }

  /**
   * Indique si une erreur donnée est présente.
   * @param pErrorType Clé de l'erreur.
   * @returns True si l'erreur est présente.
   */
  hasError(pErrorType: string): boolean
  {
    const lErrors = this.getErrors();
    return lErrors !== null && lErrors[pErrorType] !== undefined;
  }

  /**
   * Identifiant unique du bloc d'erreur pour aria-describedby.
   */
  get ErrorId(): string
  {
    return `${this.id}-error`;
  }

  /**
   * Construit le message d'erreur complet.
   * @returns Le message formaté.
   */
  getErrorMessage(): string
  {
    return this._ValidationService.BuildErrorMessage(this, this.getErrors());
  }

  /**
   * Retourne le compteur de caractères.
   * @returns Le texte du compteur.
   */
  getCharCount(): string
  {
    if (!this.showCharCount || !this.maxLength || typeof this.internalValue !== 'string') return '';
    return `${this.internalValue.length} / ${this.maxLength}`;
  }
  //#endregion
}
