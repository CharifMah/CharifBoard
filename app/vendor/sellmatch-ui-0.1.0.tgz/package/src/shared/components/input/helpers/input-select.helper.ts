/**
 * Helper pour le mode select custom de l'<app-input>.
 * Extrait de input.component.ts pour réduire la taille du composant principal.
 * Toutes les méthodes sont pures et prennent le composant en paramètre.
 */
import { IInputOption, IInputOptionVisual } from '../input.types';

/**
 * Normalise les métadonnées visuelles d'une option vers `IInputOptionVisual`.
 * - cm - Forme unique imposée par le refactor KAN-REF-VISUAL-STYLE : les visuels viennent
 * exclusivement de `option.style: RefVisualStyleDTO`. Si l'option n'a pas de style, on
 * retourne un visuel vide (le rendu retombe sur le libellé brut).
 * @param pOpt L'option à normaliser.
 * @returns Les métadonnées visuelles résolues (peut être vide).
 */
export function ResolveOptionVisual(pOpt: IInputOption | undefined | null): IInputOptionVisual {
  if (!pOpt?.style) {
    return {};
  }
  return {
    Icon: pOpt.style.icon,
    Color: pOpt.style.color,
    Variant: pOpt.style.variant
  };
}

/**
 * Indique si une option porte des métadonnées visuelles (Icon/Color) à afficher en pastille.
 * Les options sans Icon ni Color gardent l'ancien rendu texte brut.
 * @param pOpt L'option à tester.
 * @returns True si l'option doit être rendue comme pastille colorée.
 */
export function HasOptionVisual(pOpt: IInputOption): boolean {
  if (!pOpt) {
    return false;
  }
  const lVis: IInputOptionVisual = ResolveOptionVisual(pOpt);
  return !!(lVis.Icon && lVis.Color);
}

/**
 * Détermine la variante visuelle à appliquer pour une option (soft par défaut).
 * @param pOpt L'option.
 * @returns La variante ('soft' | 'solid' | 'outline').
 */
export function OptionVariant(pOpt: IInputOption): string {
  if (!pOpt) {
    return 'soft';
  }
  const lVis: IInputOptionVisual = ResolveOptionVisual(pOpt);
  return lVis.Variant ?? 'soft';
}

/**
 * Résout les métadonnées visuelles pour la valeur courante du select custom.
 * @param pInternalValue La valeur courante.
 * @param pOptions Les options disponibles.
 * @returns Les métadonnées visuelles ou null.
 */
export function ResolveSelectedOptionVisual(
  pInternalValue: unknown,
  pOptions: IInputOption[] | undefined | null
): IInputOptionVisual | null {
  if (pInternalValue === null || pInternalValue === undefined || pInternalValue === '') {
    return null;
  }
  const lOpt: IInputOption | undefined =
    (pOptions ?? []).find((pOpt) => String(pOpt.Value) === String(pInternalValue));
  if (!lOpt || !HasOptionVisual(lOpt)) {
    return null;
  }
  const lVis: IInputOptionVisual = ResolveOptionVisual(lOpt);
  return { Icon: lVis.Icon, Color: lVis.Color, Variant: lVis.Variant ?? 'soft' };
}

/**
 * Retourne le libellé affiché pour la valeur courante du select custom.
 * @param pInternalValue La valeur courante.
 * @param pOptions Les options disponibles.
 * @param pPlaceholderOption Le placeholder à afficher si aucune correspondance.
 * @returns Le libellé ou le placeholder.
 */
export function ResolveSelectedLabel(
  pInternalValue: unknown,
  pOptions: IInputOption[] | undefined | null,
  pPlaceholderOption: string
): string {
  if (pInternalValue === null || pInternalValue === undefined || pInternalValue === '') {
    return pPlaceholderOption;
  }
  const lOpt: IInputOption | undefined =
    (pOptions ?? []).find((pOpt) => String(pOpt.Value) === String(pInternalValue));
  return lOpt ? lOpt.Label : pPlaceholderOption;
}
