import { Injectable, ElementRef, inject, Renderer2 } from '@angular/core';

/**
 * Service responsable du positionnement fixed d'un dropdown par rapport à son champ.
 * Écoute le scroll de window ET de tous les ancêtres scrollables pour maintenir
 * l'alignement, et bascule vers le haut quand l'espace disponible sous le champ est insuffisant.
 * Fourni au niveau du composant (pas singleton) pour isoler les listeners par instance.
 */
@Injectable()
export class InputDropdownPositionService {
  //#region Attributes
  private readonly _Renderer = inject(Renderer2);
  private _CleanupFns: (() => void)[] = [];
  //#endregion

  //#region Public API
  /**
   * Calcule les styles inline pour positionner le dropdown en fixed.
   * Si l'espace sous le champ est insuffisant et que l'espace au-dessus le permet,
   * le dropdown s'ouvre vers le haut.
   * @param pWrapper Élément wrapper du select (référence).
   * @param pMaxDropdownHeight Hauteur maximale estimée du dropdown (défaut 240px).
   * @returns Dictionnaire de styles CSS à appliquer au dropdown.
   */
  public Position(pWrapper: ElementRef<HTMLElement>, pMaxDropdownHeight: number = 240): Record<string, string> {
    if (!pWrapper?.nativeElement) return {};

    const lRect: DOMRect = pWrapper.nativeElement.getBoundingClientRect();
    const lViewportHeight = window.innerHeight;
    const lSpaceBelow = lViewportHeight - lRect.bottom;
    const lSpaceAbove = lRect.top;

    const lBaseStyles: Record<string, string> = {
      position: 'fixed',
      left: `${lRect.left}px`,
      width: `${lRect.width}px`,
      right: 'auto'
    };

    // - cm - Ouvrir vers le haut si l'espace sous le champ est insuffisant et qu'il y a de la place au-dessus
    if (lSpaceBelow < pMaxDropdownHeight && lSpaceAbove >= pMaxDropdownHeight) {
      return {
        ...lBaseStyles,
        top: 'auto',
        bottom: `${lViewportHeight - lRect.top}px`
      };
    }

    return {
      ...lBaseStyles,
      top: `${lRect.bottom}px`,
      bottom: 'auto'
    };
  }

  /**
   * Attache les écouteurs de scroll/resize nécessaires au repositionnement du dropdown.
   * @param pWrapper Wrapper de référence du select.
   * @param pOnReposition Callback appelé à chaque scroll/resize (doit mettre à jour les styles).
   */
  public Attach(pWrapper: ElementRef<HTMLElement>, pOnReposition: () => void): void {
    this.Clear();

    const lScrollHandler = (): void => pOnReposition();
    const lResizeHandler = (): void => pOnReposition();

    // - cm - Écoute les scrolls sur tous les ancêtres scrollables (ex: body de la grid)
    const lScrollableAncestors = this.GetScrollableAncestors(pWrapper.nativeElement);
    for (const lAncestor of lScrollableAncestors) {
      lAncestor.addEventListener('scroll', lScrollHandler, { capture: true, passive: true });
      this._CleanupFns.push(() => lAncestor.removeEventListener('scroll', lScrollHandler, true));
    }

    // - cm - Écoute le scroll global en capture (toolbars, dialogs, etc.)
    window.addEventListener('scroll', lScrollHandler, { capture: true, passive: true });
    this._CleanupFns.push(() => window.removeEventListener('scroll', lScrollHandler, true));

    // - cm - Resize de la fenêtre
    const lResizeCleanup = this._Renderer.listen('window', 'resize', lResizeHandler);
    this._CleanupFns.push(lResizeCleanup);
  }

  /**
   * Nettoie tous les listeners de positionnement.
   */
  public Clear(): void {
    for (const lCleanup of this._CleanupFns) {
      lCleanup();
    }
    this._CleanupFns = [];
  }
  //#endregion

  //#region Helpers
  /**
   * Remonte les ancêtres d'un élément et retourne ceux qui sont scrollables.
   * @param pElement Élément de départ.
   * @returns Liste des ancêtres scrollables (body exclu car couvert par window).
   */
  private GetScrollableAncestors(pElement: HTMLElement): HTMLElement[] {
    const lAncestors: HTMLElement[] = [];
    let lCurrent: HTMLElement | null = pElement.parentElement;

    while (lCurrent) {
      const lStyle = window.getComputedStyle(lCurrent);
      const lOverflowY = lStyle.overflowY;
      const lOverflowX = lStyle.overflowX;
      const lOverflow = lStyle.overflow;
      const lIsScrollable = /scroll|auto/.test(lOverflowY)
        || /scroll|auto/.test(lOverflowX)
        || /scroll|auto/.test(lOverflow);

      if (lIsScrollable && lCurrent !== document.body) {
        lAncestors.push(lCurrent);
      }

      lCurrent = lCurrent.parentElement;
    }

    return lAncestors;
  }
  //#endregion
}
