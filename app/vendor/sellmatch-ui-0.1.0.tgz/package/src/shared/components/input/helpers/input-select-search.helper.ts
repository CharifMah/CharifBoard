/**
 * Helper pour le mode select-search de l'<app-input>.
 * Extrait de input.component.ts pour réduire la taille du composant principal.
 */
import { IInputOption } from '../input.types';

/**
 * Filtre les options par la requête de recherche courante.
 * @param pOptions Les options complètes.
 * @param pQuery La requête de recherche (sera normalisée en lowercase).
 * @returns Les options dont le libellé contient la requête.
 */
export function FilterSearchOptions(
  pOptions: IInputOption[] | undefined | null,
  pQuery: string
): IInputOption[] {
  const lOptions = pOptions ?? [];
  const lQuery: string = (pQuery ?? '').toLowerCase().trim();
  if (!lQuery) {
    return lOptions;
  }
  return lOptions.filter((pOpt) => pOpt.Label.toLowerCase().includes(lQuery));
}

/**
 * Retourne le libellé d'une option select-search à partir de sa valeur.
 * @param pValue Valeur sélectionnée.
 * @param pOptions Les options disponibles.
 * @returns Le libellé associé, ou la valeur en string.
 */
export function SearchLabel(
  pValue: string | number | boolean,
  pOptions: IInputOption[] | undefined | null
): string {
  const lOpt: IInputOption | undefined =
    (pOptions ?? []).find((pOpt) => String(pOpt.Value) === String(pValue));
  return lOpt ? lOpt.Label : String(pValue);
}
