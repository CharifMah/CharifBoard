import { ValidatorFn } from '@angular/forms';
import {RefVisualStyleDTO} from "../../../core/crm/dto";

//#region Types
/**
 * Types d'éditeurs supportés par le composant app-input.
 */
export type InputType =
  | 'text'
  | 'number'
  | 'email'
  | 'password'
  | 'tel'
  | 'date'
  | 'search'
  | 'select'
  | 'multi-select'
  | 'checkbox'
  | 'textarea'
  | 'select-search';


/**
 * Métadonnées visuelles d'une option de select (pastille colorée + icône Material).
 * - cm - Forme unique `RefVisualStyleDTO` (cf. KAN-REF-VISUAL-STYLE) : tous les référentiels BDD
 * exposent leur visuel via la FK `style_id` vers `crm.ref_visual_style` (icon/color/variant).
 */
export interface IInputOptionVisual {
  /** Nom d'icône Material (ex: 'star', 'check_circle'). */
  Icon?: string;
  /** Couleur CSS (hex, rgb, var(...)). */
  Color?: string;
  /** Variante du pastillage : 'soft' (défaut), 'solid', 'outline'. */
  Variant?: 'soft' | 'solid' | 'outline' | string;
}

/**
 * Option d'un select / select-search.
 * - cm - Les métadonnées visuelles (Icon/Color/Variant) vivent dans `style: RefVisualStyleDTO`,
 * forme unique imposée par le refactor KAN-REF-VISUAL-STYLE. Quand `style.icon` et
 * `style.color` sont présents, l'app-input affiche une pastille au lieu d'un libellé brut.
 */
export interface IInputOption {
  /** Libellé affiché (résolu statique). */
  Label: string;
  /**
   * Clé i18n pour résoudre le libellé dynamiquement au render et au changement de langue.
   * - cm - Optionnel et prioritaire sur `Label` quand résolu par <app-input-select>. Si la clé
   * est absente du sous-registre courant, le composant retombe sur `Label`.
   */
  LabelCle?: string;
  /** Valeur associée. */
  Value: string | number | boolean;

  /** Métadonnées visuelles issues de `crm.ref_visual_style` (FK `style_id` des référentiels). */
  style?: RefVisualStyleDTO;
}

/**
 * Données nécessaires pour construire les validateurs d'un app-input.
 */
export interface IInputValidationContext {
  /** Type d'éditeur. */
  type: InputType;
  /** Champ requis. */
  required: boolean;
  /** Valeur minimale (number/date). */
  min: number | string;
  /** Valeur maximale (number/date). */
  max: number | string;
  /** Pas (number). */
  step: number | string;
  /** Longueur maximale (text/number). */
  maxLength: number | null;
  /** Longueur minimale (text/number). */
  minLength: number | null;
  /** Validateurs personnalisés. */
  customValidators: ValidatorFn | ValidatorFn[];
}

/**
 * Données nécessaires pour formater les messages d'erreur d'un app-input.
 */
export interface IInputErrorContext {
  /** Messages personnalisés par clé d'erreur. */
  errorMessages: Record<string, string>;
}
//#endregion
