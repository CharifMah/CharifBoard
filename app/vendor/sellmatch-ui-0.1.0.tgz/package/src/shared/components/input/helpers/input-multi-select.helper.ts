/**
 * Helper pour le mode multi-select de l'<app-input>.
 * Extrait de input.component.ts pour réduire la taille du composant principal.
 */

/**
 * Normalise une valeur brute en tableau pour le mode multi-select.
 * @param pValue Valeur brute.
 * @returns Un tableau (vide si aucune sélection).
 */
export function NormalizeMultiSelectValue(pValue: unknown): unknown[] {
  if (pValue === null || pValue === undefined || pValue === '') {
    return [];
  }
  if (Array.isArray(pValue)) {
    return [...pValue];
  }
  return [pValue];
}

/**
 * Retourne le libellé résumé du multi-select (placeholder ou compteur).
 * @param pInternalValue La valeur courante.
 * @param pPlaceholderOption Le placeholder.
 * @returns Le texte du résumé.
 */
export function MultiSelectSummary(
  pInternalValue: unknown,
  pPlaceholderOption: string
): string {
  const lValues: unknown[] = NormalizeMultiSelectValue(pInternalValue);
  if (lValues.length === 0) {
    return pPlaceholderOption;
  }
  const lCount: number = lValues.length;
  return `${lCount} sélection${lCount > 1 ? 's' : ''}`;
}

/**
 * Indique si une valeur est sélectionnée.
 * @param pValue La valeur à tester.
 * @param pInternalValue La valeur courante.
 * @returns True si sélectionnée.
 */
export function IsMultiSelected(
  pValue: string | number | boolean,
  pInternalValue: unknown
): boolean {
  const lValues: unknown[] = NormalizeMultiSelectValue(pInternalValue);
  return lValues.some((pV) => String(pV) === String(pValue));
}

/**
 * Bascule une option dans le tableau de sélections.
 * @param pValue La valeur à basculer.
 * @param pInternalValue La valeur courante.
 * @returns Le nouveau tableau.
 */
export function ToggleMultiSelectOption(
  pValue: string | number | boolean,
  pInternalValue: unknown
): unknown[] {
  const lValues: unknown[] = NormalizeMultiSelectValue(pInternalValue);
  const lIndex: number = lValues.findIndex((pV) => String(pV) === String(pValue));
  if (lIndex >= 0) {
    lValues.splice(lIndex, 1);
  } else {
    lValues.push(pValue);
  }
  return [...lValues];
}
