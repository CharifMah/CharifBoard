import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { RoutePath } from '../../routes/app.routes.constants';

@Injectable({
  providedIn: 'root'
})
export class RouteUtils {
  private TEST_PATH: string = '/test';
  public Router: Router = inject(Router);

  public GetRoute(pPath: RoutePath, pParams?: Record<string, string | number>): string {
    const lIsTestMode: boolean = this.Router.url.includes(this.TEST_PATH);
    let lFullPath: string = '/' + pPath;

    // Remplacer les paramètres dans le chemin
    if (pParams) {
      Object.entries(pParams).forEach(([key, value]) => {
        lFullPath = lFullPath.replace(`:${key}`, value.toString());
      });
    }

    if (environment.maintenance && (lIsTestMode)) {
      return this.TEST_PATH + lFullPath;
    }
    return lFullPath;
  }

  public NavigateTo(pPath: RoutePath): void {
    this.Router.navigate([this.GetRoute(pPath)]);
  }

  /**
   * Scrolls to an element with the given ID
   * @param pElementId The ID of the element to scroll to
   * @param pSmooth Whether to use smooth scrolling
   */
  public ScrollToElement(pElementId: string, pSmooth: boolean = true): void {
    const lElement: HTMLElement | null = document.getElementById(pElementId);
    if (lElement) {
      lElement.scrollIntoView({
        behavior: pSmooth ? 'auto' : 'smooth',
        block: 'start'
      });
    }
  }
}
