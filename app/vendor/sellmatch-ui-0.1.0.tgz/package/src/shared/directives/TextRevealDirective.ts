import { Directive, ElementRef, AfterViewInit, Inject, PLATFORM_ID, Input, OnDestroy } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { TranslateService, LangChangeEvent, TranslationChangeEvent } from '@ngx-translate/core';
import { Subscription } from 'rxjs';

export type TScrollAnimation = 'word' | 'fade' | 'none';

/**
 * Directive générique d'animation au scroll.
 * - 'word' : découpe le texte en mots et les anime un par un (Cuberto-like)
 * - 'fade' : fade-up + slide de l'élément entier
 * - 'none' : pas d'animation (utile pour les conteneurs)
 * 
 * Usage :
 *   <h1 appScrollReveal [Animation]="'word'">Texte mot à mot</h1>
 *   <div appScrollReveal [Animation]="'fade'">Bloc fade-up</div>
 */
@Directive({
  selector: '[appScrollReveal]',
  standalone: true
})
export class ScrollRevealDirective implements AfterViewInit, OnDestroy
{
  /** Type d'animation : 'word' (mots), 'fade' (bloc), 'none' */
  @Input() public Animation: TScrollAnimation = 'fade';
  /** Délai entre chaque mot (word) ou délai avant animation (fade) */
  @Input() public StaggerDelay: number = 80;
  /** Durée de l'animation en ms */
  @Input() public Duration: number = 700;
  /** Seuil de visibilité IntersectionObserver (0-1) */
  @Input() public Threshold: number = 0.15;
  /** Décallage de translation Y en px */
  @Input() public OffsetY: number = 40;
  /** Délai supplémentaire basé sur la position dans la page (ms par 100px) */
  @Input() public OrderDelay: number = 0;

  private _IsBrowser: boolean;
  private _Observer: IntersectionObserver | null = null;
  private _MutationObserver: MutationObserver | null = null;
  private _LangChangeSubscription: Subscription | null = null;
  private _TranslationChangeSubscription: Subscription | null = null;
  private _OrderMs: number = 0;
  private _HasRevealed: boolean = false;
  private _IsDestroyed: boolean = false;

  // - cm - Références aux nœuds texte originaux créés par Angular pour le binding
  // `{{ ... | translate }}`. Stockés AVANT le premier découpage pour pouvoir lire la
  // NOUVELLE traduction après un changement de langue : Angular met à jour ces nœuds
  // (même détachés du DOM) avec le texte traduit, ce qui permet de récupérer le texte
  // à jour sans dépendre du timing du MutationObserver ni du DOM visible.
  private _OriginalTextNodes: Text[] = [];

  // - cm - Timeout en attente pour le re-découpage différé après changement de langue.
  // Permet d'attendre qu'Angular ait mis à jour les nœuds texte originaux (et terminé
  // sa change detection) avant qu'on les lise. Annulé si un nouveau changement arrive
  // ou si la directive est détruite.
  private _PendingResplit: ReturnType<typeof setTimeout> | null = null;

  constructor(
    private _ElementRef: ElementRef<HTMLElement>,
    @Inject(PLATFORM_ID) pPlatformId: object,
    private _Translate: TranslateService
  )
  {
    this._IsBrowser = isPlatformBrowser(pPlatformId);
  }

  ngAfterViewInit(): void
  {
    if (!this._IsBrowser) return;

    const lEl = this._ElementRef.nativeElement;

    // - cm - Calcule un délai basé sur la position verticale dans la page
    // pour que les éléments du haut s'animent avant ceux du bas
    this._OrderMs = this._ComputeOrderMs(lEl);

    if (this.Animation === 'word')
    {
      this._SetupWordReveal(lEl, this._OrderMs);
      this._WatchTextChanges(lEl, this._OrderMs);
      this._SubscribeLangChanges(lEl);
      this._SubscribeTranslationChanges(lEl);
    }
    else
    {
      this._SetupFadeReveal(lEl, this._OrderMs);
    }
  }

  ngOnDestroy(): void
  {
    // - cm - Marque la directive comme détruite AVANT de déconnecter/annuler : évite
    // qu'un `_ScheduleResplit` en attente exécute sa callback après destruction.
    this._IsDestroyed = true;
    this._Observer?.disconnect();
    this._MutationObserver?.disconnect();
    this._LangChangeSubscription?.unsubscribe();
    this._TranslationChangeSubscription?.unsubscribe();
    if (this._PendingResplit !== null)
    {
      clearTimeout(this._PendingResplit);
      this._PendingResplit = null;
    }
  }

  /**
   * Observe les changements de texte (ex: changement de langue via pipe translate)
   * et re-applique le découpage en mots pour que l'animation suive le nouveau texte.
   * - cm - Le pipe ngx-translate met à jour les nœuds texte après un changement de
   * langue. Sans cet observer, les mots restent figés dans l'ancienne langue (le titre
   * principal ne change pas alors que le reste de la page se met à jour).
   */
  private _WatchTextChanges(pEl: HTMLElement, pOrderMs: number): void
  {
    if (typeof MutationObserver === 'undefined') return;

    // - cm - Texte de référence (après découpage initial). On ne re-découpe QUE si le
    // texte brut a réellement changé (changement de langue), pas sur nos propres mutations.
    let lLastText: string = this._GetPlainText(pEl);

    this._MutationObserver = new MutationObserver(() =>
    {
      const lCurrentText: string = this._GetPlainText(pEl);

      // - cm - Ignore si le texte brut n'a pas changé (propres mutations du découpage,
      // changements de structure, transitions...). Seul un vrai changement de contenu
      // (nouveau texte traduit par le pipe) doit déclencher le re-découpage.
      if (lCurrentText === lLastText) return;

      lLastText = lCurrentText;
      this._ReapplyWordSplit(pEl, pOrderMs);
    });

    this._MutationObserver.observe(pEl, {
      characterData: true,
      childList: true,
      subtree: true
    });
  }

  /**
   * S'abonne à `onLangChange` pour ré-exécuter le cycle de découpage/reveal quand
   * l'utilisateur change de langue via le `TranslateService`.
   * - cm - Le re-découpage est DIFFÉRÉ via `_ScheduleResplit` (`setTimeout(0)`) pour
   * laisser Angular terminer son cycle de change detection et mettre à jour les nœuds
   * texte originaux (détachés) avec la nouvelle traduction. Sans ce délai, on lit
   * l'ancienne traduction et le DOM reste figé sur l'ancienne langue (les nouveaux
   * mots restent en FR alors que le reste de la page passe en EN).
   * @param pEl Élément hôte de la directive
   */
  private _SubscribeLangChanges(pEl: HTMLElement): void
  {
    this._LangChangeSubscription = this._Translate.onLangChange.subscribe(
      (_pEvent: LangChangeEvent) =>
      {
        this._ScheduleResplit(pEl);
      }
    );
  }

  /**
   * S'abonne à `onTranslationChange` pour ré-exécuter le cycle de découpage/reveal
   * quand le dictionnaire de traductions est rechargé (chargement initial async, hot
   * reload, mise à jour dynamique des traductions).
   * - cm - Même logique de différé que `_SubscribeLangChanges` : on attend qu'Angular
   * ait appliqué la nouvelle traduction avant de re-découper. Couvre le cas du boot
   * initial où `ngAfterViewInit` s'exécute avec la clé brute (avant la fin du fetch
   * du JSON) et où `onLangChange` n'a pas émis (langue déjà active).
   * @param pEl Élément hôte de la directive
   */
  private _SubscribeTranslationChanges(pEl: HTMLElement): void
  {
    this._TranslationChangeSubscription = this._Translate.onTranslationChange.subscribe(
      (_pEvent: TranslationChangeEvent) =>
      {
        this._ScheduleResplit(pEl);
      }
    );
  }

  /**
   * Programme un re-découpage différé après un changement de langue ou de traduction.
   * - cm - Annule un re-découpage précédent en attente (changements rapides : ex.
   * FR→EN→ES en quelques ms) puis schedule un `setTimeout(0)` (macrotask) pour laisser
   * Angular terminer sa change detection et mettre à jour les nœuds texte originaux
   * avant qu'on les lise. Un `queueMicrotask` ne suffit pas : il s'exécute AVANT
   * le cycle de CD déclenché par zone.js, et on lirait l'ancien texte.
   * @param pEl Élément hôte de la directive
   */
  private _ScheduleResplit(pEl: HTMLElement): void
  {
    if (this._IsDestroyed) return;
    if (this._PendingResplit !== null)
    {
      clearTimeout(this._PendingResplit);
    }
    this._PendingResplit = setTimeout(() =>
    {
      this._PendingResplit = null;
      if (this._IsDestroyed) return;
      // - cm - Recalcule l'orderMs en fonction de la position actuelle (le
      // scroll a pu évoluer depuis l'init, ex: après navigation ou resize).
      this._OrderMs = this._ComputeOrderMs(pEl);
      this._ReapplyWordSplit(pEl, this._OrderMs);
    }, 0);
  }

  /**
   * Re-applique le cycle complet de découpage des mots pour suivre un changement de
   * contenu (changement de langue via `onLangChange` / `onTranslationChange`, ou
   * mutation détectée par le `MutationObserver`).
   * - cm - Lit le NOUVEAU texte depuis les nœuds texte originaux (`_OriginalTextNodes`),
   * mis à jour par Angular avec la nouvelle traduction même s'ils sont détachés du
   * DOM. Fallback sur le contenu textuel courant si les nœuds originaux ne sont plus
   * disponibles (sécurité). Insère un nœud texte temporaire avec le nouveau texte
   * que `_SetupWordReveal` va découper, puis nettoie.
   * - cm - Déconnecte le `MutationObserver` AVANT la réécriture du DOM pour éviter
   * les boucles infinies, puis le ré-attache via `queueMicrotask`. Pour
   * l'`IntersectionObserver`, on ne le déconnecte que si l'élément n'a pas encore
   * été révélé : s'il l'a déjà été, on rejoue l'animation immédiatement (sinon
   * les nouveaux spans resteraient figés à `translateY(105%)`).
   * @param pEl Élément hôte de la directive
   * @param pOrderMs Délai d'ordre recalculé (ms)
   */
  private _ReapplyWordSplit(pEl: HTMLElement, pOrderMs: number): void
  {
    // - cm - Lit le texte à jour depuis les nœuds texte originaux (mis à jour par
    // Angular avec la nouvelle traduction, même détachés du DOM). Fallback sur le
    // contenu textuel visible si les nœuds originaux ne sont plus disponibles.
    const lNewText: string = this._GetOriginalText() || this._GetPlainText(pEl);
    const lTrimmed: string = lNewText.trim();
    if (!lTrimmed) return;

    const lWasRevealed: boolean = this._HasRevealed;
    this._MutationObserver?.disconnect();

    this._FlattenWords(pEl);

    // - cm - Insère le nouveau texte comme nœud texte temporaire que `_SetupWordReveal`
    // va traiter. On l'insère en première position pour préserver l'ordre visuel
    // (avant les éventuels autres nœuds texte / le highlight span géré par Angular).
    const lTempTextNode: Text = document.createTextNode(lNewText);
    pEl.insertBefore(lTempTextNode, pEl.firstChild);

    this._SetupWordReveal(pEl, pOrderMs);

    // - cm - Si l'élément était déjà visible/révélé, l'IO d'origine s'est déjà
    // déconnecté (unobserve). On rejoue l'animation tout de suite pour les nouveaux
    // mots, sinon ils resteraient à `translateY(105%)` car le nouvel IO attend la
    // prochaine intersection (déjà passée).
    if (lWasRevealed)
    {
      this._Observer?.disconnect();
      this._Observer = null;
      const lInners: HTMLElement[] = Array.from(pEl.querySelectorAll<HTMLElement>(':scope > .sr-word > .sr-word__inner'));
      for (let i = 0; i < lInners.length; i++)
      {
        lInners[i].style.transform = 'translateY(0)';
      }
    }

    queueMicrotask(() =>
    {
      this._MutationObserver?.observe(pEl, {
        characterData: true,
        childList: true,
        subtree: true
      });
    });
  }

  /**
   * Calcule le délai d'ordre (ms) à partir de la position verticale de l'élément
   * dans la page (15ms par 100px de distance au sommet, plus le `OrderDelay`).
   * @param pEl Élément hôte de la directive
   * @returns Délai d'ordre en millisecondes
   */
  private _ComputeOrderMs(pEl: HTMLElement): number
  {
    const lRect = pEl.getBoundingClientRect();
    const lScrollY = window.scrollY || window.pageYOffset;
    const lAbsoluteTop = lRect.top + lScrollY;
    return Math.floor(lAbsoluteTop / 100) * 15 + this.OrderDelay;
  }

  /**
   * Retourne le texte brut complet de l'élément (tous les nœuds texte concaténés),
   * sans tenir compte des spans de découpage.
   */
  private _GetPlainText(pEl: HTMLElement): string
  {
    return (pEl.textContent ?? '').replace(/\s+/g, ' ').trim();
  }

  /**
   * Lit le texte courant depuis les nœuds texte originaux créés par Angular pour le
   * binding `{{ ... | translate }}`. Ces nœuds sont détachés du DOM après le premier
   * découpage mais Angular les met à jour avec la nouvelle traduction à chaque
   * changement de langue (le `Text` node reste vivant en mémoire, juste détaché).
   * - cm - C'est la SOURCE DE VÉRITÉ pour le re-découpage après changement de langue :
   * elle reflète la traduction à jour sans dépendre du timing du `MutationObserver`
   * (qui ne voit jamais les updates car le nœud est détaché) ni du DOM visible
   * (qui contient encore l'ancienne traduction dans les `.sr-word`).
   * @returns Texte traduit courant (concaténé des nœuds originaux), ou '' si aucun
   */
  private _GetOriginalText(): string
  {
    if (this._OriginalTextNodes.length === 0) return '';
    return this._OriginalTextNodes
      .map((pNode) => pNode.nodeValue ?? '')
      .join('')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Supprime les spans générés par `_SetupWordReveal` sans recréer de nœuds texte.
   * - cm - Contrairement à l'ancienne version qui recréait des nœuds texte à partir
   * du contenu des spans (toujours l'ANCIEN texte, jamais mis à jour par Angular),
   * on les supprime simplement : le nouveau texte sera inséré par `_ReapplyWordSplit`
   * depuis `_OriginalTextNodes` (mis à jour par Angular avec la nouvelle traduction).
   * Conserve les éléments non-générés (ex: `<span class="hero__title-highlight">`,
   * `<span class="text-gradient">`) gérés directement par Angular.
   */
  private _FlattenWords(pEl: HTMLElement): void
  {
    const lWords: HTMLElement[] = Array.from(pEl.querySelectorAll(':scope > .sr-word'));
    for (const lWord of lWords)
    {
      lWord.remove();
    }
  }

  //#region Word Animation
  private _SetupWordReveal(pEl: HTMLElement, pOrderMs: number): void
  {
    const lInners: HTMLElement[] = [];

    // - cm - Parcourt uniquement les noeuds textes directs (pas ceux dans les enfants <span>)
    const lDirectTextNodes: Text[] = [];
    for (let i = 0; i < pEl.childNodes.length; i++)
    {
      const lNode = pEl.childNodes[i];
      if (lNode.nodeType === Node.TEXT_NODE)
      {
        lDirectTextNodes.push(lNode as Text);
      }
    }

    if (lDirectTextNodes.length === 0) return;

    // - cm - Capture les références aux nœuds texte ORIGINAUX (créés par Angular pour
    // le binding `{{ ... | translate }}`) AVANT de les remplacer. Angular continue à
    // mettre à jour ces nœuds (en mémoire) même après qu'on les a détachés du DOM,
    // ce qui nous permet de relire la nouvelle traduction lors d'un changement de
    // langue via `_GetOriginalText()`. On ne capture qu'une seule fois (au 1er setup)
    // pour ne pas écraser les références avec des nœuds texte temporaires insérés
    // lors des re-découpages suivants.
    if (this._OriginalTextNodes.length === 0)
    {
      this._OriginalTextNodes = lDirectTextNodes.slice();
    }

    for (const lTextNode of lDirectTextNodes)
    {
      const lText = lTextNode.textContent ?? '';
      if (!lText.trim()) continue;

      const lWords = lText.split(/(\s+)/);
      const lFragment = document.createDocumentFragment();

      for (const lWord of lWords)
      {
        if (lWord.trim().length === 0)
        {
          lFragment.appendChild(document.createTextNode(lWord));
        }
        else
        {
          const lInner = document.createElement('span');
          lInner.className = 'sr-word__inner';
          lInner.style.display = 'inline-block';
          lInner.style.transform = 'translateY(105%)';
          lInner.style.transition = `transform ${this.Duration}ms cubic-bezier(0.25, 0.1, 0.1, 1)`;
          lInner.textContent = lWord;

          const lWrapper = document.createElement('span');
          lWrapper.className = 'sr-word';
          lWrapper.style.display = 'inline-block';
          lWrapper.style.overflow = 'hidden';
          lWrapper.style.verticalAlign = 'bottom';
          lWrapper.style.paddingBottom = '1px';
          lWrapper.appendChild(lInner);
          lFragment.appendChild(lWrapper);
          lInners.push(lInner);
        }
      }

      // - cm - Remplace le noeud texte par le fragment de mots wrapés
      lTextNode.parentNode?.replaceChild(lFragment, lTextNode);
    }

    // - cm - Stagger delays avec ordre
    for (let i = 0; i < lInners.length; i++)
    {
      lInners[i].style.transitionDelay = `${pOrderMs + i * this.StaggerDelay}ms`;
    }

    this._Observe(pEl, () =>
    {
      for (let i = 0; i < lInners.length; i++)
      {
        lInners[i].style.transform = 'translateY(0)';
      }
    });
  }
  //#endregion

  //#region Fade Animation
  private _SetupFadeReveal(pEl: HTMLElement, pOrderMs: number): void
  {
    pEl.style.opacity = '0';
    pEl.style.transform = `translateY(${this.OffsetY}px)`;
    pEl.style.transition = `opacity ${this.Duration}ms cubic-bezier(0.25, 0.1, 0.1, 1), transform ${this.Duration}ms cubic-bezier(0.25, 0.1, 0.1, 1)`;
    pEl.style.transitionDelay = `${pOrderMs}ms`;

    this._Observe(pEl, () =>
    {
      pEl.style.opacity = '1';
      pEl.style.transform = 'translateY(0)';
    });
  }
  //#endregion

  //#region Observer
  private _Observe(pEl: HTMLElement, pOnReveal: () => void): void
  {
    this._Observer = new IntersectionObserver(
      (pEntries: IntersectionObserverEntry[]) =>
      {
        for (const lEntry of pEntries)
        {
          if (lEntry.isIntersecting)
          {
            // - cm - Applique le stagger delay avant l'animation
            setTimeout(pOnReveal, this.Animation === 'fade' ? this.StaggerDelay : 0);
            this._HasRevealed = true;
            this._Observer?.unobserve(pEl);
            break;
          }
        }
      },
      { threshold: this.Threshold }
    );
    this._Observer.observe(pEl);
  }
  //#endregion
}
