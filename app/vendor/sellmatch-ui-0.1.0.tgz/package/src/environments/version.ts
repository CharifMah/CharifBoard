// - cm - Fichier généré par scripts/bump-version.js. NE PAS ÉDITER À LA MAIN.
// - cm - Mis à jour automatiquement à chaque build. Gitignoré : non commité.
export const APP_VERSION = 'build.20260819-170714-bd1093d9-dirty';
export const APP_BUILD_DATE = '2026-08-19T17:07:14.927Z';
export const APP_GIT_SHA = 'bd1093d9-dirty';
