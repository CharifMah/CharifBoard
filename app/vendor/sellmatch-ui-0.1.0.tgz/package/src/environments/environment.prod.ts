export const environment = {
  production: true,
  recette: false,
  apiBaseUrl: 'https://api.sellmatch.fr',
  apiUrl: 'https://api.sellmatch.fr/api',
  SignalUrl: 'https://api.sellmatch.fr',
  maintenance: true,
  publishableKey: 'pk_live_51T0iGuLBwVXx9nCbb3IEfxgYvE31TEDiD4TNeDzF90WjMhaCp4Pip0gEuY5qDqJM7QDAPqOn92O8H0IajwHIPaMY00aSgqlxie',
  mapboxToken: 'pk.eyJ1IjoiYWRtaW5zZWxsbWF0Y2giLCJhIjoiY21zajR6bDB3MDNidTJ3c2RkOGw2ZXR4cyJ9.n8wxEOakEe-5pwQv2z9hxg',
  posthog: {
    apiKey: 'phc_BnFHPjHHgXPf8dMRjtkbdxxUZ72xonRPBVuAZQRme4K4',
    host: 'https://posthog.sellmatch.fr',
    debug: false
  }
};
