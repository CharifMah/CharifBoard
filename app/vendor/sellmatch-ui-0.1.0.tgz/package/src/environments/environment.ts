export const environment = {
  production: false,
  recette: false,
  apiBaseUrl: '',
  apiUrl: '/api',
  SignalUrl: 'https://localhost:7122',
  maintenance: false,
  publishableKey: 'pk_test_51T0iH6Lyn5XprDw0QYcKEHBNAJLrl3E55UD3g7IPGTnrrdVGXEEaxodrslmBtXVDg5jlOLfRi8QZ1ToIiV2QlnkS00Pzvukkk0',
  mapboxToken: 'pk.eyJ1IjoiYWRtaW5zZWxsbWF0Y2giLCJhIjoiY21zajR6bDB3MDNidTJ3c2RkOGw2ZXR4cyJ9.n8wxEOakEe-5pwQv2z9hxg',
  posthog: {
    apiKey: 'phc_BnFHPjHHgXPf8dMRjtkbdxxUZ72xonRPBVuAZQRme4K4',
    host: 'https://posthog.sellmatch.fr',
    debug: true
  }
};
