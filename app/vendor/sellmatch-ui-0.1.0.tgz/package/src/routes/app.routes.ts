import { Routes } from '@angular/router';
import { ROUTE_PATHS } from '../routes/app.routes.constants';
import { LayoutComponent } from '../shared/components/layout/layout.component';
import { authGuard, guestGuard } from '../core/guards/auth.guard';
import { roleGuard } from '../core/guards';
import { UnauthorizedComponent } from '@views/unauthorized/unauthorized.component';
import { CommentCaMarcheComponent } from '@views/Public/comment-ca-marche/comment-ca-marche.component';
import { PricingPageComponent } from '@views/Public/pricing/pricing-page.component';
import { PaymentConfirmationPageComponent } from '@views/Public/payment-confirmation/payment-confirmation-page.component';
import { SubscriptionManagementPageComponent } from '@views/Public/subscription-management/subscription-management-page.component';
import { ForgotPasswordComponent } from '@views/Authentification/ForgotPassword/forgot-password.component';
import { LoginComponent } from '@views/Authentification/Login/login.component';
import { RegisterComponent } from '@views/Authentification/Register/register.component';
import { ResetPasswordComponent } from '@views/Authentification/ResetPassword/reset-password.component';
import { DashboardProComponent } from '@views/Dashboards/pro/dashboard-pro/dashboard-pro.component';
import { DashboardVendeurComponent } from '@views/Dashboards/vendeur/dashboard-vendeur/dashboard-vendeur.component';
import { CrmLayoutComponent } from '@views/Crm/crm-layout/crm-layout.component';
import { PlaygroundComponent } from '@views/Playground/playground.component';
import { CGUComponent } from '@views/Public/Legal/CGU/cgu.component';
import { ContactComponent } from '@views/Public/contact/contact.component';
import { FaqComponent } from '@views/Public/faq/faq.component';
import { HomeComponent } from '@views/Public/home/home.component';
import { PolitiqueConfidentialiteComponent } from '@views/Public/Legal/politique-confidentialite/politique-confidentialite.component';
import { ProfilProComponent } from '@views/Public/profil-pro/profil-pro.component';
import { MentionsLegalesComponent } from '@views/Public/Legal/MentionsLegales/mentions-legales.component';
import { CookiesPolicyComponent } from '@views/Public/Legal/cookies-policy/cookies-policy.component';
import { CGVComponent } from '@views/Public/Legal/CGV/cgv.component';
import { OutilEstimationComponent } from '@views/Public/OutilEstimation/outil-estimation.component';
import { EstimationVilleComponent } from '@views/Public/EstimationVille/estimation-ville.component';
import { BlogListComponent } from '@views/Public/Blog/blog-list/blog-list.component';
import { BlogArticleComponent } from '@views/Public/Blog/blog-article/blog-article.component';
import { subscriptionGuard } from '../core/guards/subscription.guard';

const mainRoutes: Routes = [
  //#region Public
  {
    path: ROUTE_PATHS.OUTILESTIMATION,
    component: OutilEstimationComponent
  },
  {
    path: ROUTE_PATHS.ESTIMATION_VILLE,
    component: EstimationVilleComponent
  },
  {
    path: ROUTE_PATHS.BLOG,
    component: BlogListComponent
  },
  {
    path: ROUTE_PATHS.BLOG_ARTICLE,
    component: BlogArticleComponent
  },
  {
    path: ROUTE_PATHS.POLICY,
    component: PolitiqueConfidentialiteComponent
  },
  {
    path: ROUTE_PATHS.CGU,
    component: CGUComponent
  },
  {
    path: ROUTE_PATHS.CONTACT,
    component: ContactComponent
  },
  {
    path: ROUTE_PATHS.FAQ,
    component: FaqComponent
  },
  {
    path: ROUTE_PATHS.PROFILPRO,
    component: ProfilProComponent
  },
  {
    path: ROUTE_PATHS.VENDEUR,
    component: CommentCaMarcheComponent
  },
  {
    path: ROUTE_PATHS.PRICING,
    component: PricingPageComponent
  },
  {
    path: ROUTE_PATHS.PAYMENT_CONFIRMATION,
    component: PaymentConfirmationPageComponent,
    canActivate: [authGuard]
  },
  {
    path: ROUTE_PATHS.SUBSCRIPTION_MANAGEMENT,
    component: SubscriptionManagementPageComponent,
    canActivate: [authGuard]
  },
  { path: ROUTE_PATHS.UNAUTHORIZED, component: UnauthorizedComponent },

  { path: ROUTE_PATHS.HOME, component: HomeComponent },
  { path: ROUTE_PATHS.MENTIONSLEGALES, component: MentionsLegalesComponent },
  { path: ROUTE_PATHS.COOKIESPOLICY, component: CookiesPolicyComponent },
  { path: ROUTE_PATHS.CGV, component: CGVComponent },

  //#region Auth
  {
    path: ROUTE_PATHS.CONNEXION,
    component: LoginComponent,
    canActivate: [guestGuard]
  },
  {
    path: ROUTE_PATHS.INSCRIPTION_PRO,
    component: RegisterComponent,
    canActivate: [guestGuard]
  },
  {
    path: ROUTE_PATHS.MDP,
    component: ForgotPasswordComponent,
    canActivate: [guestGuard]
  },
  {
    path: ROUTE_PATHS.RESET_PASSWORD,
    component: ResetPasswordComponent,
    canActivate: [guestGuard]
  },
  {
    path: ROUTE_PATHS.INSCRIPTION_VENDEUR,
    component: RegisterComponent,
    canActivate: [guestGuard]
  },
  //#endregion

  //#endregion

  //#region Private
  {
    path: ROUTE_PATHS.DASHBOARD_VENDEUR,
    component: DashboardVendeurComponent,
    canActivate: [authGuard, roleGuard(['vendeur', 'admin'])]
  },
  {
    path: ROUTE_PATHS.DASHBOARD_PRO,
    component: DashboardProComponent,
    canActivate: [authGuard, roleGuard(['professionnel', 'admin']), subscriptionGuard(['pro', 'premium'])]
  },
  //#endregion
];

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: mainRoutes
  },
  //#region CRM
  {
    path: ROUTE_PATHS.CRM,
    component: CrmLayoutComponent,
    canActivate: [authGuard, roleGuard(['professionnel', 'admin']), subscriptionGuard(['crm','premium'])]
  },
  //#endregion
  //#region Playground (admin uniquement)
  {
    path: ROUTE_PATHS.PLAYGROUND,
    component: PlaygroundComponent,
    canActivate: [authGuard, roleGuard(['admin'])]
  },
  //#endregion
  { path: '**', redirectTo: ROUTE_PATHS.HOME }
];
