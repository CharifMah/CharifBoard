// app.routes.constants.ts
export const ROUTE_PATHS = {
  HOME: '',
  CONNEXION: 'connexion',
  INSCRIPTION_VENDEUR: 'inscription-vendeur',
  INSCRIPTION_PRO: 'inscription-pro',
  VENDEUR: 'comment-ca-marche',
  FAQ: 'faq',
  CONTACT: 'contact',
  DASHBOARD_VENDEUR: 'dashboard-vendeur',
  DASHBOARD_PRO: 'dashboard-pro',
  CRM: 'crm',
  PLAYGROUND: 'playground',
  MDP: 'mot-de-passe-oublie',
  UNAUTHORIZED: 'unauthorized',
  POLICY: 'politique-confidentialite',
  CGU: 'cgu',
  PROFILPRO: 'profil/:profilUrl',
  RESET_PASSWORD: 'reset-password',
  PRICING: 'pricing',
  PAYMENT_CONFIRMATION: 'paiement/confirmation',
  SUBSCRIPTION_MANAGEMENT: 'mon-abonnement',
  MENTIONSLEGALES: 'mentions-legales',
  COOKIESPOLICY: 'politique-de-cookies',
  CGV: 'cgv',
  OUTILESTIMATION: 'estimation-immobiliere',
  ESTIMATION_VILLE: 'estimation-immobiliere/:ville',
  BLOG: 'blog',
  BLOG_ARTICLE: 'blog/:slug'
} as const;

export type RoutePath = typeof ROUTE_PATHS[keyof typeof ROUTE_PATHS];
