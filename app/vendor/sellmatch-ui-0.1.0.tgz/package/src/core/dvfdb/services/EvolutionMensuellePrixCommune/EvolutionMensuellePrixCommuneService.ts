import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { EvolutionMensuellePrixCommuneDTO } from '../../../../core/dvfdb/dto/EvolutionMensuellePrixCommune/EvolutionMensuellePrixCommuneDTO';
import { EvolutionMensuellePrixCommuneCritereDTO } from '../../../../core/dvfdb/dto/EvolutionMensuellePrixCommune/EvolutionMensuellePrixCommuneCritereDTO';

/**
 * Service permettant de récupérer l'évolution mensuelle des prix d'une commune.
 */
@Injectable({
  providedIn: 'root'
})
export class EvolutionMensuellePrixCommuneService extends ServiceBase<EvolutionMensuellePrixCommuneDTO,EvolutionMensuellePrixCommuneCritereDTO>
{

  /**
   * Initialise une nouvelle instance du service.
   */
  constructor ()
  {
    super('EvolutionMensuellePrixCommune'); // - cm - Endpoint API correspondant
  }
}
