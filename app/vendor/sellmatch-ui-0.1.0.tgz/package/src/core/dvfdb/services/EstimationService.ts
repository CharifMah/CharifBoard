import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../core/base/ServiceBase';
import { EstimationDTO } from '../../../core/dvfdb/dto/Estimation/EstimationDTO';
import { EstimationCritereDTO } from '../../../core/dvfdb/dto/Estimation/EstimationCritereDTO';

@Injectable({
  providedIn: 'root'
})
export class EstimationService extends ServiceBase<EstimationDTO, EstimationCritereDTO> {
  constructor() {
    super('Estimation');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
