import { BaseCritereDTO } from "../../../../core/base/base.critere";

export interface EstimationCritereDTO extends BaseCritereDTO
{
  longitude: number;
  latitude: number;
  typeBien: string;
  surfaceBien: number;
  surfaceTerrain: number;
  etatBien: string;
  rayonMetres: number;
  nbMoisHistorique: number;
}
