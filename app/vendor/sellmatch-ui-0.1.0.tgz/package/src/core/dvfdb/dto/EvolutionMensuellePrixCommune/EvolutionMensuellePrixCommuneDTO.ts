/**
 * DTO représentant l'évolution mensuelle des prix dans une commune.
 */
export interface EvolutionMensuellePrixCommuneDTO
{
  /**
   * Mois concerné par les données.
   */
  mois: string;

  /**
   * Nombre de ventes réalisées durant le mois.
   */
  nbVentesMois: number;

  /**
   * Prix au m² médian pour le mois.
   */
  prixM2MedianMois: number;

  /**
   * Prix au m² moyen pour le mois.
   */
  prixM2MoyenMois: number;

  /**
   * Volume total des transactions du mois.
   */
  volumeTotalMois: number;

  /**
   * Surface totale bâtie vendue durant le mois.
   */
  surfaceTotaleMois: number;

  /**
   * Nombre de ventes cumulées sur les 12 derniers mois glissants.
   */
  nbVentes12M: number;

  /**
   * Prix au m² pondéré sur les 12 derniers mois.
   */
  prixM2Pondere12M: number;

  /**
   * Prix au m² moyen glissant sur 12 mois.
   */
  prixM2MoyenGlissant12M: number;

  /**
   * Niveau de confiance statistique (Eleve, Moyen, Faible, Aucune donnee).
   */
  niveauConfianceMois: string;

  /**
   * Identifiant hérité côté API.
   */
  id?: number;
}
