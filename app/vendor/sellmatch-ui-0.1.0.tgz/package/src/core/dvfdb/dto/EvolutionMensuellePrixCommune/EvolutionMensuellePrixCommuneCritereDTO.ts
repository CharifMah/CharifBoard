import { BaseCritereDTO } from "../../../../core/base/base.critere";

/**
 * PROTECTEDFILE
 * Critères d'entrée pour la récupération de l'évolution mensuelle des prix autour d'un point.
 */
export interface EvolutionMensuellePrixCommuneCritereDTO extends BaseCritereDTO
{
  /**
  * Longitude du point de référence.
   */
  Longitude?: number;

  /**
  * Latitude du point de référence.
   */
  Latitude?: number;

  /**
  * Rayon de recherche autour du point de référence, en mètres.
  */
  RayonMetres?: number;

  /**
   * Type de bien filtré : 'maison', 'appartement' ou 'tous'.
   */
  TypeBien?: string;

  /**
   * Nombre de mois d'historique à récupérer.
   */
  NbMoisHistorique?: number;

  /**
   * Valeur foncière minimale pour filtrer les transactions.
   */
  ValeurFoncMin?: number;

  /**
   * Surface bâtie minimale pour filtrer les transactions.
   */
  SurfaceBatiMin?: number;
}
