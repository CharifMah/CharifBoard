

export interface EstimationDTO
{
  prixMoyenMetrCarre: number;
  prixMinEstime: number;
  prixMaxEstime: number;
  niveauConfiance: string;
  nombreTransactions: number;
}
