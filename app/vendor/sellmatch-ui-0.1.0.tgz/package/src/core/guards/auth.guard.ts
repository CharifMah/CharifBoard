import { inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { CanActivateFn, Router } from '@angular/router';
import { ROUTE_PATHS } from '../../routes/app.routes.constants';

import { environment } from '../../environments/environment';
import { UsersService } from '../sellmatchdb/services';
const TEST_PATH: string = '/test';
const NavigateTo = (router: Router, isTestMode: boolean, path: string): void =>
{
  const fullPath = '/' + path;
  if (environment.maintenance && isTestMode)
  {
    router.navigate([TEST_PATH + fullPath]);
  }
  else
  {
    router.navigate([fullPath]);
  }
};

/**
 * Redirige vers une route en conservant l'URL d'origine dans le paramètre `returnUrl`.
 * - cm - Permet au LoginComponent de renvoyer l'utilisateur sur la page qu'il tentait d'atteindre.
 * @param pRouter Le routeur Angular
 * @param pIsTestMode Indique si on est en mode test (préfixe /test)
 * @param pPath La route cible (sans slash)
 * @param pReturnUrl L'URL d'origine à restituer après login
 */
const NavigateToWithReturn = (pRouter: Router, pIsTestMode: boolean, pPath: string, pReturnUrl: string): void =>
{
  const lFullPath = '/' + pPath;
  const lReturnUrl = pReturnUrl?.startsWith('/') ? pReturnUrl : '/' + pReturnUrl;
  const lCommands = environment.maintenance && pIsTestMode
    ? [TEST_PATH + lFullPath]
    : [lFullPath];

  // - cm - On ne conserve le returnUrl que pour une URL interne non-vide et différente de la page de login
  if (lReturnUrl && lReturnUrl !== lFullPath && lReturnUrl !== '/' + ROUTE_PATHS.CONNEXION)
  {
    pRouter.navigate(lCommands, { queryParams: { returnUrl: lReturnUrl } });
  }
  else
  {
    pRouter.navigate(lCommands);
  }
};

export const authGuard: CanActivateFn = (route, state) =>
{
  const usersService = inject(UsersService);
  const router = inject(Router);
  const lIsBrowser = isPlatformBrowser(inject(PLATFORM_ID));
  const isTestMode = state.url.includes(TEST_PATH);

  // - cm - En SSR, on ne peut pas vérifier l'auth (pas de localStorage/sessionStorage)
  // On laisse passer pour éviter le flash de la page de connexion au refresh.
  // La redirection sera gérée côté client après hydration par le BaseViewComponent.
  if (!lIsBrowser)
  {
    return true;
  }

  if (!usersService.isLoggedIn())
  {
    // - cm - Conserve l'URL demandée pour y revenir après login (returnUrl)
    NavigateToWithReturn(router, isTestMode, ROUTE_PATHS.CONNEXION, state.url);
    return false;
  }

  return true;
};

export const guestGuard: CanActivateFn = (route, state) =>
{
  const usersService = inject(UsersService);
  const router = inject(Router);
  const lIsBrowser = isPlatformBrowser(inject(PLATFORM_ID));
  const isTestMode = state.url.includes(TEST_PATH);

  // - cm - En SSR, on ne peut pas vérifier l'auth (pas de localStorage/sessionStorage)
  // On laisse passer pour éviter une redirection prématurée vers le dashboard.
  if (!lIsBrowser)
  {
    return true;
  }

  if (usersService.isLoggedIn())
  {
    // - cm - Si un returnUrl est présent (l'utilisateur tentait d'atteindre une page protégée),
    // on y retourne au lieu du dashboard par défaut. On n'accepte qu'une URL interne (anti open-redirect).
    const lReturnUrl: string | null = route.queryParamMap?.get('returnUrl') ?? null;
    if (lReturnUrl && lReturnUrl.startsWith('/') && lReturnUrl !== '/' + ROUTE_PATHS.CONNEXION)
    {
      router.navigateByUrl(lReturnUrl);
      return false;
    }

    if (usersService.IsProfessionnel() || usersService.isAdmin())
    {
      NavigateTo(router, isTestMode, ROUTE_PATHS.DASHBOARD_PRO);
    }
    else if (usersService.IsVendeur())
    {
      NavigateTo(router, isTestMode, ROUTE_PATHS.DASHBOARD_VENDEUR);
    }
    else
    {
      NavigateTo(router, isTestMode, ROUTE_PATHS.HOME);
    }
    return false;
  }

  return true;
};
