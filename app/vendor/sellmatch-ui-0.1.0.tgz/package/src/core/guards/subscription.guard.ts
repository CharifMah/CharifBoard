import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ROUTE_PATHS } from '../../routes/app.routes.constants';
import { UsersService } from '../sellmatchdb/services';

export const subscriptionGuard = (allowedPlans: string[]): CanActivateFn =>
{
  return (route, state) =>
  {
    const usersService = inject(UsersService);
    const router = inject(Router);

    if (!usersService.isLoggedIn())
    {
      router.navigate([ROUTE_PATHS.CONNEXION], { queryParams: { returnUrl: state.url } });
      return false;
    }

    if (!usersService.hasAnyPlan(allowedPlans))
    {
      // Rediriger vers la page d'abonnement
      router.navigate([ROUTE_PATHS.UNAUTHORIZED], { queryParams: { returnUrl: state.url } });
      return false;
    }

    return true;
  };
};
