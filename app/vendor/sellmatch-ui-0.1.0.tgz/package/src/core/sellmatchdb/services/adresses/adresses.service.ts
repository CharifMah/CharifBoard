import { inject, Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';
import { TranslationService } from '../../../services/i18n';
///PROTECTEDFILE
@Injectable({
  providedIn: 'root'
})
export class AdressesService extends ServiceBase<AdressesDTO, AdressesCritereDTO>
{
  private readonly _TranslateService: TranslationService = inject(TranslationService);
  constructor ()
  {
    super('Adresses');
  }

  //#region Public API
  /**
   * Recherche des suggestions d'adresses via le backend (proxy Mapbox Search Box /forward).
   * Le backend applique par défaut un filtre excluant les POI (mairies, hôtels, restaurants) :
   * ne renvoie que adresses, rues, codes postaux, villes, localités et quartiers.
   * @param pQuery Texte saisi (minimum 3 caractères recommandé).
   * @param pLimit Nombre maximum de résultats (défaut 5).
   * @param pTypes Filtre Mapbox optionnel (ex: "address,place"). Si null/omis, le backend applique
   * le filtre par défaut (adresses + villes + codes postaux, sans POI).
   * @returns Les suggestions d'adresses avec leurs coordonnées, ou un tableau vide en cas d'erreur.
   */
  public async SearchAsync(pQuery: string, pLimit: number = 5, pTypes?: string): Promise<AdressesDTO[]> {
    if (!pQuery || pQuery.length < 3) return [];

    let lUrl = `${this.apiUrl}/search?q=${encodeURIComponent(pQuery)}&limit=${pLimit}&langue=${this._TranslateService.getCurrentLanguage()}`;
    // - cm - Ajout du filtre types si fourni (sinon, le backend applique son filtre par défaut anti-POI)
    if (pTypes && pTypes.trim().length > 0) {
      lUrl += `&types=${encodeURIComponent(pTypes.trim())}`;
    }
    try {
      const lResponse = await this.axiosInstance.get<AdressesDTO[]>(lUrl);
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    } catch (lError) {
      console.error('Erreur API Adresse (Mapbox /forward):', lError);
      return [];
    }
  }

  /**
   * Construit un libellé texte détaillé à partir d'une valeur d'adresse.
   * Gère : objet AdressesDTO (avec ou sans label), string, ou vide.
   * Format : "Rue, code postal Ville" (ex: "27 Grande Rue, 25430 Randevillers").
   * Si la rue manque (cas d'une ville seule), on retombe sur "Ville" ou "code postal Ville".
   * @param pValue La valeur reçue (objet, string ou null).
   * @returns Le libellé à afficher dans le champ.
   */
  public BuildLabel(pValue: any): string {
    if (!pValue) return '';

    // - cm - Déjà une string -> on l'affiche telle quelle.
    if (typeof pValue === 'string') return pValue;

    const lAddr = pValue as AdressesDTO;

    // - cm - Si le backend fournit un label complet (ville + CP + rue) on l'utilise tel quel.
    // C'est le cas pour les adresses déjà persistées en BDD qui ont un label riche.
    if (lAddr.label && (lAddr.label.includes(lAddr.postcode ?? '') || lAddr.label.includes(lAddr.city ?? ''))) {
      return lAddr.label;
    }

    // - cm - Reconstruction à partir des composantes (cas Mapbox : label = nom de rue court).
    // On évite les doublons street/label quand ils sont identiques.
    const lRue: string = (lAddr.street && lAddr.street.trim().length > 0)
      ? lAddr.street.trim()
      : (lAddr.label && (!lAddr.street || lAddr.street.trim() !== lAddr.label.trim()))
        ? lAddr.label.trim()
        : '';

    const lCpVille: string = [lAddr.postcode, lAddr.city]
      .filter((pPart) => !!pPart && String(pPart).trim().length > 0)
      .join(' ');

    if (lRue && lCpVille) {
      return `${lRue}, ${lCpVille}`;
    }
    return lRue || lCpVille || lAddr.label || '';
  }
  //#endregion
}
