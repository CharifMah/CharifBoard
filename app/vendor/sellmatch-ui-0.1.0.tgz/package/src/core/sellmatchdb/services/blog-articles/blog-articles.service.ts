import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { BlogArticlesDTO } from '../../../../core/sellmatchdb/dto/blog-articles/blog-articles.dto';
import { BlogArticlesCritereDTO } from '../../../../core/sellmatchdb/dto/blog-articles/blog-articles.critere';

// PROTECTEDFILE

/**
 * Service Angular pour les articles de blog SEO.
 * Étend ServiceBase pour hériter du CRUD générique et du tracking PostHog.
 */
@Injectable({
  providedIn: 'root'
})
export class BlogArticlesService extends ServiceBase<BlogArticlesDTO, BlogArticlesCritereDTO>
{
  constructor()
  {
    super('BlogArticles');
  }

  /**
   * Récupère les articles publiés triés par date de publication décroissante.
   * @param pLimit Nombre maximum d'articles à récupérer (optionnel)
   * @returns Liste des articles publiés
   */
  public async GetPublishedArticles(pLimit?: number): Promise<BlogArticlesDTO[]>
  {
    const lCritere: BlogArticlesCritereDTO = {
      isPublished: true,
      pageSize: pLimit ?? 20,
      page: 1
    };

    return await this.getAll(lCritere);
  }

  /**
   * Récupère un article par son slug.
   * @param pSlug Le slug de l'article (kebab-case)
   * @returns L'article correspondant ou null
   */
  public async GetBySlug(pSlug: string): Promise<BlogArticlesDTO | null>
  {
    const lCritere: BlogArticlesCritereDTO = {
      slug: pSlug,
      isPublished: true
    };

    return await this.get(lCritere);
  }

  /**
   * Récupère les articles mis en avant (featured).
   * @param pLimit Nombre maximum d'articles (optionnel)
   * @returns Liste des articles featured
   */
  public async GetFeaturedArticles(pLimit?: number): Promise<BlogArticlesDTO[]>
  {
    const lCritere: BlogArticlesCritereDTO = {
      isPublished: true,
      isFeatured: true,
      pageSize: pLimit ?? 5,
      page: 1
    };

    return await this.getAll(lCritere);
  }
}