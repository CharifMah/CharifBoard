// gen-hash:42669caf58e284008d5d5b9f739e0e50942fef09014da67c2ff0d016f8607826
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { EmailDTO } from '../../../../core/sellmatchdb/dto/email/email.dto';
import { EmailCritereDTO } from '../../../../core/sellmatchdb/dto/email/email.critere';

@Injectable({
  providedIn: 'root'
})
export class EmailService extends ServiceBase<EmailDTO, EmailCritereDTO> {
  constructor() {
    super('Email');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
