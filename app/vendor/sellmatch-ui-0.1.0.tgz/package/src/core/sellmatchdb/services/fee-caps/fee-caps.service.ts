// gen-hash:5c8e1f148e87f986f4c0d382a778f65ac29bb995695c98249c7a59c5bba9a4a6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { FeeCapsDTO } from '../../../../core/sellmatchdb/dto/fee-caps/fee-caps.dto';
import { FeeCapsCritereDTO } from '../../../../core/sellmatchdb/dto/fee-caps/fee-caps.critere';

@Injectable({
  providedIn: 'root'
})
export class FeeCapsService extends ServiceBase<FeeCapsDTO, FeeCapsCritereDTO> {
  constructor() {
    super('FeeCaps');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
