import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormGroup } from '@angular/forms';

/**
 * Service générique pour la gestion du sessionStorage.
 * Permet de sauvegarder, restaurer et nettoyer l'état de l'application de manière sécurisée.
 * SSR-safe : toutes les méthodes vérifient la plateforme avant d'accéder au sessionStorage.
 */
@Injectable({
  providedIn: 'root'
})
export class SessionStorageService
{
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /**
   * Sauvegarde une valeur dans le sessionStorage.
   * @param pKey La clé de stockage
   * @param pValue La valeur à sauvegarder (sera sérialisée en JSON)
   */
  public Save<T>(pKey: string, pValue: T): void 
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    try 
    {
      sessionStorage.setItem(pKey, JSON.stringify(pValue));
    }
    catch (pError) 
    {
      console.error(`Erreur lors de la sauvegarde de l'état (${pKey})`, pError); // - cm - Gestion erreur stockage
    }
  }

  /**
   * Récupère une valeur depuis le sessionStorage.
   * @param pKey La clé de stockage
   * @returns La valeur désérialisée ou null si inexistante
   */
  public Restore<T>(pKey: string): T | null 
  {
    if (!this._IsBrowser) return null; // - cm - No-op côté serveur (SSR)

    try 
    {
      const lData = sessionStorage.getItem(pKey);
      return lData ? JSON.parse(lData) as T : null;
    }
    catch (pError) 
    {
      console.error(`Erreur lors de la restauration de l'état (${pKey})`, pError); // - cm - Gestion erreur stockage
      return null;
    }
  }

  /**
   * Supprime une ou plusieurs clés du sessionStorage.
   * @param pKeys Les clés à supprimer
   */
  public Clear(...pKeys: string[]): void 
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    try 
    {
      pKeys.forEach(pKey => sessionStorage.removeItem(pKey));
    }
    catch (pError) 
    {
      console.error('Erreur lors du nettoyage de l\'état', pError); // - cm - Gestion erreur stockage
    }
  }

  /**
   * Sauvegarde l'étape actuelle et les valeurs d'un FormGroup dans le sessionStorage.
   * @param pPrefix Préfixe pour les clés de stockage
   * @param pCurrentStep L'étape en cours
   * @param pForm Le FormGroup à sauvegarder
   */
  public SaveFormStepState(pPrefix: string, pCurrentStep: number, pForm: FormGroup): void
  {
    this.Save(`${pPrefix}_step`, pCurrentStep);
    this.Save(`${pPrefix}_form`, pForm.value);
  }

  /**
   * Restaure l'étape et les valeurs d'un FormGroup depuis le sessionStorage.
   * @param pPrefix Préfixe pour les clés de stockage
   * @param pForm Le FormGroup à restaurer
   * @returns L'étape restaurée ou 1 par défaut
   */
  public RestoreFormStepState(pPrefix: string, pForm: FormGroup): number
  {
    const lStep = this.Restore<number>(`${pPrefix}_step`);
    const lFormData = this.Restore<any>(`${pPrefix}_form`);

    if (lFormData)
    {
      pForm.patchValue(lFormData); // - cm - Restauration des valeurs sans écraser les contrôleurs
    }

    return lStep ?? 1; // - cm - Retourne 1 si aucune étape n'est trouvée
  }

  /**
   * Nettoie les données d'étape et de formulaire du sessionStorage.
   * @param pPrefix Préfixe pour les clés de stockage
   */
  public ClearFormStepState(pPrefix: string): void
  {
    this.Clear(`${pPrefix}_step`, `${pPrefix}_form`);
  }
}
