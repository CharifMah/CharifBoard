// gen-hash:77272f126d013589212771040a4430b28500d3be3d57124ed3027b1ea3efed33
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RolesDTO } from '../../../../core/sellmatchdb/dto/roles/roles.dto';
import { RolesCritereDTO } from '../../../../core/sellmatchdb/dto/roles/roles.critere';

@Injectable({
  providedIn: 'root'
})
export class RolesService extends ServiceBase<RolesDTO, RolesCritereDTO> {
  constructor() {
    super('Roles');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
