import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { SettingsDTO } from '../../../../core/sellmatchdb/dto/settings/settings.dto';
import { SettingsCritereDTO } from '../../../../core/sellmatchdb/dto/settings/settings.critere';

/**
 * Service CRUD pour la table `settings` (cle/valeur/type/owner).
 * - cm - La table est GENERIQUE : un user peut avoir N settings (cle=langue, ui.theme, etc.).
 * On expose une methode dediee `upsertUserSetting` pour factoriser le pattern
 * "recherche par (userId, key) puis update ou create" que ThemeService partage
 * avec la sauvegarde de langue dans profil.component.
 */
@Injectable({
  providedIn: 'root'
})
export class SettingsService extends ServiceBase<SettingsDTO, SettingsCritereDTO> {
  constructor() {
    super('Settings');
  }

  /**
   * Cree ou met a jour un setting utilisateur a partir de sa cle logique.
   * - cm - Cherche une ligne existante par (userId, key). Si trouvee, met a jour.
   * Sinon, cree la ligne. C'est le pattern exact de `updateLanguageSetting` dans
   * profil.component, factorise pour etre reutilise par n'importe quel service
   * (ThemeService, futures preferences, etc.).
   * - cm - Ne leve pas d'exception en cas d'erreur reseau : retourne null pour
   * que l'appelant puisse decider de la strategie de fallback (localStorage, etc.).
   * @param pUserId Id du user proprietaire du setting.
   * @param pKey Cle logique du setting (ex: 'langue', 'ui.theme').
   * @param pValue Valeur a persister (stringifiee par l'appelant si besoin).
   * @param pValueType Type logique ('string', 'bool', 'int'). Defaut 'string'.
   * @returns Le DTO persiste (avec son id) ou null si echec.
   */
  public async upsertUserSetting(
    pUserId: number,
    pKey: string,
    pValue: string,
    pValueType: string = 'string'
  ): Promise<SettingsDTO | null> {
    try
    {
      // - cm - Recherche d'une ligne existante par (userId, key).
      // - cm - On passe `keys: [pKey]` ET `userIds: [pUserId]` plutot que `key`/`userId` exacts
      // pour suivre le pattern de SettingsCritereDTO (IN).
      const lExisting: SettingsDTO[] = await this.getAll({ userIds: [pUserId], keys: [pKey] });
      if (lExisting.length > 0 && lExisting[0].id !== undefined)
      {
        const lToUpdate: SettingsDTO = {
          ...lExisting[0],
          key: pKey,
          value: pValue,
          valueType: pValueType,
          userId: pUserId
        };
        // - cm - L'API Settings.Update requiert le critere de localisation en query string.
        // On utilise (userId, key) pour cibler la bonne ligne si plusieurs users partagent la cle.
        const lUpdated = await this.update(lToUpdate, { key: pKey, userId: pUserId });
        return lUpdated ?? lToUpdate;
      }
      // - cm - Pas de ligne existante : creation.
      const lNewSetting: SettingsDTO = {
        key: pKey,
        value: pValue,
        valueType: pValueType,
        userId: pUserId
      };
      const lCreated = await this.create(lNewSetting);
      return lCreated ?? lNewSetting;
    }
    catch (pError)
    {
      //TODO GEERE LEXCEPTION CORRECTEMENT remonte l'erreur corretement
      return null;
    }
  }
}
