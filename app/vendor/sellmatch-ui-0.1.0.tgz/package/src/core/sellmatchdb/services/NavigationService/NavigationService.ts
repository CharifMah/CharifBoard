// core/services/navigation/navigation.service.ts
import { Injectable, signal, computed } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class NavigationService
{
  private readonly _View = signal<string>('dashboard');
  private readonly _History = signal<string[]>(['dashboard']);

  public readonly View = this._View.asReadonly();
  public readonly CanGoBack = computed(() => this._History().length > 1);

  public Go(pView: string): void
  {
    if (this._View() === pView) return;

    this._History.update(h => [...h, pView]);
    this._View.set(pView);
  }

  public Back(): void
  {
    const lHistory = this._History();
    if (lHistory.length <= 1) return;

    this._History.set(lHistory.slice(0, -1));
    this._View.set(lHistory[lHistory.length - 2]);
  }

  public Is(pView: string): boolean
  {
    return this._View() === pView;
  }

  public Reset(pView: string = 'dashboard'): void
  {
    this._View.set(pView);
    this._History.set([pView]);
  }
}
