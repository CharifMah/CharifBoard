// gen-hash:78b52306d6c889570b0f25ecbdba7eac32ec47d969a40d0aa487160d56b6a6f6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { MessagesDTO } from '../../../../core/sellmatchdb/dto/messages/messages.dto';
import { MessagesCritereDTO } from '../../../../core/sellmatchdb/dto/messages/messages.critere';

@Injectable({
  providedIn: 'root'
})
export class MessagesService extends ServiceBase<MessagesDTO, MessagesCritereDTO> {
  constructor() {
    super('Messages');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
