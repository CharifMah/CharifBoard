// gen-hash:e3b3d0df2d095e1d7510bea80ce7e8f24cc07d387c5557b002d8e34033a61047
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { OpportunitiesDTO } from '../../../../core/sellmatchdb/dto/opportunities/opportunities.dto';
import { OpportunitiesCritereDTO } from '../../../../core/sellmatchdb/dto/opportunities/opportunities.critere';

@Injectable({
  providedIn: 'root'
})
export class OpportunitiesService extends ServiceBase<OpportunitiesDTO, OpportunitiesCritereDTO> {
  constructor() {
    super('Opportunities');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
