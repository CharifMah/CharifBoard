// gen-hash:a23636fc145018e010d708bbdf06491e04a29a74ac293ffb502a918e1fda6248
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ApplicationsDTO } from '../../../../core/sellmatchdb/dto/applications/applications.dto';
import { ApplicationsCritereDTO } from '../../../../core/sellmatchdb/dto/applications/applications.critere';

@Injectable({
  providedIn: 'root'
})
export class ApplicationsService extends ServiceBase<ApplicationsDTO, ApplicationsCritereDTO> {
  constructor() {
    super('Applications');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
