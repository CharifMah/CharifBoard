// gen-hash:2b749f69f46a81f013e0b94a2d50e72bcede62990376e3b0b15af4045c2cf9d4
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { SubscriptionPlansDTO } from '../../../../core/sellmatchdb/dto/subscription-plans/subscription-plans.dto';
import { SubscriptionPlansCritereDTO } from '../../../../core/sellmatchdb/dto/subscription-plans/subscription-plans.critere';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionPlansService extends ServiceBase<SubscriptionPlansDTO, SubscriptionPlansCritereDTO> {
  constructor() {
    super('SubscriptionPlans');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
