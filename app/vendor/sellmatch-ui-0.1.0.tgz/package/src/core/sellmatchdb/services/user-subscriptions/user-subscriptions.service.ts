// gen-hash:128931dfc07962bdc707a00f33f39e228aaba99ffd6fc5bf796ab48b9ebd4f6e
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { UserSubscriptionsDTO } from '../../../../core/sellmatchdb/dto/user-subscriptions/user-subscriptions.dto';
import { UserSubscriptionsCritereDTO } from '../../../../core/sellmatchdb/dto/user-subscriptions/user-subscriptions.critere';

@Injectable({
  providedIn: 'root'
})
export class UserSubscriptionsService extends ServiceBase<UserSubscriptionsDTO, UserSubscriptionsCritereDTO> {
  constructor() {
    super('UserSubscriptions');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
