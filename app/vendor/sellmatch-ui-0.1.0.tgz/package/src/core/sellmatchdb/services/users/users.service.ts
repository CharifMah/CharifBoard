import { inject, Injectable, OnDestroy } from '@angular/core';
import { ServiceBase, unauthorized$ } from '../../../../core/base/ServiceBase';
import { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';
import { BehaviorSubject, Subscription } from 'rxjs';
import { jwtDecode } from 'jwt-decode';
import { ROUTE_PATHS } from '../../../../routes/app.routes.constants';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';
import { PostHogService } from '../../../../core/services/posthog/PostHogService';
import { SettingsDTO, SubscriptionPlansDTO } from '../../dto';

/**
 * Interface pour le payload JWT décodé
 */
interface JwtPayload
{
  aud: string;
  exp: number;
  iss: string;
  "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": string;
  "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress": string;
  "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name": string;
  "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier": string;
  plan?: string; // Ajout du claim 'plan'
}

/**
 * Service de gestion des utilisateurs avec authentification JWT
 * Gère la session utilisateur, les rôles et les permissions
 */
@Injectable({
  providedIn: 'root'
})
export class UsersService extends ServiceBase<UsersDTO, UsersCritereDTO> implements OnDestroy
{
  //#region Attributes
  /**
   * Subject pour l'utilisateur courant avec persistence locale
   */
  private currentUserSubject = new BehaviorSubject<UsersDTO | null>(null);

  /**
   * Observable public pour l'utilisateur courant
   */
  public currentUser$ = this.currentUserSubject.asObservable();

  /**
   * Subscription au Subject global unauthorized$ : déclenché par ServiceBase
   * à chaque 401 intercepté par Axios. Permet de vider currentUserSubject
   * et nettoyer PostHog sans dépendance circulaire ServiceBase → UsersService.
   */
  private unauthorizedSubscription: Subscription;

  /**
   * Service PostHog pour identifier l'utilisateur authentifié
   */
  private readonly _PostHog: PostHogService = inject(PostHogService);
  //#endregion

  /**
   * Initialise le service et charge l'utilisateur depuis le stockage local
   */
  constructor ()
  {
    super('Users');
    this.loadUserFromStorage();
    // - cm - À chaque 401 (cookie expiré, session BDD révoquée, JWT legacy invalide),
    // on vide l'utilisateur en mémoire pour que isLoggedIn() retourne false
    // et que le BaseViewComponent redirige vers la page de login.
    this.unauthorizedSubscription = unauthorized$.subscribe(() =>
    {
      if (this.currentUserSubject.value !== null)
      {
        this.clearStorage();
        this.currentUserSubject.next(null);
        this._PostHog.Reset();
        // - cm - Note : pas de NavigateTo ici, le ServiceBase handleUnauthorized a déjà redirigé.
        // - cm - On évite ainsi les doubles navigations en cascade (toutes les requêtes échouent).
      }
    });
  }

  //#region Methods
  /**
   * Nettoie les ressources lors de la destruction du service
   */
  ngOnDestroy(): void
  {
    this.unauthorizedSubscription?.unsubscribe();  }

  /**
   * Charge l'utilisateur depuis le localStorage (si "Se souvenir de moi") ou le sessionStorage (sinon)
   * si un profil valide existe. Le token JWT est dans un cookie HttpOnly, inaccessible via JS.
   * - cm - En parallèle, lance un appel GET /api/Users/me pour rafraîchir le profil depuis le serveur
   * - cm - (le rôle/plan a pu changer côté BDD depuis le dernier login). Si l'appel réussit, le profil
   * - cm - est mis à jour en mémoire + storage. S'il échoue (réseau, JWT expiré), le profil local est
   * - cm - conservé tel quel — grâce au Fix #1, l'intercepteur 401 ne déconnecte QUE si X-Token-Expired=true.
   */
  private loadUserFromStorage(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    // - cm - Wrappé dans un try/catch : iOS Safari mobile peut lever SecurityError/QuotaExceededError
    // (mode privé, ITP) sur l'accès au storage, ce qui ferait planter l'init du service.
    let lUserJson: string | null = null;
    try
    {
      // - cm - Priorité : localStorage (remember me) puis sessionStorage (session courante)
      lUserJson = localStorage.getItem(this.USER_KEY) ?? sessionStorage.getItem(this.USER_KEY);
    } catch
    {
      // - cm - storage indisponible (iOS Safari privé/ITP) : on garde l'utilisateur en mémoire seulement
      lUserJson = null;
    }

    if (lUserJson)
    {
      try
      {
        const lUser = JSON.parse(lUserJson) as UsersDTO;
        this.currentUserSubject.next(lUser);
        this._PostHog.IdentifyUser(lUser);
      }
      catch
      {
        this.clearStorage();
      }
    }
    else
    {
      this.clearStorage();
    }

    // - cm - Rafraîchissement asynchrone depuis le serveur (ne bloque pas l'init du service).
    // - cm - Fire-and-forget : on ne propage pas l'erreur, et on ne touche pas au storage si l'API
    // - cm - ne renvoie rien (perte de session, JWT expiré sans header → l'intercepteur 401 ne déconnecte
    // - cm - pas grâce au Fix #1, mais l'utilisateur garde son profil local jusqu'au prochain reload).
    void this.refreshFromServer();
  }

  /**
   * Appel GET /api/Users/me pour rafraîchir le profil courant depuis le serveur (cookie HttpOnly).
   * Met à jour currentUser$ + storage si l'appel réussit.
   *
   * Si l'API renvoie un 401, l'intercepteur axios (dans ServiceBase) déclenche handleUnauthorized
   * qui vide le storage et redirige vers /unauthorized. On n'a donc rien à faire ici : l'absence
   * de try/catch autour de l'appel est volontaire, on laisse remonter l'erreur pour que l'intercepteur
   * prenne le relais. Cette approche est plus simple et plus fiable que de vérifier le header
   * X-Token-Expired (qui peut être masqué par CORS dans certains scénarios cross-origin).
   *
   * @returns La promesse résolue en cas de succès, ou rejetée en cas d'erreur (intercepteur 401).
   */
  private async refreshFromServer(): Promise<void>
  {
    if (!this._IsBrowser) return;
    const lUrl = `${this.apiUrl}/me`;
    // - cm - On laisse l'intercepteur 401 gérer le cas "session expirée/révoquée". Si l'API est
    // - cm - down (erreur réseau, timeout, cold start Render), l'erreur remonte ici aussi et
    // - cm - est silencieusement ignorée par l'appelant (fire-and-forget dans loadUserFromStorage).
    const lResponse = await this.axiosInstance.get<UsersDTO>(lUrl);
    const lUser = lResponse.data;
    if (lUser && lUser.id)
    {
      // - cm - Le serveur a parlé : le profil est la vérité terrain, on re-pousse dans le storage
      // - cm - en respectant le mode rememberMe courant (sinon on basculerait tout en localStorage).
      this.setUserSession(lUser);
    }
  }

  /**
   * Authentifie un utilisateur avec un identifiant (email OU username) et mot de passe.
   * @param pUser Le DTO utilisateur (Email = identifiant, PasswordHash = mot de passe en clair, RememberMe = flag)
   * @returns L'utilisateur authentifié avec token
   */
  async login(pUser: UsersDTO): Promise<UsersDTO>
  {
    const lUrl = `${this.apiUrl}/Login`;

    try
    {
      const lResponse = await this.axiosInstance.post<UsersDTO>(lUrl, pUser);
      const lUser = lResponse.data;

      // - cm - Le token JWT est stocké dans un cookie HttpOnly par le serveur (inaccessible côté JS)
      // On vérifie la présence de l'utilisateur (id) plutôt que du token
      if (lUser && lUser.id)
      {
        this.setUserSession(lUser);
      }

      return lUser;
    }
    catch (lError: any)
    {
      // - cm - Utilise handleError qui parse les ProblemDetails ASP.NET (format {"errors": {"Email": ["msg"]}})
      const lMessage = this.handleError(lError);
      throw new Error(lMessage);
    }
  }

  /**
   * Authentifie un utilisateur avec email/mot de passe
   * @param pUser Données de connexion
   * @returns L'utilisateur authentifié avec token
   */
  async GetProfilPro(pUser: UsersCritereDTO): Promise<UsersDTO>
  {
    const lUrl = `${this.apiUrl}/GetProfilPro`;

    try
    {
      const lResponse = await this.axiosInstance.post<UsersCritereDTO>(lUrl, pUser);
      const lUser = lResponse.data as UsersDTO;

      return lUser;
    }
    catch (lError: any)
    {
      const lMessage = this.handleError(lError);
      throw new Error(lMessage);
    }
  }

  public getLangue(): SettingsDTO | undefined
  {
    return this.currentUser?.userSettings?.find(s => s.key == "langue");
  }

  /**
   * Demande une réinitialisation de mot de passe pour un utilisateur
   * @param email L'email de l'utilisateur qui souhaite réinitialiser son mot de passe
   * @returns Une promesse qui indique si la demande a réussi
   */
  async requestPasswordReset(email: string): Promise<boolean>
  {
    try
    {
      // Valider l'email
      if (!email || !/\S+@\S+\.\S+/.test(email))
      {
        throw new Error("L'adresse email est invalide");
      }

      const lUrl = `${this.apiUrl}/RequestPasswordReset`;

      // Utiliser axios comme dans le reste du service
      const lResponse = await this.axiosInstance.post<{ success: boolean, message: string }>(lUrl, email);
      const result = lResponse.data;

      if (!result || !result.success)
      {
        throw new Error(result?.message || "Échec de la demande de réinitialisation");
      }

      return true;
    } catch (lError: any)
    {
      // Si l'erreur est liée à un email non trouvé, ne pas exposer cette information
      // pour des raisons de sécurité, mais logger l'erreur
      if (lError.response && lError.response.status === 404)
      {
        console.warn(`Email non trouvé pour la réinitialisation: ${email}`);
        // Simuler un succès pour ne pas révéler l'inexistence de l'email
        return true;
      }

      console.error('Erreur lors de la demande de réinitialisation de mot de passe:', lError);
      const lMessage = this.handleError(lError);
      throw new Error(lMessage);
    }
  }

  /**
   * Réinitialise le mot de passe avec le token reçu
   * @param token Le token de réinitialisation
   * @param email L'email de l'utilisateur
   * @param newPassword Le nouveau mot de passe
   * @returns Une promesse qui indique si la réinitialisation a réussi
   */
  async resetPassword(token: string, email: string, newPassword: string): Promise<boolean>
  {
    try
    {
      // Valider les paramètres
      if (!token)
      {
        throw new Error("Le token de réinitialisation est invalide");
      }

      if (!email || !/\S+@\S+\.\S+/.test(email))
      {
        throw new Error("L'adresse email est invalide");
      }

      if (!newPassword || newPassword.length < 8)
      {
        throw new Error("Le mot de passe doit contenir au moins 8 caractères");
      }

      const lUrl = `${this.apiUrl}/ResetPassword`;

      // Utiliser axios comme dans le reste du service
      const lResponse = await this.axiosInstance.post<{ success: boolean, message: string }>(
        lUrl,
        { token, email, newPassword }
      );
      const result = lResponse.data;

      if (!result || !result.success)
      {
        throw new Error(result?.message || "Échec de la réinitialisation du mot de passe");
      }

      return true;
    } catch (lError: any)
    {
      console.error('Erreur lors de la réinitialisation du mot de passe:', lError);
      const lMessage = this.handleError(lError);
      throw new Error(lMessage);
    }
  }

  /**
   * Vérifie si un token de réinitialisation est valide
   * @param token Le token à vérifier
   * @param email L'email associé au token
   * @returns Une promesse qui indique si le token est valide
   */
  async verifyResetToken(token: string, email: string): Promise<boolean>
  {
    try
    {
      if (!token || !email)
      {
        return false;
      }

      const lUrl = `${this.apiUrl}/VerifyResetToken`;

      const lResponse = await this.axiosInstance.post<{ isValid: boolean }>(
        lUrl,
        { token, email }
      );

      return lResponse.data.isValid;
    } catch (lError: any)
    {
      console.error('Erreur lors de la vérification du token de réinitialisation:', lError);
      return false;
    }
  }

  /**
   * Met à jour un utilisateur et synchronise l'état local
   * @param pUser Données à mettre à jour (doit inclure l'id)
   * @returns L'utilisateur mis à jour ou null si échec
   */
  override async update(pUser: UsersDTO, pCritere?: UsersCritereDTO): Promise<UsersDTO | null>
  {
    try
    {
      if (!pUser.id)
      {
        throw new Error("L'ID utilisateur est requis pour la mise à jour");
      }

      // Appelle la méthode parente qui retourne UsersDTO | null
      const lUpdatedUser = await super.update(pUser, pCritere);

      // Synchronise seulement si l'utilisateur a été mis à jour
      if (lUpdatedUser)
      {
        this.synchronizeCurrentUser(lUpdatedUser);
      }

      return lUpdatedUser;
    }
    catch (error)
    {
      console.error('Erreur lors de la mise à jour de l\'utilisateur:', error);
      throw new Error(this.handleError(error));
    }
  }

  /**
   * Synchronise l'utilisateur courant avec les nouvelles données
   * @param pUpdatedUser Utilisateur mis à jour depuis le serveur
   */
  private synchronizeCurrentUser(pUpdatedUser: UsersDTO): void
  {
    const lCurrentUser = this.currentUserSubject.value;

    if (lCurrentUser && lCurrentUser.id === pUpdatedUser.id)
    {
      const lMergedUser = {
        ...lCurrentUser,
        ...pUpdatedUser,
      };

      // - cm - Mise à jour mémoire d'abord (robuste iOS Safari : localStorage peut échouer)
      this.currentUserSubject.next(lMergedUser);      
    }
  }

  /**
   * Détermine si la session doit être persistante (localStorage) ou de session (sessionStorage).
   * Basé sur le flag "rememberMe" positionné par le LoginComponent avant l'appel login.
   * @returns True si "Se souvenir de moi" est actif, false sinon.
   */
  private isRememberMe(): boolean
  {
    if (!this._IsBrowser) return false;
    try
    {
      return localStorage.getItem('rememberMe') === 'true';
    } catch
    {
      return false;
    }
  }

  /**
   * Définit la session utilisateur après une connexion réussie
   * @param pUser Utilisateur avec token
   */
  private setUserSession(pUser: UsersDTO): void
  {
    // - cm - On met d'abord à jour l'état en mémoire pour garantir la disponibilité immédiate
    // même si localStorage échoue (iOS Safari mobile : QuotaExceededError/SecurityError en mode privé ou ITP).
    this.currentUserSubject.next(pUser);
    this._PostHog.IdentifyUser(pUser);

    if (this._IsBrowser)
    { // - cm - SSR-safe
      const lSerialized = JSON.stringify(pUser);
      const lUsePersistent = this.isRememberMe();

      try
      {
        if (lUsePersistent)
        {
          // - cm - "Se souvenir de moi" : profil en localStorage (survit à la fermeture du navigateur)
          localStorage.setItem(this.USER_KEY, lSerialized);
          sessionStorage.removeItem(this.USER_KEY);
        } else
        {
          // - cm - Pas de "Se souvenir de moi" : profil en sessionStorage (supprimé à la fermeture du navigateur)
          sessionStorage.setItem(this.USER_KEY, lSerialized);
          localStorage.removeItem(this.USER_KEY);
        }
      } catch
      {
        // - cm - Échec persistence (iOS Safari) : l'utilisateur reste en mémoire pour la session
      }
    }
  }

  /**
   * Récupère le token JWT depuis le cookie HttpOnly.
   * @returns Toujours null côté client — le token est inaccessible via JavaScript (cookie HttpOnly)
   */
  getToken(): string | null
  {
    return null; // - cm - Le token JWT est dans un cookie HttpOnly, inaccessible via JS
  }

  /**
   * Vérifie si un token JWT est expiré
   * @param pToken Token à vérifier
   * @returns True si expiré, false sinon
   */
  private isTokenExpired(pToken: string): boolean
  {
    try
    {
      const lDecoded = jwtDecode<JwtPayload>(pToken);
      return lDecoded.exp * 1000 < Date.now();
    }
    catch
    {
      return true;
    }
  }

  /**
   * Récupère l'utilisateur courant
   */
  get currentUser(): UsersDTO | null
  {
    return this.currentUserSubject.value;
  }

  /**
   * Recharge de manière défensive le profil utilisateur depuis le storage si la mémoire est vide.
   * - cm - Au refresh (full page load), le guard peut s'exécuter avant que le constructeur ait eu
   * le temps de charger le profil (timing initialNavigation). On retente un chargement synchrone
   * pour fiabiliser isLoggedIn/getUserRole côté guards et éviter une redirection intempestive.
   * @returns True si un profil a été (re)chargé, false sinon.
   */
  private ensureUserLoaded(): boolean
  {
    if (this.currentUserSubject.value !== null) return true; // - cm - Déjà en mémoire
    if (!this._IsBrowser) return false; // - cm - No-op côté serveur (SSR)

    try
    {
      // - cm - Priorité : localStorage (remember me) puis sessionStorage (session courante)
      const lUserJson: string | null = localStorage.getItem(this.USER_KEY) ?? sessionStorage.getItem(this.USER_KEY);
      if (lUserJson)
      {
        const lUser = JSON.parse(lUserJson) as UsersDTO;
        this.currentUserSubject.next(lUser);
        this._PostHog.IdentifyUser(lUser);
        return true;
      }
    } catch
    {
      // - cm - storage indisponible ou JSON invalide : on garde l'état mémoire courant
    }
    return false;
  }

  /**
   * Vérifie si un utilisateur est authentifié
   * @returns True si connecté, false sinon
   */
  isLoggedIn(): boolean
  {
    // - cm - Le token n'est plus accessible côté client (cookie HttpOnly)
    // On se base sur la présence du profil utilisateur en mémoire, avec fallback storage
    return this.ensureUserLoaded();
  }

  /**
   * Récupère le rôle de l'utilisateur depuis le profil stocké
   * @returns Le rôle ou null
   */
  getUserRole(): string | null
  {
    this.ensureUserLoaded();
    const lUser = this.currentUserSubject.value;
    return lUser?.role?.name ?? null;
  }

  /**
   * Récupère l'email de l'utilisateur depuis le profil stocké
   * @returns L'email ou null
   */
  getUserEmail(): string | null
  {
    const lUser = this.currentUserSubject.value;
    return lUser?.email ?? null;
  }

  /**
   * Récupère le nom d'utilisateur depuis le profil stocké
   * @returns Le nom d'utilisateur ou null
   */
  getUserName(): string | null
  {
    const lUser = this.currentUserSubject.value;
    return lUser?.username ?? null;
  }

  /**
   * Récupère l'ID de l'utilisateur depuis le profil stocké
   * @returns L'ID utilisateur ou null
   */
  getUserId(): string | null
  {
    const lUser = this.currentUserSubject.value;
    return lUser?.id?.toString() ?? null;
  }

  /**
   * Vérifie si l'utilisateur a un rôle spécifique
   * @param pRole Rôle à vérifier
   * @returns True si l'utilisateur a le rôle
   */
  hasRole(pRole: string): boolean
  {
    const lUserRole = this.getUserRole();
    return lUserRole?.toLowerCase() === pRole.toLowerCase();
  }

  /**
   * Vérifie si l'utilisateur a au moins un des rôles spécifiés
   * @param pRoles Liste de rôles
   * @returns True si l'utilisateur a un des rôles
   */
  hasAnyRole(pRoles: string[]): boolean
  {
    const lUserRole = this.getUserRole();
    if (!lUserRole) return false;

    return pRoles.some(lRole => lRole.toLowerCase() === lUserRole.toLowerCase());
  }

  /**
   * Vérifie si l'utilisateur est administrateur
   * @returns True si admin
   */
  isAdmin(): boolean
  {
    return this.hasRole('admin');
  }

  /**
   * Vérifie si l'utilisateur est vendeur
   * @returns True si vendeur
   */
  IsVendeur(): boolean
  {
    if (!this._IsBrowser) return this.hasRole('vendeur'); // - cm - SSR-safe
    return this.hasRole('vendeur') || (this.isAdmin() && window.location.href.toString().includes('-vendeur'));
  }

  /**
   * Vérifie si l'utilisateur est professionnel
   * @returns True si professionnel
   */
  IsProfessionnel(): boolean
  {
    if (!this._IsBrowser) return this.hasRole('professionnel'); // - cm - SSR-safe
    return this.hasRole('professionnel') || (this.isAdmin() && window.location.href.toString().includes('-pro'));
  }

  /**
   * Déconnecte l'utilisateur et nettoie la session
   */
  logout(): void
  {

    // - cm - Appel API pour supprimer le cookie HttpOnly
    this.axiosInstance.post(`${this.apiUrl}/Logout`).catch(() => { /* ignore errors */ });

    this.clearStorage();
    this.currentUserSubject.next(null);
    this._PostHog.Reset();
    this.RouteUtils.NavigateTo(ROUTE_PATHS.CONNEXION);
  }

  /**
   * Nettoie toutes les données de session du localStorage et sessionStorage
   */
  private clearStorage(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)
    // - cm - Le token JWT n'est plus stocké en localStorage (cookie HttpOnly)
    // - cm - Wrappé : iOS Safari peut lever une exception sur removeItem en mode privé/ITP
    try
    {
      localStorage.removeItem(this.USER_KEY);
      localStorage.removeItem('rememberMe');
      sessionStorage.removeItem(this.USER_KEY);
    } catch
    {
      // - cm - storage indisponible : rien à nettoyer
    }
  }

  /**
 * Récupère le plan d'abonnement actif de l'utilisateur courant.
 * @returns L'objet SubscriptionPlansDTO (contenant id, key, label, ...) ou null.
 */
  getUserPlan(): SubscriptionPlansDTO | null
  {
    this.ensureUserLoaded();
    const lUser = this.currentUserSubject.value;
    if (!lUser) return null;

    // 1. Si le DTO a directement la propriété planKey, on peut récupérer le plan via une autre propriété ?
    //    Mais ici on va utiliser la collection userSubscriptions, plus fiable.
    if (lUser.userSubscriptions && lUser.userSubscriptions.length > 0)
    {
      const now = new Date();
      const activeSub = lUser.userSubscriptions.find(sub =>
      {
        if (sub.status?.toLowerCase() !== 'active') return false;
        const start = sub.currentPeriodStart ? new Date(sub.currentPeriodStart) : null;
        const end = sub.currentPeriodEnd ? new Date(sub.currentPeriodEnd) : null;
        if (end === null) return true; // one-shot
        if (start && start <= now && end >= now) return true;
        return false;
      });
      return activeSub?.plan ?? null;
    }

    return null;
  }

  /**
   * Récupère la clé du plan actif.
   * @returns La clé du plan (ex: "pro", "crm", ...) ou null.
   */
  getUserPlanKey(): string | null
  {
    const plan = this.getUserPlan();
    return plan?.key ?? null;
  }

  /**
   * Vérifie si l'utilisateur a un plan parmi ceux autorisés.
   */
  hasAnyPlan(allowedPlans: string[]): boolean
  {
    const planKey = this.getUserPlanKey();
    return planKey !== null && allowedPlans.includes(planKey);
  }

  /**
   * Vérifie si l'utilisateur a un plan spécifique.
   */
  hasPlan(planKey: string): boolean
  {
    return this.getUserPlanKey() === planKey;
  }

  //#endregion
}
