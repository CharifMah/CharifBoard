import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { SelectionsDTO } from '../../../../core/sellmatchdb/dto/selections/selections.dto';
import { SelectionsCritereDTO } from '../../../../core/sellmatchdb/dto/selections/selections.critere';

@Injectable({
  providedIn: 'root'
})
export class SelectionsService extends ServiceBase<SelectionsDTO, SelectionsCritereDTO> {
  constructor() {
    super('Selections');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
