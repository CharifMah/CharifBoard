// gen-hash:931e22023a32d61ef73343610f6dff3ddbf7919a384808e1edf9e37cf14440bb
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { NotificationsDTO } from '../../../../core/sellmatchdb/dto/notifications/notifications.dto';
import { NotificationsCritereDTO } from '../../../../core/sellmatchdb/dto/notifications/notifications.critere';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService extends ServiceBase<NotificationsDTO, NotificationsCritereDTO> {
  constructor() {
    super('Notifications');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
