import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { SessionStorageService } from '../../../../core/sellmatchdb/services/SessionStorage/SessionStorageService';

/**
 * Service générique pour la gestion du localStorage.
 * Permet de sauvegarder, restaurer et nettoyer l'état persistant de l'application de manière sécurisée.
 * SSR-safe : toutes les méthodes vérifient la plateforme avant d'accéder au localStorage.
 * - cm - API miroir de `SessionStorageService` (mêmes signatures `Save<T>`, `Restore<T>`,
 * `Clear`, `SaveFormStepState`, `RestoreFormStepState`, `ClearFormStepState`). Cela permet
 * de basculer d'un backend à l'autre en gardant le même contrat côté appelant.
 * Fallback automatique vers `sessionStorage` si `localStorage` n'est pas disponible
 * (mode privé Safari, quota dépassé, contexte sécurisé restrictif).
 */
@Injectable({
  providedIn: 'root'
})
export class LocalStorageService
{
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /**
   * Service de fallback injecté une fois pour toutes (cf. ThemeService / GridZoomService
   * pour le précédent). Toute erreur `localStorage` (quota, mode privé) bascule
   * silencieusement vers le `sessionStorage` du `SessionStorageService`.
   * - cm - Pas d'injection circulaire : `LocalStorageService` n'est pas référencé
   * par `SessionStorageService`, et vice-versa. Les deux services sont stateless.
   */
  private readonly _SessionFallback: SessionStorageService = inject(SessionStorageService);

  /**
   * Sauvegarde une valeur dans le localStorage (sérialisée en JSON).
   * @param pKey La clé de stockage.
   * @param pValue La valeur à sauvegarder.
   */
  public Save<T>(pKey: string, pValue: T): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    try
    {
      localStorage.setItem(pKey, JSON.stringify(pValue));
    }
    catch (pError)
    {
      // - cm - Fallback sessionStorage si localStorage indisponible (mode privé Safari,
      // quota dépassé). Même stratégie que ThemeService / GridZoomService.
      this._SessionFallback.Save(pKey, pValue);
    }
  }

  /**
   * Récupère une valeur depuis le localStorage (désérialisée depuis JSON).
   * @param pKey La clé de stockage.
   * @returns La valeur désérialisée ou null si inexistante / corrompue.
   */
  public Restore<T>(pKey: string): T | null
  {
    if (!this._IsBrowser) return null; // - cm - No-op côté serveur (SSR)

    try
    {
      const lData = localStorage.getItem(pKey);
      return lData ? JSON.parse(lData) as T : null;
    }
    catch (pError)
    {
      // - cm - JSON corrompu : on retombe sur le fallback plutôt que de crasher l'app.
      return this._SessionFallback.Restore<T>(pKey);
    }
  }

  /**
   * Supprime une ou plusieurs clés du localStorage.
   * - cm - Tente d'abord `removeItem` direct (atomic). Si ça échoue, fallback
   * `SessionStorageService.Clear` (qui ne supprime QUE de sessionStorage,
   * mais on a au moins nettoyé ce qu'on pouvait côté local).
   * @param pKeys Les clés à supprimer.
   */
  public Clear(...pKeys: string[]): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    try
    {
      pKeys.forEach(pKey => localStorage.removeItem(pKey));
    }
    catch (pError)
    {
      this._SessionFallback.Clear(...pKeys);
    }
  }

  /**
   * Sauvegarde l'étape actuelle et les valeurs d'un FormGroup dans le localStorage.
   * - cm - Sucre syntaxique : délègue à `Save`. Conservé pour la parité d'API avec
   * `SessionStorageService` (utilisé par quelques flows de wizard).
   * @param pPrefix Préfixe pour les clés de stockage.
   * @param pCurrentStep L'étape en cours.
   * @param pForm Le FormGroup à sauvegarder.
   */
  public SaveFormStepState(pPrefix: string, pCurrentStep: number, pForm: FormGroup): void
  {
    this.Save(`${pPrefix}_step`, pCurrentStep);
    this.Save(`${pPrefix}_form`, pForm.value);
  }

  /**
   * Restaure l'étape et les valeurs d'un FormGroup depuis le localStorage.
   * - cm - Sucre syntaxique : délègue à `Restore`. Cf. `SaveFormStepState`.
   * @param pPrefix Préfixe pour les clés de stockage.
   * @param pForm Le FormGroup à restaurer.
   * @returns L'étape restaurée ou 1 par défaut.
   */
  public RestoreFormStepState(pPrefix: string, pForm: FormGroup): number
  {
    const lStep = this.Restore<number>(`${pPrefix}_step`);
    const lFormData = this.Restore<FormGroup['value']>(`${pPrefix}_form`);

    if (lFormData)
    {
      pForm.patchValue(lFormData); // - cm - Restauration des valeurs sans écraser les contrôleurs
    }

    return lStep ?? 1; // - cm - Retourne 1 si aucune étape n'est trouvée
  }

  /**
   * Nettoie les données d'étape et de formulaire du localStorage.
   * - cm - Sucre syntaxique : délègue à `Clear`. Cf. `SaveFormStepState`.
   * @param pPrefix Préfixe pour les clés de stockage.
   */
  public ClearFormStepState(pPrefix: string): void
  {
    this.Clear(`${pPrefix}_step`, `${pPrefix}_form`);
  }
}