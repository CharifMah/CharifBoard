// gen-hash:e8b19d247f28c2963cf6f6fd6877c0aec338f1e14eda56f0e25f4629e3d0e7cb
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { LiaiOpportunitiesStatusDTO } from '../../../../core/sellmatchdb/dto/liai-opportunities-status/liai-opportunities-status.dto';
import { LiaiOpportunitiesStatusCritereDTO } from '../../../../core/sellmatchdb/dto/liai-opportunities-status/liai-opportunities-status.critere';

@Injectable({
  providedIn: 'root'
})
export class LiaiOpportunitiesStatusService extends ServiceBase<LiaiOpportunitiesStatusDTO, LiaiOpportunitiesStatusCritereDTO> {
  constructor() {
    super('LiaiOpportunitiesStatus');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
