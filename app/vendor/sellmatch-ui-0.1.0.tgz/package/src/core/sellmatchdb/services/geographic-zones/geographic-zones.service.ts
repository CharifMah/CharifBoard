import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { GeographicZonesDTO } from '../../../../core/sellmatchdb/dto/geographic-zones/geographic-zones.dto';
import { GeographicZonesCritereDTO } from '../../../../core/sellmatchdb/dto/geographic-zones/geographic-zones.critere';

@Injectable({
  providedIn: 'root'
})
export class GeographicZonesService extends ServiceBase<GeographicZonesDTO, GeographicZonesCritereDTO> {
  constructor() {
    super('GeographicZones');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
