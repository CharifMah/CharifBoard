import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ConversationParticipantsDTO } from '../../../../core/sellmatchdb/dto/conversation-participants/conversation-participants.dto';
import { ConversationParticipantsCritereDTO } from '../../../../core/sellmatchdb/dto/conversation-participants/conversation-participants.critere';

@Injectable({
  providedIn: 'root'
})
export class ConversationParticipantsService extends ServiceBase<ConversationParticipantsDTO, ConversationParticipantsCritereDTO> {
  constructor() {
    super('ConversationParticipants');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
