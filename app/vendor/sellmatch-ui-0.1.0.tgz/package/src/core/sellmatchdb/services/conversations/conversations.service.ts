// gen-hash:ff5a1a438a17cd531795899becb0ac3ffaefc6d9fe4c29b3c209a74a8357c3e6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ConversationsDTO } from '../../../../core/sellmatchdb/dto/conversations/conversations.dto';
import { ConversationsCritereDTO } from '../../../../core/sellmatchdb/dto/conversations/conversations.critere';

@Injectable({
  providedIn: 'root'
})
export class ConversationsService extends ServiceBase<ConversationsDTO, ConversationsCritereDTO> {
  constructor() {
    super('Conversations');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
