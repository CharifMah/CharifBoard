import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { BlogArticleVersionsDTO } from '../../../../core/sellmatchdb/dto/blog-article-versions/blog-article-versions.dto';
import { BlogArticleVersionsCritereDTO } from '../../../../core/sellmatchdb/dto/blog-article-versions/blog-article-versions.critere';

// PROTECTEDFILE

/**
 * Service Angular pour l'historique des versions d'articles de blog.
 */
@Injectable({
  providedIn: 'root'
})
export class BlogArticleVersionsService extends ServiceBase<BlogArticleVersionsDTO, BlogArticleVersionsCritereDTO>
{
  constructor()
  {
    super('BlogArticleVersions');
  }

  /**
   * Récupère l'historique des versions d'un article.
   * @param pArticleId ID de l'article
   * @returns Liste des versions triées par numéro décroissant
   */
  public async GetHistory(pArticleId: number): Promise<BlogArticleVersionsDTO[]>
  {
    try
    {
      const lResponse = await this.axiosInstance.get<BlogArticleVersionsDTO[]>(
        `${this.apiUrl}/history/${pArticleId}`
      );
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    }
    catch (pError)
    {
      this.handleError(pError);
      return [];
    }
  }

  /**
   * Restaure une version précédente d'un article.
   * @param pVersionId ID de la version à restaurer
   * @returns La version restaurée ou null
   */
  public async Revert(pVersionId: number): Promise<BlogArticleVersionsDTO | null>
  {
    try
    {
      const lResponse = await this.axiosInstance.post<BlogArticleVersionsDTO>(
        `${this.apiUrl}/revert/${pVersionId}`
      );
      return lResponse.data;
    }
    catch (pError)
    {
      this.handleError(pError);
      return null;
    }
  }
}