// gen-hash:9109b1b513a55f5f044a2f6b7377fe0c5532498f28660376b517d44fa65d5924
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { AvailableServicesDTO } from '../../../../core/sellmatchdb/dto/available-services/available-services.dto';
import { AvailableServicesCritereDTO } from '../../../../core/sellmatchdb/dto/available-services/available-services.critere';

@Injectable({
  providedIn: 'root'
})
export class AvailableServicesService extends ServiceBase<AvailableServicesDTO, AvailableServicesCritereDTO> {
  constructor() {
    super('AvailableServices');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
