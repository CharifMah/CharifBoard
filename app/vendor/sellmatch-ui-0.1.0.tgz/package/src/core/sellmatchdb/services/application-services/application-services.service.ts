// gen-hash:47452454c271e318deb61fd8fbde401ae76278c9da45efd26aa79cf3c1b33ec1
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ApplicationServicesDTO } from '../../../../core/sellmatchdb/dto/application-services/application-services.dto';
import { ApplicationServicesCritereDTO } from '../../../../core/sellmatchdb/dto/application-services/application-services.critere';

@Injectable({
  providedIn: 'root'
})
export class ApplicationServicesService extends ServiceBase<ApplicationServicesDTO, ApplicationServicesCritereDTO> {
  constructor() {
    super('ApplicationServices');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
