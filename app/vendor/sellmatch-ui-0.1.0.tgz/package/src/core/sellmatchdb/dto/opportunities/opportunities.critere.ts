import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { AdressesCritereDTO } from '../adresses/adresses.critere';
import { ApplicationsCritereDTO } from '../applications/applications.critere';
import { ConversationsCritereDTO } from '../conversations/conversations.critere';
import { LiaiOpportunitiesStatusCritereDTO } from '../liai-opportunities-status/liai-opportunities-status.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface OpportunitiesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre IsNull sur userId (true = IS NULL, false = IS NOT NULL) */
  userIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de idStatusId */
  idStatusId?: number;
  /** Filtre IsNull sur idStatusId (true = IS NULL, false = IS NOT NULL) */
  idStatusIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour idStatusId (IN) */
  idStatusIds?: number[];
  /** Filtre idStatusId différent de toutes ces valeurs (NOT IN) */
  idStatusIdIsDifferentList?: number[];

  /** Filtre idStatusId supérieur ou égal à cette valeur */
  idStatusIdMin?: number;

  /** Filtre idStatusId inférieur ou égal à cette valeur */
  idStatusIdMax?: number;

  /** Filtre idStatusId strictement supérieur à cette valeur */
  idStatusIdGreaterThan?: number;

  /** Filtre idStatusId strictement inférieur à cette valeur */
  idStatusIdLessThan?: number;

  /** Filtre idStatusId différent de cette valeur */
  idStatusIdIsDifferent?: number;

  /** Filtre par valeur exacte de referenceCode */
  referenceCode?: string;
  /** Filtre IsNull sur referenceCode (true = IS NULL, false = IS NOT NULL) */
  referenceCodeIsNull?: boolean;
  /** Filtre referenceCode différent de cette valeur (NOT EQUAL) */
  referenceCodeIsDifferent?: string;
  /** Filtre par liste de valeurs pour referenceCode (IN) */
  referenceCodes?: string[];
  /** Filtre referenceCode différent de toutes ces valeurs (NOT IN) */
  referenceCodeIsDifferentList?: string[];

  /** Filtre referenceCode contenant cette valeur (LIKE %value%) */
  referenceCodeLike?: string;

  /** Filtre referenceCode commençant par cette valeur (LIKE value%) */
  referenceCodeStartsWith?: string;

  /** Filtre referenceCode terminant par cette valeur (LIKE %value) */
  referenceCodeEndsWith?: string;

  /** Filtre referenceCode ne contenant pas cette valeur (NOT LIKE %value%) */
  referenceCodeIsDifferentLike?: string;

  /** Filtre par valeur exacte de propertyType */
  propertyType?: string;
  /** Filtre IsNull sur propertyType (true = IS NULL, false = IS NOT NULL) */
  propertyTypeIsNull?: boolean;
  /** Filtre propertyType différent de cette valeur (NOT EQUAL) */
  propertyTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour propertyType (IN) */
  propertyTypes?: string[];
  /** Filtre propertyType différent de toutes ces valeurs (NOT IN) */
  propertyTypeIsDifferentList?: string[];

  /** Filtre propertyType contenant cette valeur (LIKE %value%) */
  propertyTypeLike?: string;

  /** Filtre propertyType commençant par cette valeur (LIKE value%) */
  propertyTypeStartsWith?: string;

  /** Filtre propertyType terminant par cette valeur (LIKE %value) */
  propertyTypeEndsWith?: string;

  /** Filtre propertyType ne contenant pas cette valeur (NOT LIKE %value%) */
  propertyTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de surface */
  surface?: number;
  /** Filtre IsNull sur surface (true = IS NULL, false = IS NOT NULL) */
  surfaceIsNull?: boolean;
  /** Filtre par liste de valeurs pour surface (IN) */
  surfaces?: number[];
  /** Filtre surface différent de toutes ces valeurs (NOT IN) */
  surfaceIsDifferentList?: number[];

  /** Filtre surface supérieur ou égal à cette valeur */
  surfaceMin?: number;

  /** Filtre surface inférieur ou égal à cette valeur */
  surfaceMax?: number;

  /** Filtre surface strictement supérieur à cette valeur */
  surfaceGreaterThan?: number;

  /** Filtre surface strictement inférieur à cette valeur */
  surfaceLessThan?: number;

  /** Filtre surface différent de cette valeur */
  surfaceIsDifferent?: number;

  /** Filtre par valeur exacte de priceRangeMin */
  priceRangeMin?: number;
  /** Filtre IsNull sur priceRangeMin (true = IS NULL, false = IS NOT NULL) */
  priceRangeMinIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceRangeMin (IN) */
  priceRangeMins?: number[];
  /** Filtre priceRangeMin différent de toutes ces valeurs (NOT IN) */
  priceRangeMinIsDifferentList?: number[];

  /** Filtre priceRangeMin supérieur ou égal à cette valeur */
  priceRangeMinMin?: number;

  /** Filtre priceRangeMin inférieur ou égal à cette valeur */
  priceRangeMinMax?: number;

  /** Filtre priceRangeMin strictement supérieur à cette valeur */
  priceRangeMinGreaterThan?: number;

  /** Filtre priceRangeMin strictement inférieur à cette valeur */
  priceRangeMinLessThan?: number;

  /** Filtre priceRangeMin différent de cette valeur */
  priceRangeMinIsDifferent?: number;

  /** Filtre par valeur exacte de priceRangeMax */
  priceRangeMax?: number;
  /** Filtre IsNull sur priceRangeMax (true = IS NULL, false = IS NOT NULL) */
  priceRangeMaxIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceRangeMax (IN) */
  priceRangeMaxs?: number[];
  /** Filtre priceRangeMax différent de toutes ces valeurs (NOT IN) */
  priceRangeMaxIsDifferentList?: number[];

  /** Filtre priceRangeMax supérieur ou égal à cette valeur */
  priceRangeMaxMin?: number;

  /** Filtre priceRangeMax inférieur ou égal à cette valeur */
  priceRangeMaxMax?: number;

  /** Filtre priceRangeMax strictement supérieur à cette valeur */
  priceRangeMaxGreaterThan?: number;

  /** Filtre priceRangeMax strictement inférieur à cette valeur */
  priceRangeMaxLessThan?: number;

  /** Filtre priceRangeMax différent de cette valeur */
  priceRangeMaxIsDifferent?: number;

  /** Filtre par valeur exacte de description */
  description?: string;
  /** Filtre IsNull sur description (true = IS NULL, false = IS NOT NULL) */
  descriptionIsNull?: boolean;
  /** Filtre description différent de cette valeur (NOT EQUAL) */
  descriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour description (IN) */
  descriptions?: string[];
  /** Filtre description différent de toutes ces valeurs (NOT IN) */
  descriptionIsDifferentList?: string[];

  /** Filtre description contenant cette valeur (LIKE %value%) */
  descriptionLike?: string;

  /** Filtre description commençant par cette valeur (LIKE value%) */
  descriptionStartsWith?: string;

  /** Filtre description terminant par cette valeur (LIKE %value) */
  descriptionEndsWith?: string;

  /** Filtre description ne contenant pas cette valeur (NOT LIKE %value%) */
  descriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de viewsCount */
  viewsCount?: number;
  /** Filtre IsNull sur viewsCount (true = IS NULL, false = IS NOT NULL) */
  viewsCountIsNull?: boolean;
  /** Filtre par liste de valeurs pour viewsCount (IN) */
  viewsCounts?: number[];
  /** Filtre viewsCount différent de toutes ces valeurs (NOT IN) */
  viewsCountIsDifferentList?: number[];

  /** Filtre viewsCount supérieur ou égal à cette valeur */
  viewsCountMin?: number;

  /** Filtre viewsCount inférieur ou égal à cette valeur */
  viewsCountMax?: number;

  /** Filtre viewsCount strictement supérieur à cette valeur */
  viewsCountGreaterThan?: number;

  /** Filtre viewsCount strictement inférieur à cette valeur */
  viewsCountLessThan?: number;

  /** Filtre viewsCount différent de cette valeur */
  viewsCountIsDifferent?: number;

  /** Filtre par valeur exacte de publishedAt */
  publishedAt?: Date | string;
  /** Filtre IsNull sur publishedAt (true = IS NULL, false = IS NOT NULL) */
  publishedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour publishedAt (IN) */
  publishedAts?: Date | string[];
  /** Filtre publishedAt différent de toutes ces valeurs (NOT IN) */
  publishedAtIsDifferentList?: Date | string[];

  /** Filtre publishedAt à partir de cette date (incluse) */
  publishedAtFrom?: Date | string;

  /** Filtre publishedAt jusqu'à cette date (incluse) */
  publishedAtTo?: Date | string;

  /** Filtre publishedAt strictement après cette date */
  publishedAtAfter?: Date | string;

  /** Filtre publishedAt strictement avant cette date */
  publishedAtBefore?: Date | string;

  /** Filtre publishedAt différent de cette date */
  publishedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de expiresAt */
  expiresAt?: Date | string;
  /** Filtre IsNull sur expiresAt (true = IS NULL, false = IS NOT NULL) */
  expiresAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour expiresAt (IN) */
  expiresAts?: Date | string[];
  /** Filtre expiresAt différent de toutes ces valeurs (NOT IN) */
  expiresAtIsDifferentList?: Date | string[];

  /** Filtre expiresAt à partir de cette date (incluse) */
  expiresAtFrom?: Date | string;

  /** Filtre expiresAt jusqu'à cette date (incluse) */
  expiresAtTo?: Date | string;

  /** Filtre expiresAt strictement après cette date */
  expiresAtAfter?: Date | string;

  /** Filtre expiresAt strictement avant cette date */
  expiresAtBefore?: Date | string;

  /** Filtre expiresAt différent de cette date */
  expiresAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de closedAt */
  closedAt?: Date | string;
  /** Filtre IsNull sur closedAt (true = IS NULL, false = IS NOT NULL) */
  closedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour closedAt (IN) */
  closedAts?: Date | string[];
  /** Filtre closedAt différent de toutes ces valeurs (NOT IN) */
  closedAtIsDifferentList?: Date | string[];

  /** Filtre closedAt à partir de cette date (incluse) */
  closedAtFrom?: Date | string;

  /** Filtre closedAt jusqu'à cette date (incluse) */
  closedAtTo?: Date | string;

  /** Filtre closedAt strictement après cette date */
  closedAtAfter?: Date | string;

  /** Filtre closedAt strictement avant cette date */
  closedAtBefore?: Date | string;

  /** Filtre closedAt différent de cette date */
  closedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de isPrio */
  isPrio?: boolean;
  /** Filtre isPrio différent de cette valeur (NOT EQUAL) */
  isPrioIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isPrio (IN) */
  isPrios?: boolean[];
  /** Filtre isPrio différent de toutes ces valeurs (NOT IN) */
  isPrioIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de paymentid */
  paymentid?: string;
  /** Filtre IsNull sur paymentid (true = IS NULL, false = IS NOT NULL) */
  paymentidIsNull?: boolean;
  /** Filtre paymentid différent de cette valeur (NOT EQUAL) */
  paymentidIsDifferent?: string;
  /** Filtre par liste de valeurs pour paymentid (IN) */
  paymentids?: string[];
  /** Filtre paymentid différent de toutes ces valeurs (NOT IN) */
  paymentidIsDifferentList?: string[];

  /** Filtre paymentid contenant cette valeur (LIKE %value%) */
  paymentidLike?: string;

  /** Filtre paymentid commençant par cette valeur (LIKE value%) */
  paymentidStartsWith?: string;

  /** Filtre paymentid terminant par cette valeur (LIKE %value) */
  paymentidEndsWith?: string;

  /** Filtre paymentid ne contenant pas cette valeur (NOT LIKE %value%) */
  paymentidIsDifferentLike?: string;

  /** Filtre par valeur exacte de addressId */
  addressId?: number;
  /** Filtre IsNull sur addressId (true = IS NULL, false = IS NOT NULL) */
  addressIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour addressId (IN) */
  addressIds?: number[];
  /** Filtre addressId différent de toutes ces valeurs (NOT IN) */
  addressIdIsDifferentList?: number[];

  /** Filtre addressId supérieur ou égal à cette valeur */
  addressIdMin?: number;

  /** Filtre addressId inférieur ou égal à cette valeur */
  addressIdMax?: number;

  /** Filtre addressId strictement supérieur à cette valeur */
  addressIdGreaterThan?: number;

  /** Filtre addressId strictement inférieur à cette valeur */
  addressIdLessThan?: number;

  /** Filtre addressId différent de cette valeur */
  addressIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où address est NULL).
   * false = INNER JOIN.
   * À configurer AVANT address.
   */
  includeAddressEmpty?: boolean;

  /** Filtre imbriqué sur la navigation address. */
  address?: AdressesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où idStatusNavigation est NULL).
   * false = INNER JOIN.
   * À configurer AVANT idStatusNavigation.
   */
  includeIdstatusnavigationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation idStatusNavigation. */
  idStatusNavigation?: LiaiOpportunitiesStatusCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur applications.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT applications.
   */
  applicationsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont applications est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT applications.
   */
  includeApplicationsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour applications.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT applications.
   */
  applicationsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection applications. */
  applications?: ApplicationsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur conversations.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT conversations.
   */
  conversationsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont conversations est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT conversations.
   */
  includeConversationsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour conversations.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT conversations.
   */
  conversationsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection conversations. */
  conversations?: ConversationsCritereDTO;

}
