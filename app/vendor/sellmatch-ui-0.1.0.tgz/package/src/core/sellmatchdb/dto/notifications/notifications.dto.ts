/**
 * DTO for table: notifications
 * Auto-generated - Do not modify manually
 */

import type { UsersDTO } from '../users/users.dto';

export interface NotificationsDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  type?: string;
  title?: string;
  content?: string;
  data?: Record<string, unknown>;
  readAt?: Date | string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  user?: UsersDTO;
}
