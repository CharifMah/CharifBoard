import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { BlogArticlesCritereDTO } from '../blog-articles/blog-articles.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface BlogArticleVersionsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de articleId */
  articleId?: number;
  /** Filtre par liste de valeurs pour articleId (IN) */
  articleIds?: number[];
  /** Filtre articleId différent de toutes ces valeurs (NOT IN) */
  articleIdIsDifferentList?: number[];

  /** Filtre articleId supérieur ou égal à cette valeur */
  articleIdMin?: number;

  /** Filtre articleId inférieur ou égal à cette valeur */
  articleIdMax?: number;

  /** Filtre articleId strictement supérieur à cette valeur */
  articleIdGreaterThan?: number;

  /** Filtre articleId strictement inférieur à cette valeur */
  articleIdLessThan?: number;

  /** Filtre articleId différent de cette valeur */
  articleIdIsDifferent?: number;

  /** Filtre par valeur exacte de title */
  title?: string;
  /** Filtre IsNull sur title (true = IS NULL, false = IS NOT NULL) */
  titleIsNull?: boolean;
  /** Filtre title différent de cette valeur (NOT EQUAL) */
  titleIsDifferent?: string;
  /** Filtre par liste de valeurs pour title (IN) */
  titles?: string[];
  /** Filtre title différent de toutes ces valeurs (NOT IN) */
  titleIsDifferentList?: string[];

  /** Filtre title contenant cette valeur (LIKE %value%) */
  titleLike?: string;

  /** Filtre title commençant par cette valeur (LIKE value%) */
  titleStartsWith?: string;

  /** Filtre title terminant par cette valeur (LIKE %value) */
  titleEndsWith?: string;

  /** Filtre title ne contenant pas cette valeur (NOT LIKE %value%) */
  titleIsDifferentLike?: string;

  /** Filtre par valeur exacte de slug */
  slug?: string;
  /** Filtre IsNull sur slug (true = IS NULL, false = IS NOT NULL) */
  slugIsNull?: boolean;
  /** Filtre slug différent de cette valeur (NOT EQUAL) */
  slugIsDifferent?: string;
  /** Filtre par liste de valeurs pour slug (IN) */
  slugs?: string[];
  /** Filtre slug différent de toutes ces valeurs (NOT IN) */
  slugIsDifferentList?: string[];

  /** Filtre slug contenant cette valeur (LIKE %value%) */
  slugLike?: string;

  /** Filtre slug commençant par cette valeur (LIKE value%) */
  slugStartsWith?: string;

  /** Filtre slug terminant par cette valeur (LIKE %value) */
  slugEndsWith?: string;

  /** Filtre slug ne contenant pas cette valeur (NOT LIKE %value%) */
  slugIsDifferentLike?: string;

  /** Filtre par valeur exacte de metaDescription */
  metaDescription?: string;
  /** Filtre IsNull sur metaDescription (true = IS NULL, false = IS NOT NULL) */
  metaDescriptionIsNull?: boolean;
  /** Filtre metaDescription différent de cette valeur (NOT EQUAL) */
  metaDescriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour metaDescription (IN) */
  metaDescriptions?: string[];
  /** Filtre metaDescription différent de toutes ces valeurs (NOT IN) */
  metaDescriptionIsDifferentList?: string[];

  /** Filtre metaDescription contenant cette valeur (LIKE %value%) */
  metaDescriptionLike?: string;

  /** Filtre metaDescription commençant par cette valeur (LIKE value%) */
  metaDescriptionStartsWith?: string;

  /** Filtre metaDescription terminant par cette valeur (LIKE %value) */
  metaDescriptionEndsWith?: string;

  /** Filtre metaDescription ne contenant pas cette valeur (NOT LIKE %value%) */
  metaDescriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de content */
  content?: string;
  /** Filtre IsNull sur content (true = IS NULL, false = IS NOT NULL) */
  contentIsNull?: boolean;
  /** Filtre content différent de cette valeur (NOT EQUAL) */
  contentIsDifferent?: string;
  /** Filtre par liste de valeurs pour content (IN) */
  contents?: string[];
  /** Filtre content différent de toutes ces valeurs (NOT IN) */
  contentIsDifferentList?: string[];

  /** Filtre content contenant cette valeur (LIKE %value%) */
  contentLike?: string;

  /** Filtre content commençant par cette valeur (LIKE value%) */
  contentStartsWith?: string;

  /** Filtre content terminant par cette valeur (LIKE %value) */
  contentEndsWith?: string;

  /** Filtre content ne contenant pas cette valeur (NOT LIKE %value%) */
  contentIsDifferentLike?: string;

  /** Filtre par valeur exacte de excerpt */
  excerpt?: string;
  /** Filtre IsNull sur excerpt (true = IS NULL, false = IS NOT NULL) */
  excerptIsNull?: boolean;
  /** Filtre excerpt différent de cette valeur (NOT EQUAL) */
  excerptIsDifferent?: string;
  /** Filtre par liste de valeurs pour excerpt (IN) */
  excerpts?: string[];
  /** Filtre excerpt différent de toutes ces valeurs (NOT IN) */
  excerptIsDifferentList?: string[];

  /** Filtre excerpt contenant cette valeur (LIKE %value%) */
  excerptLike?: string;

  /** Filtre excerpt commençant par cette valeur (LIKE value%) */
  excerptStartsWith?: string;

  /** Filtre excerpt terminant par cette valeur (LIKE %value) */
  excerptEndsWith?: string;

  /** Filtre excerpt ne contenant pas cette valeur (NOT LIKE %value%) */
  excerptIsDifferentLike?: string;

  /** Filtre par valeur exacte de category */
  category?: string;
  /** Filtre IsNull sur category (true = IS NULL, false = IS NOT NULL) */
  categoryIsNull?: boolean;
  /** Filtre category différent de cette valeur (NOT EQUAL) */
  categoryIsDifferent?: string;
  /** Filtre par liste de valeurs pour category (IN) */
  categorys?: string[];
  /** Filtre category différent de toutes ces valeurs (NOT IN) */
  categoryIsDifferentList?: string[];

  /** Filtre category contenant cette valeur (LIKE %value%) */
  categoryLike?: string;

  /** Filtre category commençant par cette valeur (LIKE value%) */
  categoryStartsWith?: string;

  /** Filtre category terminant par cette valeur (LIKE %value) */
  categoryEndsWith?: string;

  /** Filtre category ne contenant pas cette valeur (NOT LIKE %value%) */
  categoryIsDifferentLike?: string;

  /** Filtre par valeur exacte de tags */
  tags?: string;
  /** Filtre IsNull sur tags (true = IS NULL, false = IS NOT NULL) */
  tagsIsNull?: boolean;
  /** Filtre tags différent de cette valeur (NOT EQUAL) */
  tagsIsDifferent?: string;
  /** Filtre par liste de valeurs pour tags (IN) */
  tagss?: string[];
  /** Filtre tags différent de toutes ces valeurs (NOT IN) */
  tagsIsDifferentList?: string[];

  /** Filtre tags contenant cette valeur (LIKE %value%) */
  tagsLike?: string;

  /** Filtre tags commençant par cette valeur (LIKE value%) */
  tagsStartsWith?: string;

  /** Filtre tags terminant par cette valeur (LIKE %value) */
  tagsEndsWith?: string;

  /** Filtre tags ne contenant pas cette valeur (NOT LIKE %value%) */
  tagsIsDifferentLike?: string;

  /** Filtre par valeur exacte de coverImage */
  coverImage?: string;
  /** Filtre IsNull sur coverImage (true = IS NULL, false = IS NOT NULL) */
  coverImageIsNull?: boolean;
  /** Filtre coverImage différent de cette valeur (NOT EQUAL) */
  coverImageIsDifferent?: string;
  /** Filtre par liste de valeurs pour coverImage (IN) */
  coverImages?: string[];
  /** Filtre coverImage différent de toutes ces valeurs (NOT IN) */
  coverImageIsDifferentList?: string[];

  /** Filtre coverImage contenant cette valeur (LIKE %value%) */
  coverImageLike?: string;

  /** Filtre coverImage commençant par cette valeur (LIKE value%) */
  coverImageStartsWith?: string;

  /** Filtre coverImage terminant par cette valeur (LIKE %value) */
  coverImageEndsWith?: string;

  /** Filtre coverImage ne contenant pas cette valeur (NOT LIKE %value%) */
  coverImageIsDifferentLike?: string;

  /** Filtre par valeur exacte de ogImage */
  ogImage?: string;
  /** Filtre IsNull sur ogImage (true = IS NULL, false = IS NOT NULL) */
  ogImageIsNull?: boolean;
  /** Filtre ogImage différent de cette valeur (NOT EQUAL) */
  ogImageIsDifferent?: string;
  /** Filtre par liste de valeurs pour ogImage (IN) */
  ogImages?: string[];
  /** Filtre ogImage différent de toutes ces valeurs (NOT IN) */
  ogImageIsDifferentList?: string[];

  /** Filtre ogImage contenant cette valeur (LIKE %value%) */
  ogImageLike?: string;

  /** Filtre ogImage commençant par cette valeur (LIKE value%) */
  ogImageStartsWith?: string;

  /** Filtre ogImage terminant par cette valeur (LIKE %value) */
  ogImageEndsWith?: string;

  /** Filtre ogImage ne contenant pas cette valeur (NOT LIKE %value%) */
  ogImageIsDifferentLike?: string;

  /** Filtre par valeur exacte de readingTimeMinutes */
  readingTimeMinutes?: number;
  /** Filtre IsNull sur readingTimeMinutes (true = IS NULL, false = IS NOT NULL) */
  readingTimeMinutesIsNull?: boolean;
  /** Filtre par liste de valeurs pour readingTimeMinutes (IN) */
  readingTimeMinutess?: number[];
  /** Filtre readingTimeMinutes différent de toutes ces valeurs (NOT IN) */
  readingTimeMinutesIsDifferentList?: number[];

  /** Filtre readingTimeMinutes supérieur ou égal à cette valeur */
  readingTimeMinutesMin?: number;

  /** Filtre readingTimeMinutes inférieur ou égal à cette valeur */
  readingTimeMinutesMax?: number;

  /** Filtre readingTimeMinutes strictement supérieur à cette valeur */
  readingTimeMinutesGreaterThan?: number;

  /** Filtre readingTimeMinutes strictement inférieur à cette valeur */
  readingTimeMinutesLessThan?: number;

  /** Filtre readingTimeMinutes différent de cette valeur */
  readingTimeMinutesIsDifferent?: number;

  /** Filtre par valeur exacte de isPublished */
  isPublished?: boolean;
  /** Filtre IsNull sur isPublished (true = IS NULL, false = IS NOT NULL) */
  isPublishedIsNull?: boolean;
  /** Filtre isPublished différent de cette valeur (NOT EQUAL) */
  isPublishedIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isPublished (IN) */
  isPublisheds?: boolean[];
  /** Filtre isPublished différent de toutes ces valeurs (NOT IN) */
  isPublishedIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de isFeatured */
  isFeatured?: boolean;
  /** Filtre IsNull sur isFeatured (true = IS NULL, false = IS NOT NULL) */
  isFeaturedIsNull?: boolean;
  /** Filtre isFeatured différent de cette valeur (NOT EQUAL) */
  isFeaturedIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isFeatured (IN) */
  isFeatureds?: boolean[];
  /** Filtre isFeatured différent de toutes ces valeurs (NOT IN) */
  isFeaturedIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de versionNumber */
  versionNumber?: number;
  /** Filtre par liste de valeurs pour versionNumber (IN) */
  versionNumbers?: number[];
  /** Filtre versionNumber différent de toutes ces valeurs (NOT IN) */
  versionNumberIsDifferentList?: number[];

  /** Filtre versionNumber supérieur ou égal à cette valeur */
  versionNumberMin?: number;

  /** Filtre versionNumber inférieur ou égal à cette valeur */
  versionNumberMax?: number;

  /** Filtre versionNumber strictement supérieur à cette valeur */
  versionNumberGreaterThan?: number;

  /** Filtre versionNumber strictement inférieur à cette valeur */
  versionNumberLessThan?: number;

  /** Filtre versionNumber différent de cette valeur */
  versionNumberIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdById */
  createdById?: number;
  /** Filtre IsNull sur createdById (true = IS NULL, false = IS NOT NULL) */
  createdByIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdById (IN) */
  createdByIds?: number[];
  /** Filtre createdById différent de toutes ces valeurs (NOT IN) */
  createdByIdIsDifferentList?: number[];

  /** Filtre createdById supérieur ou égal à cette valeur */
  createdByIdMin?: number;

  /** Filtre createdById inférieur ou égal à cette valeur */
  createdByIdMax?: number;

  /** Filtre createdById strictement supérieur à cette valeur */
  createdByIdGreaterThan?: number;

  /** Filtre createdById strictement inférieur à cette valeur */
  createdByIdLessThan?: number;

  /** Filtre createdById différent de cette valeur */
  createdByIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où article est NULL).
   * false = INNER JOIN.
   * À configurer AVANT article.
   */
  includeArticleEmpty?: boolean;

  /** Filtre imbriqué sur la navigation article. */
  article?: BlogArticlesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où createdByNavigation est NULL).
   * false = INNER JOIN.
   * À configurer AVANT createdByNavigation.
   */
  includeCreatedbynavigationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation createdByNavigation. */
  createdByNavigation?: UsersCritereDTO;

}
