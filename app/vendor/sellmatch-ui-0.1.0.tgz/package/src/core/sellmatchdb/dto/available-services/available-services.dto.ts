/**
 * DTO for table: available_services
 * Auto-generated - Do not modify manually
 */

import type { ApplicationServicesDTO } from '../application-services/application-services.dto';

export interface AvailableServicesDTO {
  /** Primary Key */
  id?: number;
  category?: string;
  serviceKey?: string;
  serviceLabel?: string;
  icon?: string;
  displayOrder?: number;
  isActive?: boolean;
  createdAt?: Date | string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de ApplicationServices */
  applicationServices?: ApplicationServicesDTO[];
}
