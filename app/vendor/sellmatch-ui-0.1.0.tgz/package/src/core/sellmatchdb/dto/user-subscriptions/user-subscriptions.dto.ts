/**
 * DTO for table: user_subscriptions
 * Auto-generated - Do not modify manually
 */

import type { SubscriptionPlansDTO } from '../subscription-plans/subscription-plans.dto';
import type { UsersDTO } from '../users/users.dto';

export interface UserSubscriptionsDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  planId?: number;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  status?: string;
  billingPeriod?: string;
  currentPeriodStart?: Date | string;
  currentPeriodEnd?: Date | string;
  canceledAt?: Date | string;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers SubscriptionPlans */
  plan?: SubscriptionPlansDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
