/**
 * DTO for table: liai_opportunities_status
 * Auto-generated - Do not modify manually
 */

import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';

export interface LiaiOpportunitiesStatusDTO {
  /** Primary Key */
  id?: number;
  status?: string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Opportunities */
  opportunities?: OpportunitiesDTO[];
}
