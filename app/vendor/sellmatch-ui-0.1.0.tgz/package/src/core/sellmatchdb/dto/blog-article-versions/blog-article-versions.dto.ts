/**
 * DTO for table: blog_article_versions
 * Auto-generated - Do not modify manually
 */

import type { BlogArticlesDTO } from '../blog-articles/blog-articles.dto';
import type { UsersDTO } from '../users/users.dto';

export interface BlogArticleVersionsDTO {
  /** Primary Key */
  id?: number;
  articleId?: number;
  title?: string;
  slug?: string;
  metaDescription?: string;
  content?: string;
  excerpt?: string;
  category?: string;
  tags?: string;
  coverImage?: string;
  ogImage?: string;
  readingTimeMinutes?: number;
  isPublished?: boolean;
  isFeatured?: boolean;
  versionNumber?: number;
  createdAt?: Date | string;
  createdById?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers BlogArticles */
  article?: BlogArticlesDTO;
  /** Navigation property vers Users */
  createdByNavigation?: UsersDTO;
}
