import { BaseCritereDTO } from '../../../../core/base/base.critere';

export interface FeeCapsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de priceMin */
  priceMin?: number;
  /** Filtre par liste de valeurs pour priceMin (IN) */
  priceMins?: number[];
  /** Filtre priceMin différent de toutes ces valeurs (NOT IN) */
  priceMinIsDifferentList?: number[];

  /** Filtre priceMin supérieur ou égal à cette valeur */
  priceMinMin?: number;

  /** Filtre priceMin inférieur ou égal à cette valeur */
  priceMinMax?: number;

  /** Filtre priceMin strictement supérieur à cette valeur */
  priceMinGreaterThan?: number;

  /** Filtre priceMin strictement inférieur à cette valeur */
  priceMinLessThan?: number;

  /** Filtre priceMin différent de cette valeur */
  priceMinIsDifferent?: number;

  /** Filtre par valeur exacte de priceMax */
  priceMax?: number;
  /** Filtre IsNull sur priceMax (true = IS NULL, false = IS NOT NULL) */
  priceMaxIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceMax (IN) */
  priceMaxs?: number[];
  /** Filtre priceMax différent de toutes ces valeurs (NOT IN) */
  priceMaxIsDifferentList?: number[];

  /** Filtre priceMax supérieur ou égal à cette valeur */
  priceMaxMin?: number;

  /** Filtre priceMax inférieur ou égal à cette valeur */
  priceMaxMax?: number;

  /** Filtre priceMax strictement supérieur à cette valeur */
  priceMaxGreaterThan?: number;

  /** Filtre priceMax strictement inférieur à cette valeur */
  priceMaxLessThan?: number;

  /** Filtre priceMax différent de cette valeur */
  priceMaxIsDifferent?: number;

  /** Filtre par valeur exacte de feeType */
  feeType?: string;
  /** Filtre IsNull sur feeType (true = IS NULL, false = IS NOT NULL) */
  feeTypeIsNull?: boolean;
  /** Filtre feeType différent de cette valeur (NOT EQUAL) */
  feeTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour feeType (IN) */
  feeTypes?: string[];
  /** Filtre feeType différent de toutes ces valeurs (NOT IN) */
  feeTypeIsDifferentList?: string[];

  /** Filtre feeType contenant cette valeur (LIKE %value%) */
  feeTypeLike?: string;

  /** Filtre feeType commençant par cette valeur (LIKE value%) */
  feeTypeStartsWith?: string;

  /** Filtre feeType terminant par cette valeur (LIKE %value) */
  feeTypeEndsWith?: string;

  /** Filtre feeType ne contenant pas cette valeur (NOT LIKE %value%) */
  feeTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de maxPercentage */
  maxPercentage?: number;
  /** Filtre IsNull sur maxPercentage (true = IS NULL, false = IS NOT NULL) */
  maxPercentageIsNull?: boolean;
  /** Filtre par liste de valeurs pour maxPercentage (IN) */
  maxPercentages?: number[];
  /** Filtre maxPercentage différent de toutes ces valeurs (NOT IN) */
  maxPercentageIsDifferentList?: number[];

  /** Filtre maxPercentage supérieur ou égal à cette valeur */
  maxPercentageMin?: number;

  /** Filtre maxPercentage inférieur ou égal à cette valeur */
  maxPercentageMax?: number;

  /** Filtre maxPercentage strictement supérieur à cette valeur */
  maxPercentageGreaterThan?: number;

  /** Filtre maxPercentage strictement inférieur à cette valeur */
  maxPercentageLessThan?: number;

  /** Filtre maxPercentage différent de cette valeur */
  maxPercentageIsDifferent?: number;

  /** Filtre par valeur exacte de maxFixedAmount */
  maxFixedAmount?: number;
  /** Filtre IsNull sur maxFixedAmount (true = IS NULL, false = IS NOT NULL) */
  maxFixedAmountIsNull?: boolean;
  /** Filtre par liste de valeurs pour maxFixedAmount (IN) */
  maxFixedAmounts?: number[];
  /** Filtre maxFixedAmount différent de toutes ces valeurs (NOT IN) */
  maxFixedAmountIsDifferentList?: number[];

  /** Filtre maxFixedAmount supérieur ou égal à cette valeur */
  maxFixedAmountMin?: number;

  /** Filtre maxFixedAmount inférieur ou égal à cette valeur */
  maxFixedAmountMax?: number;

  /** Filtre maxFixedAmount strictement supérieur à cette valeur */
  maxFixedAmountGreaterThan?: number;

  /** Filtre maxFixedAmount strictement inférieur à cette valeur */
  maxFixedAmountLessThan?: number;

  /** Filtre maxFixedAmount différent de cette valeur */
  maxFixedAmountIsDifferent?: number;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre IsNull sur isActive (true = IS NULL, false = IS NOT NULL) */
  isActiveIsNull?: boolean;
  /** Filtre isActive différent de cette valeur (NOT EQUAL) */
  isActiveIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];
  /** Filtre isActive différent de toutes ces valeurs (NOT IN) */
  isActiveIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

}
