/**
 * DTO for table: email
 * Auto-generated - Do not modify manually
 */

export interface EmailDTO {
  /** Primary Key */
  id?: number;
  emails?: string;
  createdAt?: Date | string;
}
