import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface NotificationsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de type */
  type?: string;
  /** Filtre IsNull sur type (true = IS NULL, false = IS NOT NULL) */
  typeIsNull?: boolean;
  /** Filtre type différent de cette valeur (NOT EQUAL) */
  typeIsDifferent?: string;
  /** Filtre par liste de valeurs pour type (IN) */
  types?: string[];
  /** Filtre type différent de toutes ces valeurs (NOT IN) */
  typeIsDifferentList?: string[];

  /** Filtre type contenant cette valeur (LIKE %value%) */
  typeLike?: string;

  /** Filtre type commençant par cette valeur (LIKE value%) */
  typeStartsWith?: string;

  /** Filtre type terminant par cette valeur (LIKE %value) */
  typeEndsWith?: string;

  /** Filtre type ne contenant pas cette valeur (NOT LIKE %value%) */
  typeIsDifferentLike?: string;

  /** Filtre par valeur exacte de title */
  title?: string;
  /** Filtre IsNull sur title (true = IS NULL, false = IS NOT NULL) */
  titleIsNull?: boolean;
  /** Filtre title différent de cette valeur (NOT EQUAL) */
  titleIsDifferent?: string;
  /** Filtre par liste de valeurs pour title (IN) */
  titles?: string[];
  /** Filtre title différent de toutes ces valeurs (NOT IN) */
  titleIsDifferentList?: string[];

  /** Filtre title contenant cette valeur (LIKE %value%) */
  titleLike?: string;

  /** Filtre title commençant par cette valeur (LIKE value%) */
  titleStartsWith?: string;

  /** Filtre title terminant par cette valeur (LIKE %value) */
  titleEndsWith?: string;

  /** Filtre title ne contenant pas cette valeur (NOT LIKE %value%) */
  titleIsDifferentLike?: string;

  /** Filtre par valeur exacte de content */
  content?: string;
  /** Filtre IsNull sur content (true = IS NULL, false = IS NOT NULL) */
  contentIsNull?: boolean;
  /** Filtre content différent de cette valeur (NOT EQUAL) */
  contentIsDifferent?: string;
  /** Filtre par liste de valeurs pour content (IN) */
  contents?: string[];
  /** Filtre content différent de toutes ces valeurs (NOT IN) */
  contentIsDifferentList?: string[];

  /** Filtre content contenant cette valeur (LIKE %value%) */
  contentLike?: string;

  /** Filtre content commençant par cette valeur (LIKE value%) */
  contentStartsWith?: string;

  /** Filtre content terminant par cette valeur (LIKE %value) */
  contentEndsWith?: string;

  /** Filtre content ne contenant pas cette valeur (NOT LIKE %value%) */
  contentIsDifferentLike?: string;

  /** Filtre par valeur exacte de data */
  data?: Record<string, unknown>;
  /** Filtre IsNull sur data (true = IS NULL, false = IS NOT NULL) */
  dataIsNull?: boolean;
  /** Filtre data différent de cette valeur (NOT EQUAL) */
  dataIsDifferent?: Record<string, unknown>;
  /** Filtre par liste de valeurs pour data (IN) */
  datas?: Record<string, unknown>[];
  /** Filtre data différent de toutes ces valeurs (NOT IN) */
  dataIsDifferentList?: Record<string, unknown>[];

  /** Filtre par valeur exacte de readAt */
  readAt?: Date | string;
  /** Filtre IsNull sur readAt (true = IS NULL, false = IS NOT NULL) */
  readAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour readAt (IN) */
  readAts?: Date | string[];
  /** Filtre readAt différent de toutes ces valeurs (NOT IN) */
  readAtIsDifferentList?: Date | string[];

  /** Filtre readAt à partir de cette date (incluse) */
  readAtFrom?: Date | string;

  /** Filtre readAt jusqu'à cette date (incluse) */
  readAtTo?: Date | string;

  /** Filtre readAt strictement après cette date */
  readAtAfter?: Date | string;

  /** Filtre readAt strictement avant cette date */
  readAtBefore?: Date | string;

  /** Filtre readAt différent de cette date */
  readAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
