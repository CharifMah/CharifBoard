/**
 * DTO for table: application_services
 * Auto-generated - Do not modify manually
 */

import type { ApplicationsDTO } from '../applications/applications.dto';
import type { AvailableServicesDTO } from '../available-services/available-services.dto';

export interface ApplicationServicesDTO {
  /** Primary Key */
  id?: number;
  applicationId?: number;
  serviceId?: number;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Applications */
  application?: ApplicationsDTO;
  /** Navigation property vers AvailableServices */
  service?: AvailableServicesDTO;
}
