import { BaseCritereDTO } from '../../../../core/base/base.critere';

export interface EmailCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de emails */
  emails?: string;
  /** Filtre IsNull sur emails (true = IS NULL, false = IS NOT NULL) */
  emailsIsNull?: boolean;
  /** Filtre emails différent de cette valeur (NOT EQUAL) */
  emailsIsDifferent?: string;
  /** Filtre par liste de valeurs pour emails (IN) */
  emailss?: string[];
  /** Filtre emails différent de toutes ces valeurs (NOT IN) */
  emailsIsDifferentList?: string[];

  /** Filtre emails contenant cette valeur (LIKE %value%) */
  emailsLike?: string;

  /** Filtre emails commençant par cette valeur (LIKE value%) */
  emailsStartsWith?: string;

  /** Filtre emails terminant par cette valeur (LIKE %value) */
  emailsEndsWith?: string;

  /** Filtre emails ne contenant pas cette valeur (NOT LIKE %value%) */
  emailsIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

}
