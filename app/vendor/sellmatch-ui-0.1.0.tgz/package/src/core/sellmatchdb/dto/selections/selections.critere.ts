import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ApplicationsCritereDTO } from '../applications/applications.critere';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface SelectionsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;
  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;
  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;
  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre par valeur exacte de opportunityId */
  opportunityId?: number;
  /** Filtre par liste de valeurs pour opportunityId (IN) */
  opportunityIds?: number[];

  /** Filtre opportunityId supérieur ou égal à cette valeur */
  opportunityIdMin?: number;
  /** Filtre opportunityId inférieur ou égal à cette valeur */
  opportunityIdMax?: number;
  /** Filtre opportunityId strictement supérieur à cette valeur */
  opportunityIdGreaterThan?: number;
  /** Filtre opportunityId strictement inférieur à cette valeur */
  opportunityIdLessThan?: number;

  /** Filtre par valeur exacte de applicationId */
  applicationId?: number;
  /** Filtre par liste de valeurs pour applicationId (IN) */
  applicationIds?: number[];

  /** Filtre applicationId supérieur ou égal à cette valeur */
  applicationIdMin?: number;
  /** Filtre applicationId inférieur ou égal à cette valeur */
  applicationIdMax?: number;
  /** Filtre applicationId strictement supérieur à cette valeur */
  applicationIdGreaterThan?: number;
  /** Filtre applicationId strictement inférieur à cette valeur */
  applicationIdLessThan?: number;

  /** Filtre par valeur exacte de professionalId */
  professionalId?: number;
  /** Filtre par liste de valeurs pour professionalId (IN) */
  professionalIds?: number[];

  /** Filtre professionalId supérieur ou égal à cette valeur */
  professionalIdMin?: number;
  /** Filtre professionalId inférieur ou égal à cette valeur */
  professionalIdMax?: number;
  /** Filtre professionalId strictement supérieur à cette valeur */
  professionalIdGreaterThan?: number;
  /** Filtre professionalId strictement inférieur à cette valeur */
  professionalIdLessThan?: number;

  /** Filtre par valeur exacte de vendorId */
  vendorId?: number;
  /** Filtre par liste de valeurs pour vendorId (IN) */
  vendorIds?: number[];

  /** Filtre vendorId supérieur ou égal à cette valeur */
  vendorIdMin?: number;
  /** Filtre vendorId inférieur ou égal à cette valeur */
  vendorIdMax?: number;
  /** Filtre vendorId strictement supérieur à cette valeur */
  vendorIdGreaterThan?: number;
  /** Filtre vendorId strictement inférieur à cette valeur */
  vendorIdLessThan?: number;

  /** Filtre par valeur exacte de anonymityLiftedAt */
  anonymityLiftedAt?: Date | string;
  /** Filtre par liste de valeurs pour anonymityLiftedAt (IN) */
  anonymityLiftedAts?: Date | string[];

  /** Filtre anonymityLiftedAt à partir de cette date (incluse) */
  anonymityLiftedAtFrom?: Date | string;
  /** Filtre anonymityLiftedAt jusqu'à cette date (incluse) */
  anonymityLiftedAtTo?: Date | string;
  /** Filtre anonymityLiftedAt strictement après cette date */
  anonymityLiftedAtAfter?: Date | string;
  /** Filtre anonymityLiftedAt strictement avant cette date */
  anonymityLiftedAtBefore?: Date | string;

  /** Filtre par valeur exacte de vendorContactShared */
  vendorContactShared?: boolean;
  /** Filtre par liste de valeurs pour vendorContactShared (IN) */
  vendorContactShareds?: boolean[];

  /** Filtre par valeur exacte de professionalContactShared */
  professionalContactShared?: boolean;
  /** Filtre par liste de valeurs pour professionalContactShared (IN) */
  professionalContactShareds?: boolean[];

  /** Filtre par valeur exacte de status */
  status?: string;
  /** Filtre par liste de valeurs pour status (IN) */
  statuss?: string[];

  /** Filtre status contenant cette valeur (LIKE %value%) */
  statusContains?: string;
  /** Filtre status commençant par cette valeur (LIKE value%) */
  statusStartsWith?: string;
  /** Filtre status terminant par cette valeur (LIKE %value) */
  statusEndsWith?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;
  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;
  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;
  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;
  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;
  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;
  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /** Filtre imbriqué sur application */
  application?: ApplicationsCritereDTO;

  /** Filtre imbriqué sur opportunity */
  opportunity?: OpportunitiesCritereDTO;

  /** Filtre imbriqué sur professional */
  professional?: UsersCritereDTO;

  /** Filtre imbriqué sur vendor */
  vendor?: UsersCritereDTO;

}
