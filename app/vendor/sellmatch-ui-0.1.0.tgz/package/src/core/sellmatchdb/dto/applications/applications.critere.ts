import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { ApplicationServicesCritereDTO } from '../application-services/application-services.critere';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface ApplicationsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de opportunityId */
  opportunityId?: number;
  /** Filtre par liste de valeurs pour opportunityId (IN) */
  opportunityIds?: number[];
  /** Filtre opportunityId différent de toutes ces valeurs (NOT IN) */
  opportunityIdIsDifferentList?: number[];

  /** Filtre opportunityId supérieur ou égal à cette valeur */
  opportunityIdMin?: number;

  /** Filtre opportunityId inférieur ou égal à cette valeur */
  opportunityIdMax?: number;

  /** Filtre opportunityId strictement supérieur à cette valeur */
  opportunityIdGreaterThan?: number;

  /** Filtre opportunityId strictement inférieur à cette valeur */
  opportunityIdLessThan?: number;

  /** Filtre opportunityId différent de cette valeur */
  opportunityIdIsDifferent?: number;

  /** Filtre par valeur exacte de professionalId */
  professionalId?: number;
  /** Filtre IsNull sur professionalId (true = IS NULL, false = IS NOT NULL) */
  professionalIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour professionalId (IN) */
  professionalIds?: number[];
  /** Filtre professionalId différent de toutes ces valeurs (NOT IN) */
  professionalIdIsDifferentList?: number[];

  /** Filtre professionalId supérieur ou égal à cette valeur */
  professionalIdMin?: number;

  /** Filtre professionalId inférieur ou égal à cette valeur */
  professionalIdMax?: number;

  /** Filtre professionalId strictement supérieur à cette valeur */
  professionalIdGreaterThan?: number;

  /** Filtre professionalId strictement inférieur à cette valeur */
  professionalIdLessThan?: number;

  /** Filtre professionalId différent de cette valeur */
  professionalIdIsDifferent?: number;

  /** Filtre par valeur exacte de presentation */
  presentation?: string;
  /** Filtre IsNull sur presentation (true = IS NULL, false = IS NOT NULL) */
  presentationIsNull?: boolean;
  /** Filtre presentation différent de cette valeur (NOT EQUAL) */
  presentationIsDifferent?: string;
  /** Filtre par liste de valeurs pour presentation (IN) */
  presentations?: string[];
  /** Filtre presentation différent de toutes ces valeurs (NOT IN) */
  presentationIsDifferentList?: string[];

  /** Filtre presentation contenant cette valeur (LIKE %value%) */
  presentationLike?: string;

  /** Filtre presentation commençant par cette valeur (LIKE value%) */
  presentationStartsWith?: string;

  /** Filtre presentation terminant par cette valeur (LIKE %value) */
  presentationEndsWith?: string;

  /** Filtre presentation ne contenant pas cette valeur (NOT LIKE %value%) */
  presentationIsDifferentLike?: string;

  /** Filtre par valeur exacte de methodology */
  methodology?: string;
  /** Filtre IsNull sur methodology (true = IS NULL, false = IS NOT NULL) */
  methodologyIsNull?: boolean;
  /** Filtre methodology différent de cette valeur (NOT EQUAL) */
  methodologyIsDifferent?: string;
  /** Filtre par liste de valeurs pour methodology (IN) */
  methodologys?: string[];
  /** Filtre methodology différent de toutes ces valeurs (NOT IN) */
  methodologyIsDifferentList?: string[];

  /** Filtre methodology contenant cette valeur (LIKE %value%) */
  methodologyLike?: string;

  /** Filtre methodology commençant par cette valeur (LIKE value%) */
  methodologyStartsWith?: string;

  /** Filtre methodology terminant par cette valeur (LIKE %value) */
  methodologyEndsWith?: string;

  /** Filtre methodology ne contenant pas cette valeur (NOT LIKE %value%) */
  methodologyIsDifferentLike?: string;

  /** Filtre par valeur exacte de estimatedTimeline */
  estimatedTimeline?: string;
  /** Filtre IsNull sur estimatedTimeline (true = IS NULL, false = IS NOT NULL) */
  estimatedTimelineIsNull?: boolean;
  /** Filtre estimatedTimeline différent de cette valeur (NOT EQUAL) */
  estimatedTimelineIsDifferent?: string;
  /** Filtre par liste de valeurs pour estimatedTimeline (IN) */
  estimatedTimelines?: string[];
  /** Filtre estimatedTimeline différent de toutes ces valeurs (NOT IN) */
  estimatedTimelineIsDifferentList?: string[];

  /** Filtre estimatedTimeline contenant cette valeur (LIKE %value%) */
  estimatedTimelineLike?: string;

  /** Filtre estimatedTimeline commençant par cette valeur (LIKE value%) */
  estimatedTimelineStartsWith?: string;

  /** Filtre estimatedTimeline terminant par cette valeur (LIKE %value) */
  estimatedTimelineEndsWith?: string;

  /** Filtre estimatedTimeline ne contenant pas cette valeur (NOT LIKE %value%) */
  estimatedTimelineIsDifferentLike?: string;

  /** Filtre par valeur exacte de feeType */
  feeType?: string;
  /** Filtre IsNull sur feeType (true = IS NULL, false = IS NOT NULL) */
  feeTypeIsNull?: boolean;
  /** Filtre feeType différent de cette valeur (NOT EQUAL) */
  feeTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour feeType (IN) */
  feeTypes?: string[];
  /** Filtre feeType différent de toutes ces valeurs (NOT IN) */
  feeTypeIsDifferentList?: string[];

  /** Filtre feeType contenant cette valeur (LIKE %value%) */
  feeTypeLike?: string;

  /** Filtre feeType commençant par cette valeur (LIKE value%) */
  feeTypeStartsWith?: string;

  /** Filtre feeType terminant par cette valeur (LIKE %value) */
  feeTypeEndsWith?: string;

  /** Filtre feeType ne contenant pas cette valeur (NOT LIKE %value%) */
  feeTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de feePercentage */
  feePercentage?: number;
  /** Filtre IsNull sur feePercentage (true = IS NULL, false = IS NOT NULL) */
  feePercentageIsNull?: boolean;
  /** Filtre par liste de valeurs pour feePercentage (IN) */
  feePercentages?: number[];
  /** Filtre feePercentage différent de toutes ces valeurs (NOT IN) */
  feePercentageIsDifferentList?: number[];

  /** Filtre feePercentage supérieur ou égal à cette valeur */
  feePercentageMin?: number;

  /** Filtre feePercentage inférieur ou égal à cette valeur */
  feePercentageMax?: number;

  /** Filtre feePercentage strictement supérieur à cette valeur */
  feePercentageGreaterThan?: number;

  /** Filtre feePercentage strictement inférieur à cette valeur */
  feePercentageLessThan?: number;

  /** Filtre feePercentage différent de cette valeur */
  feePercentageIsDifferent?: number;

  /** Filtre par valeur exacte de feeFixedAmount */
  feeFixedAmount?: number;
  /** Filtre IsNull sur feeFixedAmount (true = IS NULL, false = IS NOT NULL) */
  feeFixedAmountIsNull?: boolean;
  /** Filtre par liste de valeurs pour feeFixedAmount (IN) */
  feeFixedAmounts?: number[];
  /** Filtre feeFixedAmount différent de toutes ces valeurs (NOT IN) */
  feeFixedAmountIsDifferentList?: number[];

  /** Filtre feeFixedAmount supérieur ou égal à cette valeur */
  feeFixedAmountMin?: number;

  /** Filtre feeFixedAmount inférieur ou égal à cette valeur */
  feeFixedAmountMax?: number;

  /** Filtre feeFixedAmount strictement supérieur à cette valeur */
  feeFixedAmountGreaterThan?: number;

  /** Filtre feeFixedAmount strictement inférieur à cette valeur */
  feeFixedAmountLessThan?: number;

  /** Filtre feeFixedAmount différent de cette valeur */
  feeFixedAmountIsDifferent?: number;

  /** Filtre par valeur exacte de message */
  message?: string;
  /** Filtre IsNull sur message (true = IS NULL, false = IS NOT NULL) */
  messageIsNull?: boolean;
  /** Filtre message différent de cette valeur (NOT EQUAL) */
  messageIsDifferent?: string;
  /** Filtre par liste de valeurs pour message (IN) */
  messages?: string[];
  /** Filtre message différent de toutes ces valeurs (NOT IN) */
  messageIsDifferentList?: string[];

  /** Filtre message contenant cette valeur (LIKE %value%) */
  messageLike?: string;

  /** Filtre message commençant par cette valeur (LIKE value%) */
  messageStartsWith?: string;

  /** Filtre message terminant par cette valeur (LIKE %value) */
  messageEndsWith?: string;

  /** Filtre message ne contenant pas cette valeur (NOT LIKE %value%) */
  messageIsDifferentLike?: string;

  /** Filtre par valeur exacte de status */
  status?: string;
  /** Filtre IsNull sur status (true = IS NULL, false = IS NOT NULL) */
  statusIsNull?: boolean;
  /** Filtre status différent de cette valeur (NOT EQUAL) */
  statusIsDifferent?: string;
  /** Filtre par liste de valeurs pour status (IN) */
  statuss?: string[];
  /** Filtre status différent de toutes ces valeurs (NOT IN) */
  statusIsDifferentList?: string[];

  /** Filtre status contenant cette valeur (LIKE %value%) */
  statusLike?: string;

  /** Filtre status commençant par cette valeur (LIKE value%) */
  statusStartsWith?: string;

  /** Filtre status terminant par cette valeur (LIKE %value) */
  statusEndsWith?: string;

  /** Filtre status ne contenant pas cette valeur (NOT LIKE %value%) */
  statusIsDifferentLike?: string;

  /** Filtre par valeur exacte de viewedAt */
  viewedAt?: Date | string;
  /** Filtre IsNull sur viewedAt (true = IS NULL, false = IS NOT NULL) */
  viewedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour viewedAt (IN) */
  viewedAts?: Date | string[];
  /** Filtre viewedAt différent de toutes ces valeurs (NOT IN) */
  viewedAtIsDifferentList?: Date | string[];

  /** Filtre viewedAt à partir de cette date (incluse) */
  viewedAtFrom?: Date | string;

  /** Filtre viewedAt jusqu'à cette date (incluse) */
  viewedAtTo?: Date | string;

  /** Filtre viewedAt strictement après cette date */
  viewedAtAfter?: Date | string;

  /** Filtre viewedAt strictement avant cette date */
  viewedAtBefore?: Date | string;

  /** Filtre viewedAt différent de cette date */
  viewedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de shortlistedAt */
  shortlistedAt?: Date | string;
  /** Filtre IsNull sur shortlistedAt (true = IS NULL, false = IS NOT NULL) */
  shortlistedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour shortlistedAt (IN) */
  shortlistedAts?: Date | string[];
  /** Filtre shortlistedAt différent de toutes ces valeurs (NOT IN) */
  shortlistedAtIsDifferentList?: Date | string[];

  /** Filtre shortlistedAt à partir de cette date (incluse) */
  shortlistedAtFrom?: Date | string;

  /** Filtre shortlistedAt jusqu'à cette date (incluse) */
  shortlistedAtTo?: Date | string;

  /** Filtre shortlistedAt strictement après cette date */
  shortlistedAtAfter?: Date | string;

  /** Filtre shortlistedAt strictement avant cette date */
  shortlistedAtBefore?: Date | string;

  /** Filtre shortlistedAt différent de cette date */
  shortlistedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de selectedAt */
  selectedAt?: Date | string;
  /** Filtre IsNull sur selectedAt (true = IS NULL, false = IS NOT NULL) */
  selectedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour selectedAt (IN) */
  selectedAts?: Date | string[];
  /** Filtre selectedAt différent de toutes ces valeurs (NOT IN) */
  selectedAtIsDifferentList?: Date | string[];

  /** Filtre selectedAt à partir de cette date (incluse) */
  selectedAtFrom?: Date | string;

  /** Filtre selectedAt jusqu'à cette date (incluse) */
  selectedAtTo?: Date | string;

  /** Filtre selectedAt strictement après cette date */
  selectedAtAfter?: Date | string;

  /** Filtre selectedAt strictement avant cette date */
  selectedAtBefore?: Date | string;

  /** Filtre selectedAt différent de cette date */
  selectedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de rejectedAt */
  rejectedAt?: Date | string;
  /** Filtre IsNull sur rejectedAt (true = IS NULL, false = IS NOT NULL) */
  rejectedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour rejectedAt (IN) */
  rejectedAts?: Date | string[];
  /** Filtre rejectedAt différent de toutes ces valeurs (NOT IN) */
  rejectedAtIsDifferentList?: Date | string[];

  /** Filtre rejectedAt à partir de cette date (incluse) */
  rejectedAtFrom?: Date | string;

  /** Filtre rejectedAt jusqu'à cette date (incluse) */
  rejectedAtTo?: Date | string;

  /** Filtre rejectedAt strictement après cette date */
  rejectedAtAfter?: Date | string;

  /** Filtre rejectedAt strictement avant cette date */
  rejectedAtBefore?: Date | string;

  /** Filtre rejectedAt différent de cette date */
  rejectedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de rejectionReason */
  rejectionReason?: string;
  /** Filtre IsNull sur rejectionReason (true = IS NULL, false = IS NOT NULL) */
  rejectionReasonIsNull?: boolean;
  /** Filtre rejectionReason différent de cette valeur (NOT EQUAL) */
  rejectionReasonIsDifferent?: string;
  /** Filtre par liste de valeurs pour rejectionReason (IN) */
  rejectionReasons?: string[];
  /** Filtre rejectionReason différent de toutes ces valeurs (NOT IN) */
  rejectionReasonIsDifferentList?: string[];

  /** Filtre rejectionReason contenant cette valeur (LIKE %value%) */
  rejectionReasonLike?: string;

  /** Filtre rejectionReason commençant par cette valeur (LIKE value%) */
  rejectionReasonStartsWith?: string;

  /** Filtre rejectionReason terminant par cette valeur (LIKE %value) */
  rejectionReasonEndsWith?: string;

  /** Filtre rejectionReason ne contenant pas cette valeur (NOT LIKE %value%) */
  rejectionReasonIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où opportunity est NULL).
   * false = INNER JOIN.
   * À configurer AVANT opportunity.
   */
  includeOpportunityEmpty?: boolean;

  /** Filtre imbriqué sur la navigation opportunity. */
  opportunity?: OpportunitiesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où professional est NULL).
   * false = INNER JOIN.
   * À configurer AVANT professional.
   */
  includeProfessionalEmpty?: boolean;

  /** Filtre imbriqué sur la navigation professional. */
  professional?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur applicationServices.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT applicationServices.
   */
  applicationServicesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont applicationServices est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT applicationServices.
   */
  includeApplicationservicesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour applicationServices.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT applicationServices.
   */
  applicationServicesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection applicationServices. */
  applicationServices?: ApplicationServicesCritereDTO;

}
