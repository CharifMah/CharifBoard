/**
 * DTO for table: conversations
 * Auto-generated - Do not modify manually
 */

import type { MessagesDTO } from '../messages/messages.dto';
import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';
import type { UsersDTO } from '../users/users.dto';

export interface ConversationsDTO {
  /** Primary Key */
  id?: number;
  opportunityId?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  professionalId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Opportunities */
  opportunity?: OpportunitiesDTO;
  /** Navigation property vers Users */
  professional?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Messages */
  messages?: MessagesDTO[];
}
