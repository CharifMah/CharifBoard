/**
 * DTO for table: fee_caps
 * Auto-generated - Do not modify manually
 */

export interface FeeCapsDTO {
  /** Primary Key */
  id?: number;
  priceMin?: number;
  priceMax?: number;
  feeType?: string;
  maxPercentage?: number;
  maxFixedAmount?: number;
  isActive?: boolean;
  createdAt?: Date | string;
  updatedAt?: Date | string;
}
