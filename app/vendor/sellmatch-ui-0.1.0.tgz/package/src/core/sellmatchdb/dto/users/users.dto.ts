/**
 * DTO for table: users
 * Auto-generated - Do not modify manually
 */

import { UserSubscriptionsDTO } from '..';
import type { AdressesDTO } from '../adresses/adresses.dto';
import type { ApplicationsDTO } from '../applications/applications.dto';
import type { ConversationsDTO } from '../conversations/conversations.dto';
import type { MessagesDTO } from '../messages/messages.dto';
import type { NotificationsDTO } from '../notifications/notifications.dto';
import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';
import type { RolesDTO } from '../roles/roles.dto';
import type { SettingsDTO } from '../settings/settings.dto';
///PROTECTEDFILE
export interface UsersDTO {
  /** Primary Key */
  id?: number;
  roleId?: number;
  email?: string;
  passwordHash?: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  avatarUrl?: string;
  isActive?: boolean;
  isVerified?: boolean;
  emailVerifiedAt?: Date | string;
  lastLoginAt?: Date | string;
  siret?: string;
  companyName?: string;
  bio?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  immodvisorApiKey?: string;
  immodvisorCid?: number;
  profilUrl?: string;
  addressId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  address?: AdressesDTO;
  /** Navigation property vers Roles */
  role?: RolesDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Applications */
  applications?: ApplicationsDTO[];
  /** Collection de Conversations */
  conversations?: ConversationsDTO[];
  /** Collection de Messages */
  messages?: MessagesDTO[];
  /** Collection de Notifications */
  notifications?: NotificationsDTO[];
  /** Collection de Opportunities */
  opportunities?: OpportunitiesDTO[];
  /** Collection de Settings */
  userSettings?: SettingsDTO[];
  userSubscriptions?: UserSubscriptionsDTO[];
}
