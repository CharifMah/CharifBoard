import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { UserSubscriptionsCritereDTO } from '../user-subscriptions/user-subscriptions.critere';

export interface SubscriptionPlansCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de key */
  key?: string;
  /** Filtre IsNull sur key (true = IS NULL, false = IS NOT NULL) */
  keyIsNull?: boolean;
  /** Filtre key différent de cette valeur (NOT EQUAL) */
  keyIsDifferent?: string;
  /** Filtre par liste de valeurs pour key (IN) */
  keys?: string[];
  /** Filtre key différent de toutes ces valeurs (NOT IN) */
  keyIsDifferentList?: string[];

  /** Filtre key contenant cette valeur (LIKE %value%) */
  keyLike?: string;

  /** Filtre key commençant par cette valeur (LIKE value%) */
  keyStartsWith?: string;

  /** Filtre key terminant par cette valeur (LIKE %value) */
  keyEndsWith?: string;

  /** Filtre key ne contenant pas cette valeur (NOT LIKE %value%) */
  keyIsDifferentLike?: string;

  /** Filtre par valeur exacte de label */
  label?: string;
  /** Filtre IsNull sur label (true = IS NULL, false = IS NOT NULL) */
  labelIsNull?: boolean;
  /** Filtre label différent de cette valeur (NOT EQUAL) */
  labelIsDifferent?: string;
  /** Filtre par liste de valeurs pour label (IN) */
  labels?: string[];
  /** Filtre label différent de toutes ces valeurs (NOT IN) */
  labelIsDifferentList?: string[];

  /** Filtre label contenant cette valeur (LIKE %value%) */
  labelLike?: string;

  /** Filtre label commençant par cette valeur (LIKE value%) */
  labelStartsWith?: string;

  /** Filtre label terminant par cette valeur (LIKE %value) */
  labelEndsWith?: string;

  /** Filtre label ne contenant pas cette valeur (NOT LIKE %value%) */
  labelIsDifferentLike?: string;

  /** Filtre par valeur exacte de description */
  description?: string;
  /** Filtre IsNull sur description (true = IS NULL, false = IS NOT NULL) */
  descriptionIsNull?: boolean;
  /** Filtre description différent de cette valeur (NOT EQUAL) */
  descriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour description (IN) */
  descriptions?: string[];
  /** Filtre description différent de toutes ces valeurs (NOT IN) */
  descriptionIsDifferentList?: string[];

  /** Filtre description contenant cette valeur (LIKE %value%) */
  descriptionLike?: string;

  /** Filtre description commençant par cette valeur (LIKE value%) */
  descriptionStartsWith?: string;

  /** Filtre description terminant par cette valeur (LIKE %value) */
  descriptionEndsWith?: string;

  /** Filtre description ne contenant pas cette valeur (NOT LIKE %value%) */
  descriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de stripePriceIdMonthly */
  stripePriceIdMonthly?: string;
  /** Filtre IsNull sur stripePriceIdMonthly (true = IS NULL, false = IS NOT NULL) */
  stripePriceIdMonthlyIsNull?: boolean;
  /** Filtre stripePriceIdMonthly différent de cette valeur (NOT EQUAL) */
  stripePriceIdMonthlyIsDifferent?: string;
  /** Filtre par liste de valeurs pour stripePriceIdMonthly (IN) */
  stripePriceIdMonthlys?: string[];
  /** Filtre stripePriceIdMonthly différent de toutes ces valeurs (NOT IN) */
  stripePriceIdMonthlyIsDifferentList?: string[];

  /** Filtre stripePriceIdMonthly contenant cette valeur (LIKE %value%) */
  stripePriceIdMonthlyLike?: string;

  /** Filtre stripePriceIdMonthly commençant par cette valeur (LIKE value%) */
  stripePriceIdMonthlyStartsWith?: string;

  /** Filtre stripePriceIdMonthly terminant par cette valeur (LIKE %value) */
  stripePriceIdMonthlyEndsWith?: string;

  /** Filtre stripePriceIdMonthly ne contenant pas cette valeur (NOT LIKE %value%) */
  stripePriceIdMonthlyIsDifferentLike?: string;

  /** Filtre par valeur exacte de stripePriceIdYearly */
  stripePriceIdYearly?: string;
  /** Filtre IsNull sur stripePriceIdYearly (true = IS NULL, false = IS NOT NULL) */
  stripePriceIdYearlyIsNull?: boolean;
  /** Filtre stripePriceIdYearly différent de cette valeur (NOT EQUAL) */
  stripePriceIdYearlyIsDifferent?: string;
  /** Filtre par liste de valeurs pour stripePriceIdYearly (IN) */
  stripePriceIdYearlys?: string[];
  /** Filtre stripePriceIdYearly différent de toutes ces valeurs (NOT IN) */
  stripePriceIdYearlyIsDifferentList?: string[];

  /** Filtre stripePriceIdYearly contenant cette valeur (LIKE %value%) */
  stripePriceIdYearlyLike?: string;

  /** Filtre stripePriceIdYearly commençant par cette valeur (LIKE value%) */
  stripePriceIdYearlyStartsWith?: string;

  /** Filtre stripePriceIdYearly terminant par cette valeur (LIKE %value) */
  stripePriceIdYearlyEndsWith?: string;

  /** Filtre stripePriceIdYearly ne contenant pas cette valeur (NOT LIKE %value%) */
  stripePriceIdYearlyIsDifferentLike?: string;

  /** Filtre par valeur exacte de stripePriceIdOneShot */
  stripePriceIdOneShot?: string;
  /** Filtre IsNull sur stripePriceIdOneShot (true = IS NULL, false = IS NOT NULL) */
  stripePriceIdOneShotIsNull?: boolean;
  /** Filtre stripePriceIdOneShot différent de cette valeur (NOT EQUAL) */
  stripePriceIdOneShotIsDifferent?: string;
  /** Filtre par liste de valeurs pour stripePriceIdOneShot (IN) */
  stripePriceIdOneShots?: string[];
  /** Filtre stripePriceIdOneShot différent de toutes ces valeurs (NOT IN) */
  stripePriceIdOneShotIsDifferentList?: string[];

  /** Filtre stripePriceIdOneShot contenant cette valeur (LIKE %value%) */
  stripePriceIdOneShotLike?: string;

  /** Filtre stripePriceIdOneShot commençant par cette valeur (LIKE value%) */
  stripePriceIdOneShotStartsWith?: string;

  /** Filtre stripePriceIdOneShot terminant par cette valeur (LIKE %value) */
  stripePriceIdOneShotEndsWith?: string;

  /** Filtre stripePriceIdOneShot ne contenant pas cette valeur (NOT LIKE %value%) */
  stripePriceIdOneShotIsDifferentLike?: string;

  /** Filtre par valeur exacte de priceMonthlyHt */
  priceMonthlyHt?: number;
  /** Filtre IsNull sur priceMonthlyHt (true = IS NULL, false = IS NOT NULL) */
  priceMonthlyHtIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceMonthlyHt (IN) */
  priceMonthlyHts?: number[];
  /** Filtre priceMonthlyHt différent de toutes ces valeurs (NOT IN) */
  priceMonthlyHtIsDifferentList?: number[];

  /** Filtre priceMonthlyHt supérieur ou égal à cette valeur */
  priceMonthlyHtMin?: number;

  /** Filtre priceMonthlyHt inférieur ou égal à cette valeur */
  priceMonthlyHtMax?: number;

  /** Filtre priceMonthlyHt strictement supérieur à cette valeur */
  priceMonthlyHtGreaterThan?: number;

  /** Filtre priceMonthlyHt strictement inférieur à cette valeur */
  priceMonthlyHtLessThan?: number;

  /** Filtre priceMonthlyHt différent de cette valeur */
  priceMonthlyHtIsDifferent?: number;

  /** Filtre par valeur exacte de priceYearlyHt */
  priceYearlyHt?: number;
  /** Filtre IsNull sur priceYearlyHt (true = IS NULL, false = IS NOT NULL) */
  priceYearlyHtIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceYearlyHt (IN) */
  priceYearlyHts?: number[];
  /** Filtre priceYearlyHt différent de toutes ces valeurs (NOT IN) */
  priceYearlyHtIsDifferentList?: number[];

  /** Filtre priceYearlyHt supérieur ou égal à cette valeur */
  priceYearlyHtMin?: number;

  /** Filtre priceYearlyHt inférieur ou égal à cette valeur */
  priceYearlyHtMax?: number;

  /** Filtre priceYearlyHt strictement supérieur à cette valeur */
  priceYearlyHtGreaterThan?: number;

  /** Filtre priceYearlyHt strictement inférieur à cette valeur */
  priceYearlyHtLessThan?: number;

  /** Filtre priceYearlyHt différent de cette valeur */
  priceYearlyHtIsDifferent?: number;

  /** Filtre par valeur exacte de priceOneShotTtc */
  priceOneShotTtc?: number;
  /** Filtre IsNull sur priceOneShotTtc (true = IS NULL, false = IS NOT NULL) */
  priceOneShotTtcIsNull?: boolean;
  /** Filtre par liste de valeurs pour priceOneShotTtc (IN) */
  priceOneShotTtcs?: number[];
  /** Filtre priceOneShotTtc différent de toutes ces valeurs (NOT IN) */
  priceOneShotTtcIsDifferentList?: number[];

  /** Filtre priceOneShotTtc supérieur ou égal à cette valeur */
  priceOneShotTtcMin?: number;

  /** Filtre priceOneShotTtc inférieur ou égal à cette valeur */
  priceOneShotTtcMax?: number;

  /** Filtre priceOneShotTtc strictement supérieur à cette valeur */
  priceOneShotTtcGreaterThan?: number;

  /** Filtre priceOneShotTtc strictement inférieur à cette valeur */
  priceOneShotTtcLessThan?: number;

  /** Filtre priceOneShotTtc différent de cette valeur */
  priceOneShotTtcIsDifferent?: number;

  /** Filtre par valeur exacte de isOneShot */
  isOneShot?: boolean;
  /** Filtre isOneShot différent de cette valeur (NOT EQUAL) */
  isOneShotIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isOneShot (IN) */
  isOneShots?: boolean[];
  /** Filtre isOneShot différent de toutes ces valeurs (NOT IN) */
  isOneShotIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre isActive différent de cette valeur (NOT EQUAL) */
  isActiveIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];
  /** Filtre isActive différent de toutes ces valeurs (NOT IN) */
  isActiveIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de displayOrder */
  displayOrder?: number;
  /** Filtre par liste de valeurs pour displayOrder (IN) */
  displayOrders?: number[];
  /** Filtre displayOrder différent de toutes ces valeurs (NOT IN) */
  displayOrderIsDifferentList?: number[];

  /** Filtre displayOrder supérieur ou égal à cette valeur */
  displayOrderMin?: number;

  /** Filtre displayOrder inférieur ou égal à cette valeur */
  displayOrderMax?: number;

  /** Filtre displayOrder strictement supérieur à cette valeur */
  displayOrderGreaterThan?: number;

  /** Filtre displayOrder strictement inférieur à cette valeur */
  displayOrderLessThan?: number;

  /** Filtre displayOrder différent de cette valeur */
  displayOrderIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de logoUrl */
  logoUrl?: string;
  /** Filtre IsNull sur logoUrl (true = IS NULL, false = IS NOT NULL) */
  logoUrlIsNull?: boolean;
  /** Filtre logoUrl différent de cette valeur (NOT EQUAL) */
  logoUrlIsDifferent?: string;
  /** Filtre par liste de valeurs pour logoUrl (IN) */
  logoUrls?: string[];
  /** Filtre logoUrl différent de toutes ces valeurs (NOT IN) */
  logoUrlIsDifferentList?: string[];

  /** Filtre logoUrl contenant cette valeur (LIKE %value%) */
  logoUrlLike?: string;

  /** Filtre logoUrl commençant par cette valeur (LIKE value%) */
  logoUrlStartsWith?: string;

  /** Filtre logoUrl terminant par cette valeur (LIKE %value) */
  logoUrlEndsWith?: string;

  /** Filtre logoUrl ne contenant pas cette valeur (NOT LIKE %value%) */
  logoUrlIsDifferentLike?: string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur userSubscriptions.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT userSubscriptions.
   */
  userSubscriptionsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont userSubscriptions est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT userSubscriptions.
   */
  includeUsersubscriptionsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour userSubscriptions.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT userSubscriptions.
   */
  userSubscriptionsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection userSubscriptions. */
  userSubscriptions?: UserSubscriptionsCritereDTO;

}
