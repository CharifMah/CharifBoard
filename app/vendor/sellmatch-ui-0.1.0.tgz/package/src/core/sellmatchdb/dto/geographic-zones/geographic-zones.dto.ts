/**
 * DTO for table: geographic_zones
 * Auto-generated - Do not modify manually
 */

export interface GeographicZonesDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  name?: string;
  zoneType?: string;
  parentId?: number;
  isActive?: boolean;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  parent?: GeographicZonesDTO;

  // ----- Navigation properties (One-to-Many) -----
  geographicZones?: GeographicZonesDTO[];
}
