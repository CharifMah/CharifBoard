/**
 * DTO for table: messages
 * Auto-generated - Do not modify manually
 */

import type { ConversationsDTO } from '../conversations/conversations.dto';
import type { UsersDTO } from '../users/users.dto';

export interface MessagesDTO {
  /** Primary Key */
  id?: number;
  conversationId?: number;
  senderId?: number;
  content?: string;
  readAt?: Date | string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Conversations */
  conversation?: ConversationsDTO;
  /** Navigation property vers Users */
  sender?: UsersDTO;
}
