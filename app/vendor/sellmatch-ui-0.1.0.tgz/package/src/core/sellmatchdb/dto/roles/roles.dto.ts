/**
 * DTO for table: roles
 * Auto-generated - Do not modify manually
 */

import type { UsersDTO } from '../users/users.dto';

export interface RolesDTO {
  /** Primary Key */
  id?: number;
  name?: string;
  description?: string;
  createdAt?: Date | string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Users */
  users?: UsersDTO[];
}
