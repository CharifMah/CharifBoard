import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface ReviewsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre IsNull sur id (true = IS NULL, false = IS NOT NULL) */
  idIsNull?: boolean;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de selectionId */
  selectionId?: number;
  /** Filtre IsNull sur selectionId (true = IS NULL, false = IS NOT NULL) */
  selectionIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour selectionId (IN) */
  selectionIds?: number[];
  /** Filtre selectionId différent de toutes ces valeurs (NOT IN) */
  selectionIdIsDifferentList?: number[];

  /** Filtre selectionId supérieur ou égal à cette valeur */
  selectionIdMin?: number;

  /** Filtre selectionId inférieur ou égal à cette valeur */
  selectionIdMax?: number;

  /** Filtre selectionId strictement supérieur à cette valeur */
  selectionIdGreaterThan?: number;

  /** Filtre selectionId strictement inférieur à cette valeur */
  selectionIdLessThan?: number;

  /** Filtre selectionId différent de cette valeur */
  selectionIdIsDifferent?: number;

  /** Filtre par valeur exacte de reviewerId */
  reviewerId?: number;
  /** Filtre IsNull sur reviewerId (true = IS NULL, false = IS NOT NULL) */
  reviewerIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour reviewerId (IN) */
  reviewerIds?: number[];
  /** Filtre reviewerId différent de toutes ces valeurs (NOT IN) */
  reviewerIdIsDifferentList?: number[];

  /** Filtre reviewerId supérieur ou égal à cette valeur */
  reviewerIdMin?: number;

  /** Filtre reviewerId inférieur ou égal à cette valeur */
  reviewerIdMax?: number;

  /** Filtre reviewerId strictement supérieur à cette valeur */
  reviewerIdGreaterThan?: number;

  /** Filtre reviewerId strictement inférieur à cette valeur */
  reviewerIdLessThan?: number;

  /** Filtre reviewerId différent de cette valeur */
  reviewerIdIsDifferent?: number;

  /** Filtre par valeur exacte de reviewedId */
  reviewedId?: number;
  /** Filtre IsNull sur reviewedId (true = IS NULL, false = IS NOT NULL) */
  reviewedIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour reviewedId (IN) */
  reviewedIds?: number[];
  /** Filtre reviewedId différent de toutes ces valeurs (NOT IN) */
  reviewedIdIsDifferentList?: number[];

  /** Filtre reviewedId supérieur ou égal à cette valeur */
  reviewedIdMin?: number;

  /** Filtre reviewedId inférieur ou égal à cette valeur */
  reviewedIdMax?: number;

  /** Filtre reviewedId strictement supérieur à cette valeur */
  reviewedIdGreaterThan?: number;

  /** Filtre reviewedId strictement inférieur à cette valeur */
  reviewedIdLessThan?: number;

  /** Filtre reviewedId différent de cette valeur */
  reviewedIdIsDifferent?: number;

  /** Filtre par valeur exacte de reviewerType */
  reviewerType?: string;
  /** Filtre IsNull sur reviewerType (true = IS NULL, false = IS NOT NULL) */
  reviewerTypeIsNull?: boolean;
  /** Filtre reviewerType différent de cette valeur (NOT EQUAL) */
  reviewerTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour reviewerType (IN) */
  reviewerTypes?: string[];
  /** Filtre reviewerType différent de toutes ces valeurs (NOT IN) */
  reviewerTypeIsDifferentList?: string[];

  /** Filtre reviewerType contenant cette valeur (LIKE %value%) */
  reviewerTypeLike?: string;

  /** Filtre reviewerType commençant par cette valeur (LIKE value%) */
  reviewerTypeStartsWith?: string;

  /** Filtre reviewerType terminant par cette valeur (LIKE %value) */
  reviewerTypeEndsWith?: string;

  /** Filtre reviewerType ne contenant pas cette valeur (NOT LIKE %value%) */
  reviewerTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de rating */
  rating?: number;
  /** Filtre IsNull sur rating (true = IS NULL, false = IS NOT NULL) */
  ratingIsNull?: boolean;
  /** Filtre par liste de valeurs pour rating (IN) */
  ratings?: number[];
  /** Filtre rating différent de toutes ces valeurs (NOT IN) */
  ratingIsDifferentList?: number[];

  /** Filtre rating supérieur ou égal à cette valeur */
  ratingMin?: number;

  /** Filtre rating inférieur ou égal à cette valeur */
  ratingMax?: number;

  /** Filtre rating strictement supérieur à cette valeur */
  ratingGreaterThan?: number;

  /** Filtre rating strictement inférieur à cette valeur */
  ratingLessThan?: number;

  /** Filtre rating différent de cette valeur */
  ratingIsDifferent?: number;

  /** Filtre par valeur exacte de comment */
  comment?: string;
  /** Filtre IsNull sur comment (true = IS NULL, false = IS NOT NULL) */
  commentIsNull?: boolean;
  /** Filtre comment différent de cette valeur (NOT EQUAL) */
  commentIsDifferent?: string;
  /** Filtre par liste de valeurs pour comment (IN) */
  comments?: string[];
  /** Filtre comment différent de toutes ces valeurs (NOT IN) */
  commentIsDifferentList?: string[];

  /** Filtre comment contenant cette valeur (LIKE %value%) */
  commentLike?: string;

  /** Filtre comment commençant par cette valeur (LIKE value%) */
  commentStartsWith?: string;

  /** Filtre comment terminant par cette valeur (LIKE %value) */
  commentEndsWith?: string;

  /** Filtre comment ne contenant pas cette valeur (NOT LIKE %value%) */
  commentIsDifferentLike?: string;

  /** Filtre par valeur exacte de isPublished */
  isPublished?: boolean;
  /** Filtre IsNull sur isPublished (true = IS NULL, false = IS NOT NULL) */
  isPublishedIsNull?: boolean;
  /** Filtre isPublished différent de cette valeur (NOT EQUAL) */
  isPublishedIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isPublished (IN) */
  isPublisheds?: boolean[];
  /** Filtre isPublished différent de toutes ces valeurs (NOT IN) */
  isPublishedIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où reviewed est NULL).
   * false = INNER JOIN.
   * À configurer AVANT reviewed.
   */
  includeReviewedEmpty?: boolean;

  /** Filtre imbriqué sur la navigation reviewed. */
  reviewed?: UsersCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où reviewer est NULL).
   * false = INNER JOIN.
   * À configurer AVANT reviewer.
   */
  includeReviewerEmpty?: boolean;

  /** Filtre imbriqué sur la navigation reviewer. */
  reviewer?: UsersCritereDTO;

}
