import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { ApplicationServicesCritereDTO } from '../application-services/application-services.critere';

export interface AvailableServicesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de category */
  category?: string;
  /** Filtre IsNull sur category (true = IS NULL, false = IS NOT NULL) */
  categoryIsNull?: boolean;
  /** Filtre category différent de cette valeur (NOT EQUAL) */
  categoryIsDifferent?: string;
  /** Filtre par liste de valeurs pour category (IN) */
  categorys?: string[];
  /** Filtre category différent de toutes ces valeurs (NOT IN) */
  categoryIsDifferentList?: string[];

  /** Filtre category contenant cette valeur (LIKE %value%) */
  categoryLike?: string;

  /** Filtre category commençant par cette valeur (LIKE value%) */
  categoryStartsWith?: string;

  /** Filtre category terminant par cette valeur (LIKE %value) */
  categoryEndsWith?: string;

  /** Filtre category ne contenant pas cette valeur (NOT LIKE %value%) */
  categoryIsDifferentLike?: string;

  /** Filtre par valeur exacte de serviceKey */
  serviceKey?: string;
  /** Filtre IsNull sur serviceKey (true = IS NULL, false = IS NOT NULL) */
  serviceKeyIsNull?: boolean;
  /** Filtre serviceKey différent de cette valeur (NOT EQUAL) */
  serviceKeyIsDifferent?: string;
  /** Filtre par liste de valeurs pour serviceKey (IN) */
  serviceKeys?: string[];
  /** Filtre serviceKey différent de toutes ces valeurs (NOT IN) */
  serviceKeyIsDifferentList?: string[];

  /** Filtre serviceKey contenant cette valeur (LIKE %value%) */
  serviceKeyLike?: string;

  /** Filtre serviceKey commençant par cette valeur (LIKE value%) */
  serviceKeyStartsWith?: string;

  /** Filtre serviceKey terminant par cette valeur (LIKE %value) */
  serviceKeyEndsWith?: string;

  /** Filtre serviceKey ne contenant pas cette valeur (NOT LIKE %value%) */
  serviceKeyIsDifferentLike?: string;

  /** Filtre par valeur exacte de serviceLabel */
  serviceLabel?: string;
  /** Filtre IsNull sur serviceLabel (true = IS NULL, false = IS NOT NULL) */
  serviceLabelIsNull?: boolean;
  /** Filtre serviceLabel différent de cette valeur (NOT EQUAL) */
  serviceLabelIsDifferent?: string;
  /** Filtre par liste de valeurs pour serviceLabel (IN) */
  serviceLabels?: string[];
  /** Filtre serviceLabel différent de toutes ces valeurs (NOT IN) */
  serviceLabelIsDifferentList?: string[];

  /** Filtre serviceLabel contenant cette valeur (LIKE %value%) */
  serviceLabelLike?: string;

  /** Filtre serviceLabel commençant par cette valeur (LIKE value%) */
  serviceLabelStartsWith?: string;

  /** Filtre serviceLabel terminant par cette valeur (LIKE %value) */
  serviceLabelEndsWith?: string;

  /** Filtre serviceLabel ne contenant pas cette valeur (NOT LIKE %value%) */
  serviceLabelIsDifferentLike?: string;

  /** Filtre par valeur exacte de icon */
  icon?: string;
  /** Filtre IsNull sur icon (true = IS NULL, false = IS NOT NULL) */
  iconIsNull?: boolean;
  /** Filtre icon différent de cette valeur (NOT EQUAL) */
  iconIsDifferent?: string;
  /** Filtre par liste de valeurs pour icon (IN) */
  icons?: string[];
  /** Filtre icon différent de toutes ces valeurs (NOT IN) */
  iconIsDifferentList?: string[];

  /** Filtre icon contenant cette valeur (LIKE %value%) */
  iconLike?: string;

  /** Filtre icon commençant par cette valeur (LIKE value%) */
  iconStartsWith?: string;

  /** Filtre icon terminant par cette valeur (LIKE %value) */
  iconEndsWith?: string;

  /** Filtre icon ne contenant pas cette valeur (NOT LIKE %value%) */
  iconIsDifferentLike?: string;

  /** Filtre par valeur exacte de displayOrder */
  displayOrder?: number;
  /** Filtre IsNull sur displayOrder (true = IS NULL, false = IS NOT NULL) */
  displayOrderIsNull?: boolean;
  /** Filtre par liste de valeurs pour displayOrder (IN) */
  displayOrders?: number[];
  /** Filtre displayOrder différent de toutes ces valeurs (NOT IN) */
  displayOrderIsDifferentList?: number[];

  /** Filtre displayOrder supérieur ou égal à cette valeur */
  displayOrderMin?: number;

  /** Filtre displayOrder inférieur ou égal à cette valeur */
  displayOrderMax?: number;

  /** Filtre displayOrder strictement supérieur à cette valeur */
  displayOrderGreaterThan?: number;

  /** Filtre displayOrder strictement inférieur à cette valeur */
  displayOrderLessThan?: number;

  /** Filtre displayOrder différent de cette valeur */
  displayOrderIsDifferent?: number;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre IsNull sur isActive (true = IS NULL, false = IS NOT NULL) */
  isActiveIsNull?: boolean;
  /** Filtre isActive différent de cette valeur (NOT EQUAL) */
  isActiveIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];
  /** Filtre isActive différent de toutes ces valeurs (NOT IN) */
  isActiveIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur applicationServices.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT applicationServices.
   */
  applicationServicesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont applicationServices est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT applicationServices.
   */
  includeApplicationservicesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour applicationServices.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT applicationServices.
   */
  applicationServicesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection applicationServices. */
  applicationServices?: ApplicationServicesCritereDTO;

}
