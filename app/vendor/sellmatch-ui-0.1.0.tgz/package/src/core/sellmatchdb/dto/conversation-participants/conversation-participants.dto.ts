/**
 * DTO for table: conversation_participants
 * Auto-generated - Do not modify manually
 */

import type { ConversationsDTO } from '../conversations/conversations.dto';
import type { UsersDTO } from '../users/users.dto';

export interface ConversationParticipantsDTO {
  /** Primary Key */
  conversationId?: number;
  /** Primary Key */
  userId?: number;
  joinedAt?: Date | string;
  lastReadAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  conversation?: ConversationsDTO;
  user?: UsersDTO;
}
