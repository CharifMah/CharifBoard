/**
 * DTO for table: opportunities
 * Auto-generated - Do not modify manually
 */

import type { AdressesDTO } from '../adresses/adresses.dto';
import type { ApplicationsDTO } from '../applications/applications.dto';
import type { ConversationsDTO } from '../conversations/conversations.dto';
import type { LiaiOpportunitiesStatusDTO } from '../liai-opportunities-status/liai-opportunities-status.dto';
import type { UsersDTO } from '../users/users.dto';

export interface OpportunitiesDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  idStatusId?: number;
  referenceCode?: string;
  propertyType?: string;
  surface?: number;
  priceRangeMin?: number;
  priceRangeMax?: number;
  description?: string;
  viewsCount?: number;
  publishedAt?: Date | string;
  expiresAt?: Date | string;
  closedAt?: Date | string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  isPrio?: boolean;
  paymentid?: string;
  addressId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  address?: AdressesDTO;
  /** Navigation property vers LiaiOpportunitiesStatus */
  idStatusNavigation?: LiaiOpportunitiesStatusDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Applications */
  applications?: ApplicationsDTO[];
  /** Collection de Conversations */
  conversations?: ConversationsDTO[];
}
