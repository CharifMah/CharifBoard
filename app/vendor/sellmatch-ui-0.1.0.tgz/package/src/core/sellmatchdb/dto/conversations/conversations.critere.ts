import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { MessagesCritereDTO } from '../messages/messages.critere';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface ConversationsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de opportunityId */
  opportunityId?: number;
  /** Filtre IsNull sur opportunityId (true = IS NULL, false = IS NOT NULL) */
  opportunityIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour opportunityId (IN) */
  opportunityIds?: number[];
  /** Filtre opportunityId différent de toutes ces valeurs (NOT IN) */
  opportunityIdIsDifferentList?: number[];

  /** Filtre opportunityId supérieur ou égal à cette valeur */
  opportunityIdMin?: number;

  /** Filtre opportunityId inférieur ou égal à cette valeur */
  opportunityIdMax?: number;

  /** Filtre opportunityId strictement supérieur à cette valeur */
  opportunityIdGreaterThan?: number;

  /** Filtre opportunityId strictement inférieur à cette valeur */
  opportunityIdLessThan?: number;

  /** Filtre opportunityId différent de cette valeur */
  opportunityIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de professionalId */
  professionalId?: number;
  /** Filtre par liste de valeurs pour professionalId (IN) */
  professionalIds?: number[];
  /** Filtre professionalId différent de toutes ces valeurs (NOT IN) */
  professionalIdIsDifferentList?: number[];

  /** Filtre professionalId supérieur ou égal à cette valeur */
  professionalIdMin?: number;

  /** Filtre professionalId inférieur ou égal à cette valeur */
  professionalIdMax?: number;

  /** Filtre professionalId strictement supérieur à cette valeur */
  professionalIdGreaterThan?: number;

  /** Filtre professionalId strictement inférieur à cette valeur */
  professionalIdLessThan?: number;

  /** Filtre professionalId différent de cette valeur */
  professionalIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où opportunity est NULL).
   * false = INNER JOIN.
   * À configurer AVANT opportunity.
   */
  includeOpportunityEmpty?: boolean;

  /** Filtre imbriqué sur la navigation opportunity. */
  opportunity?: OpportunitiesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où professional est NULL).
   * false = INNER JOIN.
   * À configurer AVANT professional.
   */
  includeProfessionalEmpty?: boolean;

  /** Filtre imbriqué sur la navigation professional. */
  professional?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur messages.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT messages.
   */
  messagesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont messages est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT messages.
   */
  includeMessagesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour messages.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT messages.
   */
  messagesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection messages. */
  messages?: MessagesCritereDTO;

}
