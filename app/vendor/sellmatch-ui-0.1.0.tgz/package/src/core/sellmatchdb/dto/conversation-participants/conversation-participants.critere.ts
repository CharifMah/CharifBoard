import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ConversationsCritereDTO } from '../conversations/conversations.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface ConversationParticipantsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de conversationId */
  conversationId?: number;
  /** Filtre par liste de valeurs pour conversationId (IN) */
  conversationIds?: number[];

  /** Filtre conversationId supérieur ou égal à cette valeur */
  conversationIdMin?: number;
  /** Filtre conversationId inférieur ou égal à cette valeur */
  conversationIdMax?: number;
  /** Filtre conversationId strictement supérieur à cette valeur */
  conversationIdGreaterThan?: number;
  /** Filtre conversationId strictement inférieur à cette valeur */
  conversationIdLessThan?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;
  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;
  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;
  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre par valeur exacte de joinedAt */
  joinedAt?: Date | string;
  /** Filtre par liste de valeurs pour joinedAt (IN) */
  joinedAts?: Date | string[];

  /** Filtre joinedAt à partir de cette date (incluse) */
  joinedAtFrom?: Date | string;
  /** Filtre joinedAt jusqu'à cette date (incluse) */
  joinedAtTo?: Date | string;
  /** Filtre joinedAt strictement après cette date */
  joinedAtAfter?: Date | string;
  /** Filtre joinedAt strictement avant cette date */
  joinedAtBefore?: Date | string;

  /** Filtre par valeur exacte de lastReadAt */
  lastReadAt?: Date | string;
  /** Filtre par liste de valeurs pour lastReadAt (IN) */
  lastReadAts?: Date | string[];

  /** Filtre lastReadAt à partir de cette date (incluse) */
  lastReadAtFrom?: Date | string;
  /** Filtre lastReadAt jusqu'à cette date (incluse) */
  lastReadAtTo?: Date | string;
  /** Filtre lastReadAt strictement après cette date */
  lastReadAtAfter?: Date | string;
  /** Filtre lastReadAt strictement avant cette date */
  lastReadAtBefore?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /** Filtre imbriqué sur conversation */
  conversation?: ConversationsCritereDTO;

  /** Filtre imbriqué sur user */
  user?: UsersCritereDTO;

}
