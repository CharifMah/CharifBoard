import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { SubscriptionPlansCritereDTO } from '../subscription-plans/subscription-plans.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface UserSubscriptionsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de planId */
  planId?: number;
  /** Filtre par liste de valeurs pour planId (IN) */
  planIds?: number[];
  /** Filtre planId différent de toutes ces valeurs (NOT IN) */
  planIdIsDifferentList?: number[];

  /** Filtre planId supérieur ou égal à cette valeur */
  planIdMin?: number;

  /** Filtre planId inférieur ou égal à cette valeur */
  planIdMax?: number;

  /** Filtre planId strictement supérieur à cette valeur */
  planIdGreaterThan?: number;

  /** Filtre planId strictement inférieur à cette valeur */
  planIdLessThan?: number;

  /** Filtre planId différent de cette valeur */
  planIdIsDifferent?: number;

  /** Filtre par valeur exacte de stripeCustomerId */
  stripeCustomerId?: string;
  /** Filtre IsNull sur stripeCustomerId (true = IS NULL, false = IS NOT NULL) */
  stripeCustomerIdIsNull?: boolean;
  /** Filtre stripeCustomerId différent de cette valeur (NOT EQUAL) */
  stripeCustomerIdIsDifferent?: string;
  /** Filtre par liste de valeurs pour stripeCustomerId (IN) */
  stripeCustomerIds?: string[];
  /** Filtre stripeCustomerId différent de toutes ces valeurs (NOT IN) */
  stripeCustomerIdIsDifferentList?: string[];

  /** Filtre stripeCustomerId contenant cette valeur (LIKE %value%) */
  stripeCustomerIdLike?: string;

  /** Filtre stripeCustomerId commençant par cette valeur (LIKE value%) */
  stripeCustomerIdStartsWith?: string;

  /** Filtre stripeCustomerId terminant par cette valeur (LIKE %value) */
  stripeCustomerIdEndsWith?: string;

  /** Filtre stripeCustomerId ne contenant pas cette valeur (NOT LIKE %value%) */
  stripeCustomerIdIsDifferentLike?: string;

  /** Filtre par valeur exacte de stripeSubscriptionId */
  stripeSubscriptionId?: string;
  /** Filtre IsNull sur stripeSubscriptionId (true = IS NULL, false = IS NOT NULL) */
  stripeSubscriptionIdIsNull?: boolean;
  /** Filtre stripeSubscriptionId différent de cette valeur (NOT EQUAL) */
  stripeSubscriptionIdIsDifferent?: string;
  /** Filtre par liste de valeurs pour stripeSubscriptionId (IN) */
  stripeSubscriptionIds?: string[];
  /** Filtre stripeSubscriptionId différent de toutes ces valeurs (NOT IN) */
  stripeSubscriptionIdIsDifferentList?: string[];

  /** Filtre stripeSubscriptionId contenant cette valeur (LIKE %value%) */
  stripeSubscriptionIdLike?: string;

  /** Filtre stripeSubscriptionId commençant par cette valeur (LIKE value%) */
  stripeSubscriptionIdStartsWith?: string;

  /** Filtre stripeSubscriptionId terminant par cette valeur (LIKE %value) */
  stripeSubscriptionIdEndsWith?: string;

  /** Filtre stripeSubscriptionId ne contenant pas cette valeur (NOT LIKE %value%) */
  stripeSubscriptionIdIsDifferentLike?: string;

  /** Filtre par valeur exacte de status */
  status?: string;
  /** Filtre IsNull sur status (true = IS NULL, false = IS NOT NULL) */
  statusIsNull?: boolean;
  /** Filtre status différent de cette valeur (NOT EQUAL) */
  statusIsDifferent?: string;
  /** Filtre par liste de valeurs pour status (IN) */
  statuss?: string[];
  /** Filtre status différent de toutes ces valeurs (NOT IN) */
  statusIsDifferentList?: string[];

  /** Filtre status contenant cette valeur (LIKE %value%) */
  statusLike?: string;

  /** Filtre status commençant par cette valeur (LIKE value%) */
  statusStartsWith?: string;

  /** Filtre status terminant par cette valeur (LIKE %value) */
  statusEndsWith?: string;

  /** Filtre status ne contenant pas cette valeur (NOT LIKE %value%) */
  statusIsDifferentLike?: string;

  /** Filtre par valeur exacte de billingPeriod */
  billingPeriod?: string;
  /** Filtre IsNull sur billingPeriod (true = IS NULL, false = IS NOT NULL) */
  billingPeriodIsNull?: boolean;
  /** Filtre billingPeriod différent de cette valeur (NOT EQUAL) */
  billingPeriodIsDifferent?: string;
  /** Filtre par liste de valeurs pour billingPeriod (IN) */
  billingPeriods?: string[];
  /** Filtre billingPeriod différent de toutes ces valeurs (NOT IN) */
  billingPeriodIsDifferentList?: string[];

  /** Filtre billingPeriod contenant cette valeur (LIKE %value%) */
  billingPeriodLike?: string;

  /** Filtre billingPeriod commençant par cette valeur (LIKE value%) */
  billingPeriodStartsWith?: string;

  /** Filtre billingPeriod terminant par cette valeur (LIKE %value) */
  billingPeriodEndsWith?: string;

  /** Filtre billingPeriod ne contenant pas cette valeur (NOT LIKE %value%) */
  billingPeriodIsDifferentLike?: string;

  /** Filtre par valeur exacte de currentPeriodStart */
  currentPeriodStart?: Date | string;
  /** Filtre IsNull sur currentPeriodStart (true = IS NULL, false = IS NOT NULL) */
  currentPeriodStartIsNull?: boolean;
  /** Filtre par liste de valeurs pour currentPeriodStart (IN) */
  currentPeriodStarts?: Date | string[];
  /** Filtre currentPeriodStart différent de toutes ces valeurs (NOT IN) */
  currentPeriodStartIsDifferentList?: Date | string[];

  /** Filtre currentPeriodStart à partir de cette date (incluse) */
  currentPeriodStartFrom?: Date | string;

  /** Filtre currentPeriodStart jusqu'à cette date (incluse) */
  currentPeriodStartTo?: Date | string;

  /** Filtre currentPeriodStart strictement après cette date */
  currentPeriodStartAfter?: Date | string;

  /** Filtre currentPeriodStart strictement avant cette date */
  currentPeriodStartBefore?: Date | string;

  /** Filtre currentPeriodStart différent de cette date */
  currentPeriodStartIsDifferent?: Date | string;

  /** Filtre par valeur exacte de currentPeriodEnd */
  currentPeriodEnd?: Date | string;
  /** Filtre IsNull sur currentPeriodEnd (true = IS NULL, false = IS NOT NULL) */
  currentPeriodEndIsNull?: boolean;
  /** Filtre par liste de valeurs pour currentPeriodEnd (IN) */
  currentPeriodEnds?: Date | string[];
  /** Filtre currentPeriodEnd différent de toutes ces valeurs (NOT IN) */
  currentPeriodEndIsDifferentList?: Date | string[];

  /** Filtre currentPeriodEnd à partir de cette date (incluse) */
  currentPeriodEndFrom?: Date | string;

  /** Filtre currentPeriodEnd jusqu'à cette date (incluse) */
  currentPeriodEndTo?: Date | string;

  /** Filtre currentPeriodEnd strictement après cette date */
  currentPeriodEndAfter?: Date | string;

  /** Filtre currentPeriodEnd strictement avant cette date */
  currentPeriodEndBefore?: Date | string;

  /** Filtre currentPeriodEnd différent de cette date */
  currentPeriodEndIsDifferent?: Date | string;

  /** Filtre par valeur exacte de canceledAt */
  canceledAt?: Date | string;
  /** Filtre IsNull sur canceledAt (true = IS NULL, false = IS NOT NULL) */
  canceledAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour canceledAt (IN) */
  canceledAts?: Date | string[];
  /** Filtre canceledAt différent de toutes ces valeurs (NOT IN) */
  canceledAtIsDifferentList?: Date | string[];

  /** Filtre canceledAt à partir de cette date (incluse) */
  canceledAtFrom?: Date | string;

  /** Filtre canceledAt jusqu'à cette date (incluse) */
  canceledAtTo?: Date | string;

  /** Filtre canceledAt strictement après cette date */
  canceledAtAfter?: Date | string;

  /** Filtre canceledAt strictement avant cette date */
  canceledAtBefore?: Date | string;

  /** Filtre canceledAt différent de cette date */
  canceledAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où plan est NULL).
   * false = INNER JOIN.
   * À configurer AVANT plan.
   */
  includePlanEmpty?: boolean;

  /** Filtre imbriqué sur la navigation plan. */
  plan?: SubscriptionPlansCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
