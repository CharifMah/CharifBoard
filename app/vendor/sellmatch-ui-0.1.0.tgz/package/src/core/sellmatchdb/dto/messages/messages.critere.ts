import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ConversationsCritereDTO } from '../conversations/conversations.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface MessagesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de conversationId */
  conversationId?: number;
  /** Filtre IsNull sur conversationId (true = IS NULL, false = IS NOT NULL) */
  conversationIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour conversationId (IN) */
  conversationIds?: number[];
  /** Filtre conversationId différent de toutes ces valeurs (NOT IN) */
  conversationIdIsDifferentList?: number[];

  /** Filtre conversationId supérieur ou égal à cette valeur */
  conversationIdMin?: number;

  /** Filtre conversationId inférieur ou égal à cette valeur */
  conversationIdMax?: number;

  /** Filtre conversationId strictement supérieur à cette valeur */
  conversationIdGreaterThan?: number;

  /** Filtre conversationId strictement inférieur à cette valeur */
  conversationIdLessThan?: number;

  /** Filtre conversationId différent de cette valeur */
  conversationIdIsDifferent?: number;

  /** Filtre par valeur exacte de senderId */
  senderId?: number;
  /** Filtre IsNull sur senderId (true = IS NULL, false = IS NOT NULL) */
  senderIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour senderId (IN) */
  senderIds?: number[];
  /** Filtre senderId différent de toutes ces valeurs (NOT IN) */
  senderIdIsDifferentList?: number[];

  /** Filtre senderId supérieur ou égal à cette valeur */
  senderIdMin?: number;

  /** Filtre senderId inférieur ou égal à cette valeur */
  senderIdMax?: number;

  /** Filtre senderId strictement supérieur à cette valeur */
  senderIdGreaterThan?: number;

  /** Filtre senderId strictement inférieur à cette valeur */
  senderIdLessThan?: number;

  /** Filtre senderId différent de cette valeur */
  senderIdIsDifferent?: number;

  /** Filtre par valeur exacte de content */
  content?: string;
  /** Filtre IsNull sur content (true = IS NULL, false = IS NOT NULL) */
  contentIsNull?: boolean;
  /** Filtre content différent de cette valeur (NOT EQUAL) */
  contentIsDifferent?: string;
  /** Filtre par liste de valeurs pour content (IN) */
  contents?: string[];
  /** Filtre content différent de toutes ces valeurs (NOT IN) */
  contentIsDifferentList?: string[];

  /** Filtre content contenant cette valeur (LIKE %value%) */
  contentLike?: string;

  /** Filtre content commençant par cette valeur (LIKE value%) */
  contentStartsWith?: string;

  /** Filtre content terminant par cette valeur (LIKE %value) */
  contentEndsWith?: string;

  /** Filtre content ne contenant pas cette valeur (NOT LIKE %value%) */
  contentIsDifferentLike?: string;

  /** Filtre par valeur exacte de readAt */
  readAt?: Date | string;
  /** Filtre IsNull sur readAt (true = IS NULL, false = IS NOT NULL) */
  readAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour readAt (IN) */
  readAts?: Date | string[];
  /** Filtre readAt différent de toutes ces valeurs (NOT IN) */
  readAtIsDifferentList?: Date | string[];

  /** Filtre readAt à partir de cette date (incluse) */
  readAtFrom?: Date | string;

  /** Filtre readAt jusqu'à cette date (incluse) */
  readAtTo?: Date | string;

  /** Filtre readAt strictement après cette date */
  readAtAfter?: Date | string;

  /** Filtre readAt strictement avant cette date */
  readAtBefore?: Date | string;

  /** Filtre readAt différent de cette date */
  readAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où conversation est NULL).
   * false = INNER JOIN.
   * À configurer AVANT conversation.
   */
  includeConversationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation conversation. */
  conversation?: ConversationsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où sender est NULL).
   * false = INNER JOIN.
   * À configurer AVANT sender.
   */
  includeSenderEmpty?: boolean;

  /** Filtre imbriqué sur la navigation sender. */
  sender?: UsersCritereDTO;

}
