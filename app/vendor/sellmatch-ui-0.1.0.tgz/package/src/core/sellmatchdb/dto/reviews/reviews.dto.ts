/**
 * DTO for table: reviews
 * Auto-generated - Do not modify manually
 */

import type { UsersDTO } from '../users/users.dto';

export interface ReviewsDTO {
  /** Primary Key */
  id?: number;
  selectionId?: number;
  reviewerId?: number;
  reviewedId?: number;
  reviewerType?: string;
  rating?: number;
  comment?: string;
  isPublished?: boolean;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  reviewed?: UsersDTO;
  /** Navigation property vers Users */
  reviewer?: UsersDTO;
}
