/**
 * Validator TypeScript pour OpportunitiesDTO.
 * Équivalent frontend du validator FluentValidation côté backend.
 * PROTECTEDFILE
 */

import type { OpportunitiesDTO } from './opportunities.dto';

/**
 * Interface d'une règle de validation pour un champ de OpportunitiesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface OpportunitiesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof OpportunitiesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null. */
  Validate: (pValue: unknown, pRow: OpportunitiesDTO) => string | null;
}

/**
 * Règles de validation pour OpportunitiesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const OpportunitiesValidator: Record<string, OpportunitiesFieldRule> = {
  // - cm - referenceCode : optionnel, longueur max 20
  referenceCode: {
    Key: 'referenceCode',
    Validate: (pValue: unknown, _pRow: OpportunitiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 20) {
        return 'referenceCode ne doit pas dépasser 20 caractères.';
      }
      return null;
    }
  },

  // - cm - propertyType : obligatoire, longueur max 50
  propertyType: {
    Key: 'propertyType',
    Validate: (pValue: unknown, _pRow: OpportunitiesDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'propertyType est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'propertyType ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - priceRangeMin : optionnel, valeur max alignée sur numeric(15,2)
  priceRangeMin: {
    Key: 'priceRangeMin',
    Validate: (pValue: unknown, _pRow: OpportunitiesDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return null;
      }
      const lNum: number = Number(pValue);
      if (isNaN(lNum)) {
        return 'priceRangeMin doit être un nombre valide.';
      }
      if (lNum < 0) {
        return 'priceRangeMin doit être positif.';
      }
      if (lNum > 9999999999999.99) {
        return 'priceRangeMin dépasse la valeur maximale autorisée.';
      }
      return null;
    }
  },

  // - cm - priceRangeMax : optionnel, valeur max alignée sur numeric(15,2)
  priceRangeMax: {
    Key: 'priceRangeMax',
    Validate: (pValue: unknown, _pRow: OpportunitiesDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return null;
      }
      const lNum: number = Number(pValue);
      if (isNaN(lNum)) {
        return 'priceRangeMax doit être un nombre valide.';
      }
      if (lNum < 0) {
        return 'priceRangeMax doit être positif.';
      }
      if (lNum > 9999999999999.99) {
        return 'priceRangeMax dépasse la valeur maximale autorisée.';
      }
      return null;
    }
  },

  // - cm - isPrio : obligatoire
  isPrio: {
    Key: 'isPrio',
    Validate: (pValue: unknown, _pRow: OpportunitiesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'isPrio est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de OpportunitiesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetOpportunitiesFieldValidator(pKey: string): ((pValue: unknown, pRow: OpportunitiesDTO) => string | null) | null {
  const lRule: OpportunitiesFieldRule | undefined = OpportunitiesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
