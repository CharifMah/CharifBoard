import { BaseCritereDTO } from '../../../../core/base/base.critere';

export interface GeographicZonesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;
  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;
  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;
  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre par valeur exacte de code */
  code?: string;
  /** Filtre par liste de valeurs pour code (IN) */
  codes?: string[];

  /** Filtre code contenant cette valeur (LIKE %value%) */
  codeContains?: string;
  /** Filtre code commençant par cette valeur (LIKE value%) */
  codeStartsWith?: string;
  /** Filtre code terminant par cette valeur (LIKE %value) */
  codeEndsWith?: string;

  /** Filtre par valeur exacte de name */
  name?: string;
  /** Filtre par liste de valeurs pour name (IN) */
  names?: string[];

  /** Filtre name contenant cette valeur (LIKE %value%) */
  nameContains?: string;
  /** Filtre name commençant par cette valeur (LIKE value%) */
  nameStartsWith?: string;
  /** Filtre name terminant par cette valeur (LIKE %value) */
  nameEndsWith?: string;

  /** Filtre par valeur exacte de zoneType */
  zoneType?: string;
  /** Filtre par liste de valeurs pour zoneType (IN) */
  zoneTypes?: string[];

  /** Filtre zoneType contenant cette valeur (LIKE %value%) */
  zoneTypeContains?: string;
  /** Filtre zoneType commençant par cette valeur (LIKE value%) */
  zoneTypeStartsWith?: string;
  /** Filtre zoneType terminant par cette valeur (LIKE %value) */
  zoneTypeEndsWith?: string;

  /** Filtre par valeur exacte de parentId */
  parentId?: number;
  /** Filtre par liste de valeurs pour parentId (IN) */
  parentIds?: number[];

  /** Filtre parentId supérieur ou égal à cette valeur */
  parentIdMin?: number;
  /** Filtre parentId inférieur ou égal à cette valeur */
  parentIdMax?: number;
  /** Filtre parentId strictement supérieur à cette valeur */
  parentIdGreaterThan?: number;
  /** Filtre parentId strictement inférieur à cette valeur */
  parentIdLessThan?: number;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;
  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;
  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;
  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

}
