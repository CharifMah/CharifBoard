/**
 * DTO for table: adresses
 * Auto-generated - Do not modify manually
 */

import * as GeoJSON from 'geojson';
import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';
import type { UsersDTO } from '../users/users.dto';

export interface AdressesDTO {
  /** Primary Key */
  id?: number;
  label?: string;
  housenumber?: string;
  street?: string;
  postcode?: string;
  city?: string;
  citycode?: string;
  context?: string;
  departmentCode?: string;
  regionCode?: string;
  type?: string;
  importance?: number;
  longitude?: number;
  latitude?: number;
  geom?: GeoJSON.Geometry;
  sourceApi?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  country?: string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Opportunities */
  opportunities?: OpportunitiesDTO[];
  /** Collection de Users */
  users?: UsersDTO[];
}
