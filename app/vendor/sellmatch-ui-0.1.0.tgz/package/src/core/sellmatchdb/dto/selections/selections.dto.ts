/**
 * DTO for table: selections
 * Auto-generated - Do not modify manually
 */

import type { ApplicationsDTO } from '../applications/applications.dto';
import type { ConversationsDTO } from '../conversations/conversations.dto';
import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';
import type { ReviewsDTO } from '../reviews/reviews.dto';
import type { UsersDTO } from '../users/users.dto';

export interface SelectionsDTO {
  /** Primary Key */
  id?: number;
  opportunityId?: number;
  applicationId?: number;
  professionalId?: number;
  vendorId?: number;
  anonymityLiftedAt?: Date | string;
  vendorContactShared?: boolean;
  professionalContactShared?: boolean;
  status?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  application?: ApplicationsDTO;
  opportunity?: OpportunitiesDTO;
  professional?: UsersDTO;
  vendor?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  conversations?: ConversationsDTO[];
  reviews?: ReviewsDTO[];
}
