import { FilterSchemaField } from '../../../../shared/components/FilterBar/filter-bar.component';
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { OpportunitiesCritereDTO } from '../../../../core/sellmatchdb/dto/opportunities/opportunities.critere';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';

//#region FilterSchema
/**
 * Schéma de la barre de filtres pour les opportunités.
 * Utilisé par OpportunitiesComponent et DossiersComponent.
 * Les champs plats sont transformés en structure imbriquée via MapFlatFilterToOpportunitiesCritere().
 */
export const OPPORTUNITY_FILTER_SCHEMA: Record<string, FilterSchemaField> = {
  propertyType: {
    Value: '',
    Label: 'Type de bien',
    Type: 'select',
    Options: [
      { Label: 'Maison', Value: 'Maison' },
      { Label: 'Appartement', Value: 'Appartement' },
      { Label: 'Terrain', Value: 'Terrain' }
    ]
  },
  surfaceMin: { Value: null, Label: 'Surface min', Type: 'number', Placeholder: 'm²' },
  surfaceMax: { Value: null, Label: 'Surface max', Type: 'number', Placeholder: 'm²' },
  priceRangeMinMax: { Value: null, Label: 'Budget min', Type: 'number', Placeholder: '€' },
  priceRangeMaxMax: { Value: null, Label: 'Budget max', Type: 'number', Placeholder: '€' },
  isPrio: { Value: false, Label: 'Prioritaire', Type: 'checkbox' },
  addressPostcodeLike: { Value: '', Label: 'Code postal', Type: 'text', Placeholder: 'Ex: 75001' },
  addressDepartmentCodeLike: { Value: '', Label: 'Département', Type: 'text', Placeholder: 'Ex: 75' },
  addressCityLike: { Value: '', Label: 'Ville', Type: 'text', Placeholder: 'Ex: Paris' },
  sort: {
    Value: 'createdAt',
    Label: 'Trier par',
    Type: 'select',
    Options: [
      { Label: 'Date création', Value: 'createdAt' },
      { Label: 'Prix', Value: 'priceRangeMin' },
      { Label: 'Surface', Value: 'surface' }
    ]
  },
  sortDirection: {
    Value: 'desc',
    Label: 'Ordre',
    Type: 'select',
    Options: [
      { Label: 'Descendant', Value: 'desc' },
      { Label: 'Ascendant', Value: 'asc' }
    ]
  }
};
//#endregion

//#region FilterMapping
/**
 * Transforme les filtres plats de la FilterBar en structure imbriquée OpportunitiesCritereDTO.
 * Gère l'extraction des champs adresse et la construction du critère final.
 * @param pCritere Critères plats reçus de la FilterBar
 * @returns Critère structuré pour l'API
 */
export function MapFlatFilterToOpportunitiesCritere(pCritere: BaseCritereDTO): OpportunitiesCritereDTO
{
  const lRecord: Record<string, unknown> = pCritere as Record<string, unknown>;

  // - cm - Extraction des champs adresse pour imbrication
  const lAddress: AdressesCritereDTO = {};
  const lPostcodeLike: unknown = lRecord['addressPostcodeLike'];
  const lDepartmentCodeLike: unknown = lRecord['addressDepartmentCodeLike'];
  const lCityLike: unknown = lRecord['addressCityLike'];

  if (typeof lPostcodeLike === 'string' && lPostcodeLike.trim()) { lAddress.postcodeLike = lPostcodeLike; }
  if (typeof lDepartmentCodeLike === 'string' && lDepartmentCodeLike.trim()) { lAddress.departmentCodeLike = lDepartmentCodeLike; }
  if (typeof lCityLike === 'string' && lCityLike.trim()) { lAddress.cityLike = lCityLike; }

  // - cm - Construction du critère final avec imbrication adresse
  const lFilter: OpportunitiesCritereDTO = {
    propertyType: typeof lRecord['propertyType'] === 'string' && (lRecord['propertyType'] as string).trim()
      ? lRecord['propertyType'] as string
      : undefined,
    surfaceMin: typeof lRecord['surfaceMin'] === 'number' ? lRecord['surfaceMin'] as number : undefined,
    surfaceMax: typeof lRecord['surfaceMax'] === 'number' ? lRecord['surfaceMax'] as number : undefined,
    priceRangeMinMax: typeof lRecord['priceRangeMinMax'] === 'number' ? lRecord['priceRangeMinMax'] as number : undefined,
    priceRangeMaxMax: typeof lRecord['priceRangeMaxMax'] === 'number' ? lRecord['priceRangeMaxMax'] as number : undefined,
    isPrio: lRecord['isPrio'] === true ? true : undefined,
    sort: typeof lRecord['sort'] === 'string' ? lRecord['sort'] as string : 'createdAt',
    sortDirection: typeof lRecord['sortDirection'] === 'string' ? lRecord['sortDirection'] as 'desc' | 'asc' : 'desc' as const,
    address: Object.keys(lAddress).length > 0 ? lAddress : undefined
  };

  return lFilter;
}
//#endregion