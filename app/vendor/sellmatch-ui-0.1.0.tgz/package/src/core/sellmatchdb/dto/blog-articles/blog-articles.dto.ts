/**
 * DTO for table: blog_articles
 * Auto-generated - Do not modify manually
 */

import type { BlogArticleVersionsDTO } from '../blog-article-versions/blog-article-versions.dto';
import type { UsersDTO } from '../users/users.dto';

export interface BlogArticlesDTO {
  /** Primary Key */
  id?: number;
  title?: string;
  slug?: string;
  metaDescription?: string;
  content?: string;
  excerpt?: string;
  category?: string;
  tags?: string;
  coverImage?: string;
  ogImage?: string;
  readingTimeMinutes?: number;
  isPublished?: boolean;
  isFeatured?: boolean;
  publishedAt?: Date | string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  authorId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  author?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de BlogArticleVersions */
  blogArticleVersions?: BlogArticleVersionsDTO[];
}
