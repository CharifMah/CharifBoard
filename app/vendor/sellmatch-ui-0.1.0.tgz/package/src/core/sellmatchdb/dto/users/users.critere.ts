import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ApplicationsCritereDTO } from '../applications/applications.critere';
import { MessagesCritereDTO } from '../messages/messages.critere';
import { NotificationsCritereDTO } from '../notifications/notifications.critere';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';
import { ReviewsCritereDTO } from '../reviews/reviews.critere';
import { RolesCritereDTO } from '../roles/roles.critere';
import { SettingsCritereDTO } from '../settings/settings.critere';
///PROTECTEDFILE
export interface UsersCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;
  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;
  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;
  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre par valeur exacte de roleId */
  roleId?: number;
  /** Filtre par liste de valeurs pour roleId (IN) */
  roleIds?: number[];

  /** Filtre roleId supérieur ou égal à cette valeur */
  roleIdMin?: number;
  /** Filtre roleId inférieur ou égal à cette valeur */
  roleIdMax?: number;
  /** Filtre roleId strictement supérieur à cette valeur */
  roleIdGreaterThan?: number;
  /** Filtre roleId strictement inférieur à cette valeur */
  roleIdLessThan?: number;

  /** Filtre par valeur exacte de email */
  email?: string;
  /** Filtre par liste de valeurs pour email (IN) */
  emails?: string[];

  /** Filtre email contenant cette valeur (LIKE %value%) */
  emailLike?: string;
  /** Filtre email commençant par cette valeur (LIKE value%) */
  emailStartsWith?: string;
  /** Filtre email terminant par cette valeur (LIKE %value) */
  emailEndsWith?: string;

  /** Filtre par valeur exacte de username */
  username?: string;
  /** Filtre par liste de valeurs pour username (IN) */
  usernames?: string[];

  /** Filtre username contenant cette valeur (LIKE %value%) */
  usernameLike?: string;
  /** Filtre username commençant par cette valeur (LIKE value%) */
  usernameStartsWith?: string;
  /** Filtre username terminant par cette valeur (LIKE %value) */
  usernameEndsWith?: string;

  /** Filtre par valeur exacte de firstName */
  firstName?: string;
  /** Filtre par liste de valeurs pour firstName (IN) */
  firstNames?: string[];

  /** Filtre firstName contenant cette valeur (LIKE %value%) */
  firstNameLike?: string;
  /** Filtre firstName commençant par cette valeur (LIKE value%) */
  firstNameStartsWith?: string;
  /** Filtre firstName terminant par cette valeur (LIKE %value) */
  firstNameEndsWith?: string;

  /** Filtre par valeur exacte de lastName */
  lastName?: string;
  /** Filtre par liste de valeurs pour lastName (IN) */
  lastNames?: string[];

  /** Filtre lastName contenant cette valeur (LIKE %value%) */
  lastNameLike?: string;
  /** Filtre lastName commençant par cette valeur (LIKE value%) */
  lastNameStartsWith?: string;
  /** Filtre lastName terminant par cette valeur (LIKE %value) */
  lastNameEndsWith?: string;

  /** Filtre par valeur exacte de phone */
  phone?: string;
  /** Filtre par liste de valeurs pour phone (IN) */
  phones?: string[];

  /** Filtre phone contenant cette valeur (LIKE %value%) */
  phoneLike?: string;
  /** Filtre phone commençant par cette valeur (LIKE value%) */
  phoneStartsWith?: string;
  /** Filtre phone terminant par cette valeur (LIKE %value) */
  phoneEndsWith?: string;

  /** Filtre par valeur exacte de avatarUrl */
  avatarUrl?: string;
  /** Filtre par liste de valeurs pour avatarUrl (IN) */
  avatarUrls?: string[];

  /** Filtre avatarUrl contenant cette valeur (LIKE %value%) */
  avatarUrlLike?: string;
  /** Filtre avatarUrl commençant par cette valeur (LIKE value%) */
  avatarUrlStartsWith?: string;
  /** Filtre avatarUrl terminant par cette valeur (LIKE %value) */
  avatarUrlEndsWith?: string;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];

  /** Filtre par valeur exacte de isVerified */
  isVerified?: boolean;
  /** Filtre par liste de valeurs pour isVerified (IN) */
  isVerifieds?: boolean[];

  /** Filtre par valeur exacte de emailVerifiedAt */
  emailVerifiedAt?: Date | string;
  /** Filtre par liste de valeurs pour emailVerifiedAt (IN) */
  emailVerifiedAts?: Date | string[];

  /** Filtre emailVerifiedAt à partir de cette date (incluse) */
  emailVerifiedAtFrom?: Date | string;
  /** Filtre emailVerifiedAt jusqu'à cette date (incluse) */
  emailVerifiedAtTo?: Date | string;
  /** Filtre emailVerifiedAt strictement après cette date */
  emailVerifiedAtAfter?: Date | string;
  /** Filtre emailVerifiedAt strictement avant cette date */
  emailVerifiedAtBefore?: Date | string;

  /** Filtre par valeur exacte de lastLoginAt */
  lastLoginAt?: Date | string;
  /** Filtre par liste de valeurs pour lastLoginAt (IN) */
  lastLoginAts?: Date | string[];

  /** Filtre lastLoginAt à partir de cette date (incluse) */
  lastLoginAtFrom?: Date | string;
  /** Filtre lastLoginAt jusqu'à cette date (incluse) */
  lastLoginAtTo?: Date | string;
  /** Filtre lastLoginAt strictement après cette date */
  lastLoginAtAfter?: Date | string;
  /** Filtre lastLoginAt strictement avant cette date */
  lastLoginAtBefore?: Date | string;

  /** Filtre par valeur exacte de failedLoginAttempts */
  failedLoginAttempts?: number;
  /** Filtre par liste de valeurs pour failedLoginAttempts (IN) */
  failedLoginAttemptss?: number[];

  /** Filtre failedLoginAttempts supérieur ou égal à cette valeur */
  failedLoginAttemptsMin?: number;
  /** Filtre failedLoginAttempts inférieur ou égal à cette valeur */
  failedLoginAttemptsMax?: number;
  /** Filtre failedLoginAttempts strictement supérieur à cette valeur */
  failedLoginAttemptsGreaterThan?: number;
  /** Filtre failedLoginAttempts strictement inférieur à cette valeur */
  failedLoginAttemptsLessThan?: number;

  /** Filtre par valeur exacte de lockedUntil */
  lockedUntil?: Date | string;
  /** Filtre par liste de valeurs pour lockedUntil (IN) */
  lockedUntils?: Date | string[];

  /** Filtre lockedUntil à partir de cette date (incluse) */
  lockedUntilFrom?: Date | string;
  /** Filtre lockedUntil jusqu'à cette date (incluse) */
  lockedUntilTo?: Date | string;
  /** Filtre lockedUntil strictement après cette date */
  lockedUntilAfter?: Date | string;
  /** Filtre lockedUntil strictement avant cette date */
  lockedUntilBefore?: Date | string;

  /** Filtre par valeur exacte de siret */
  siret?: string;
  /** Filtre par liste de valeurs pour siret (IN) */
  sirets?: string[];

  /** Filtre siret contenant cette valeur (LIKE %value%) */
  siretLike?: string;
  /** Filtre siret commençant par cette valeur (LIKE value%) */
  siretStartsWith?: string;
  /** Filtre siret terminant par cette valeur (LIKE %value) */
  siretEndsWith?: string;

  /** Filtre par valeur exacte de companyName */
  companyName?: string;
  /** Filtre par liste de valeurs pour companyName (IN) */
  companyNames?: string[];

  /** Filtre companyName contenant cette valeur (LIKE %value%) */
  companyNameLike?: string;
  /** Filtre companyName commençant par cette valeur (LIKE value%) */
  companyNameStartsWith?: string;
  /** Filtre companyName terminant par cette valeur (LIKE %value) */
  companyNameEndsWith?: string;

  /** Filtre par valeur exacte de address */
  address?: string;
  /** Filtre par liste de valeurs pour address (IN) */
  addresss?: string[];

  /** Filtre address contenant cette valeur (LIKE %value%) */
  addressLike?: string;
  /** Filtre address commençant par cette valeur (LIKE value%) */
  addressStartsWith?: string;
  /** Filtre address terminant par cette valeur (LIKE %value) */
  addressEndsWith?: string;

  /** Filtre par valeur exacte de city */
  city?: string;
  /** Filtre par liste de valeurs pour city (IN) */
  citys?: string[];

  /** Filtre city contenant cette valeur (LIKE %value%) */
  cityLike?: string;
  /** Filtre city commençant par cette valeur (LIKE value%) */
  cityStartsWith?: string;
  /** Filtre city terminant par cette valeur (LIKE %value) */
  cityEndsWith?: string;

  /** Filtre par valeur exacte de postalCode */
  postalCode?: string;
  /** Filtre par liste de valeurs pour postalCode (IN) */
  postalCodes?: string[];

  /** Filtre postalCode contenant cette valeur (LIKE %value%) */
  postalCodeLike?: string;
  /** Filtre postalCode commençant par cette valeur (LIKE value%) */
  postalCodeStartsWith?: string;
  /** Filtre postalCode terminant par cette valeur (LIKE %value) */
  postalCodeEndsWith?: string;

  /** Filtre par valeur exacte de country */
  country?: string;
  /** Filtre par liste de valeurs pour country (IN) */
  countrys?: string[];

  /** Filtre country contenant cette valeur (LIKE %value%) */
  countryLike?: string;
  /** Filtre country commençant par cette valeur (LIKE value%) */
  countryStartsWith?: string;
  /** Filtre country terminant par cette valeur (LIKE %value) */
  countryEndsWith?: string;

  /** Filtre par valeur exacte de bio */
  bio?: string;
  /** Filtre par liste de valeurs pour bio (IN) */
  bios?: string[];

  /** Filtre bio contenant cette valeur (LIKE %value%) */
  bioLike?: string;
  /** Filtre bio commençant par cette valeur (LIKE value%) */
  bioStartsWith?: string;
  /** Filtre bio terminant par cette valeur (LIKE %value) */
  bioEndsWith?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;
  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;
  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;
  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;
  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;
  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;
  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre par valeur exacte de immodvisorApiKey */
  immodvisorApiKey?: string;
  /** Filtre par liste de valeurs pour immodvisorApiKey (IN) */
  immodvisorApiKeys?: string[];

  /** Filtre immodvisorApiKey contenant cette valeur (LIKE %value%) */
  immodvisorApiKeyLike?: string;
  /** Filtre immodvisorApiKey commençant par cette valeur (LIKE value%) */
  immodvisorApiKeyStartsWith?: string;
  /** Filtre immodvisorApiKey terminant par cette valeur (LIKE %value) */
  immodvisorApiKeyEndsWith?: string;

  /** Filtre par valeur exacte de immodvisorCid */
  immodvisorCid?: number;
  /** Filtre par liste de valeurs pour immodvisorCid (IN) */
  immodvisorCids?: number[];

  /** Filtre immodvisorCid supérieur ou égal à cette valeur */
  immodvisorCidMin?: number;
  /** Filtre immodvisorCid inférieur ou égal à cette valeur */
  immodvisorCidMax?: number;
  /** Filtre immodvisorCid strictement supérieur à cette valeur */
  immodvisorCidGreaterThan?: number;
  /** Filtre immodvisorCid strictement inférieur à cette valeur */
  immodvisorCidLessThan?: number;

  // Filtres imbriqués (Many-to-One)
  /** Filtre imbriqué sur role */
  role?: RolesCritereDTO;

  /** Filtre imbriqué sur applications */
  applications?: ApplicationsCritereDTO;

  /** Filtre imbriqué sur messages */
  messages?: MessagesCritereDTO;

  /** Filtre imbriqué sur notifications */
  notifications?: NotificationsCritereDTO;

  /** Filtre imbriqué sur opportunities */
  opportunities?: OpportunitiesCritereDTO;

  /** Filtre imbriqué sur reviewedReviews */
  reviewedReviews?: ReviewsCritereDTO;

  /** Filtre imbriqué sur reviewerReviews */
  reviewerReviews?: ReviewsCritereDTO;

  /** Filtre imbriqué sur settings */
  settings?: SettingsCritereDTO;

  /** Filtre par valeur exacte de profilUrl */
  profilUrl?: string;
  /** Filtre par liste de valeurs pour profilUrl (IN) */
  profilUrls?: string[];

  /** Filtre profilUrl contenant cette valeur (LIKE %value%) */
  profilUrlLike?: string;
  /** Filtre profilUrl commençant par cette valeur (LIKE value%) */
  profilUrlStartsWith?: string;
  /** Filtre profilUrl terminant par cette valeur (LIKE %value) */
  profilUrlEndsWith?: string;

}
