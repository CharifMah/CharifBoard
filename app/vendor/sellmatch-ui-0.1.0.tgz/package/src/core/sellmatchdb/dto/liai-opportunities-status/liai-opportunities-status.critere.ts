import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';

export interface LiaiOpportunitiesStatusCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de status */
  status?: string;
  /** Filtre IsNull sur status (true = IS NULL, false = IS NOT NULL) */
  statusIsNull?: boolean;
  /** Filtre status différent de cette valeur (NOT EQUAL) */
  statusIsDifferent?: string;
  /** Filtre par liste de valeurs pour status (IN) */
  statuss?: string[];
  /** Filtre status différent de toutes ces valeurs (NOT IN) */
  statusIsDifferentList?: string[];

  /** Filtre status contenant cette valeur (LIKE %value%) */
  statusLike?: string;

  /** Filtre status commençant par cette valeur (LIKE value%) */
  statusStartsWith?: string;

  /** Filtre status terminant par cette valeur (LIKE %value) */
  statusEndsWith?: string;

  /** Filtre status ne contenant pas cette valeur (NOT LIKE %value%) */
  statusIsDifferentLike?: string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur opportunities.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT opportunities.
   */
  opportunitiesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont opportunities est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT opportunities.
   */
  includeOpportunitiesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour opportunities.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT opportunities.
   */
  opportunitiesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection opportunities. */
  opportunities?: OpportunitiesCritereDTO;

}
