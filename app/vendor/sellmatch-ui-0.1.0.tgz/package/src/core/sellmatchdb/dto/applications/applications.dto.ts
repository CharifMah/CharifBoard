/**
 * DTO for table: applications
 * Auto-generated - Do not modify manually
 */

import type { ApplicationServicesDTO } from '../application-services/application-services.dto';
import type { OpportunitiesDTO } from '../opportunities/opportunities.dto';
import type { UsersDTO } from '../users/users.dto';

export interface ApplicationsDTO {
  /** Primary Key */
  id?: number;
  opportunityId?: number;
  professionalId?: number;
  presentation?: string;
  methodology?: string;
  estimatedTimeline?: string;
  feeType?: string;
  feePercentage?: number;
  feeFixedAmount?: number;
  message?: string;
  status?: string;
  viewedAt?: Date | string;
  shortlistedAt?: Date | string;
  selectedAt?: Date | string;
  rejectedAt?: Date | string;
  rejectionReason?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Opportunities */
  opportunity?: OpportunitiesDTO;
  /** Navigation property vers Users */
  professional?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de ApplicationServices */
  applicationServices?: ApplicationServicesDTO[];
}
