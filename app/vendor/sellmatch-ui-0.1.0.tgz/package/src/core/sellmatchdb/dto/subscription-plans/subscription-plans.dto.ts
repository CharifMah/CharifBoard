/**
 * DTO for table: subscription_plans
 * Auto-generated - Do not modify manually
 */

import type { UserSubscriptionsDTO } from '../user-subscriptions/user-subscriptions.dto';

export interface SubscriptionPlansDTO {
  /** Primary Key */
  id?: number;
  key?: string;
  label?: string;
  description?: string;
  stripePriceIdMonthly?: string;
  stripePriceIdYearly?: string;
  stripePriceIdOneShot?: string;
  priceMonthlyHt?: number;
  priceYearlyHt?: number;
  priceOneShotTtc?: number;
  isOneShot?: boolean;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  logoUrl?: string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de UserSubscriptions */
  userSubscriptions?: UserSubscriptionsDTO[];
}
