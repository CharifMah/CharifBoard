/**
 * DTO for table: settings
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../base/BaseDTO';
import type { UsersDTO } from '../users/users.dto';

export interface SettingsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  key?: string;
  value?: string;
  valueType?: string;
  description?: string;
  isPublic?: boolean;
  updatedById?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  updatedByNavigation?: UsersDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
