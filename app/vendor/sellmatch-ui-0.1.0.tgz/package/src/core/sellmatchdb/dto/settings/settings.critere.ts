import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface SettingsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de key */
  key?: string;
  /** Filtre IsNull sur key (true = IS NULL, false = IS NOT NULL) */
  keyIsNull?: boolean;
  /** Filtre key différent de cette valeur (NOT EQUAL) */
  keyIsDifferent?: string;
  /** Filtre par liste de valeurs pour key (IN) */
  keys?: string[];
  /** Filtre key différent de toutes ces valeurs (NOT IN) */
  keyIsDifferentList?: string[];

  /** Filtre key contenant cette valeur (LIKE %value%) */
  keyLike?: string;

  /** Filtre key commençant par cette valeur (LIKE value%) */
  keyStartsWith?: string;

  /** Filtre key terminant par cette valeur (LIKE %value) */
  keyEndsWith?: string;

  /** Filtre key ne contenant pas cette valeur (NOT LIKE %value%) */
  keyIsDifferentLike?: string;

  /** Filtre par valeur exacte de value */
  value?: string;
  /** Filtre IsNull sur value (true = IS NULL, false = IS NOT NULL) */
  valueIsNull?: boolean;
  /** Filtre value différent de cette valeur (NOT EQUAL) */
  valueIsDifferent?: string;
  /** Filtre par liste de valeurs pour value (IN) */
  values?: string[];
  /** Filtre value différent de toutes ces valeurs (NOT IN) */
  valueIsDifferentList?: string[];

  /** Filtre value contenant cette valeur (LIKE %value%) */
  valueLike?: string;

  /** Filtre value commençant par cette valeur (LIKE value%) */
  valueStartsWith?: string;

  /** Filtre value terminant par cette valeur (LIKE %value) */
  valueEndsWith?: string;

  /** Filtre value ne contenant pas cette valeur (NOT LIKE %value%) */
  valueIsDifferentLike?: string;

  /** Filtre par valeur exacte de valueType */
  valueType?: string;
  /** Filtre IsNull sur valueType (true = IS NULL, false = IS NOT NULL) */
  valueTypeIsNull?: boolean;
  /** Filtre valueType différent de cette valeur (NOT EQUAL) */
  valueTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour valueType (IN) */
  valueTypes?: string[];
  /** Filtre valueType différent de toutes ces valeurs (NOT IN) */
  valueTypeIsDifferentList?: string[];

  /** Filtre valueType contenant cette valeur (LIKE %value%) */
  valueTypeLike?: string;

  /** Filtre valueType commençant par cette valeur (LIKE value%) */
  valueTypeStartsWith?: string;

  /** Filtre valueType terminant par cette valeur (LIKE %value) */
  valueTypeEndsWith?: string;

  /** Filtre valueType ne contenant pas cette valeur (NOT LIKE %value%) */
  valueTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de description */
  description?: string;
  /** Filtre IsNull sur description (true = IS NULL, false = IS NOT NULL) */
  descriptionIsNull?: boolean;
  /** Filtre description différent de cette valeur (NOT EQUAL) */
  descriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour description (IN) */
  descriptions?: string[];
  /** Filtre description différent de toutes ces valeurs (NOT IN) */
  descriptionIsDifferentList?: string[];

  /** Filtre description contenant cette valeur (LIKE %value%) */
  descriptionLike?: string;

  /** Filtre description commençant par cette valeur (LIKE value%) */
  descriptionStartsWith?: string;

  /** Filtre description terminant par cette valeur (LIKE %value) */
  descriptionEndsWith?: string;

  /** Filtre description ne contenant pas cette valeur (NOT LIKE %value%) */
  descriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de isPublic */
  isPublic?: boolean;
  /** Filtre IsNull sur isPublic (true = IS NULL, false = IS NOT NULL) */
  isPublicIsNull?: boolean;
  /** Filtre isPublic différent de cette valeur (NOT EQUAL) */
  isPublicIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isPublic (IN) */
  isPublics?: boolean[];
  /** Filtre isPublic différent de toutes ces valeurs (NOT IN) */
  isPublicIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de updatedById */
  updatedById?: number;
  /** Filtre IsNull sur updatedById (true = IS NULL, false = IS NOT NULL) */
  updatedByIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedById (IN) */
  updatedByIds?: number[];
  /** Filtre updatedById différent de toutes ces valeurs (NOT IN) */
  updatedByIdIsDifferentList?: number[];

  /** Filtre updatedById supérieur ou égal à cette valeur */
  updatedByIdMin?: number;

  /** Filtre updatedById inférieur ou égal à cette valeur */
  updatedByIdMax?: number;

  /** Filtre updatedById strictement supérieur à cette valeur */
  updatedByIdGreaterThan?: number;

  /** Filtre updatedById strictement inférieur à cette valeur */
  updatedByIdLessThan?: number;

  /** Filtre updatedById différent de cette valeur */
  updatedByIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre IsNull sur userId (true = IS NULL, false = IS NOT NULL) */
  userIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où updatedByNavigation est NULL).
   * false = INNER JOIN.
   * À configurer AVANT updatedByNavigation.
   */
  includeUpdatedbynavigationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation updatedByNavigation. */
  updatedByNavigation?: UsersCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
