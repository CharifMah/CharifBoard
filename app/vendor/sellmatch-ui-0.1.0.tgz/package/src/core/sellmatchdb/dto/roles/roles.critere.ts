import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { UsersCritereDTO } from '../users/users.critere';

export interface RolesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de name */
  name?: string;
  /** Filtre IsNull sur name (true = IS NULL, false = IS NOT NULL) */
  nameIsNull?: boolean;
  /** Filtre name différent de cette valeur (NOT EQUAL) */
  nameIsDifferent?: string;
  /** Filtre par liste de valeurs pour name (IN) */
  names?: string[];
  /** Filtre name différent de toutes ces valeurs (NOT IN) */
  nameIsDifferentList?: string[];

  /** Filtre name contenant cette valeur (LIKE %value%) */
  nameLike?: string;

  /** Filtre name commençant par cette valeur (LIKE value%) */
  nameStartsWith?: string;

  /** Filtre name terminant par cette valeur (LIKE %value) */
  nameEndsWith?: string;

  /** Filtre name ne contenant pas cette valeur (NOT LIKE %value%) */
  nameIsDifferentLike?: string;

  /** Filtre par valeur exacte de description */
  description?: string;
  /** Filtre IsNull sur description (true = IS NULL, false = IS NOT NULL) */
  descriptionIsNull?: boolean;
  /** Filtre description différent de cette valeur (NOT EQUAL) */
  descriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour description (IN) */
  descriptions?: string[];
  /** Filtre description différent de toutes ces valeurs (NOT IN) */
  descriptionIsDifferentList?: string[];

  /** Filtre description contenant cette valeur (LIKE %value%) */
  descriptionLike?: string;

  /** Filtre description commençant par cette valeur (LIKE value%) */
  descriptionStartsWith?: string;

  /** Filtre description terminant par cette valeur (LIKE %value) */
  descriptionEndsWith?: string;

  /** Filtre description ne contenant pas cette valeur (NOT LIKE %value%) */
  descriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur users.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT users.
   */
  usersFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont users est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT users.
   */
  includeUsersEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour users.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT users.
   */
  usersMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection users. */
  users?: UsersCritereDTO;

}
