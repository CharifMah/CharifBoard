import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ApplicationsCritereDTO } from '../applications/applications.critere';
import { AvailableServicesCritereDTO } from '../available-services/available-services.critere';

export interface ApplicationServicesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de applicationId */
  applicationId?: number;
  /** Filtre par liste de valeurs pour applicationId (IN) */
  applicationIds?: number[];
  /** Filtre applicationId différent de toutes ces valeurs (NOT IN) */
  applicationIdIsDifferentList?: number[];

  /** Filtre applicationId supérieur ou égal à cette valeur */
  applicationIdMin?: number;

  /** Filtre applicationId inférieur ou égal à cette valeur */
  applicationIdMax?: number;

  /** Filtre applicationId strictement supérieur à cette valeur */
  applicationIdGreaterThan?: number;

  /** Filtre applicationId strictement inférieur à cette valeur */
  applicationIdLessThan?: number;

  /** Filtre applicationId différent de cette valeur */
  applicationIdIsDifferent?: number;

  /** Filtre par valeur exacte de serviceId */
  serviceId?: number;
  /** Filtre par liste de valeurs pour serviceId (IN) */
  serviceIds?: number[];
  /** Filtre serviceId différent de toutes ces valeurs (NOT IN) */
  serviceIdIsDifferentList?: number[];

  /** Filtre serviceId supérieur ou égal à cette valeur */
  serviceIdMin?: number;

  /** Filtre serviceId inférieur ou égal à cette valeur */
  serviceIdMax?: number;

  /** Filtre serviceId strictement supérieur à cette valeur */
  serviceIdGreaterThan?: number;

  /** Filtre serviceId strictement inférieur à cette valeur */
  serviceIdLessThan?: number;

  /** Filtre serviceId différent de cette valeur */
  serviceIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où application est NULL).
   * false = INNER JOIN.
   * À configurer AVANT application.
   */
  includeApplicationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation application. */
  application?: ApplicationsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où service est NULL).
   * false = INNER JOIN.
   * À configurer AVANT service.
   */
  includeServiceEmpty?: boolean;

  /** Filtre imbriqué sur la navigation service. */
  service?: AvailableServicesCritereDTO;

}
