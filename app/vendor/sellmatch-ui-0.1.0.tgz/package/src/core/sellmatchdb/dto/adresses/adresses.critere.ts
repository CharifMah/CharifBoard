import { BaseCritereDTO } from '../../../../core/base/base.critere';
import * as GeoJSON from 'geojson';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { OpportunitiesCritereDTO } from '../opportunities/opportunities.critere';
import { UsersCritereDTO } from '../users/users.critere';

export interface AdressesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de label */
  label?: string;
  /** Filtre IsNull sur label (true = IS NULL, false = IS NOT NULL) */
  labelIsNull?: boolean;
  /** Filtre label différent de cette valeur (NOT EQUAL) */
  labelIsDifferent?: string;
  /** Filtre par liste de valeurs pour label (IN) */
  labels?: string[];
  /** Filtre label différent de toutes ces valeurs (NOT IN) */
  labelIsDifferentList?: string[];

  /** Filtre label contenant cette valeur (LIKE %value%) */
  labelLike?: string;

  /** Filtre label commençant par cette valeur (LIKE value%) */
  labelStartsWith?: string;

  /** Filtre label terminant par cette valeur (LIKE %value) */
  labelEndsWith?: string;

  /** Filtre label ne contenant pas cette valeur (NOT LIKE %value%) */
  labelIsDifferentLike?: string;

  /** Filtre par valeur exacte de housenumber */
  housenumber?: string;
  /** Filtre IsNull sur housenumber (true = IS NULL, false = IS NOT NULL) */
  housenumberIsNull?: boolean;
  /** Filtre housenumber différent de cette valeur (NOT EQUAL) */
  housenumberIsDifferent?: string;
  /** Filtre par liste de valeurs pour housenumber (IN) */
  housenumbers?: string[];
  /** Filtre housenumber différent de toutes ces valeurs (NOT IN) */
  housenumberIsDifferentList?: string[];

  /** Filtre housenumber contenant cette valeur (LIKE %value%) */
  housenumberLike?: string;

  /** Filtre housenumber commençant par cette valeur (LIKE value%) */
  housenumberStartsWith?: string;

  /** Filtre housenumber terminant par cette valeur (LIKE %value) */
  housenumberEndsWith?: string;

  /** Filtre housenumber ne contenant pas cette valeur (NOT LIKE %value%) */
  housenumberIsDifferentLike?: string;

  /** Filtre par valeur exacte de street */
  street?: string;
  /** Filtre IsNull sur street (true = IS NULL, false = IS NOT NULL) */
  streetIsNull?: boolean;
  /** Filtre street différent de cette valeur (NOT EQUAL) */
  streetIsDifferent?: string;
  /** Filtre par liste de valeurs pour street (IN) */
  streets?: string[];
  /** Filtre street différent de toutes ces valeurs (NOT IN) */
  streetIsDifferentList?: string[];

  /** Filtre street contenant cette valeur (LIKE %value%) */
  streetLike?: string;

  /** Filtre street commençant par cette valeur (LIKE value%) */
  streetStartsWith?: string;

  /** Filtre street terminant par cette valeur (LIKE %value) */
  streetEndsWith?: string;

  /** Filtre street ne contenant pas cette valeur (NOT LIKE %value%) */
  streetIsDifferentLike?: string;

  /** Filtre par valeur exacte de postcode */
  postcode?: string;
  /** Filtre IsNull sur postcode (true = IS NULL, false = IS NOT NULL) */
  postcodeIsNull?: boolean;
  /** Filtre postcode différent de cette valeur (NOT EQUAL) */
  postcodeIsDifferent?: string;
  /** Filtre par liste de valeurs pour postcode (IN) */
  postcodes?: string[];
  /** Filtre postcode différent de toutes ces valeurs (NOT IN) */
  postcodeIsDifferentList?: string[];

  /** Filtre postcode contenant cette valeur (LIKE %value%) */
  postcodeLike?: string;

  /** Filtre postcode commençant par cette valeur (LIKE value%) */
  postcodeStartsWith?: string;

  /** Filtre postcode terminant par cette valeur (LIKE %value) */
  postcodeEndsWith?: string;

  /** Filtre postcode ne contenant pas cette valeur (NOT LIKE %value%) */
  postcodeIsDifferentLike?: string;

  /** Filtre par valeur exacte de city */
  city?: string;
  /** Filtre IsNull sur city (true = IS NULL, false = IS NOT NULL) */
  cityIsNull?: boolean;
  /** Filtre city différent de cette valeur (NOT EQUAL) */
  cityIsDifferent?: string;
  /** Filtre par liste de valeurs pour city (IN) */
  citys?: string[];
  /** Filtre city différent de toutes ces valeurs (NOT IN) */
  cityIsDifferentList?: string[];

  /** Filtre city contenant cette valeur (LIKE %value%) */
  cityLike?: string;

  /** Filtre city commençant par cette valeur (LIKE value%) */
  cityStartsWith?: string;

  /** Filtre city terminant par cette valeur (LIKE %value) */
  cityEndsWith?: string;

  /** Filtre city ne contenant pas cette valeur (NOT LIKE %value%) */
  cityIsDifferentLike?: string;

  /** Filtre par valeur exacte de citycode */
  citycode?: string;
  /** Filtre IsNull sur citycode (true = IS NULL, false = IS NOT NULL) */
  citycodeIsNull?: boolean;
  /** Filtre citycode différent de cette valeur (NOT EQUAL) */
  citycodeIsDifferent?: string;
  /** Filtre par liste de valeurs pour citycode (IN) */
  citycodes?: string[];
  /** Filtre citycode différent de toutes ces valeurs (NOT IN) */
  citycodeIsDifferentList?: string[];

  /** Filtre citycode contenant cette valeur (LIKE %value%) */
  citycodeLike?: string;

  /** Filtre citycode commençant par cette valeur (LIKE value%) */
  citycodeStartsWith?: string;

  /** Filtre citycode terminant par cette valeur (LIKE %value) */
  citycodeEndsWith?: string;

  /** Filtre citycode ne contenant pas cette valeur (NOT LIKE %value%) */
  citycodeIsDifferentLike?: string;

  /** Filtre par valeur exacte de context */
  context?: string;
  /** Filtre IsNull sur context (true = IS NULL, false = IS NOT NULL) */
  contextIsNull?: boolean;
  /** Filtre context différent de cette valeur (NOT EQUAL) */
  contextIsDifferent?: string;
  /** Filtre par liste de valeurs pour context (IN) */
  contexts?: string[];
  /** Filtre context différent de toutes ces valeurs (NOT IN) */
  contextIsDifferentList?: string[];

  /** Filtre context contenant cette valeur (LIKE %value%) */
  contextLike?: string;

  /** Filtre context commençant par cette valeur (LIKE value%) */
  contextStartsWith?: string;

  /** Filtre context terminant par cette valeur (LIKE %value) */
  contextEndsWith?: string;

  /** Filtre context ne contenant pas cette valeur (NOT LIKE %value%) */
  contextIsDifferentLike?: string;

  /** Filtre par valeur exacte de departmentCode */
  departmentCode?: string;
  /** Filtre IsNull sur departmentCode (true = IS NULL, false = IS NOT NULL) */
  departmentCodeIsNull?: boolean;
  /** Filtre departmentCode différent de cette valeur (NOT EQUAL) */
  departmentCodeIsDifferent?: string;
  /** Filtre par liste de valeurs pour departmentCode (IN) */
  departmentCodes?: string[];
  /** Filtre departmentCode différent de toutes ces valeurs (NOT IN) */
  departmentCodeIsDifferentList?: string[];

  /** Filtre departmentCode contenant cette valeur (LIKE %value%) */
  departmentCodeLike?: string;

  /** Filtre departmentCode commençant par cette valeur (LIKE value%) */
  departmentCodeStartsWith?: string;

  /** Filtre departmentCode terminant par cette valeur (LIKE %value) */
  departmentCodeEndsWith?: string;

  /** Filtre departmentCode ne contenant pas cette valeur (NOT LIKE %value%) */
  departmentCodeIsDifferentLike?: string;

  /** Filtre par valeur exacte de regionCode */
  regionCode?: string;
  /** Filtre IsNull sur regionCode (true = IS NULL, false = IS NOT NULL) */
  regionCodeIsNull?: boolean;
  /** Filtre regionCode différent de cette valeur (NOT EQUAL) */
  regionCodeIsDifferent?: string;
  /** Filtre par liste de valeurs pour regionCode (IN) */
  regionCodes?: string[];
  /** Filtre regionCode différent de toutes ces valeurs (NOT IN) */
  regionCodeIsDifferentList?: string[];

  /** Filtre regionCode contenant cette valeur (LIKE %value%) */
  regionCodeLike?: string;

  /** Filtre regionCode commençant par cette valeur (LIKE value%) */
  regionCodeStartsWith?: string;

  /** Filtre regionCode terminant par cette valeur (LIKE %value) */
  regionCodeEndsWith?: string;

  /** Filtre regionCode ne contenant pas cette valeur (NOT LIKE %value%) */
  regionCodeIsDifferentLike?: string;

  /** Filtre par valeur exacte de type */
  type?: string;
  /** Filtre IsNull sur type (true = IS NULL, false = IS NOT NULL) */
  typeIsNull?: boolean;
  /** Filtre type différent de cette valeur (NOT EQUAL) */
  typeIsDifferent?: string;
  /** Filtre par liste de valeurs pour type (IN) */
  types?: string[];
  /** Filtre type différent de toutes ces valeurs (NOT IN) */
  typeIsDifferentList?: string[];

  /** Filtre type contenant cette valeur (LIKE %value%) */
  typeLike?: string;

  /** Filtre type commençant par cette valeur (LIKE value%) */
  typeStartsWith?: string;

  /** Filtre type terminant par cette valeur (LIKE %value) */
  typeEndsWith?: string;

  /** Filtre type ne contenant pas cette valeur (NOT LIKE %value%) */
  typeIsDifferentLike?: string;

  /** Filtre par valeur exacte de importance */
  importance?: number;
  /** Filtre IsNull sur importance (true = IS NULL, false = IS NOT NULL) */
  importanceIsNull?: boolean;
  /** Filtre par liste de valeurs pour importance (IN) */
  importances?: number[];
  /** Filtre importance différent de toutes ces valeurs (NOT IN) */
  importanceIsDifferentList?: number[];

  /** Filtre importance supérieur ou égal à cette valeur */
  importanceMin?: number;

  /** Filtre importance inférieur ou égal à cette valeur */
  importanceMax?: number;

  /** Filtre importance strictement supérieur à cette valeur */
  importanceGreaterThan?: number;

  /** Filtre importance strictement inférieur à cette valeur */
  importanceLessThan?: number;

  /** Filtre importance différent de cette valeur */
  importanceIsDifferent?: number;

  /** Filtre par valeur exacte de longitude */
  longitude?: number;
  /** Filtre IsNull sur longitude (true = IS NULL, false = IS NOT NULL) */
  longitudeIsNull?: boolean;
  /** Filtre par liste de valeurs pour longitude (IN) */
  longitudes?: number[];
  /** Filtre longitude différent de toutes ces valeurs (NOT IN) */
  longitudeIsDifferentList?: number[];

  /** Filtre longitude supérieur ou égal à cette valeur */
  longitudeMin?: number;

  /** Filtre longitude inférieur ou égal à cette valeur */
  longitudeMax?: number;

  /** Filtre longitude strictement supérieur à cette valeur */
  longitudeGreaterThan?: number;

  /** Filtre longitude strictement inférieur à cette valeur */
  longitudeLessThan?: number;

  /** Filtre longitude différent de cette valeur */
  longitudeIsDifferent?: number;

  /** Filtre par valeur exacte de latitude */
  latitude?: number;
  /** Filtre IsNull sur latitude (true = IS NULL, false = IS NOT NULL) */
  latitudeIsNull?: boolean;
  /** Filtre par liste de valeurs pour latitude (IN) */
  latitudes?: number[];
  /** Filtre latitude différent de toutes ces valeurs (NOT IN) */
  latitudeIsDifferentList?: number[];

  /** Filtre latitude supérieur ou égal à cette valeur */
  latitudeMin?: number;

  /** Filtre latitude inférieur ou égal à cette valeur */
  latitudeMax?: number;

  /** Filtre latitude strictement supérieur à cette valeur */
  latitudeGreaterThan?: number;

  /** Filtre latitude strictement inférieur à cette valeur */
  latitudeLessThan?: number;

  /** Filtre latitude différent de cette valeur */
  latitudeIsDifferent?: number;

  /** Filtre par valeur exacte de geom */
  geom?: GeoJSON.Geometry;
  /** Filtre IsNull sur geom (true = IS NULL, false = IS NOT NULL) */
  geomIsNull?: boolean;
  /** Filtre geom spatialement différent de cette valeur */
  geomIsDifferent?: GeoJSON.Geometry;

  /** Filtre geom intersectant cette géométrie */
  geomIntersects?: GeoJSON.Geometry;

  /** Filtre geom contenu dans cette géométrie */
  geomWithin?: GeoJSON.Geometry;

  /** Filtre par valeur exacte de sourceApi */
  sourceApi?: string;
  /** Filtre IsNull sur sourceApi (true = IS NULL, false = IS NOT NULL) */
  sourceApiIsNull?: boolean;
  /** Filtre sourceApi différent de cette valeur (NOT EQUAL) */
  sourceApiIsDifferent?: string;
  /** Filtre par liste de valeurs pour sourceApi (IN) */
  sourceApis?: string[];
  /** Filtre sourceApi différent de toutes ces valeurs (NOT IN) */
  sourceApiIsDifferentList?: string[];

  /** Filtre sourceApi contenant cette valeur (LIKE %value%) */
  sourceApiLike?: string;

  /** Filtre sourceApi commençant par cette valeur (LIKE value%) */
  sourceApiStartsWith?: string;

  /** Filtre sourceApi terminant par cette valeur (LIKE %value) */
  sourceApiEndsWith?: string;

  /** Filtre sourceApi ne contenant pas cette valeur (NOT LIKE %value%) */
  sourceApiIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de country */
  country?: string;
  /** Filtre IsNull sur country (true = IS NULL, false = IS NOT NULL) */
  countryIsNull?: boolean;
  /** Filtre country différent de cette valeur (NOT EQUAL) */
  countryIsDifferent?: string;
  /** Filtre par liste de valeurs pour country (IN) */
  countrys?: string[];
  /** Filtre country différent de toutes ces valeurs (NOT IN) */
  countryIsDifferentList?: string[];

  /** Filtre country contenant cette valeur (LIKE %value%) */
  countryLike?: string;

  /** Filtre country commençant par cette valeur (LIKE value%) */
  countryStartsWith?: string;

  /** Filtre country terminant par cette valeur (LIKE %value) */
  countryEndsWith?: string;

  /** Filtre country ne contenant pas cette valeur (NOT LIKE %value%) */
  countryIsDifferentLike?: string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur opportunities.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT opportunities.
   */
  opportunitiesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont opportunities est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT opportunities.
   */
  includeOpportunitiesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour opportunities.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT opportunities.
   */
  opportunitiesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection opportunities. */
  opportunities?: OpportunitiesCritereDTO;

  /**
   * Mode de filtrage de l'Include sur users.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT users.
   */
  usersFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont users est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT users.
   */
  includeUsersEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour users.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT users.
   */
  usersMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection users. */
  users?: UsersCritereDTO;

}
