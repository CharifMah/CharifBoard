export enum ECollectionMatch
{
  Any = 'Any',
  None = 'None',
  All = 'All'
}
