import { inject, ChangeDetectorRef, DestroyRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ROUTE_PATHS } from '../../routes/app.routes.constants';
import { SettingsService, UsersService } from '../../core/sellmatchdb/services';
import { RouteUtils } from '../../shared/utils/route-utils';
import { BusyService } from '../../core/services/busy/BusyService';
import { NavigationService } from '../../core/sellmatchdb/services/NavigationService/NavigationService';
import { environment } from '../../environments/environment';
import { SubscriptionPlansDTO, UsersDTO } from '../../core/sellmatchdb/dto';
import { SessionStorageService } from '../../core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { LocalStorageService } from '../../core/sellmatchdb/services/LocalStorage/LocalStorageService';
import { PostHogService } from '../../core/services/posthog/PostHogService';
import { TranslationService } from '../../core/services/i18n/TranslationService';


/**
 * Classe abstraite de base pour les composants angular
 *
 */
export abstract class BaseComponent
{

  //#region Properties
  /**
   * User Service 
   */
  protected UsersService: UsersService = inject(UsersService);

  /**
   * Utilitaire de navigation sur les routes
   */
  protected RouteUtils: RouteUtils = inject(RouteUtils);
  /**
   * Service pour le busy
   */
  protected BusyService: BusyService = inject(BusyService);
  /**
   * Service de navigation dans les vues
   */
  protected readonly Nav: NavigationService = inject(NavigationService);
  /**
   * Service de gestion du sessionStorage
   */
  protected readonly SessionStorage: SessionStorageService = inject(SessionStorageService);
  /**
   * Service de gestion du localStorage (persistant cross-session).
   */
  protected readonly LocalStorage: LocalStorageService = inject(LocalStorageService);
  /**
   * Serivce des settings du user
   */
  protected readonly SettingsService: SettingsService = inject(SettingsService);
  /**
   * Service PostHog pour le tracking et l'analytics
   */
  protected readonly PostHog: PostHogService = inject(PostHogService);
  /**
   * Service de traduction (i18n) basé sur ngx-translate
   */
  protected readonly Translate: TranslationService = inject(TranslationService);

  /**
   * Force le re-render du template dès que le dictionnaire de traductions est
   */
  constructor ()
  {
    // - cm - Injections locales : pas de champs de classe → pas de collision
    const lCdr: ChangeDetectorRef | null = inject(ChangeDetectorRef, { optional: true });
    const lDestroyRef: DestroyRef = inject(DestroyRef);

    // - cm - Si ChangeDetectorRef n'est pas disponible (sous-classe service),
    if (lCdr)
    {
      // - cm - Boot initial asynchrone : le JSON est chargé après le 1er render.
      this.Translate.TranslationLoaded.pipe(takeUntilDestroyed(lDestroyRef)).subscribe(() =>
      {
        lCdr.markForCheck();
      });
      // - cm - Changement explicite de langue via setLanguage()
      this.Translate.LanguageChanged.pipe(takeUntilDestroyed(lDestroyRef)).subscribe(() =>
      {
        lCdr.markForCheck();
      });
    }
  }

  /**
   * Nom automatique du composant courant (ex: "OutilEstimationComponent")
   * Utilisé par les composants enfants (bouton, etc.) pour le tracking PostHog
   */
  public get Name(): string
  {
    return this.constructor.name;
  }

  public ApiBaseUrl: string = environment.apiBaseUrl;

  /**
  * Les routes de navigation
  */
  protected Routes = ROUTE_PATHS;
  /**
   * La vue en cours EX: dossiers, messages, dashboard
   */
  public get View(): string
  {
    return this.Nav.View();
  }
  /**
   * Si l'utilisateur est connecter
   */
  get isLoggedIn(): boolean
  {
    return this.UsersService.isLoggedIn();
  }
  /**
   * Si l'utilisateur est un vendeur
   */
  get IsVendeur(): boolean
  {
    return this.UsersService.IsVendeur();
  }
  /**
   * Si l'utilisateur est un pro
   */
  get IsProfessionnel(): boolean
  {
    return this.UsersService.IsProfessionnel();
  }
  /**
 * Si l'utilisateur est un admin
 */
  get isAdmin(): boolean
  {
    return this.UsersService.isAdmin();
  }
  /**
   * Le role de l'utilisateur
   */
  get userRole(): string | null
  {
    return this.UsersService.getUserRole();
  }

  get CurrentUserId(): string | null
  {
    return this.UsersService.getUserId();
  }

  get userSubscription(): SubscriptionPlansDTO | null
  {
    return this.UsersService.getUserPlan();
  }

  //#endregion

  //#region Methods

  /**
 * Construit un nom d'événement PostHog standardisé.
 * Format : tracking_{nomParent}_{label}
 * @param pLabel Texte à transformer (ex: texte du bouton)
 * @param pPrefix Préfixe optionnel (défaut: 'tracking')
 * @returns Nom d'événement formaté (ex: tracking_outil_estimation_suivant)
 */
  public BuildTrackingName(pLabel: string, pPrefix: string = 'tracking'): string
  {
    const lParentName: string = this.Name
      .replace(/Component$/i, '')
      .replace(/([a-z])([A-Z])/g, '$1_$2')
      .toLowerCase();

    const lLabel: string = pLabel
      .toLowerCase()
      .replace(/[^a-z0-9\u00e0-\u00fc]+/g, '_')
      .replace(/^_|_$/g, '')
      .replace(/_+/g, '_');

    return `${pPrefix}_${lParentName}_${lLabel}`;
  }

  //#region CRUD brouillon — anti double POST

  /** Référence d'objet pour bloquer le re-déclenchement RowAdded → RowValidated. */
  private readonly _BrouillonTracker: WeakSet<object> = new WeakSet<object>();

  /** Handler unifié pour `(RowAdded)`. */
  public async OnBrouillonRowAdded<T extends object>(
    pRow: T,
    pCreateFn: (pRow: T) => Promise<void>,
    pPostCreateHook?: (pRow: T) => Promise<void>
  ): Promise<void>
  {
    const lId = (pRow as { id?: unknown }).id;
    if (typeof lId === 'number' && lId > 0)
    {
      return;
    }
    this._BrouillonTracker.add(pRow);
    await pCreateFn(pRow);
    if (pPostCreateHook)
    {
      await pPostCreateHook(pRow);
    }
  }

  /** Handler unifié pour `(RowValidated)`. No-op si déjà créé. */
  public async OnBrouillonRowValidated<T extends object>(
    pRow: T,
    pCreateFn: (pRow: T) => Promise<void>,
    pPostCreateHook?: (pRow: T) => Promise<void>
  ): Promise<void>
  {
    const lId = (pRow as { id?: unknown }).id;
    if (typeof lId === 'number' && lId > 0)
    {
      return;
    }
    if (this._BrouillonTracker.has(pRow))
    {
      return;
    }
    this._BrouillonTracker.add(pRow);
    await pCreateFn(pRow);
    if (pPostCreateHook)
    {
      await pPostCreateHook(pRow);
    }
  }

  /** Prépare le DTO brouillon : delete id, hook recalculate, hook extra setup. */
  public PrepareBrouillonDto<TDTO extends { id?: number }>(
    pRow: TDTO,
    pRecalculate?: (pDto: TDTO) => void,
    pExtraSetup?: (pDto: TDTO) => void
  ): TDTO | null
  {
    try
    {
      const lDto: TDTO = { ...pRow } as TDTO;
      delete (lDto as { id?: number }).id;
      if (pRecalculate)
      {
        pRecalculate(lDto);
      }
      if (pExtraSetup)
      {
        pExtraSetup(lDto);
      }
      return lDto;
    } catch
    {
      return null;
    }
  }

  /** Extrait le message d'erreur métier du back (ServiceBase.create jette Error(message)). */
  public ExtractBackError(pErr: unknown, pFallback: string): string
  {
    return (pErr as Error)?.message ?? pFallback;
  }

  //#endregion

  /**
 * Le nom de l'utilisateur complet
 * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
 */
  public getFullName(pUser?: UsersDTO): string
  {
    const targetUser: UsersDTO | null = pUser ?? this.UsersService.currentUser;
    const firstName: string = targetUser?.firstName || '';
    const lastName: string = targetUser?.lastName || '';
    return firstName + " " + lastName || 'Utilisateur';
  }

  /**
   * Initial de l'utilisateur
   * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
   */
  public getInitials(pUser?: UsersDTO): string
  {
    const targetUser = pUser ?? this.UsersService.currentUser;
    const first = targetUser?.firstName?.charAt(0) || '';
    const last = targetUser?.lastName?.charAt(0) || '';
    return (first + last).toUpperCase() || 'U';
  }

  /**
   * Format le prix
   * @param pPrice le prix
   * @returns le prix en string formater
   */
  public FormatPrice(pPrice: number | undefined): string
  {
    if (pPrice === undefined || pPrice === null) return '';
    if (pPrice === 0) return '0 €';

    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0
    }).format(pPrice);
  }
  /**
   * Formate la date
   * @param pDate la date
   * @returns la date formater
   */
  public FormatDate(pDate: Date | string | undefined): string
  {
    if (!pDate) return '';

    const lDate: Date = typeof pDate === 'string' ? new Date(pDate) : pDate;

    return new Intl.DateTimeFormat('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(lDate);
  }

  /**
   * Formate la date avec l'heure précise (jour, mois, année, heure, minute, seconde).
   * @param pDate la date
   * @returns la date formatée avec l'heure
   */
  public FormatDateTime(pDate: Date | string | undefined): string
  {
    if (!pDate) return '';

    const lDate: Date = typeof pDate === 'string' ? new Date(pDate) : pDate;

    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(lDate);
  }

  //#region Navigation
  /**
   * Navigation vers la view
   * @param pView la vue
   */
  public Go(pView: string): void
  {
    this.Nav.Go(pView);
  }
  /**
   * Verifie si la view existe
   * @param pView la view
   * @returns vrai ou faux
   */
  public Is(pView: string): boolean
  {
    return this.Nav.Is(pView);
  }
  //#endregion

  /**
   * Convertit une chaîne de caractères en valeur d'énumération
   * @param value La chaîne à convertir
   * @param enumType Le type d'énumération cible
   * @returns La valeur d'énumération correspondante
   */
  public ConvertToEnum<T extends object, K extends keyof T>(value: string, enumType: T): T[K]
  {
    return enumType[value as unknown as K];
  }

  /**
   * Convertit une valeur d'énumération en chaîne de caractères
   * @param enumValue La valeur d'énumération à convertir
   * @param enumType Le type d'énumération source
   * @returns La chaîne de caractères correspondante
   */
  public EnumToString<T extends object>(enumValue: number | string, enumType: T): string
  {
    const lKeys: string[] = Object.keys(enumType).filter(key => isNaN(Number(key)));
    const lValues: string[] = Object.values(enumType).filter(value => !isNaN(Number(value)));

    // Si c'est un nombre, on cherche la clé correspondante
    if (typeof enumValue === 'number')
    {
      const lIndex: number = lValues.indexOf(enumValue as any);
      return lIndex >= 0 ? lKeys[lIndex] : '';
    }

    // Sinon on retourne la valeur directement si c'est déjà une chaîne
    return String(enumValue);
  }

  //#endregion

}
