/**
 * Base criteria for all CritereDTO
 * Provides common properties for pagination, sorting and search
 * Auto-generated - Do not modify manually
 */
export interface BaseCritereDTO
{
    // ----- Identifiers -----
    /** Recherche par identifiant unique */
    id?: number;
    /** Recherche par liste d'identifiants (IN) */
    ids?: number[];
    /** Exclure ces identifiants des résultats */
    excludeIds?: number[];

    // ----- Pagination -----
    /** Numéro de la page (commence à 1) */
    page?: number;
    /** Nombre d'éléments par page */
    pageSize?: number;
    /** Nombre d'éléments à ignorer depuis le début */
    skip?: number;
    /** Nombre maximum d'éléments à retourner */
    limit?: number;
    /** Indique s'il y a une page suivante (rempli par le service) */
    hasNext?: boolean;
    /** Nombre total d'éléments correspondant aux critères (rempli par le service) */
    totalCount?: number;

    // ----- Sorting -----
    /** Nom de la propriété sur laquelle trier */
    sort?: string;
    /** Direction du tri : "asc" ou "desc" */
    sortDirection?: 'asc' | 'desc';
    /** Alternative à sort - Format : "PropertyName" ou "PropertyName desc" */
    orderBy?: string;

    // ----- Search -----
    /** Recherche textuelle globale */
    search?: string;

    // ----- Query Options -----
    /** Liste des propriétés à retourner (projection) */
    select?: string[];
    /** Liste des propriétés à exclure du résultat */
    exclude?: string[];
    /** Inclure les éléments supprimés (soft delete) */
    includeDeleted?: boolean;
    /** Retourner uniquement les éléments supprimés (soft delete) */
    onlyDeleted?: boolean;

    // ----- Audit -----
    /** Filtrer par l'utilisateur qui a créé l'élément */
    createdBy?: number;
    /** Filtrer par l'utilisateur qui a modifié l'élément */
    updatedBy?: number;
    /** Filtrer les éléments créés après cette date */
    createdAfter?: Date | string;
    /** Filtrer les éléments créés avant cette date */
    createdBefore?: Date | string;
    /** Filtrer les éléments modifiés après cette date */
    updatedAfter?: Date | string;
    /** Filtrer les éléments modifiés avant cette date */
    updatedBefore?: Date | string;
}
