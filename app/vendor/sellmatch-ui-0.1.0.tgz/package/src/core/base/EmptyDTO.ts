export interface EmptyDTO
{

}
