// shared/components/base/BaseViewComponent.ts

import { Component, inject, OnInit, OnDestroy, ChangeDetectionStrategy, AfterViewInit } from "@angular/core";
import { UsersDTO } from "../../../core/sellmatchdb/dto";

import { Subscription } from "rxjs";
import { ActivatedRoute, Params } from "@angular/router";
import { BaseComponent } from "../../../core/base/BaseComponent";
import { TutorialService } from "../../../core/services/tutorial/tutorial.service";

/**
 * Classe de base abstraite pour les vues (dashboards, pages authentifiées).
 * Gère automatiquement le cycle de vie des subscriptions via _Subs.
 */
@Component({
  changeDetection: ChangeDetectionStrategy.Eager,
  template: ''
})
export abstract class BaseViewComponent extends BaseComponent implements OnInit, OnDestroy, AfterViewInit
{
  //#region Properties
  protected readonly DefaultView: string = 'dashboard';
  protected abstract LoadData(): Promise<void>;
  private readonly _Subs: Subscription = new Subscription();
  public Route: ActivatedRoute = inject(ActivatedRoute);
  public User: UsersDTO | null = null;
  public ShowSupport = false;

  //#endregion

  //#region Attributes
  /**
   * Service de tutoriel (singleton). Branche automatiquement `OnViewChange` sur `Nav.Go`
   * pour que toute vue derivant de `BaseViewComponent` puisse etre pilotee par le tuto
   * sans avoir a rebrancher manuellement le callback dans chaque composant.
   */
  private readonly _Tutorial: TutorialService = inject(TutorialService);
  //#endregion

  //#region Init
  async ngOnInit(): Promise<void>
  {
    if (!this.UsersService.isLoggedIn())
    {
      this.RouteUtils.NavigateTo(this.Routes.CONNEXION);
      return;
    }

    // - cm - Lit le param view dans l'URL au refresh pour restaurer la vue
    const lViewParam: string | null = this.Route.snapshot.queryParamMap.get('view');
    this.Nav.Reset(lViewParam ?? this.DefaultView);

    this.Sub(
      this.UsersService.currentUser$.subscribe(u => this.User = u)
    );

    await this.Load(() => this.LoadData());

    // - cm - Branchement auto du tuto : tous les BaseViewComponent peuvent etre navigues par le tuto.
    // Le delai de 300 ms est gere cote TutorialOverlayComponent (voir _MeasureDelayMs) pour laisser la vue peindre
    // avant de mesurer la position du spotlight.
    this._Tutorial.OnViewChange = (pView: string): void => {
      this.Nav.Go(pView);
    };
  }

  ngAfterViewInit(): void
  {
    this.Sub(
      this.Route.queryParams.subscribe(pParams =>
      {
        this.ConfigQueryParams(pParams);
      })
    );
  }

  /**
   * Nettoie toutes les subscriptions pour éviter les fuites mémoire.
   */
  ngOnDestroy(): void
  {
    // - cm - Debranchement du tuto pour eviter les fuites memoire
    this._Tutorial.OnViewChange = null;

    this._Subs.unsubscribe(); // - cm - Désabonnement global de toutes les subscriptions
  }

  //#endregion

  //#region Methods
  /**
   * Ajoute une subscription au conteneur global pour désabonnement automatique.
   * @param pSub La subscription à enregistrer
   */
  protected Sub(pSub: Subscription): void
  {
    this._Subs.add(pSub);
  }

  /**
   * Chargement du dashboard
   * @param pAction methode de chargement des données
   * @returns Promise<T>
   */
  protected async Load<T>(pAction: () => Promise<T>): Promise<T>
  {
    this.BusyService.show();
    try
    {
      return await pAction();
    }
    finally
    {
      this.BusyService.hide();
    }
  }

  protected ConfigQueryParams(pParams : Params) : void
  {
    // Vérifier si un paramètre pour ouvrir une vue spécifique est présent
    if (pParams['view'])
    {
      this.Go(pParams['view']);
    }
  }

  /**
   * Navigation vers une view + synchro de l'URL avec le query param `view`.
   * - cm - Sur refresh, le param `view` est relu par ConfigQueryParams qui rappelle Go,
   * donc on revient automatiquement sur la vue ouverte avant le refresh.
   * @param pView la vue cible
   */
  public override Go(pView: string): void
  {
    // - cm - Evite la boucle : ne rien faire si la view ne change pas
    if (this.Nav.View() === pView)
    {
      return;
    }

    super.Go(pView);

    // - cm - Met a jour le query param view dans l'URL sans changer de route
    // - cm - Utilise navigateByUrl avec UrlTree pour eviter les problemes de relativeTo
    const lUrlTree = this.RouteUtils.Router.createUrlTree([], {
      relativeTo: this.Route,
      queryParams: { view: pView },
      queryParamsHandling: 'merge'
    });
    void this.RouteUtils.Router.navigateByUrl(lUrlTree, { replaceUrl: true });
  }
  //#endregion
}
