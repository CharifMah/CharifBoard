import { BaseCritereDTO } from "../../core/base/base.critere";


/**
 * Interface de base pour tous les services.
 * Fournit les opérations CRUD standard avec support des critères de recherche.
 */
export interface IServiceBase<TDto, TCritere extends BaseCritereDTO>
{

  /**
   * Récupère tous les éléments selon les critères spécifiés.
   * Supporte la pagination, le tri et les filtres personnalisés.
   * @param critere Les critères de recherche (optionnel)
   * @returns Une promesse avec la collection d'éléments
   */
  getAll(critere?: TCritere): Promise<TDto[]>;

  /**
   * Récupère un élément unique selon les critères spécifiés.
   * @param critere Les critères de recherche
   * @returns Une promesse avec l'élément trouvé ou null
   */
  get(critere: TCritere): Promise<TDto | null>;

  /**
   * Crée un nouvel élément.
   * @param dto Les données de l'élément à créer
   * @returns Une promesse avec l'élément créé
   */
  create(dto: TDto): Promise<TDto>;

  /**
   * Met à jour un élément.
   * @param dto Les nouvelles données de l'élément
   * @param critere Les critères pour identifier l'élément (optionnel)
   * @returns Une promesse avec l'élément mis à jour ou null
   */
  update(dto: TDto, critere?: TCritere): Promise<TDto | null>;

  /**
   * Supprime un élément identifié par les critères.
   * @param critere Les critères pour identifier l'élément
   * @returns Une promesse avec true si supprimé, false sinon
   */
  delete(critere: TCritere): Promise<boolean>;

  /**
   * Compte le nombre d'éléments correspondant aux critères.
   * @param critere Les critères de recherche (optionnel)
   * @returns Une promesse avec le nombre d'éléments
   */
  count(critere?: TCritere): Promise<number>;

  /**
   * Vérifie si au moins un élément existe selon les critères.
   * @param critere Les critères de recherche
   * @returns Une promesse avec true si existe, false sinon
   */
  exists(critere: TCritere): Promise<boolean>;
}
