import { inject, Inject, Injectable, InjectionToken, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { BaseCritereDTO } from '../../core/base/base.critere';
import { IServiceBase } from './IServiceBase';
import { IExcelExportRequest } from '../../shared/components/grid/grid-xlsx-export.service';
import { Router } from '@angular/router';
import { RouteUtils } from '../../shared/utils/route-utils';
import { environment } from '../../environments/environment';
import { ROUTE_PATHS } from '../../routes/app.routes.constants';
import { PostHogService } from '../../core/services/posthog/PostHogService';
import { Subject } from 'rxjs';

/**
 * Subject global notifié à chaque 401 intercepté par n'importe quel ServiceBase.
 * Le UsersService s'y abonne pour vider le currentUserSubject (currentUser$).
 * Permet de casser la dépendance circulaire ServiceBase → UsersService.
 */
export const unauthorized$ = new Subject<void>();

export const API_ENDPOINT = new InjectionToken<string>('apiEndpoint');

/**
 * Classe de base abstraite pour tous les services.
 * Implémente les opérations CRUD standard avec Axios.
 * Le tracking PostHog est automatique sur chaque appel API.
 */
@Injectable()
export abstract class ServiceBase<TDto, TCritere extends BaseCritereDTO>
  implements IServiceBase<TDto, TCritere> {
  protected Router = inject(Router);
  protected RouteUtils = inject(RouteUtils);
  protected PostHog: PostHogService = inject(PostHogService);
  protected apiUrl: string;
  protected axiosInstance: AxiosInstance;

  protected readonly TOKEN_KEY = 'token';
  protected readonly USER_KEY = 'user';

  /**
   * Indique si l'on s'exécute côté navigateur (SSR-safe)
   */
  protected readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /**
   * Nom de l'endpoint pour le tracking PostHog
   */
  protected get TrackingEndpoint(): string
  {
    return this.endpoint
      .replace(/([a-z])([A-Z])/g, '$1_$2')
      .toLowerCase();
  }

  /**
   * Construit l'URL de base de l'API pour ce service.
   * - cm - Hook d'override : les services fils peuvent surcharger pour viser une
   * autre base (ex : assets statiques racine pour i18n, URL absolue externe, etc.).
   * @param pEndpoint Nom de l'endpoint passé au constructeur
   * @returns URL de base complète
   */
  protected BuildApiUrl(pEndpoint: string): string
  {
    return `${environment.apiUrl}/${pEndpoint}`;
  }

  constructor(
    @Inject(API_ENDPOINT) protected endpoint: string
  ) {
    this.apiUrl = this.BuildApiUrl(endpoint);

    this.axiosInstance = axios.create({
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true, // - cm - Envoie les cookies HttpOnly (auth) avec chaque requête
    });

    this.setupInterceptors();
  }

  //#region CRUD Operations

  /**
   * Récupère tous les éléments selon les critères.
   * @param critere Les critères de recherche (optionnel)
   * @returns Liste des éléments correspondants (tableau vide en cas d'erreur)
   */
  async getAll(critere?: TCritere): Promise<TDto[]> {
    try {
      const lResponse = await this.axiosInstance.post<TDto[]>(
        `${this.apiUrl}/GetAll`,
        critere ?? {}
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_all`);
      // - cm - Garantit un tableau même si l'API retourne null/undefined
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    } catch (lError) {
      this.handleError(lError);
      // - cm - Retourne un tableau vide au lieu de propager l'erreur
      return [];
    }
  }

  /**
   * Récupère un élément selon les critères.
   * @param critere Les critères de recherche
   * @returns L'élément trouvé ou null
   */
  async get(critere: TCritere): Promise<TDto | null> {
    try {
      const lResponse = await this.axiosInstance.post<TDto>(
        `${this.apiUrl}/Get`,
        critere
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get`);
      return lResponse.data;
    } catch (lError: any) {
      if (lError.response?.status === 404) {
        return null;
      }
      this.handleError(lError);
      return null;
    }
  }

  /**
   * Crée un nouvel élément.
   * @param dto Le DTO de l'élément à créer
   * @returns L'élément créé
   */
  async create(dto: TDto): Promise<TDto> {
    try {
      const lResponse = await this.axiosInstance.post<TDto>(
        `${this.apiUrl}/Create`,
        dto
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_create`);
      return lResponse.data;
    } catch (lError) {
      const lMessage: string = this.handleError(lError);
      throw new Error(lMessage);
    }
  }

  /**
   * Met à jour un élément.
   * @param pDTO Le DTO avec les nouvelles données
   * @param pCritere Les critères pour identifier l'élément (optionnel)
   * @returns L'élément mis à jour ou null
   */
  async update(pDTO: TDto, pCritere?: TCritere): Promise<TDto | null> {
    try {
      const lConfig: AxiosRequestConfig = {};
      lConfig.params = pCritere;

      const lResponse = await this.axiosInstance.put<TDto>(
        `${this.apiUrl}/Update`,
        pDTO,
        lConfig
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_update`);
      return lResponse.data;
    } catch (lError: any) {
      if (lError.response?.status === 404) {
        return null;
      }
      this.handleError(lError);
      return null;
    }
  }

  /**
   * Supprime un élément.
   * @param critere Les critères pour identifier l'élément
   * @returns True si supprimé, false sinon
   */
  async delete(critere: TCritere): Promise<boolean> {
    try {
      await this.axiosInstance.delete(`${this.apiUrl}/Delete`, {
        data: critere
      });
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_delete`);
      return true;
    } catch (lError: any) {
      if (lError.response?.status === 404) {
        return false;
      }
      this.handleError(lError);
      return false;
    }
  }

  /**
   * Compte les éléments selon les critères.
   * @param critere Les critères de recherche (optionnel)
   * @returns Le nombre d'éléments
   */
  async count(critere?: TCritere): Promise<number> {
    try {
      const lResponse = await this.axiosInstance.post<number>(
        `${this.apiUrl}/Count`,
        critere ?? {}
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_count`);
      return lResponse.data;
    } catch (lError) {
      this.handleError(lError);
      return 0;
    }
  }

  /**
   * Vérifie si un élément existe selon les critères.
   * @param critere Les critères de recherche
   * @returns True si existe, false sinon
   */
  async exists(critere: TCritere): Promise<boolean> {
    try {
      const lResponse = await this.axiosInstance.post<boolean>(
        `${this.apiUrl}/Exists`,
        critere
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_exists`);
      return lResponse.data;
    } catch (lError) {
      this.handleError(lError);
      return false;
    }
  }

  /**
   * Exporte les éléments du service courant en XLSX via l'endpoint backend POST /api/{Controller}/ExportXlsx.
   * Utilise l'instance axios interne du service (cohérent avec le reste du projet, pas d'URL en dur).
   * @param pRequest Requête d'export (Critere, Title, UserName, Columns). Si null, export complet.
   * @returns Le Blob XLSX à télécharger.
   */
  async exportXlsx(pRequest: IExcelExportRequest<TCritere> | null = null): Promise<Blob> {
    try {
      const lResponse = await this.axiosInstance.post(
        `${this.apiUrl}/ExportXlsx`,
        pRequest ?? {},
        { responseType: 'blob' }
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_export_xlsx`, {
        hasFilter: !!pRequest?.Critere,
        hasColumns: !!pRequest?.Columns && (pRequest.Columns?.length ?? 0) > 0
      });
      return lResponse.data as Blob;
    } catch (lError) {
      this.handleError(lError);
      throw lError;
    }
  }

  //#endregion

  //#region Utility Methods

  /**
   * Filtre une liste d'éléments côté client.
   * @param pItems Les éléments à filtrer
   * @param pCriteria Les critères de filtre
   * @returns Les éléments filtrés
   */
  filter(pItems: TDto[], pCriteria: Partial<TDto>): TDto[] {
    if (!pCriteria) {
      return pItems;
    }
    return pItems.filter(lItem => {
      return Object.keys(pCriteria).every(lKey => {
        const lCriteriaValue = (pCriteria as any)[lKey];
        const lItemValue = (lItem as any)[lKey];
        if (lCriteriaValue === undefined || lCriteriaValue === null) {
          return true;
        }
        if (typeof lItemValue === 'string' && typeof lCriteriaValue === 'string') {
          return lItemValue.toLowerCase().includes(lCriteriaValue.toLowerCase());
        }
        return lItemValue === lCriteriaValue;
      });
    });
  }

  /**
   * Trie une liste d'éléments côté client.
   * @param pItems Les éléments à trier
   * @param pKey La clé de tri
   * @param pAscending Ordre ascendant (true par défaut)
   * @returns Les éléments triés
   */
  sort(pItems: TDto[], pKey: keyof TDto, pAscending = true): TDto[] {
    return [...pItems].sort((a, b) => {
      const lValueA = a[pKey];
      const lValueB = b[pKey];
      if (lValueA === lValueB) return 0;
      let lComparison = 0;
      if (lValueA === null || lValueA === undefined) {
        lComparison = -1;
      } else if (lValueB === null || lValueB === undefined) {
        lComparison = 1;
      } else if (typeof lValueA === 'string') {
        lComparison = (lValueA as string).localeCompare(lValueB as string);
      } else {
        lComparison = lValueA < lValueB ? -1 : 1;
      }
      return pAscending ? lComparison : -lComparison;
    });
  }

  /**
   * Pagine une liste d'éléments côté client.
   * @param pItems Les éléments à paginer
   * @param pPage Le numéro de page (commence à 1)
   * @param pPageSize La taille de la page
   * @returns Les éléments de la page
   */
  paginate(pItems: TDto[], pPage: number, pPageSize: number): TDto[] {
    const lStartIndex = (pPage - 1) * pPageSize;
    return pItems.slice(lStartIndex, lStartIndex + pPageSize);
  }
  //#endregion

  //#region Interceptors & Error Handling

  /**
   * Installe les intercepteurs axios par défaut (401 -> redirection login, propagation des erreurs).
   * - cm - Hook d'override : passé de private à protected pour permettre aux services fils
   * d'adapter ou d'étendre le comportement (appeler super.setupInterceptors() puis ajouter).
   */
  protected setupInterceptors(): void {
    this.axiosInstance.interceptors.request.use(
      (pConfig) => {
        // - cm - Le token JWT est envoyé automatiquement via le cookie HttpOnly (withCredentials: true)
        // Plus besoin de lire le token depuis localStorage
        return pConfig;
      },
      (pError) => {
        return Promise.reject(pError);
      }
    );

    this.axiosInstance.interceptors.response.use(
      (pResponse) => pResponse,
      async (pError) => {
        const lOriginalRequest = pError.config;

        // - cm - 401 interceptor : on redirige systematiquement vers /unauthorized pour tout 401
        // authentifie. La distinction X-Token-Expired n'est plus fiable (header masque par CORS dans
        // certains scenarios ; voir CorsExtensions.WithExposedHeaders). Le 401 NON authentifie
        // (pas de cookie, JWT absent) renvoie aussi sur /unauthorized : l'utilisateur doit se
        // reconnecter, c'est le meme parcours. Le cold start Render / proxy 401 transitoire est
        // gere par le _retry flag sur les requetes API individuelles.
        if (pError.response?.status === 401 && !lOriginalRequest._retry) {
          // - cm - On ne redirige PAS si on est sur l'appel /api/Users/Login lui-meme : sinon le
          // message d'erreur de login est masque par une redirection immediate.
          // - cm - Depuis /api/Users/me -> 200 + null (cf. commit bd1093d9), on n'a plus
          // besoin du check public : un visiteur sur une page publique
          // n'obtient plus de 401 sur /me, et un 401 sur les autres endpoints traduit
          // reellement une session expiree ou un acces refuse.
          const lUrl: string = lOriginalRequest?.url ?? '';
          const lIsLoginRequest = lUrl.includes('/api/Users/Login');

          if (!lIsLoginRequest) {
            lOriginalRequest._retry = true;
            this.handleUnauthorized();
          }
        }

        return Promise.reject(pError);
      }
    );
  }

  private handleUnauthorized(): void {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    // - cm - Avant tout, on preserve l'URL courante dans le query param `returnUrl`
    // de la page /unauthorized. Au relogin, l'utilisateur sera redirige vers
    // cette page (cf. login.component._routeReturnUrl et authGuard.NavigateToWithReturn).
    // - cm - Le LastUrlService a deja sauvegarde cette URL cote BDD + localStorage,
    // mais on double avec le returnUrl query param pour les cas ou le localStorage
    // est vide (cache vide, mode prive Safari, autre navigateur) et que le
    // settings BDD n'est pas encore synchro.
    const lCurrentUrl: string = this.RouteUtils.Router.url ?? '/';
    const lPathOnly: string = lCurrentUrl.split('?')[0].split('#')[0];

    // - cm - Notifie le UsersService pour qu'il vide currentUserSubject et nettoie PostHog
    // - cm - Utilise un Subject RxJS plutôt qu'une injection directe pour éviter la dépendance circulaire
    unauthorized$.next();

    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    localStorage.removeItem('rememberMe');
    sessionStorage.removeItem(this.USER_KEY);

    // - cm - Redirige vers /unauthorized (page dediee qui explique la deconnexion + propose
    // - cm - de se reconnecter). On preserve l'URL courante en returnUrl (le login
    // - cm - composant la filtrera si elle pointe vers une route publique).
    if (lPathOnly && lPathOnly !== '/')
    {
      this.RouteUtils.Router.navigate(
        [this.RouteUtils.GetRoute(ROUTE_PATHS.UNAUTHORIZED)],
        { queryParams: { returnUrl: lCurrentUrl } }
      );
    }
    else
    {
      this.RouteUtils.NavigateTo(ROUTE_PATHS.UNAUTHORIZED);
    }
  }

  /**
   * Gère les erreurs API de manière centralisée.
   * Log l'erreur, gère le cas 401 (redirection login) et extrait le message
   * métier du backend pour le caller (notamment les 400 FluentValidation
   * et 500 DbUpdateException).
   * @param pError L'erreur à traiter.
   * @returns Le message lisible pour affichage UI (toast, banner, etc.).
   */
  protected handleError(pError: any): string {
    console.error('API Error:', pError);

    const lResponse = pError?.response;
    const lData: any = lResponse?.data;

    // - cm - Format FluentValidation back (cf. BaseApiController.CreateAsync
    //      qui mappe les ValidationException en 400 avec un tableau d'erreurs
    //      typées : { message, errors: [{ field, error }] }).
    if (Array.isArray(lData?.errors) && lData.errors.length > 0) {
      const lMessages: string[] = lData.errors
        .map((pE: { field?: string; error?: string }) => {
          const lField: string = pE.field ?? '?';
          const lErr: string = pE.error ?? pE.toString();
          return `${lField}: ${lErr}`;
        });
      return lMessages.join(' ; ');
    }

    // - cm - Format ASP.NET ProblemDetails (cf. ModelState.AddModelError).
    //      errors est alors un Record<string, string[]>.
    if (lData?.errors && typeof lData.errors === 'object') {
      const lErrors: Record<string, string[]> = lData.errors;
      const lMessages: string[] = [];
      for (const lKey in lErrors) {
        const lVal = lErrors[lKey];
        if (Array.isArray(lVal)) {
          lMessages.push(...lVal);
        } else if (typeof lVal === 'string') {
          lMessages.push(lVal);
        }
      }
      if (lMessages.length > 0) {
        return lMessages.join(' ; ');
      }
    }

    // - cm - Format ServiceException (cf. BaseApiController : 500 DbUpdate etc.)
    //      Le back expose { message, detail } où detail contient le type + msg original.
    if (lData?.message) {
      const lMsg: string = String(lData.message);
      if (lData.detail) {
        return `${lMsg} (${lData.detail})`;
      }
      return lMsg;
    }

    // - cm - Fallback : titre ASP.NET ProblemDetails.
    if (lData?.title) {
      return lData.title;
    }

    // - cm - Fallback : message générique avec status.
    if (lResponse?.status) {
      return `Erreur ${lResponse.status} : ${lResponse.statusText || 'Une erreur est survenue.'}`;
    }

    return pError?.message ?? 'Une erreur est survenue.';
  }

  //#endregion
}
