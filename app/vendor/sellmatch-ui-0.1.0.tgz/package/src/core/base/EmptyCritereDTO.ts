import { BaseCritereDTO } from "./base.critere";

export interface EmptyCritereDTO extends BaseCritereDTO
{

}
