export enum ECollectionFilterMode
{
  Filter = 'Filter',
  Both = 'Both'
}
