export const CATEGORY_LABELS: Record<string, string> = {
  'visuels': '📸 Visuels & Mise en valeur',
  'prises_vue': '🚁 Prises de vue spéciales',
  'diffusion': '🌐 Diffusion & Visibilité',
  'strategie': '📊 Commercialisation & Stratégie'
};

export const CATEGORY_ICONS: Record<string, string> = {
  'visuels': 'photo_camera',
  'prises_vue': 'flight',
  'diffusion': 'share',
  'strategie': 'trending_up'
};
