import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../core/base/ServiceBase';
import { EmptyCritereDTO } from '../../../core/base/EmptyCritereDTO';
import { EmptyDTO } from '../../../core/base/EmptyDTO';

/**
 * Réponse de vérification de session Stripe.
 */
export interface IStripeSessionStatus {
  status: string;
  payment_status: string;
  payment_intent?: string;
  customer_email?: string;
  amount_total?: number;
  currency?: string;
  created?: number;
  expires_at?: number;
}

export interface IStripePaymentVerification {
  status: 'paid' | 'unpaid' | 'pending' | 'unknown';
  paymentIntentId?: string;
  sessionDetails?: IStripeSessionStatus;
}

/**
 * Service Stripe : vérifie le statut d'une session Checkout.
 * - cm - La création de session est gérée par le backend via
 *   UserSubscriptionsService (SubscriptionController moderne).
 *   Ce service ne fait plus que la vérification du statut et le
 *   chargement du script Stripe.js pour les composants Embedded.
 */
@Injectable({
  providedIn: 'root',
})
export class StripeService extends ServiceBase<EmptyDTO, EmptyCritereDTO>
{
  constructor()
  {
    super('');
  }

  /**
   * Vérifie le statut d'une session de paiement.
   * @param pSessionId L'ID de la session à vérifier.
   * @returns Un objet contenant le statut de la session.
   */
  async checkSessionStatus(pSessionId: string): Promise<IStripeSessionStatus>
  {
    try
    {
      const lUrl = `${this.apiUrl}SessionStatus/Session?session_id=${pSessionId}`;
      const lResponse = await this.axiosInstance.get<IStripeSessionStatus>(lUrl);
      return lResponse.data;
    }
    catch (lError: any)
    {
      console.error('Erreur lors de la vérification de la session:', lError);
      throw new Error(this.handleError(lError));
    }
  }

  /**
   * Vérifie le statut d'une session et l'analyse en 'paid' / 'unpaid' / 'pending'.
   * @param pSessionId L'ID de la session Stripe.
   * @returns Un objet avec le statut simplifié et les détails.
   */
  async verifyPaymentSession(pSessionId: string): Promise<IStripePaymentVerification>
  {
    try
    {
      const sessionStatus = await this.checkSessionStatus(pSessionId);

      let lStatus: 'paid' | 'unpaid' | 'pending' | 'unknown' = 'unknown';

      if (sessionStatus.status === 'complete')
      {
        if (sessionStatus.payment_status === 'paid')
        {
          lStatus = 'paid';
        }
        else if (sessionStatus.payment_status === 'unpaid')
        {
          lStatus = 'unpaid';
        }
        else
        {
          lStatus = 'pending';
        }
      }

      return {
        status: lStatus,
        paymentIntentId: sessionStatus.payment_intent,
        sessionDetails: sessionStatus,
      };
    }
    catch (pError)
    {
      console.error('Erreur lors de la vérification de la session de paiement:', pError);
      throw pError;
    }
  }

  /**
   * Charge le script Stripe.js de manière asynchrone.
   * @returns Une promesse qui se résout avec l'objet Stripe.js global.
   */
  loadStripeScript(): Promise<any>
  {
    return new Promise((pResolve, pReject) =>
    {
      if ((window as any).Stripe)
      {
        pResolve((window as any).Stripe);
        return;
      }

      const lScript = document.createElement('script');
      lScript.src = 'https://js.stripe.com/v3/';
      lScript.async = true;
      lScript.onload = () => pResolve((window as any).Stripe);
      lScript.onerror = () => pReject(new Error('Impossible de charger le script Stripe.js'));
      document.body.appendChild(lScript);
    });
  }

  /**
   * Initialise l'objet Stripe avec votre clé publique.
   * @param pPublishableKey La clé publique Stripe (pk_test_…).
   * @returns L'instance Stripe initialisée.
   */
  async initializeStripe(pPublishableKey: string): Promise<any>
  {
    try
    {
      const lStripeJs = await this.loadStripeScript();
      return lStripeJs(pPublishableKey);
    }
    catch (pError)
    {
      console.error("Erreur lors de l'initialisation de Stripe:", pError);
      throw pError;
    }
  }
}
