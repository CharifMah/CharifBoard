import {Injectable, EventEmitter, signal, Signal, WritableSignal, inject, PLATFORM_ID} from '@angular/core';
import {isPlatformServer} from '@angular/common';
import {
  TranslateService,
  LangChangeEvent,
  TranslationChangeEvent,
  TranslateLoader,
  TranslationObject
} from '@ngx-translate/core';
import {Observable, from, firstValueFrom} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {ServiceBase} from '../../../core/base/ServiceBase';
import {EmptyCritereDTO} from '../../../core/base/EmptyCritereDTO';
import {EmptyDTO} from '../../../core/base/EmptyDTO';
import {RefTranslationsService} from '../../../core/crm/services/ref-translations/ref-translations.service';
import {RefTranslationsDTO} from '../../../core/crm/dto/ref-translations/ref-translations.dto';

export type SupportedLanguage = 'fr' | 'en' | 'es' | 'pt';

export interface ITranslationRegistry {
  _meta?: { language: string; version?: string; note?: string };
  files: string[];
  fr?: { files: string[] };
  en?: { files: string[] };
  es?: { files: string[] };
  pt?: { files: string[] };
}

@Injectable({providedIn: 'root'})
export class TranslationService extends ServiceBase<EmptyDTO, EmptyCritereDTO> implements TranslateLoader {
  //#region Attribute
  private static readonly _DefaultLanguage: SupportedLanguage = 'fr';
  private static readonly _FallbackLanguage: SupportedLanguage = 'fr';
  private static readonly _RegistryPath: string = '/assets/i18n/registry/';
  private static readonly _GlobalRegistryName: string = 'global';

  private readonly _RefCache: Map<string, Map<number, string>> = new Map<string, Map<number, string>>();
  // - cm - Set des refTables déjà préchargées au moins une fois : utilisé pour
  // re-précharger automatiquement la NOUVELLE langue au onLangChange (sinon les
  // dropdowns restent sur l'ancienne entrée `_RefCache` jusqu'au reload manuel).
  private readonly _PreloadedRefTables: Set<string> = new Set<string>();
  // - cm - Promise partagée par refTable/lang pour éviter N GET parallèles quand
  // plusieurs composants appellent preloadRefTable simultanément.
  private readonly _RefLoading: Map<string, Promise<void>> = new Map<string, Promise<void>>();

  private readonly RefTranslations: RefTranslationsService = inject(RefTranslationsService);
  private readonly HttpClient: HttpClient = inject(HttpClient);
  private readonly _IsServer: boolean = isPlatformServer(inject(PLATFORM_ID));
  private readonly Translate: TranslateService = inject(TranslateService);
  //#endregion

  //#region Property
  /** Émet la langue courante à chaque changement — BaseComponent s'y abonne pour markForCheck. */
  public readonly LanguageChanged: EventEmitter<SupportedLanguage> = new EventEmitter<SupportedLanguage>();
  /** Émet à chaque chargement/mise à jour du dictionnaire (boot + changement de langue). */
  public readonly TranslationLoaded: EventEmitter<void> = new EventEmitter<void>();

  private readonly _InstantTick: WritableSignal<number> = signal<number>(0);
  /** Tick bumpé au chargement i18n et au changement de langue — abonné par les computed() et le pipe `tkey`. */
  public readonly InstantTick: Signal<number> = this._InstantTick.asReadonly();
  //#endregion

  //#region CTOR
  constructor() {
    super('i18n');
    this.Translate.addLangs(['fr', 'en', 'es', 'pt']);
    this.Translate.setFallbackLang(TranslationService._FallbackLanguage);

    // - cm - use() est différé par la factory du loader (timer(0)) pour casser le cycle DI.
    this.Translate.use(TranslationService._DefaultLanguage).subscribe(() => {
      this._InstantTick.update(pN => pN + 1);
      this.TranslationLoaded.emit();
    });

    this.Translate.onLangChange.subscribe((pEvent: LangChangeEvent) => {
      const lLang: SupportedLanguage = this._LangOrDefault(pEvent.lang);
      // - cm - Invalide TOUTES les entrées du cache `_RefCache` à chaque changement
      // de langue : la clé `${refTable}@${lang}` change, donc les anciennes entrées
      // (FR pour toutes les tables) ne correspondent plus à la langue active.
      this._InvalidateRefCache();
      // - cm - Re-précharge automatiquement les refTables déjà vues, dans la
      // NOUVELLE langue. Sans ça, les dropdowns restent sur le fallback FR natif
      // (`pR.libelle`) jusqu'à un reload manuel de la page.
      for (const lRefTable of this._PreloadedRefTables) {
        void this.preloadRefTable(lRefTable, lLang);
      }
      this._InstantTick.update(pN => pN + 1);
      this.LanguageChanged.emit(lLang);
      this.TranslationLoaded.emit();
    });

    this.Translate.onTranslationChange.subscribe(() => {
      this._InstantTick.update(pN => pN + 1);
      this.TranslationLoaded.emit();
    });
  }

  //#endregion

  //#region Methods
  /** URL vide — les traductions sont des assets statiques à la racine du site. */
  protected override BuildApiUrl(pEndpoint: string): string {
    return '';
  }

  /** Point d'entrée TranslateLoader (ngx-translate). */
  public getTranslation(pLang: string): Observable<TranslationObject> {
    return from(this.LoadTranslationsAsync(pLang));
  }

  /** Charge le registre GLOBAL + tous les fichiers de la langue cible, namespacés et deep-merged. */
  public async LoadTranslationsAsync(pLang: string): Promise<TranslationObject> {
    const lRegistryPath: string = `${TranslationService._RegistryPath}${TranslationService._GlobalRegistryName}.registry.json`;
    let lRegistry: ITranslationRegistry | null = null;
    try {
      lRegistry = await this._FetchJson<ITranslationRegistry>(lRegistryPath);
      this.PostHog.Capture(`api_i18n_registry_loaded`, {language: pLang, scope: 'global'});
    } catch (lError: any) {
      console.warn(`[i18n] Registre global introuvable : ${lRegistryPath}`, lError);
      return {};
    }

    const lFiles: string[] = this._RegistryFilesForLang(lRegistry, pLang);
    if (lFiles.length === 0) {
      return {};
    }

    const lResults: TranslationObject[] = await Promise.all(
      lFiles.map(async (pFile: string): Promise<TranslationObject> => {
        try {
          const lResponse: TranslationObject = await this._FetchJson<TranslationObject>(`/${pFile}`);
          const lNamespace: string = this._ExtractNamespace(pFile);
          const lLangSection: TranslationObject = this._SplitByLang(lResponse, pLang);
          const lClean: TranslationObject = {...lLangSection};
          delete (lClean as Record<string, unknown>)['_meta'];
          const lWrapped: TranslationObject = {};
          (lWrapped as Record<string, unknown>)[lNamespace] = lClean;
          return lWrapped;
        } catch (lError: any) {
          console.warn(`[i18n] Fichier introuvable : ${pFile}`, lError);
          return {};
        }
      })
    );

    return this._DeepMergeAll(lResults);
  }

  /**
   * Charge un sous-registre de page (ex: `crm.taches.registry.json`) en plus du global.
   * @param pPageKey Clé page (utilisée comme `${pPageKey}.registry.json`)
   * @param pLang Langue cible (défaut = langue courante)
   */
  public async loadPageTranslations(pPageKey: string, pLang?: SupportedLanguage): Promise<void> {
    const lLang: SupportedLanguage = pLang ?? this.getCurrentLanguage();
    const lUrl: string = `${TranslationService._RegistryPath}${pPageKey}.registry.json`;
    try {
      const lSubRegistry: ITranslationRegistry = await this._FetchJson<ITranslationRegistry>(lUrl);
      const lFiles: string[] = this._RegistryFilesForLang(lSubRegistry, lLang);
      if (lFiles.length === 0) {
        return;
      }
      const lResults: TranslationObject[] = await Promise.all(
        lFiles.map(async (pFile: string): Promise<TranslationObject> => {
          try {
            const lResp: TranslationObject = await this._FetchJson<TranslationObject>(`/${pFile}`);
            const lNamespace: string = this._ExtractNamespace(pFile);
            const lLangSection: TranslationObject = this._SplitByLang(lResp, lLang);
            const lClean: TranslationObject = {...lLangSection};
            delete (lClean as Record<string, unknown>)['_meta'];
            const lWrapped: TranslationObject = {};
            (lWrapped as Record<string, unknown>)[lNamespace] = lClean;
            return lWrapped;
          } catch (lError: any) {
            console.warn(`[i18n] Fichier sous-registre introuvable : ${pFile}`, lError);
            return {};
          }
        })
      );
      // - cm - setTranslation(merge=true) pousse les clés dans le store ngx-translate SANS écraser l'existant.
      this.Translate.setTranslation(lLang, this._DeepMergeAll(lResults), true);
      this._InstantTick.update(pN => pN + 1);
      this.TranslationLoaded.emit();
      this.PostHog.Capture(`api_i18n_page_translations_loaded`, {
        page: pPageKey,
        language: lLang,
        files: lResults.length
      });
    } catch (lError: any) {
      console.warn(`[i18n] Sous-registre introuvable : ${lUrl}`, lError);
    }
  }

  /** Bascule la langue active et émet LanguageChanged + TranslationLoaded une fois le load terminé. */
  public setLanguage(pLang: SupportedLanguage): void {
    this.Translate.use(pLang).subscribe(() => {
      this._InstantTick.update(pN => pN + 1);
      this.LanguageChanged.emit(pLang);
      this.TranslationLoaded.emit();
    });
  }

  /** Snapshot de la langue active. */
  public getCurrentLanguage(): SupportedLanguage {
    return this._LangOrDefault(this.Translate.getCurrentLang());
  }

  /** Traduction synchrone via TranslateService.instant (utilisé par `translate()` dans les templates). */
  public translate(pKey: string, pParams?: object): string {
    return this.Translate.instant(pKey, pParams);
  }

  /** Variante réactive : lit InstantTick() pour s'abonner aux bump i18n (à utiliser dans computed()). */
  public TranslateReactive(pKey: string, pParams?: object): string {
    this.InstantTick();
    return this.Translate.instant(pKey, pParams);
  }

  /** Précharge les ref_translations d'une table dans la langue cible. Idempotent par refTable. */
  public async preloadRefTable(pRefTable: string, pLang?: SupportedLanguage): Promise<void> {
    const lLang: SupportedLanguage = pLang ?? this.getCurrentLanguage();
    const lKey: string = `${pRefTable}@${lLang}`;
    // - cm - Track la table pour le re-préchargement auto au onLangChange.
    // Fait ICI (et pas seulement à la 1re fois) pour gérer le cas où le composant
    // appelle preloadRefTable après un changement de langue : on ajoute la table
    // au set même si elle était déjà dedans.
    this._PreloadedRefTables.add(pRefTable);
    // - cm - Partage de Promise : si 2 composants appellent preloadRefTable en
    // parallèle, on retourne la même Promise (pas 2 GET).
    const lInFlight: Promise<void> | undefined = this._RefLoading.get(lKey);
    if (lInFlight) {
      return lInFlight;
    }
    // - cm - PAS d'early-return si `_RefCache.has(lKey)` : si on re-précharge suite à
    // un changement de langue, `_RefCache` contient encore l'ENTRÉE de l'ancienne
    // langue sous la même clé si jamais on a mal invalidé — on doit absolument
    // écraser avec la nouvelle entrée. L'invalidation a eu lieu dans onLangChange.
    const lPromise: Promise<void> = (async (): Promise<void> => {
      try {
        const lRows: RefTranslationsDTO[] = await this.RefTranslations.getAll({refTable: pRefTable, lang: lLang});
        const lMap: Map<number, string> = new Map<number, string>();
        for (const lRow of lRows) {
          if (typeof lRow.refId === 'number' && typeof lRow.libelle === 'string') {
            lMap.set(lRow.refId, lRow.libelle);
          }
        }
        this._RefCache.set(lKey, lMap);
        this._InstantTick.update(pN => pN + 1);
        this.TranslationLoaded.emit();
      } catch (lError: any) {
        console.warn(`[i18n] Echec ref_translations ${pRefTable} (${lLang})`, lError);
        this._RefCache.set(lKey, new Map<number, string>());
      } finally {
        this._RefLoading.delete(lKey);
      }
    })();
    this._RefLoading.set(lKey, lPromise);
    return lPromise;
  }

  /**
   * Libellé d'une ligne de ref_translations depuis le cache (sync). Lit InstantTick() pour s'abonner au rechargement.
   * - cm - Fallback FR : les libellés français vivent directement dans la table de
   * référentiel (`ref_origine_recrutement.libelle`) et non dans `ref_translations`.
   * Si la langue courante est FR et qu'aucune traduction n'est trouvée dans le
   * cache, on retourne le `pFallback` (généralement le `pR.libelle` natif) au lieu
   * du placeholder technique `ref_<table>_<id>`. Pour ES/EN/PT on conserve le
   * placeholder si la traduction manque, pour aider à repérer les trous de
   * traduction (cf. filtre `!pOpt.Label.startsWith(_OrigineFallbackPrefix)`).
   */
  public translateRef(pRefTable: string, pRefId: number, pFallback?: string | null, pLang?: SupportedLanguage): string {
    if (pRefId == null || isNaN(pRefId)) {
      return pFallback ?? '';
    }
    const lLang: SupportedLanguage = pLang ?? this.getCurrentLanguage();
    const lMap: Map<number, string> | undefined = this._RefCache.get(`${pRefTable}@${lLang}`);
    if (lMap && lMap.has(pRefId)) {
      return lMap.get(pRefId)!;
    }
    this.InstantTick();
    if (lLang === 'fr' && pFallback) {
      return pFallback;
    }
    return pFallback ?? `ref_${pRefTable}_${pRefId}`;
  }

  /** Variante réactive de translateRef pour computed(). */
  public translateRefReactive(pRefTable: string, pRefId: number, pFallback?: string | null, pLang?: SupportedLanguage): string {
    this.InstantTick();
    return this.translateRef(pRefTable, pRefId, pFallback, pLang);
  }

  private _LangOrDefault(pLang: string | null | undefined): SupportedLanguage {
    return (pLang === 'fr' || pLang === 'en' || pLang === 'es' || pLang === 'pt')
      ? (pLang as SupportedLanguage)
      : TranslationService._DefaultLanguage;
  }

  //#endregion

  //#region Private Methods
  /**
   * Lit un JSON : HttpClient en browser, fs.readFile en SSR (chemin via env var SSR_I18N_BASE_DIR,
   * défaut = `<cwd>/src`). L'import dynamique `node:fs/promises` n'est jamais bundlé côté browser.
   */
  private async _FetchJson<T>(pUrl: string): Promise<T> {
    if (this._IsServer) {
      const lImport: (pS: string) => Promise<any> = new Function('pS', 'return import(pS)') as (pS: string) => Promise<any>;
      const lFs: any = await lImport('node:fs/promises');
      const lPath: any = await lImport('node:path');
      const lRel: string = pUrl.startsWith('/') ? pUrl.slice(1) : pUrl;
      const lBaseDir: string = process.env['SSR_I18N_BASE_DIR'] || lPath.resolve(process.cwd(), 'src');
      const lContent: string = await lFs.readFile(lPath.join(lBaseDir, lRel), 'utf-8');
      const lStripped: string = lContent.charCodeAt(0) === 0xFEFF ? lContent.slice(1) : lContent;
      return JSON.parse(lStripped) as T;
    }
    return await firstValueFrom(this.HttpClient.get<T>(pUrl));
  }

  /** Extrait le namespace du nom de fichier : `home.json` → `home`. */
  private _ExtractNamespace(pFile: string): string {
    const lBase: string = pFile.split('/').pop() ?? pFile;
    const lNoExt: string = lBase.endsWith('.json') ? lBase.slice(0, -'.json'.length) : lBase;
    return lNoExt;
  }

  /**
   * Invalide TOUTES les entrées du cache `_RefCache` (toutes langues, toutes tables).
   * - cm - Appelé au `onLangChange` AVANT le re-préchargement auto. Garantit qu'aucune
   * ancienne entrée (langue précédente) ne subsiste pendant le re-fetch.
   */
  private _InvalidateRefCache(): void {
    this._RefCache.clear();
  }

  /** Liste des fichiers pour la langue cible (section `pLang.files` du registre multi-langues). */
  private _RegistryFilesForLang(pRegistry: ITranslationRegistry | null, pLang: string): string[] {
    if (!pRegistry) {
      return [];
    }
    const lSection: { files: string[] } | undefined = (pRegistry as unknown as Record<string, {
      files: string[]
    } | undefined>)[pLang];
    if (lSection && Array.isArray(lSection.files)) {
      return lSection.files.filter((pFile: string) => !!pFile && pFile.length > 0);
    }
    return [];
  }

  /** Isole la section de la langue dans un fichier multi-langues `{ fr:{}, en:{}, es:{}, pt:{} }`. */
  private _SplitByLang(pResponse: TranslationObject, pLang: string): TranslationObject {
    if (!pResponse || typeof pResponse !== 'object') {
      return {};
    }
    const lSection: unknown = (pResponse as Record<string, unknown>)[pLang];
    if (lSection && typeof lSection === 'object' && !Array.isArray(lSection)) {
      return lSection as TranslationObject;
    }
    return {};
  }

  /** Deep-merge d'une liste d'objets — la dernière occurrence gagne sur les conflits. */
  private _DeepMergeAll(pObjects: TranslationObject[]): TranslationObject {
    const lResult: TranslationObject = {};
    for (const lObj of pObjects) {
      if (lObj && typeof lObj === 'object' && !Array.isArray(lObj)) {
        this._DeepMergeInto(lResult, lObj);
      }
    }
    return lResult;
  }

  private _DeepMergeInto(pTarget: TranslationObject, pSource: TranslationObject): void {
    for (const lKey of Object.keys(pSource)) {
      const lSourceVal: unknown = (pSource as Record<string, unknown>)[lKey];
      const lTargetVal: unknown = (pTarget as Record<string, unknown>)[lKey];
      if (lSourceVal && typeof lSourceVal === 'object' && !Array.isArray(lSourceVal)
        && lTargetVal && typeof lTargetVal === 'object' && !Array.isArray(lTargetVal)) {
        this._DeepMergeInto(lTargetVal as TranslationObject, lSourceVal as TranslationObject);
      } else {
        (pTarget as Record<string, unknown>)[lKey] = lSourceVal;
      }
    }
  }

  //#endregion
}
