import { Directive, Input, OnInit, OnDestroy, inject, effect } from '@angular/core';
import { TranslateContextService } from './TranslateContextService';

/**
 * Directive de déclaration du namespace i18n sur un élément parent.
 *
 * Rôle :
 *  - Déclare le namespace du composant courant via l'input `[ns]`
 *  - Le pousse dans le `TranslateContextService` (pile LIFO) pour que les pipes
 *    `tkey` enfants le lisent automatiquement SANS avoir à le passer en argument.
 *
 * Exemple :
 * ```html
 * <!-- Avant : 17 computed<string> dans le TS pour 17 labels -->
 * <!-- Après : 0 attribut TS, juste la directive + le pipe dans le HTML -->
 * <section appTranslate [ns]="'crm-projets'">
 *   <h1>{{ 'title' | tkey }}</h1>
 *   <h2>{{ 'subtitle' | tkey }}</h2>
 *   <p>{{ 'counter' | tkey : { count: 5 } }}</p>
 * </section>
 * ```
 *
 * Pourquoi une directive et pas un simple input `[ns]` sur le composant racine ?
 *  - La directive fonctionne avec **n'importe quel** élément HTML ou composant, sans
 *    avoir à modifier les composants enfants (Grid, Popup, FilterBar, etc.).
 *  - Elle permet de redéfinir localement le namespace (ex: une grid embarquée dans
 *    une page CRM a son propre namespace 'recherches' sans affecter la page parente).
 *
 * Gestion des changements dynamiques de `[ns]` :
 *  - Si `[ns]` change en cours de vie (rare, ex: navigation entre sous-routes avec
 *    namespaces différents), un `effect()` Angular détecte le changement et met à jour
 *    la pile automatiquement.
 *
 * Cycle de vie :
 *  - `ngOnInit` : push du namespace sur la pile.
 *  - `ngOnDestroy` : pop du namespace (restaure celui du parent).
 *  - `effect()` : détecte les changements dynamiques de `[ns]` et met à jour la pile.
 */
@Directive({
  selector: '[appTranslate]',
  standalone: true
})
export class TranslateDirective implements OnInit, OnDestroy
{
  //#region Attribute
  /**
   * Service de contexte i18n : pile de namespaces pour les composants imbriqués.
   */
  private readonly _Context: TranslateContextService = inject(TranslateContextService);

  /**
   * Dernier namespace poussé sur la pile (pour détecter les changements dynamiques).
   * - cm - Null tant que ngOnInit n'a pas été appelé (avant l'init, on ne push rien).
   */
  private _PushedNamespace: string | null = null;
  //#endregion

  //#region Input
  /**
   * Namespace i18n à déclarer dans le contexte des enfants.
   * - cm - Convention : nom du dossier de la view (ex: 'crm-projets', 'recherches').
   * - cm - Toutes les pipes `tkey` enfants utiliseront ce namespace pour résoudre
   * - cm - leurs clés (ex: `'title' | tkey` -> `'crm-projets.title'`).
   *
   * @example
   * ```html
   * <section appTranslate [ns]="'crm-projets'">
   *   <h1>{{ 'title' | tkey }}</h1>
   * </section>
   * ```
   */
  @Input({ required: true, alias: 'ns' })
  public set Ns(pNamespace: string)
  {
    this._Ns = pNamespace ?? '';
    // - cm - Si ngOnInit a déjà été appelé, on met à jour la pile dynamiquement.
    // - cm - L'effect ci-dessous détectera le changement et fera le swap.
  }
  public get Ns(): string
  {
    return this._Ns;
  }
  private _Ns: string = '';
  //#endregion

  //#region CTOR
  /**
   * Initialise la directive : crée un effect qui réagit aux changements de namespace.
   * - cm - L'effect lit `this.Ns` et appelle `UpdateNamespace()` qui gère la pile.
   * - cm - Angular exécute l'effect APRÈS la 1ère détection de changement, ce qui
   * - cm - garantit que `ngOnInit` a déjà fait le push initial.
   */
  public constructor()
  {
    // - cm - Effect réactif : se déclenche à chaque changement de `this.Ns`.
    // - cm - C'est ici qu'on gère les changements dynamiques de namespace.
    effect(() =>
    {
      const lNamespace: string = this._Ns;
      // - cm - Ne rien faire si ngOnInit n'a pas encore été appelé (initialisation
      // - cm - en cours, l'effect se déclenche une 1ère fois avant ngOnInit).
      if (this._PushedNamespace === null)
      {
        return;
      }
      // - cm - Namespace a changé après l'init : on swap dans la pile
      if (lNamespace !== this._PushedNamespace)
      {
        this._Context.PopNamespace();
        this._Context.PushNamespace(lNamespace);
        this._PushedNamespace = lNamespace;
      }
    });
  }
  //#endregion

  //#region Lifecycle
  /**
   * Pousse le namespace sur la pile du contexte i18n.
   * - cm - Tous les pipes `tkey` enfants liront ce namespace jusqu'à la destruction.
   */
  public ngOnInit(): void
  {
    this._Context.PushNamespace(this._Ns);
    this._PushedNamespace = this._Ns;
  }

  /**
   * Restaure le namespace parent depuis la pile.
   * - cm - Indispensable pour les composants imbriqués (ex: page > grid > column) :
   * - cm - la destruction de la grid ne doit pas laisser le namespace de la page
   * - cm - "écrasé" par celui de la grid.
   */
  public ngOnDestroy(): void
  {
    if (this._PushedNamespace !== null)
    {
      this._Context.PopNamespace();
      this._PushedNamespace = null;
    }
  }
  //#endregion
}
