import { Pipe, PipeTransform, inject } from '@angular/core';
import { TranslateKeyResolver } from './TranslateKeyResolver';
import { TranslateContextService } from './TranslateContextService';

/**
 * Options de transformation passées au pipe `tkey`.
 * - cm - Permet de passer le namespace et les params d'interpolation
 * - cm - dans un seul argument typé (au lieu d'une liste positionnelle).
 * - cm - Ex: `'counter' | tkey : { ns: 'crm-projets', params: { count: 5 } }`.
 */
export interface ITranslateKeyOptions
{
  /** Namespace i18n du composant (optionnel, ex: 'crm-projets'). Lu depuis le contexte si absent. */
  ns?: string;
  /** Paramètres d'interpolation (optionnel, ex: `{ count: 5 }`). */
  params?: Record<string, unknown>;
}

/**
 * Pipe pur de traduction i18n avec résolution automatique du namespace.
 *
 * Remplace les `computed<string>` qui ne font QUE wrapper `Translate.translate(key)`.
 * Au lieu de créer 17 attributs `PageTitle`, `SubtitleI18n`, `ConfirmDeleteTitleI18n`...
 * dans le TS, on déclare le namespace UNE fois et on utilise le pipe dans le HTML.
 *
 * @example
 * ```html
 * <!-- Avec namespace déclaré sur l'élément racine (forme recommandée) -->
 * <section appTranslate [ns]="'crm-projets'">
 *   <h1>{{ 'title' | tkey }}</h1>
 *   <h2>{{ 'subtitle' | tkey }}</h2>
 *   <p>{{ 'counter' | tkey : { params: { count: 5 } } }}</p>
 * </section>
 *
 * <!-- Avec namespace passé en argument (forme ponctuelle) -->
 * <app-grid-column [Label]="'nom_projet' | tkey : { ns: 'recherches' }" />
 * <app-popup [title]="'popup.confirmDeleteTitle' | tkey : { ns: 'crm-projets' }" />
 * ```
 *
 * **Réactivité** :
 *  - Le pipe est `pure: true` (défaut) : il se ré-évalue si ses arguments changent
 *    OU si une dépendance réactive (signal) lue dans le pipe change.
 *  - Le `InstantTick()` du `TranslationService` est lu en interne : Angular détecte
 *    la dépendance au signal et force la réévaluation au chargement du dictionnaire
 *    ou au changement de langue.
 *  - Le `Namespace()` du contexte est également lu : la directive parente `appTranslate`
 *    qui pousse un namespace déclenche la réévaluation du pipe.
 *
 * **Pourquoi `pure: false` (et pas `pure: true)** :
 *  - `pure: true` ne réévalue le pipe QUE si ses arguments changent. Lire un signal
 *    (`InstantTick()`, `Namespace()`) à l'intérieur de `transform()` ne crée PAS
 *    de dépendance réactive pour le pipe lui-même : Angular ne détecte pas les
 *    lectures de signaux faites dans le pipe comme déclencheurs de réévaluation.
 *  - Conséquence : avec `pure: true`, le changement de langue (qui bump `InstantTick`)
 *    ne ré-évalue PAS les pipes `tkey` déjà rendus. Les labels restent figés.
 *  - `pure: false` force la réévaluation à chaque cycle de change detection. Comme
 *    on a un système qui re-déclenche la CD au changement de langue (via le
 *    `markForCheck()` de `BaseComponent` sur `TranslationLoaded`/`LanguageChanged`),
 *    le pipe sera réévalué et affichera la nouvelle traduction.
 *  - Coût : léger (le pipe est synchrone, ne fait qu'un `instant()`).
 *
 * **Convention de nommage** :
 *  - Le pipe est exposé sous le nom court `tkey` (à privilégier dans les templates).
 */
@Pipe({
  name: 'tkey',
  standalone: true,
  pure: false
})
export class TranslateKeyPipe implements PipeTransform
{
  //#region Attribute
  /**
   * Service de résolution des clés i18n.
   */
  private readonly _Resolver: TranslateKeyResolver = inject(TranslateKeyResolver);

  /**
   * Service de contexte : permet au pipe de lire le namespace déclaré par la
   * directive parente `appTranslate` via `[ns]="..."`.
   * - cm - Si aucun namespace n'est passé en argument et que le contexte est vide,
   * - cm - le pipe retourne la clé brute (mode dégradé : pas de namespace).
   */
  private readonly _Context: TranslateContextService = inject(TranslateContextService);
  //#endregion

  //#region Methods

  /**
   * Transforme un chemin de clé en chaîne traduite.
   * - cm - Le pipe est `pure: true` (défaut) : Angular ne le rappelle que si les
   * - cm - arguments OU le namespace du contexte changent. La lecture de
   * - cm - `InstantTick()` à l'intérieur du resolver crée une dépendance réactive
   * - cm - qui force la réévaluation au chargement du dictionnaire ou au changement
   * - cm - de langue.
   *
   * Résolution du namespace (par ordre de priorité) :
   *  1. `options.ns` explicite (ex: `'title' | tkey : { ns: 'crm-projets' }`)
   *  2. Namespace du contexte (déclaré par `appTranslate [ns]` sur un parent)
   *  3. Aucun namespace : la clé est utilisée telle quelle (utile pour les clés globales)
   *
   * @param pPath Chemin de la clé (ex: 'title', 'filters.nom')
   * @param pOptions Options : `{ ns?, params? }` (optionnel)
   * @returns Chaîne traduite (ou la clé brute si non trouvée)
   */
  public transform(pPath: string, pOptions?: ITranslateKeyOptions | null): string
  {
    if (!pPath)
    {
      return '';
    }
    // - cm - Lecture du namespace depuis le contexte : crée une dépendance réactive
    // - cm - au signal TranslateContextService.Namespace(). Angular détecte cette
    // - cm - dépendance et force la réévaluation du pipe si le namespace change
    // - cm - (ex: navigation entre pages qui déclarent des namespaces différents).
    const lContextNs: string = this._Context.Namespace();

    // - cm - Normalisation des arguments : seul l'objet options est supporté
    // - cm - (cf. ITranslateKeyOptions).
    let lNamespace: string = lContextNs;
    let lParams: Record<string, unknown> | undefined;

    if (pOptions && typeof pOptions === 'object')
    {
      // - cm - Forme objet : `'path' | tkey : { ns: '...', params: {...} }`
      // - cm - Distinction explicite : si `ns` est PRÉSENT dans l'objet (même vide),
      // - cm - on respecte la valeur (chaîne vide = pas de namespace). Sinon,
      // - cm - on fallback sur le namespace du contexte (appTranslate parent).
      // - cm - Avant : `(pOptions.ns && ...)` traitait ns:'' comme absent, ce qui
      // - cm - forçait le préfixe par le contexte (ex: 'grid') sur les clés déjà
      // - cm - namespace-préfixées par l'appelant (ex: 'recrutements.contact_id').
      // - cm - Conséquence : les LabelCle des grilles affichaient 'grid.<key>' au
      // - cm - lieu de la traduction attendue.
      if ('ns' in pOptions)
      {
        lNamespace = pOptions.ns ?? '';
      }
      else
      {
        lNamespace = lContextNs;
      }
      lParams = pOptions.params;
    }

    return this._Resolver.ResolveReactive(lNamespace, pPath, lParams);
  }

  //#endregion
}