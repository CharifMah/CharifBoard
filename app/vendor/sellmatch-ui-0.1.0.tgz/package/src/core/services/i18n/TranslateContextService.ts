import { Injectable, signal, Signal, WritableSignal } from '@angular/core';

/**
 * Service de contexte pour le namespace i18n courant.
 *
 * Rôle : permettre à la directive `appTranslate` (placée sur un élément parent)
 * de déclarer un namespace i18n, et au pipe `TranslateKeyPipe` (utilisé dans les
 * enfants) de le lire automatiquement SANS avoir à le passer en argument partout.
 *
 * Exemple :
 * ```html
 * <section appTranslate [ns]="'crm-projets'">
 *   <h1>{{ 'title' | tkey }}</h1>            <!-- lit ns = 'crm-projets' du contexte -->
 *   <h2>{{ 'subtitle' | tkey }}</h2>         <!-- idem -->
 * </section>
 * ```
 *
 * Alternative (sans directive parente) :
 * ```html
 * <h1>{{ 'title' | tkey : 'crm-projets' }}</h1>  <!-- ns passé en argument -->
 * ```
 *
 * Implémentation : un signal global. Angular garantit que la directive met à jour
 * le signal avant le rendu des enfants (le pipe lit le signal au moment de la
 * transformation, qui a lieu APRÈS le binding des inputs de la directive parente).
 *
 * Pourquoi un signal et pas un Subject ?
 *  - Le pipe est `pure: true` (défaut) : Angular ne le ré-évalue que si la valeur
 *    qu'il lit change. Un Subject ne déclencherait pas la réévaluation car Angular
 *    ne sait pas s'y abonner. Un signal, OUI : le pipe lit `Namespace()` et Angular
 *    détecte la dépendance automatiquement.
 *
 * Pourquoi `providedIn: 'root'` et pas `providers: [TranslateContext]` par composant ?
 *  - Évite d'avoir à injecter le service dans chaque composant pour qu'il soit
 *    disponible pour ses enfants. Le service est global : la directive push, les
 *    pipes pop en remontant l'arbre.
 *  - Trade-off : si plusieurs composants utilisent des namespaces différents en
 *    même temps sur la même page, il faut gérer la pile (push/pop). Cf. la
 *    directive `appTranslate` qui gère ça via `_PushNamespace` / `_PopNamespace`.
 */
@Injectable({
  providedIn: 'root'
})
export class TranslateContextService
{
  //#region Attribute
  /**
   * Namespace courant du contexte i18n (utilisé par les pipes `tkey` enfants).
   * - cm - String vide = pas de namespace par défaut (le pipe attend un argument explicite).
   */
  private readonly _Namespace: WritableSignal<string> = signal<string>('');

  /**
   * Pile de namespaces pour gérer les composants imbriqués (ex: page > grid > column).
   * - cm - Permet à un enfant de redéfinir son namespace sans écraser celui du parent.
   * - cm - Quand l'enfant se détruit, on restaure le namespace parent.
   */
  private readonly _Stack: string[] = [];
  //#endregion

  //#region Property
  /**
   * Signal readonly exposant le namespace courant.
   * - cm - Lu par `TranslateKeyPipe` pour connaître le namespace à préfixer.
   */
  public readonly Namespace: Signal<string> = this._Namespace.asReadonly();
  //#endregion

  //#region Methods

  /**
   * Pousse un namespace sur la pile et le définit comme namespace courant.
   * - cm - À appeler dans `ngOnInit` de la directive `appTranslate`.
   * @param pNamespace Le namespace à définir (ex: 'crm-projets')
   */
  public PushNamespace(pNamespace: string): void
  {
    // - cm - Empile l'ancien namespace pour pouvoir le restaurer au pop
    this._Stack.push(this._Namespace());
    this._Namespace.set(pNamespace);
  }

  /**
   * Restaure le namespace parent depuis la pile.
   * - cm - À appeler dans `ngOnDestroy` de la directive `appTranslate`.
   */
  public PopNamespace(): void
  {
    const lPrevious: string | undefined = this._Stack.pop();
    this._Namespace.set(lPrevious ?? '');
  }

  /**
   * Lit le namespace courant.
   * - cm - Méthode utilitaire pour les composants qui veulent lire le namespace
   * - cm - sans passer par le signal (ex: dans des subscriptions RxJS).
   * @returns Le namespace courant (peut être vide)
   */
  public GetNamespace(): string
  {
    return this._Namespace();
  }

  //#endregion
}
