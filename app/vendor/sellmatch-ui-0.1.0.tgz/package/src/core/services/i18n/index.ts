/**
 * Barrel file du module i18n.
 * Exporte tous les artefacts du système de traduction générique.
 *
 * Usage :
 * ```typescript
 * import { TranslationService, TranslateKeyPipe, TranslateDirective } from '../../../core/services/i18n';
 * ```
 */
export { TranslationService } from './TranslationService';
export { TranslateKeyResolver } from './TranslateKeyResolver';
export { TranslateKeyPipe } from './TranslateKeyPipe';
export { TranslateDirective } from './TranslateDirective';
export { TranslateContextService } from './TranslateContextService';
