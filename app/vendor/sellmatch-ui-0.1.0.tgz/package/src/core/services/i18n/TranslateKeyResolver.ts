import { Injectable, inject, Signal } from '@angular/core';
import { TranslationService } from './TranslationService';

/**
 * Service de résolution générique de clés i18n.
 *
 * Rôle :
 *  - Prend un `namespace` (ex: 'crm-projets') + un `path` (ex: 'title', 'filters.nom')
 *  - Reconstruit automatiquement la clé complète (`crm-projets.title`)
 *  - Délègue la traduction au `TranslationService` (réactif via `InstantTick`)
 *
 * Pourquoi un service séparé ?
 *  - Centralise la convention "namespace = dossier de la view"
 *  - Évite d'avoir N getters/computed `PageTitle`, `SubtitleI18n`, `ConfirmDeleteTitleI18n`...
 *    dans chaque composant, qui ne font QUE wrapper `Translate.translate(key)`.
 *  - Permet au pipe `TranslateKeyPipe` et à la directive `appTranslate` de partager
 *    la même logique de résolution (DRY).
 *
 * Convention de nommage :
 *  - Le `namespace` est fourni explicitement par le composant (input `[ns]` du pipe
 *    ou de la directive). Il correspond au nom du dossier de la view (ex: 'crm-projets').
 *  - Le `path` peut être une simple clé ('title') ou un chemin pointé ('filters.nomPlaceholder').
 *  - La clé résolue est : `${namespace}.${path}`.
 *
 * Réactivité :
 *  - Toutes les méthodes lisent `InstantTick()` pour s'abonner au chargement du dictionnaire
 *    et aux changements de langue (sinon, le 1er render affiche la clé brute).
 *  - À utiliser dans des `computed()`, des pipes ou des templates Angular : la dépendance
 *    au signal `InstantTick` est détectée automatiquement par Angular.
 *
 * Usage typique :
 * ```typescript
 * // Avant : 17 attributs `computed` dans le TS pour 17 labels
 * public readonly PageTitle = computed(() => this.Translate.translate('crm-projets.title'));
 *
 * // Après : 0 attribut dans le TS
 * // Dans le HTML : {{ 'title' | tkey : 'crm-projets' }}
 * // Ou dans une prop : [Label]="'nom_projet' | tkey : 'recherches'"
 * ```
 */
@Injectable({
  providedIn: 'root'
})
export class TranslateKeyResolver
{
  //#region Attribute
  /**
   * Service de traduction sous-jacent (wrapper ngx-translate + loader registry).
   * - cm - Injecté dans le CONSTRUCTEUR (et non dans les méthodes) car `inject()`
   * - cm - ne peut être appelé que dans un contexte d'injection (CTOR, factory,
   * - cm - field initializer, runInInjectionContext). Hors de ces contextes (ex:
   * - cm - appel depuis un pipe pendant le rendering), `inject()` lève NG0203.
   * - cm - En stockant la dépendance dans un attribut privé, les méthodes publiques
   * - cm - (Resolve, ResolveReactive, BuildKey) peuvent être appelées depuis
   * - cm - n'importe quel contexte (pipe, computed, change detection cycle...).
   */
  private readonly _Translate: TranslationService = inject(TranslationService);
  //#endregion

  //#region Methods

  /**
   * Résout une clé i18n à partir d'un namespace et d'un chemin, en mode **réactif**.
   * - cm - Lit `InstantTick()` pour s'abonner au chargement du dictionnaire.
   * - cm - Destiné aux `computed()` Angular (la dépendance au signal est détectée
   * - cm - automatiquement et déclenche le recalcul à chaque bump).
   *
   * @param pNamespace Namespace du composant (ex: 'crm-projets'). Si vide, le path est utilisé tel quel.
   * @param pPath Chemin de la clé dans le namespace (ex: 'title', 'filters.nom').
   * @param pParams Paramètres d'interpolation (optionnel, ex: `{ count: 3 }`).
   * @returns La chaîne traduite (ou la clé brute si non trouvée).
   */
  public ResolveReactive(pNamespace: string | null | undefined, pPath: string, pParams?: object): string
  {
    // - cm - Lecture du tick : abonne ce computed au chargement i18n
    this._Translate.InstantTick();
    return this.Resolve(pNamespace, pPath, pParams);
  }

  /**
   * Résout une clé i18n à partir d'un namespace et d'un chemin, en mode **synchrone**.
   * - cm - N'abonne PAS au tick : à utiliser dans les contextes où la réactivité
   * - cm - n'est pas nécessaire (ex: subscriptions RxJS déjà établies).
   *
   * @param pNamespace Namespace du composant (ex: 'crm-projets'). Si vide, le path est utilisé tel quel.
   * @param pPath Chemin de la clé dans le namespace (ex: 'title', 'filters.nom').
   * @param pParams Paramètres d'interpolation (optionnel, ex: `{ count: 3 }`).
   * @returns La chaîne traduite (ou la clé brute si non trouvée).
   */
  public Resolve(pNamespace: string | null | undefined, pPath: string, pParams?: object): string
  {
    const lKey: string = this.BuildKeyInternal(pNamespace, pPath);
    return this._Translate.translate(lKey, pParams);
  }

  /**
   * Construit la clé i18n complète à partir d'un namespace et d'un path.
   * - cm - Méthode publique pour exposer la convention aux appelants externes
   * - cm - (ex: tests, debug). Délègue à la méthode interne.
   *
   * @param pNamespace Namespace du composant (ex: 'crm-projets')
   * @param pPath Chemin de la clé (ex: 'title', 'filters.nom')
   * @returns Clé i18n complète (ex: 'crm-projets.title')
   */
  public BuildKey(pNamespace: string | null | undefined, pPath: string): string
  {
    return this.BuildKeyInternal(pNamespace, pPath);
  }

  /**
   * Expose le signal réactif `InstantTick` du `TranslationService`.
   * - cm - Permet au pipe et à la directive de s'abonner au tick sans dupliquer
   * - cm - la logique de souscription.
   *
   * @returns Signal Angular incrémenté à chaque chargement/changement de langue
   */
  public GetInstantTick(): Signal<number>
  {
    return this._Translate.InstantTick;
  }

  //#endregion

  //#region Private Methods

  /**
   * Construit la clé i18n : `${namespace}.${path}` ou `path` si pas de namespace.
   * - cm - Méthode privée interne : PascalCase strict (règle ESLint du projet).
   * - cm - Préfixe `Internal` pour distinguer du wrapper public `BuildKey`.
   * @param pNamespace Namespace du composant
   * @param pPath Chemin de la clé
   * @returns Clé complète
   */
  private BuildKeyInternal(pNamespace: string | null | undefined, pPath: string): string
  {
    const lNamespace: string = (pNamespace ?? '').trim();
    const lPath: string = (pPath ?? '').trim();
    if (lNamespace.length === 0)
    {
      return lPath;
    }
    // - cm - Si le path commence déjà par le namespace, on ne double pas le préfixe
    // - cm - (sécurité pour les appels qui passent déjà une clé complète).
    if (lPath === lNamespace || lPath.startsWith(`${lNamespace}.`))
    {
      return lPath;
    }
    return `${lNamespace}.${lPath}`;
  }

  //#endregion
}
