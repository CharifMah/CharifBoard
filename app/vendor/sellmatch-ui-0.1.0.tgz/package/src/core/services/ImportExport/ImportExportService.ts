import { Injectable } from '@angular/core';
import axios, { AxiosInstance } from 'axios';
import { environment } from '../../../environments/environment';

/**
 * Résultat d'un import CSV.
 */
export interface ImportResult {
  created: number;
  updated: number;
  errors: number;
  errorDetails: string[];
}

/**
 * Service d'import/export CSV pour les entités CRM.
 */
@Injectable({
  providedIn: 'root'
})
export class ImportExportService {
  private readonly _apiUrl: string;
  private readonly _axiosInstance: AxiosInstance;

  constructor() {
    this._apiUrl = `${environment.apiUrl}/ImportExport`;

    this._axiosInstance = axios.create({
      withCredentials: true // - cm - Cookie HttpOnly pour l'authentification
    });
  }

  /**
   * Importe un fichier CSV d'opportunités.
   * @param pFile Fichier CSV (UTF-8, séparateur point-virgule)
   * @returns Résultat de l'import
   */
  async importOpportunities(pFile: File): Promise<ImportResult> {
    const lFormData = new FormData();
    lFormData.append('pFile', pFile);

    const lResponse = await this._axiosInstance.post<ImportResult>(
      `${this._apiUrl}/opportunities/import`,
      lFormData
    );

    return lResponse.data;
  }

  /**
   * Exporte les opportunités au format CSV.
   * @returns Blob du fichier CSV téléchargeable
   */
  async exportOpportunities(): Promise<Blob> {
    const lResponse = await this._axiosInstance.post(
      `${this._apiUrl}/opportunities/export`,
      null,
      {
        responseType: 'blob'
      }
    );

    return lResponse.data as Blob;
  }

  /**
   * Déclenche le téléchargement d'un Blob dans le navigateur.
   * @param pBlob Contenu du fichier
   * @param pFileName Nom du fichier
   */
  downloadBlob(pBlob: Blob, pFileName: string): void {
    const lUrl = window.URL.createObjectURL(pBlob);
    const lLink = document.createElement('a');
    lLink.href = lUrl;
    lLink.download = pFileName;
    document.body.appendChild(lLink);
    lLink.click();
    document.body.removeChild(lLink);
    window.URL.revokeObjectURL(lUrl);
  }
}
