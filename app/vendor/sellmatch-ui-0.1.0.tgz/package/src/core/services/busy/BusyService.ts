import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

interface BusyState
{
  show: boolean;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class BusyService
{
  private busySubject = new BehaviorSubject<BusyState>({ show: false, message: '' });
  busy$ = this.busySubject.asObservable();

  // - cm - Sémaphore : compte les appels show() non encore libérés par hide().
  // Le busy reste visible tant que le compteur est > 0, et s'éteint dès qu'il retombe à 0.
  private requestCount = 0;

  /**
   * Affiche le busy (incrémente le sémaphore). Ne s'éteint que quand tous les show() sont libérés.
   * @param pMessage Message optionnel affiché sous le spinner
   */
  show(pMessage = 'Chargement...'): void
  {
    this.requestCount++;
    // - cm - On ne met à jour l'état que s'il passe de caché -> visible (évite les émissions redondantes)
    if (!this.busySubject.value.show)
    {
      this.busySubject.next({ show: true, message: pMessage });
    }
  }

  /**
   * Libère un appel show() (décrémente le sémaphore). N'éteint le busy que quand le compteur retombe à 0.
   */
  hide(): void
  {
    if (this.requestCount > 0)
    {
      this.requestCount--;
    }

    if (this.requestCount <= 0)
    {
      this.requestCount = 0;
      if (this.busySubject.value.show)
      {
        this.busySubject.next({ show: false, message: '' });
      }
    }
  }

  /**
   * Force la fermeture du busy et réinitialise le sémaphore (usage de dérogation / cleanup).
   */
  forceHide(): void
  {
    this.requestCount = 0;
    if (this.busySubject.value.show)
    {
      this.busySubject.next({ show: false, message: '' });
    }
  }

  /**
   * Exécute une tâche asynchrone en encadrant automatiquement show/hide (sémaphore).
   * Le busy ne s'éteint que quand toutes les tâches concurrentes sont résolues.
   * @param pTask La promise à exécuter
   * @param pMessage Message optionnel affiché pendant la tâche
   * @returns Le résultat de la promise
   */
  async run<T>(pTask: Promise<T>, pMessage = 'Chargement...'): Promise<T>
  {
    this.show(pMessage);
    try
    {
      return await pTask;
    }
    finally
    {
      this.hide();
    }
  }
}
