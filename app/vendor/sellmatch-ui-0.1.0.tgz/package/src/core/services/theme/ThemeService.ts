import { Injectable, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SessionStorageService } from '../../../core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { UsersService } from '../../../core/sellmatchdb/services/users/users.service';
import { SettingsService } from '../../../core/sellmatchdb/services/settings/settings.service';
import { SettingsDTO } from '../../../core/sellmatchdb/dto/settings/settings.dto';

/**
 * Type de thème disponible pour l'application.
 */
export type ETheme = 'light' | 'dark';

/**
 * Cle logique du setting BDD stockant la preference theme utilisateur.
 * - cm - Table `settings` GENERIQUE (Key/Value/ValueType/UserId), clee partagee
 * avec `langue` deja utilisee dans profil.component. Le ThemeService suit
 * le meme pattern de persistance.
 */
export const THEME_SETTING_KEY: string = 'ui.theme';

/**
 * Service de gestion du thème (clair/sombre) de l'application.
 * Persiste le choix utilisateur dans le localStorage ET dans la table BDD
 * `settings` (cle `ui.theme`, scope par userId) pour suivre l'utilisateur
 * d'un device a l'autre / d'un navigateur a l'autre.
 * SSR-safe : aucune interaction DOM côté serveur.
 */
@Injectable({
  providedIn: 'root'
})
export class ThemeService
{
  //#region Attributes
  /** Clé de stockage du thème en localStorage. */
  private readonly _StorageKey: string = 'sellmatch-theme';

  /** Indique si le code s'exécute côté navigateur. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Service de sessionStorage pour fallback. */
  private readonly _SessionStorage: SessionStorageService = inject(SessionStorageService);

  /** Service utilisateur courant (pour lire/ecrire le setting BDD `ui.theme`). */
  private readonly _UsersService: UsersService = inject(UsersService);

  /** Service settings generique (upsert cle/valeur en BDD). */
  private readonly _SettingsService: SettingsService = inject(SettingsService);

  /**
   * Cache memoire du dernier theme applique depuis la BDD pour eviter
   * d'ecraser la pref serveur si l'utilisateur a plusieurs onglets ouverts.
   * - cm - Cle = `${userId}:${THEME_SETTING_KEY}` pour supporter le multi-user
   * (changement de compte sur la meme session navigateur).
   */
  private readonly _ServerThemeCache: Map<string, ETheme> = new Map<string, ETheme>();
  //#endregion

  //#region Properties
  /** Signal réactif exposant le thème courant. */
  public readonly CurrentTheme = signal<ETheme>('light');

  /**
   * Indique qu'une persistance BDD du theme est en cours (fire-and-forget).
   * - cm - Permet aux composants de la grid settings d'afficher leur skeleton
   * pendant l'appel upsert (cf. profil.component.SettingsLoading).
   * Passe a `true` au debut de `_PersistThemeToServer`, a `false` au retour.
   * SSR-safe : reste `false` cote serveur (le toggle n'est pas appele en SSR).
   */
  public readonly IsPersisting = signal<boolean>(false);

  /** Indique si le thème sombre est actif. */
  public get IsDark(): boolean
  {
    return this.CurrentTheme() === 'dark';
  }
  //#endregion

  //#region Methods
  /**
   * Initialise le thème au démarrage de l'application.
   * Priorité : localStorage > préférence système > clair.
   * - cm - Ne touche PAS a la BDD : le chargement depuis le profil user
   * se fait via `SyncFromUserSettings()` une fois le UsersService charge.
   * Cela evite une race condition au boot (UsersService pas encore ready).
   */
  public Init(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    const lStored = this._ReadStoredTheme();
    const lTheme: ETheme = lStored ?? this._DetectSystemPreference();

    this.ApplyTheme(lTheme);
  }

  /**
   * Synchronise le theme courant avec le setting BDD de l'utilisateur connecte.
   * - cm - Appele une fois que le UsersService a resolu `currentUser` (apres
   * login OU loadUserFromStorage + refreshFromServer). Si un setting
   * `ui.theme` existe en BDD, il prend le pas sur le localStorage
   * (car le localStorage peut etre obsolete si l'utilisateur a change
   * de device ou vide son cache).
   * - cm - Idempotent : safe a appeler plusieurs fois (pas d'effet si
   * le theme deja applique correspond au setting serveur).
   * @returns Promise resolue une fois la synchro terminee (best-effort).
   */
  public async SyncFromUserSettings(): Promise<void>
  {
    if (!this._IsBrowser) return;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id)
    {
      // - cm - Pas d'utilisateur connecte : on garde le theme local (localStorage/systeme).
      return;
    }
    const lUserId: number = lUser.id;
    const lSetting = this._FindThemeSetting(lUser.userSettings);
    if (!lSetting || !lSetting.value)
    {
      // - cm - Pas de setting serveur : on conserve le theme local. Pas de write auto
      // vers la BDD — l'utilisateur n'a pas explicitement toggle, donc on ne pollue
      // pas la table avec des valeurs implicites.
      return;
    }
    const lServerTheme = this._CoerceSettingValue(lSetting.value);
    if (!lServerTheme)
    {
      // - cm - Valeur invalide cote serveur (autre que 'light'/'dark') : on log et on garde le local.
      console.warn(`[ThemeService] Valeur de setting '${THEME_SETTING_KEY}' invalide : '${lSetting.value}'`);
      return;
    }
    this._ServerThemeCache.set(this._CacheKey(lUserId), lServerTheme);
    // - cm - On n'applique QUE si different du theme courant pour eviter un flash
    // inutile au boot (le localStorage a deja pu poser le bon theme).
    if (this.CurrentTheme() !== lServerTheme)
    {
      this.ApplyTheme(lServerTheme);
    }
  }

  /**
   * Bascule entre le thème clair et sombre.
   */
  public Toggle(): void
  {
    const lNext: ETheme = this.IsDark ? 'light' : 'dark';
    this.ApplyTheme(lNext);
  }

  /**
   * Applique explicitement un thème donné.
   * Pose l'attribut `data-theme` sur `<html>` ; les variables CSS sont
   * définies côté SCSS via `:root[data-theme='dark']` (spécificité + !important).
   * Persiste en localStorage (synchrone) ET en BDD (fire-and-forget) si user connecté.
   * @param pTheme Le thème à appliquer ('light' ou 'dark').
   */
  public ApplyTheme(pTheme: ETheme): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    this.CurrentTheme.set(pTheme);
    document.documentElement.setAttribute('data-theme', pTheme);
    this._WriteStoredTheme(pTheme);

    // - cm - Persistance BDD best-effort : on lance en arriere-plan sans bloquer l'UI.
    // La resolution de la promesse est silencieuse (succes = cache, echec = warning console).
    void this._PersistThemeToServer(pTheme);
  }

  /**
   * Persiste le theme en BDD via SettingsService.upsertUserSetting.
   * - cm - Best-effort : ne leve pas d'exception, ne bloque pas l'UI.
   * Si l'utilisateur n'est pas connecte, no-op silencieux (le localStorage
   * reste la seule source de verite pour la session anonyme).
   * - cm - Compare avec `_ServerThemeCache` pour eviter une boucle d'ecriture
   * quand `SyncFromUserSettings` declenche un `ApplyTheme` (qui rappellerait
   * `_PersistThemeToServer` avec la meme valeur).
   * - cm - Met a jour `IsPersisting` (signal public) debut/fin pour que les
   * composants UI puissent afficher leur skeleton pendant l'appel reseau.
   */
  private async _PersistThemeToServer(pTheme: ETheme): Promise<void>
  {
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return;
    const lUserId: number = lUser.id;
    const lCacheKey: string = this._CacheKey(lUserId);
    if (this._ServerThemeCache.get(lCacheKey) === pTheme)
    {
      // - cm - On vient de synchro depuis la BDD, pas la peine de re- POSTer la meme valeur.
      return;
    }
    this.IsPersisting.set(true);
    try
    {
      const lSaved = await this._SettingsService.upsertUserSetting(
        lUserId,
        THEME_SETTING_KEY,
        pTheme,
        'string'
      );
      if (lSaved)
      {
        this._ServerThemeCache.set(lCacheKey, pTheme);
        // - cm - On patche `currentUser.userSettings` pour que `getUserThemeSetting()`
        // (cf. profil.component si on l'expose plus tard) reflete immediatement la nouvelle
        // valeur sans devoir refetch /api/Users/me.
        if (lUser.userSettings)
        {
          const lExisting = this._FindThemeSetting(lUser.userSettings);
          if (lExisting && lExisting.id !== undefined)
          {
            lExisting.value = pTheme;
          }
          else
          {
            lUser.userSettings.push({
              id: lSaved.id,
              key: THEME_SETTING_KEY,
              value: pTheme,
              valueType: 'string',
              userId: lUserId
            });
          }
        }
      }
    }
    finally
    {
      this.IsPersisting.set(false);
    }
  }

  /**
   * Lit le thème persisté depuis le localStorage.
   * @returns Le thème stocké ou null si absent/invalide.
   */
  private _ReadStoredTheme(): ETheme | null
  {
    if (!this._IsBrowser) return null; // - cm - No-op côté serveur (SSR)

    const lRaw = localStorage.getItem(this._StorageKey);
    if (lRaw === 'light' || lRaw === 'dark') return lRaw;

    // - cm - Fallback sessionStorage pour compat
    const lFallback = this._SessionStorage.Restore<ETheme>(this._StorageKey);
    if (lFallback === 'light' || lFallback === 'dark') return lFallback;

    return null;
  }

  /**
   * Persiste le thème dans le localStorage.
   * @param pTheme Le thème à sauvegarder.
   */
  private _WriteStoredTheme(pTheme: ETheme): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    try
    {
      localStorage.setItem(this._StorageKey, pTheme);
    }
    catch (pError)
    {
      // - cm - Fallback sessionStorage si localStorage indisponible
      this._SessionStorage.Save(this._StorageKey, pTheme);
    }
  }

  /**
   * Détecte la préférence système de l'utilisateur.
   * @returns 'dark' si l'utilisateur préfère le sombre, sinon 'light'.
   */
  private _DetectSystemPreference(): ETheme
  {
    if (!this._IsBrowser) return 'light'; // - cm - No-op côté serveur (SSR)

    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  /**
   * Cherche le setting `ui.theme` dans le tableau `userSettings` du user.
   * - cm - Meme approche que `UsersService.getLangue()` : on accepte les cles
   * case-insensitive pour resister a une migration future du nom de cle.
   * - cm - Le type est `SettingsDTO` complet pour pouvoir lire `lExisting.id`
   * lors du patch de `currentUser.userSettings` apres upsert.
   */
  private _FindThemeSetting(pUserSettings: SettingsDTO[] | undefined): SettingsDTO | undefined
  {
    if (!pUserSettings) return undefined;
    return pUserSettings.find(pS => (pS.key ?? '').toLowerCase() === THEME_SETTING_KEY.toLowerCase());
  }

  /**
   * Convertit une valeur BDD (string libre) en ETheme strict.
   * - cm - Accepte uniquement 'light' / 'dark' (lowercase). Toute autre valeur
   * (null, 'auto', vide, etc.) renvoie null — l'appelant decide du fallback.
   */
  private _CoerceSettingValue(pValue: string | undefined | null): ETheme | null
  {
    if (!pValue) return null;
    const lNormalized = pValue.toLowerCase().trim();
    if (lNormalized === 'light' || lNormalized === 'dark')
    {
      return lNormalized as ETheme;
    }
    return null;
  }

  /**
   * Construit la cle de cache memoire `_ServerThemeCache` pour un user donne.
   */
  private _CacheKey(pUserId: number): string
  {
    return `${pUserId}:${THEME_SETTING_KEY}`;
  }
  //#endregion
}
