import * as signalR from '@microsoft/signalr';
import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Subject } from 'rxjs';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { ConversationsDTO } from '../../../core/sellmatchdb/dto/conversations/conversations.dto';
import { MessagesDTO } from '../../../core/sellmatchdb/dto/messages/messages.dto';
import { environment } from '../../../environments/environment';
import { ConversationsService } from '../../sellmatchdb/services/conversations/conversations.service';

@Injectable({ providedIn: 'root' })
export class ChatService extends BaseComponent {

  /** Indique si l'on s'exécute côté navigateur (SSR-safe) */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /**
   * Nettoie le contenu d'un message en supprimant les balises HTML
   * pour prévenir les attaques XSS côté client (defense-in-depth).
   * @param pContent Le contenu brut reçu
   * @returns Le contenu nettoyé, sans balises HTML
   */
  private static SanitizeContent(pContent: string | undefined | null): string {
    if (!pContent) return '';

    // - cm - Si on est côté navigateur, utiliser DOMParser pour un nettoyage robuste
    if (typeof DOMParser !== 'undefined') {
      const lDoc = new DOMParser().parseFromString(pContent, 'text/html');
      return lDoc.body.textContent || '';
    }

    // - cm - Fallback SSR : strip manuel des balises
    return pContent.replace(/<[^>]+>/g, '');
  }

  //#region Properties
  public ConversationService = inject(ConversationsService);
  private hubConnection: signalR.HubConnection | null = null;

  private conversationDeletedSubject = new Subject<number>();
  public conversationDeleted$ = this.conversationDeletedSubject.asObservable();

  // Subjects pour les événements
  private messageSubject = new BehaviorSubject<any>(null);
  public messageReceived$ = this.messageSubject.asObservable();

  private stateSubject = new BehaviorSubject<string>('Disconnected');
  public connectionState$ = this.stateSubject.asObservable();

  private conversationsSubject = new BehaviorSubject<ConversationsDTO[]>([]);
  public conversations$ = this.conversationsSubject.asObservable();

  private messagesLoadedSubject = new BehaviorSubject<MessagesDTO[] | null>(null);
  public messagesLoaded$ = this.messagesLoadedSubject.asObservable();

  private messageReadSubject = new Subject<{ messageId: number; readAt: Date }>();
  public messageRead$ = this.messageReadSubject.asObservable();

  private userTypingSubject = new Subject<{ conversationId: number; userId: number; userName: string }>();
  public userTyping$ = this.userTypingSubject.asObservable();

  private userJoinedSubject = new Subject<{ conversationId: number; userId: number; userName: string }>();
  public userJoined$ = this.userJoinedSubject.asObservable();

  private userLeftSubject = new Subject<{ conversationId: number; userId: number; userName: string }>();
  public userLeft$ = this.userLeftSubject.asObservable();

  // Nouveau subject pour les erreurs d'accès
  private accessErrorSubject = new Subject<string>();
  public accessError$ = this.accessErrorSubject.asObservable();

  //#endregion

  //#region Methods
  async connect(): Promise<void> {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)

    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${environment.SignalUrl}/messages?clientUrl=${encodeURIComponent(window.location.href)}`, {
        // - cm - Le token JWT est envoyé via le cookie HttpOnly (withCredentials: true)
        // SignalR lira automatiquement le cookie grâce à la config OnMessageReceived côté API
        withCredentials: true
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000, 60000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    // - cm - Timeout client: 30s sans ping serveur = deconnexion
    // Le serveur envoie un keepalive toutes les 15s, donc 30s laisse une marge
    this.hubConnection.serverTimeoutInMilliseconds = 30000;

    this.setupEventHandlers();
    this.setupConnectionStateHandlers();

    try {
      await this.hubConnection.start();
      console.log('✅ SignalR connecté');
      this.stateSubject.next('Connected');
    } catch (error) {
      console.error('❌ Erreur connexion SignalR:', error);
      this.stateSubject.next('Error');
      throw error;
    }
  }

  private setupEventHandlers(): void {
    if (!this.hubConnection) return;

    // Réception d'un message
    this.hubConnection.on('ReceiveMessage', (
      conversationId: number,
      messageId: number,
      senderId: number,
      senderName: string,
      content: string,
      timestamp: string
    ) => {
      // - cm - Sanitization XSS du contenu reçu
      const lSanitizedContent = ChatService.SanitizeContent(content);

      this.messageSubject.next({
        id: messageId,
        conversationId,
        senderId,
        senderName,
        content: lSanitizedContent,
        timestamp
      });
    });

    // Chargement des conversations
    this.hubConnection.on('LoadConversations', (conversations: ConversationsDTO[]) => {
      // - cm - Sanitization XSS de tous les messages dans chaque conversation
      const lSanitized = conversations?.map(conv => ({
        ...conv,
        messages: conv.messages?.map(msg => ({
          ...msg,
          content: ChatService.SanitizeContent(msg.content)
        }))
      }));
      this.conversationsSubject.next(lSanitized ?? []);
    });

    // Chargement des messages d'une conversation
    this.hubConnection.on('LoadMessages', (messages: MessagesDTO[]) => {
      // - cm - Sanitization XSS de chaque message chargé
      const lSanitized = messages?.map(msg => ({
        ...msg,
        content: ChatService.SanitizeContent(msg.content)
      }));
      this.messagesLoadedSubject.next(lSanitized ?? []);
    });

    // Notification de lecture
    this.hubConnection.on('MessageRead', (messageId: number, readAt: string) => {
      this.messageReadSubject.next({ messageId, readAt: new Date(readAt) });
    });

    // Indicateur de frappe
    this.hubConnection.on('UserTyping', (conversationId: number, userId: number, userName: string) => {
      this.userTypingSubject.next({ conversationId, userId, userName });
    });

    // Utilisateur rejoint
    this.hubConnection.on('UserJoinedConversation', (conversationId: number, userId: number, userName: string) => {
      console.log(`👤 ${userName} a rejoint la conversation ${conversationId}`);
      this.userJoinedSubject.next({ conversationId, userId, userName });
    });

    // Utilisateur parti
    this.hubConnection.on('UserLeftConversation', (conversationId: number, userId: number, userName: string) => {
      console.log(`👋 ${userName} a quitté la conversation ${conversationId}`);
      this.userLeftSubject.next({ conversationId, userId, userName });
    });

    // Erreur serveur ou d'accès
    this.hubConnection.on('Error', (errorMessage: string) => {
      console.error('❌ Erreur SignalR:', errorMessage);
      this.accessErrorSubject.next(errorMessage);
    });
  }

  private setupConnectionStateHandlers(): void {
    if (!this.hubConnection) return;

    this.hubConnection.onreconnecting((error) => {
      console.log('🔄 Reconnexion en cours...', error);
      this.stateSubject.next('Reconnecting');
    });

    this.hubConnection.onreconnected((connectionId) => {
      console.log('✅ Reconnecté avec ID:', connectionId);
      this.stateSubject.next('Connected');
    });

    this.hubConnection.onclose((error) => {
      console.log('🔴 Connexion fermée', error);
      this.stateSubject.next('Disconnected');
    });
  }

  async sendMessage(conversationId: number, content: string): Promise<void> {
    this.ensureConnected();
    await this.hubConnection!.invoke('SendMessage', conversationId, content);
  }

  async joinConversation(conversationId: number): Promise<void> {
    this.ensureConnected();
    await this.hubConnection!.invoke('JoinConversation', conversationId);
  }

  async leaveConversation(conversationId: number): Promise<void> {
    if (this.hubConnection?.state === signalR.HubConnectionState.Connected) {
      await this.hubConnection.invoke('LeaveConversation', conversationId);
    }
  }

  public async getConversations(): Promise<void> {
    try {
      this.ensureConnected();
      await this.hubConnection!.invoke('GetConversations');
    } catch (error) {
      console.log(error);
    }
  }

  async getMessages(conversationId: number, skip: number = 0, take: number = 50): Promise<void> {
    try {
      this.ensureConnected();
      await this.hubConnection!.invoke('GetMessages', conversationId, skip, take);
    } catch (error) {
      console.log(error);
    }
  }

  async markAsRead(messageId: number): Promise<void> {
    try {
      this.ensureConnected();
      await this.hubConnection!.invoke('MarkAsRead', messageId);
    } catch (error) {
      console.log(error);
    }
  }

  async sendTypingIndicator(conversationId: number): Promise<void> {
    try {
      if (this.hubConnection?.state === signalR.HubConnectionState.Connected) {
        await this.hubConnection.invoke('SendTypingIndicator', conversationId);
      }
    } catch (error) {
      console.log(error);
    }

  }

  // Méthodes utilitaires pour le débogage
  async testConversationAccess(conversationId: number): Promise<boolean> {
    try {
      this.ensureConnected();
      return await this.hubConnection!.invoke<boolean>('TestConversationAccess', conversationId);
    } catch (error) {
      return false;
    }
  }

  async getAccessibleConversationIds(): Promise<number[]> {
    try {
      this.ensureConnected();
      return await this.hubConnection!.invoke<number[]>('GetAccessibleConversationIds');
    } catch (error) {
      return [];
    }
  }

  private ensureConnected(): void {
    if (this.hubConnection?.state !== signalR.HubConnectionState.Connected) {
      throw new Error('SignalR non connecté');
    }
  }

  disconnect(): void {
    if (this.hubConnection) {
      this.hubConnection.stop();
      this.hubConnection = null;
      this.stateSubject.next('Disconnected');
    }
  }

  get isConnected(): boolean {
    return this.hubConnection?.state === signalR.HubConnectionState.Connected;
  }

  async deleteConversation(professionalId: number, opportunityId: number): Promise<void> {
    try {
      this.ensureConnected();
      await this.hubConnection!.invoke('DeleteConversation', professionalId, opportunityId);
    } catch (error) {
      console.log('Erreur lors de la suppression de la conversation:', error);
    }
  }
  //#endregion
}
