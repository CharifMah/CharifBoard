import { Injectable, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

import { SessionStorageService } from '../../../core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { UsersService } from '../../../core/sellmatchdb/services/users/users.service';
import { SettingsService } from '../../../core/sellmatchdb/services/settings/settings.service';

/**
 * Cle logique du setting BDD stockant la derniere URL authentifiee visitee.
 * - cm - Suit la convention de ThemeService (`ui.<feature>`). La table
 * `settings` est GENERIQUE (Key/Value/ValueType/UserId), le meme pattern
 * que `ui.theme` est applique pour permettre la synchro multi-device.
 */
export const LAST_URL_SETTING_KEY: string = 'ui.last_visited_url';

/**
 * Service de persistance de la derniere URL authentifiee visitee par l'utilisateur.
 * - cm - Permet, apres un relogin (session expiree, navigation privee, autre
 * navigateur), de rediriger l'utilisateur vers la page ou il etait plutot
 * que sur le dashboard par defaut.
 *
 * Strategie de persistance (meme approche que ThemeService) :
 * 1. localStorage (synchrone, source de verite immediate au boot).
 * 2. Table BDD `settings` cle `ui.last_visited_url` (fire-and-forget, best-effort)
 *    pour suivre l'utilisateur d'un device a l'autre.
 *
 * Regles de filtrage :
 * - On ne persiste QUE les URLs des navigations realisees par des utilisateurs
 *   connectes (cf. _SaveUrlIfAuthenticated). Pas de filtrage des routes
 *   publiques : la persistance est deja scopee aux sessions authentifiees, et
 *   toute URL publique persistee est de toute facon ecrasee par la prochaine
 *   navigation sur une route protegee.
 * - On ne persiste QUE si l'utilisateur est connecte (sinon pas de `userId`
 *   pour la cle BDD et pas d'interet fonctionnel).
 * - SSR-safe : aucune interaction localStorage / Router cote serveur.
 */
@Injectable({
  providedIn: 'root'
})
export class LastUrlService
{
  //#region Attributes
  /**
   * Cle localStorage de la derniere URL authentifiee.
   * - cm - Scope par userId pour resister au changement de compte sur la meme
   * session navigateur (cas multi-user sur la meme machine).
   */
  private static readonly _LocalStoragePrefix: string = 'sellmatch-last-url-';

  /** Indique si le code s'exécute côté navigateur. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Router Angular pour s'abonner aux NavigationEnd. */
  private readonly _Router: Router = inject(Router);

  /** Service de sessionStorage pour fallback. */
  private readonly _SessionStorage: SessionStorageService = inject(SessionStorageService);

  /** Service utilisateur courant (pour lire le userId). */
  private readonly _UsersService: UsersService = inject(UsersService);

  /** Service settings generique (upsert cle/valeur en BDD). */
  private readonly _SettingsService: SettingsService = inject(SettingsService);

  /**
   * Cache memoire du dernier userId traite. Evite d'ecrire plusieurs fois
   * pour la meme navigation successive (cf. ThemeService._ServerThemeCache).
   */
  private _TrackedUserId: number | null = null;

  /**
   * Indique qu'une persistance BDD est en cours (fire-and-forget).
   * - cm - Comme ThemeService.IsPersisting, expose pour les composants qui
   * souhaiteraient afficher un skeleton (non utilise pour l'instant mais
   * garde la coherence avec le pattern).
   */
  public readonly IsPersisting = signal<boolean>(false);
  //#endregion

  //#region Methods
  /**
   * Demarre le tracking de la derniere URL authentifiee.
   * - cm - A appeler UNE fois au boot de l'app (dans AppComponent), apres
   * l'init du ThemeService. On s'abonne aux NavigationEnd du Router et
   * on filtre :
   *   - SSR (no-op cote serveur).
   *   - Pas d'utilisateur connecte (la persistance n'a pas de sens).
   *   - URLs publiques (login, register, unauthorized, etc.).
   * L'URL persistee est nettoyee de ses query params sensibles (cf. _SanitizeUrl)
   * et du fragment (#).
   *
   * Idempotent : safe a appeler plusieurs fois (le second appel ne cree
   * pas de double subscription grace a `_TrackedUserId` et un flag interne).
   */
  public StartTracking(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)
    if (this._TrackedUserId !== null) return; // - cm - Idempotent

    this._Router.events
      .pipe(filter((pEvent): pEvent is NavigationEnd => pEvent instanceof NavigationEnd))
      .subscribe((pEvent) =>
      {
        this._OnNavigationEnd(pEvent.urlAfterRedirects);
      });
  }

  /**
   * Recupere la derniere URL authentifiee persistee pour l'utilisateur courant.
   * - cm - Ordre de priorite : localStorage > BDD (via la cle `ui.last_visited_url`
   * deja chargee dans `currentUser.userSettings`). Le retour est sanitise :
   * null si l'URL est vide, publique ou invalide.
   *
   * @returns L'URL a utiliser pour la redirection post-login, ou null si aucune.
   */
  public GetLastUrl(): string | null
  {
    if (!this._IsBrowser) return null;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return null;

    const lUserId: number = lUser.id;
    const lLocalKey: string = this._LocalKey(lUserId);

    // - cm - Priorite 1 : localStorage (rapide, synchrone, reflete la derniere
    // navigation effective meme si la BDD n'a pas encore synchro).
    const lLocal: string | null = this._ReadLocal(lLocalKey);
    if (lLocal && this._IsValidRedirectTarget(lLocal)) return lLocal;

    // - cm - Priorite 2 : setting BDD (charge dans `currentUser.userSettings`
    // via /api/Users/me). On accepte une cle legacy `last_visited_url` (sans
    // prefixe `ui.`) pour resister a une migration future du nom de cle.
    const lFromSettings: string | undefined = this._FindInUserSettings(lUser.userSettings);
    if (lFromSettings && this._IsValidRedirectTarget(lFromSettings)) return lFromSettings;

    return null;
  }

  /**
   * Efface la derniere URL persistee (localStorage + BDD) pour l'utilisateur courant.
   * - cm - A appeler apres une redirection reussie pour eviter qu'une future
   * deconnexion ramene systematiquement a la meme page. Le `returnUrl` query
   * param reste prioritaire (cf. login.component), donc on n'efface QUE si
   * on a effectivement utilise la valeur locale.
   */
  public async Clear(): Promise<void>
  {
    if (!this._IsBrowser) return;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return;
    const lUserId: number = lUser.id;

    // - cm - Efface localStorage + fallback sessionStorage.
    try { localStorage.removeItem(this._LocalKey(lUserId)); }
    catch { /* ignore */ }
    this._SessionStorage.Clear(this._LocalKey(lUserId));

    // - cm - Efface le setting BDD (best-effort). On ne leve pas d'exception
    // si l'utilisateur n'est pas connecte ou si la BDD echoue.
    try
    {
      // - cm - Upsert avec valeur vide + cle distincte "cleared" plutot que DELETE
      // pour respecter l'API CRUD du SettingsService (pas de methode delete exposee).
      // Le login.component filtrera les valeurs vides via _IsValidRedirectTarget.
      // TODO a terme : exposer un deleteByKey si le besoin se confirme.
      void this._SettingsService.upsertUserSetting(
        lUserId,
        LAST_URL_SETTING_KEY,
        '',
        'string'
      );
    }
    catch
    {
      // - cm - Best-effort : pas de propagation d'erreur.
    }
  }

  /**
   * Handler appele a chaque NavigationEnd du Router.
   * Filtre et persiste l'URL si elle est eligible.
   * @param pUrl URL brute apres redirections (ex: /dashboard-pro/biens/42).
   */
  private _OnNavigationEnd(pUrl: string): void
  {
    if (!this._IsBrowser) return;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return; // - cm - Pas de tracking si pas connecte

    const lUserId: number = lUser.id;
    const lSanitized: string | null = this._SanitizeUrl(pUrl);
    if (!lSanitized) return; // - cm - URL publique ou invalide → on ignore

    // - cm - Ecrit localStorage synchrone. Source de verite immediate pour
    // le prochain GetLastUrl() (cas du 401 suivi d'un relogin immediat).
    this._WriteLocal(this._LocalKey(lUserId), lSanitized);

    // - cm - Fire-and-forget BDD. Best-effort, on ne bloque pas la navigation.
    void this._PersistToServer(lUserId, lSanitized);
  }

  /**
   * Persiste l'URL en BDD via SettingsService.upsertUserSetting.
   * - cm - Best-effort, ne leve pas d'exception. Compare avec la derniere
   * valeur BDD pour eviter des ecritures inutiles (memes gardes que
   * ThemeService._ServerThemeCache, simplifie ici car on ecrit par URL).
   */
  private async _PersistToServer(pUserId: number, pUrl: string): Promise<void>
  {
    this.IsPersisting.set(true);
    try
    {
      const lSaved = await this._SettingsService.upsertUserSetting(
        pUserId,
        LAST_URL_SETTING_KEY,
        pUrl,
        'string'
      );
      if (lSaved)
      {
        // - cm - Patche `currentUser.userSettings` pour que GetLastUrl()
        // puisse lire la nouvelle valeur sans refetch /api/Users/me.
        const lUser = this._UsersService.currentUser;
        if (lUser?.userSettings)
        {
          const lExisting = this._FindUserSetting(lUser.userSettings);
          if (lExisting && lExisting.id !== undefined)
          {
            lExisting.value = pUrl;
          }
          else
          {
            lUser.userSettings.push({
              id: lSaved.id,
              key: LAST_URL_SETTING_KEY,
              value: pUrl,
              valueType: 'string',
              userId: pUserId
            });
          }
        }
      }
    }
    finally
    {
      this.IsPersisting.set(false);
    }
  }

  /**
   * Sanitize une URL brute avant persistance.
   * - cm - Vire le fragment, normalise le cas, et rejette les URLs externes.
   * Pas de filtrage des routes publiques : la persistance est deja scopee
   * aux utilisateurs connectes (cf. _SaveUrlIfAuthenticated), donc une URL
   * publique persistee est de toute facon ecrasee par la prochaine
   * navigation sur une route protegee.
   * @param pUrl URL brute (avec query/fragment eventuels).
   * @returns URL nettoyee ou null si non eligible.
   */
  private _SanitizeUrl(pUrl: string): string | null
  {
    if (!pUrl) return null;
    // - cm - Vire le fragment (#) et split le query pour ne garder que le path.
    const lPathOnly: string = pUrl.split('?')[0].split('#')[0].toLowerCase();
    if (!lPathOnly.startsWith('/')) return null; // - cm - Refuse les URLs externes (open-redirect)
    // - cm - On conserve le query string original (apres sanitize du path) pour
    // permettre des redirections comme /crm/biens?filter=actifs. Le _IsValidRedirectTarget
    // reverifie a la lecture.
    return pUrl;
  }

  /**
   * Verifie qu'une URL peut servir de cible de redirection post-login.
   * - cm - Meme politique anti open-redirect que login.component._routeReturnUrl :
   * on n'accepte qu'une URL interne absolue (commençant par /) differente de /connexion.
   * @param pUrl URL a tester.
   * @returns true si l'URL est eligible comme redirect target.
   */
  private _IsValidRedirectTarget(pUrl: string | null | undefined): boolean
  {
    if (!pUrl) return false;
    const lSanitized: string | null = this._SanitizeUrl(pUrl);
    if (!lSanitized) return false;
    const lPathOnly: string = lSanitized.split('?')[0].split('#')[0].toLowerCase();
    return lPathOnly.startsWith('/') && lPathOnly !== '/connexion';
  }

  /**
   * Cherche le setting `ui.last_visited_url` (ou legacy `last_visited_url`) dans
   * le tableau `userSettings` du user. Case-insensitive sur la cle.
   * @param pUserSettings Tableau de settings (peut etre undefined).
   * @returns La valeur trouvee ou undefined.
   */
  private _FindInUserSettings(pUserSettings: any[] | undefined): string | undefined
  {
    const lSetting = this._FindUserSetting(pUserSettings);
    return lSetting?.value ?? undefined;
  }

  /**
   * Variante renvoyant l'objet SettingsDTO complet (pour mutation de `value`).
   */
  private _FindUserSetting(pUserSettings: any[] | undefined): any | undefined
  {
    if (!pUserSettings) return undefined;
    return pUserSettings.find((pS: any) => {
      const lKey: string = (pS?.key ?? '').toLowerCase();
      return lKey === LAST_URL_SETTING_KEY.toLowerCase() || lKey === 'last_visited_url';
    });
  }

  /**
   * Lit l'URL depuis localStorage avec fallback sessionStorage.
   * @param pKey Cle localStorage scopee par userId.
   * @returns La valeur stockee ou null.
   */
  private _ReadLocal(pKey: string): string | null
  {
    if (!this._IsBrowser) return null;
    try
    {
      const lRaw: string | null = localStorage.getItem(pKey);
      if (lRaw) return lRaw;
    }
    catch { /* ignore */ }
    return this._SessionStorage.Restore<string>(pKey);
  }

  /**
   * Ecrit l'URL dans localStorage avec fallback sessionStorage.
   */
  private _WriteLocal(pKey: string, pValue: string): void
  {
    if (!this._IsBrowser) return;
    try
    {
      localStorage.setItem(pKey, pValue);
    }
    catch
    {
      this._SessionStorage.Save(pKey, pValue);
    }
  }

  /**
   * Construit la cle localStorage scopee par userId pour eviter les collisions
   * en cas de multi-user sur la meme machine.
   */
  private _LocalKey(pUserId: number): string
  {
    return `${LastUrlService._LocalStoragePrefix}${pUserId}`;
  }
  //#endregion
}
