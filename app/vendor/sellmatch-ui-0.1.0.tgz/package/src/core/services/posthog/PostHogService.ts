import { DestroyRef, Injectable, NgZone } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import posthog from 'posthog-js';
import { environment } from '../../../environments/environment';
import { UsersDTO } from '../../../core/sellmatchdb/dto';
import {
  POSTHOG_CIRCUIT_FAILURE_THRESHOLD,
  POSTHOG_CIRCUIT_OPEN_FLAG,
  POSTHOG_CIRCUIT_REARM_AT_KEY,
  POSTHOG_CIRCUIT_REARM_DELAY_MS,
  POSTHOG_CIRCUIT_STORAGE_KEY,
  POSTHOG_FLUSH_INTERVAL_MS,
  POSTHOG_REQUEST_TIMEOUT_MS
} from './posthog-circuit-breaker.constants';

/**
 * Service PostHog pour le tracking d'événements et l'analytics.
 * Initialisé hors de la zone Angular pour éviter les cycles de change detection excessifs.
 * Tous les appels sont protégés par try/catch pour ne jamais bloquer l'app
 * si le serveur PostHog est indisponible.
 */
@Injectable({
  providedIn: 'root'
})
export class PostHogService {
  private _Initialized: boolean = false;
  private readonly _Destroy$ = new Subject<void>();

  //#region Constructor
  constructor(
    private readonly _NgZone: NgZone,
    private readonly _DestroyRef: DestroyRef,
    private readonly _Router: Router,
  ) {
    this.Initialize();
    this.HookRouterNavigation();
  }
  //#endregion

  //#region Methods

  /**
   * Initialise PostHog hors de la zone Angular pour réduire les cycles de change detection.
   * - cm - Configure le tracking automatique des changements de route via $pageview et installe
   * - cm - un circuit breaker 3 niveaux (tuning SDK + on_request_error + opt_out) pour stopper
   * - cm - les requêtes vers un serveur PostHog down et économiser de la bande passante.
   */
  private Initialize(): void {
    if (typeof window === 'undefined') return;

    try {
      // - cm - Prédéfinit _config pour que /config.js puisse pousser la configuration serveur
      // même quand posthog-js a déjà remplacé la queue par l'instance importée.
      const lWindowPostHog: any = (window as any).posthog ?? posthog;
      if (!lWindowPostHog._config) {
        lWindowPostHog._config = (pConfig: Record<string, any>): void => {
          posthog.set_config(pConfig);
        };
      }
      (window as any).posthog = lWindowPostHog;

      // - cm - Si un circuit est déjà ouvert en sessionStorage (page rechargée sans hard refresh),
      // on court-circuite complètement l'init : aucun événement, aucun retry, aucun log.
      if (this.IsCircuitOpen()) {
        this._Initialized = false;
        this.MaybeRearmCircuit();
        return;
      }

      this._NgZone.runOutsideAngular(() => {
        // - cm - Détection HTTPS pour activer les cookies sécurisés
        const lIsHttps: boolean = typeof window !== 'undefined' && window.location.protocol === 'https:';
        posthog.init(environment.posthog.apiKey, {
          api_host: environment.posthog.host,
          ui_host: environment.posthog.host,
          autocapture: true, // - cm - Capture automatique des interactions (clicks, submits, changes)
          capture_pageview: 'history_change', // - cm - Capture $pageview/$pageleave sur changements d'historique SPA (pushState/replaceState/popstate)
          advanced_enable_surveys: false,
          persistence: 'localStorage+cookie', // - cm - Double stockage, fallback memory automatique si bloqué
          disable_persistence: false, // - cm - S'assure que la persistance reste active
          secure_cookie: lIsHttps, // - cm - Cookies sécurisés en HTTPS uniquement
          person_profiles: 'always', // - cm - Crée un person profile même pour les users anonymes (sinon "No profile associated with this ID")
          debug: false, // - cm - Debug mode selon l'environnement
          // - cm - (août 2026) Circuit breaker niveau 1 — tuning natif du SDK :
          // - cm - Session recording désactivé : c'est lui qui génère la majorité des POST /s/
          // - cm - en retry_count=9 (snapshots rrweb batchés). On le coupe en attendant le fix
          // - cm - infra. Réactivable en remettant disable_session_recording: false.
          disable_session_recording: true,
          // - cm - Flush interval 60s au lieu de 5s (12× moins de tentatives batch).
          // - cm - Les events restent en mémoire et partent au beacon unload.
          request_queue_config: {
            flush_interval_ms: POSTHOG_FLUSH_INTERVAL_MS
          },
          // - cm - Timeout 8s par requête (au lieu de 30s default). Évite les warnings
          // - cm - navigateur "slow request" et coupe court aux retries longs.
          // - cm - (cast any : non exposé dans PostHogConfig TS mais supporté à l'exécution)
          ...({ request_timeout: POSTHOG_REQUEST_TIMEOUT_MS } as any),
          // - cm - Compression désactivée : économie CPU négligeable ici mais évite une
          // - cm - boucle gzip inutile quand le serveur répond quand même une erreur.
          disable_compression: true,
          // - cm - Callback d'erreur réseau : branche le circuit breaker niveau 2.
          // - cm - Doit être passé dans init() (pas via set_config post-init).
          on_request_error: (pErr: { statusCode?: number; message?: string }): void => {
            const lStatus: number = pErr?.statusCode ?? 0;
            const lIsNetworkOr5xx: boolean =
              lStatus === 0 ||
              (lStatus >= 500 && lStatus < 600);
            if (!lIsNetworkOr5xx) {
              if (lStatus > 0) {
                this.ResetCircuitFailures();
              }
              return;
            }
            this.RegisterCircuitFailure();
          },
          loaded: (ph) => {
            this._Initialized = true;
            // - cm - Reset compteur échecs si on arrive ici (chargement réussi).
            this.ResetCircuitFailures();

            try {
              // - cm - Probe initiale pour détecter rapidement si le serveur répond.
              // - cm - Si OK → compteur reste à 0. Si KO → on incrémente et on applique le seuil.
              this.ProbePostHogAvailability();
            } catch { /* silence */ }

            // - cm - Si on a détecté que ça passe, on capture opt-in.
            if (!this.IsCircuitOpen()) {
              ph.opt_in_capturing();
            } else {
              // - cm - Circuit déjà ouvert après la probe : on coupe tout.
              ph.opt_out_capturing();
            }
          }
        });
      });

      // - cm - Le callback on_request_error est passé directement dans posthog.init() ci-dessus,
      // - cm - voir bloc autour de la ligne `disable_compression: true`. Il ne peut pas être
      // - cm - ajouté via posthog.set_config() post-init de manière fiable (warning SDK + race).

      // - cm - Nettoyage des abonnements à la destruction du service
      this._DestroyRef.onDestroy(() => {
        this._Destroy$.next();
        this._Destroy$.complete();
        posthog.reset();
      });
    }
    catch {
      this._Initialized = false;
    }
  }

  /**
   * Branche le Router Angular pour émettre $pageleave + $pageview à chaque navigation SPA.
   * Complète le mécanisme natif `capture_pageview: 'history_change'` pour garantir la présence
   * des navigation events dans le Session Replay PostHog.
   */
  private HookRouterNavigation(): void {
    if (typeof window === 'undefined') return;

    this._NgZone.runOutsideAngular(() => {
      this._Router.events.pipe(
        filter((pEvent): pEvent is NavigationEnd => pEvent instanceof NavigationEnd),
        takeUntil(this._Destroy$)
      ).subscribe({
        next: (pEvent: NavigationEnd): void => {
          try {
            // - cm - $pageleave de la route précédente avant d'enregistrer le $pageview suivant
            posthog.capture('$pageleave', { $pathname: window.location.pathname });
            // - cm - $pageview explicite pour la nouvelle route (navigation event du replay)
            posthog.capture('$pageview', {
              $current_url: pEvent.urlAfterRedirects,
              $pathname: new URL(pEvent.urlAfterRedirects, window.location.origin).pathname
            });
          } catch { /* silence */ }
        }
      });
    });
  }

  //#region Circuit Breaker

  /**
   * Effectue un GET léger sur `/decide/` pour détecter si le serveur PostHog répond.
   * - cm - Cette probe est appelée une seule fois à l'init du SDK, dans le callback `loaded`.
   * - cm - On utilise fetch natif (pas le SDK) pour ne pas polluer la queue posthog.
   */
  private ProbePostHogAvailability(): void {
    try {
      const lUrl: string = `${environment.posthog.host}/decide/?v=3&lib=phc-probe`;
      const lCtrl: AbortController = new AbortController();
      const lTimer: ReturnType<typeof setTimeout> = setTimeout(
        () => lCtrl.abort(),
        POSTHOG_REQUEST_TIMEOUT_MS
      );
      fetch(lUrl, { method: 'GET', signal: lCtrl.signal, credentials: 'omit', cache: 'no-store' })
        .then((pRes: Response): void => {
          clearTimeout(lTimer);
          if (pRes.ok) {
            this.ResetCircuitFailures();
            return;
          }
          if (pRes.status >= 500) {
            this.RegisterCircuitFailure();
          }
        })
        .catch((): void => {
          clearTimeout(lTimer);
          this.RegisterCircuitFailure();
        });
    } catch { /* silence */ }
  }

  /**
   * Incrémente le compteur d'échecs circuit breaker en sessionStorage.
   * - cm - Au seuil, ouvre le circuit (opt_out_capturing + flag window + timestamp réarmement).
   */
  private RegisterCircuitFailure(): void {
    try {
      const lCurrent: number = this.ReadCircuitFailures();
      const lNext: number = lCurrent + 1;
      sessionStorage.setItem(POSTHOG_CIRCUIT_STORAGE_KEY, String(lNext));
      if (lNext >= POSTHOG_CIRCUIT_FAILURE_THRESHOLD) {
        this.OpenCircuit();
      }
    } catch { /* silence */ }
  }

  /**
   * Remet le compteur d'échecs à zéro. Appelé sur 2xx ou après réarmement réussi.
   */
  private ResetCircuitFailures(): void {
    try {
      sessionStorage.removeItem(POSTHOG_CIRCUIT_STORAGE_KEY);
      sessionStorage.removeItem(POSTHOG_CIRCUIT_REARM_AT_KEY);
      (window as any)[POSTHOG_CIRCUIT_OPEN_FLAG] = false;
    } catch { /* silence */ }
  }

  /**
   * Lit le compteur d'échecs en sessionStorage. Retourne 0 si absent ou storage indisponible.
   * @returns Nombre d'échecs consécutifs observés
   */
  private ReadCircuitFailures(): number {
    try {
      const lRaw: string | null = sessionStorage.getItem(POSTHOG_CIRCUIT_STORAGE_KEY);
      if (!lRaw) return 0;
      const lValue: number = parseInt(lRaw, 10);
      return Number.isFinite(lValue) && lValue >= 0 ? lValue : 0;
    } catch {
      return 0;
    }
  }

  /**
   * Ouvre le circuit breaker : flag window, opt_out SDK, vidage queue, timestamp réarmement.
   * - cm - Coupe immédiatement toutes les futures requêtes du SDK posthog-js.
   */
  private OpenCircuit(): void {
    try {
      (window as any)[POSTHOG_CIRCUIT_OPEN_FLAG] = true;
      sessionStorage.setItem(
        POSTHOG_CIRCUIT_REARM_AT_KEY,
        String(Date.now() + POSTHOG_CIRCUIT_REARM_DELAY_MS)
      );
      try {
        posthog.opt_out_capturing();
      } catch { /* silence */ }
      try {
        // - cm - Vide la queue en mémoire pour éviter que les events en attente ressortent
        // au prochain passage en mode online.
        const lQueue: any = (posthog as any)._queue;
        if (lQueue && Array.isArray(lQueue)) {
          lQueue.length = 0;
        }
      } catch { /* silence */ }
    } catch { /* silence */ }
  }

  /**
   * Vérifie si on doit tenter un réarmement du circuit (5 min écoulées depuis l'ouverture).
   * - cm - Si oui, fait une probe réseau. Si 2xx → reset le compteur. Si KO → repousse.
   */
  private MaybeRearmCircuit(): void {
    try {
      const lRearmAt: string | null = sessionStorage.getItem(POSTHOG_CIRCUIT_REARM_AT_KEY);
      if (!lRearmAt) return;
      const lRearmAtMs: number = parseInt(lRearmAt, 10);
      if (!Number.isFinite(lRearmAtMs)) return;
      if (Date.now() < lRearmAtMs) return;
      this.ProbePostHogAvailability();
    } catch { /* silence */ }
  }

  /**
   * Indique si le circuit est actuellement ouvert (et donc le tracking désactivé).
   * - cm - Utilisé par Initialize() pour court-circuiter l'init SDK si on est en mode dégradé.
   * @returns true si on a dépassé le seuil d'échecs et que le délai de réarmement n'est pas écoulé
   */
  private IsCircuitOpen(): boolean {
    try {
      const lFlag: boolean = (window as any)[POSTHOG_CIRCUIT_OPEN_FLAG] === true;
      const lRearmAt: string | null = sessionStorage.getItem(POSTHOG_CIRCUIT_REARM_AT_KEY);
      if (!lFlag || !lRearmAt) return false;
      const lRearmAtMs: number = parseInt(lRearmAt, 10);
      if (!Number.isFinite(lRearmAtMs)) return false;
      // - cm - true tant que le délai n'est pas écoulé. À l'expiration, MaybeRearmCircuit()
      // fait une probe et le IsCircuitOpen() suivant retournera false si elle passe.
      return Date.now() < lRearmAtMs;
    } catch {
      return false;
    }
  }

  //#endregion

  /**
   * Capture un événement personnalisé
   * @param pEventName Nom de l'événement
   * @param pProperties Propriétés optionnelles
   */
  public Capture(pEventName: string, pProperties?: Record<string, any>): void {
    if (!this._Initialized) return;
    try { posthog.capture(pEventName, pProperties); } catch { /* silence */ }
  }

  /**
   * Identifie un utilisateur avec ses propriétés
   * @param pUserId Identifiant unique de l'utilisateur
   * @param pProprietes Propriétés utilisateur optionnelles
   */
  public Identify(pUserId: string, pProprietes?: Record<string, any>): void {
    if (!this._Initialized) return;
    try { posthog.identify(pUserId, pProprietes); } catch { /* silence */ }
  }

  /**
   * Identifie un utilisateur connecté à partir du DTO applicatif
   * @param pUser Utilisateur connecté à synchroniser avec PostHog
   */
  public IdentifyUser(pUser: UsersDTO): void {
    if (!this._Initialized || !pUser.id) return;

    const lUserProperties: Record<string, any> = {
      ...pUser,
      userId: pUser.id,
      isLoggedIn: true
    };

    try {
      posthog.identify(pUser.id.toString(), lUserProperties);
      posthog.people.set(lUserProperties);
      // - cm - Fige la source de la 1ère visite (set_once n'écrase pas si déjà présent)
      const lUtm: Record<string, any> = this.ParseUtmParams();
      posthog.people.set_once({
        initial_referrer: document.referrer || '$direct',
        initial_referring_domain: this.ExtractDomain(document.referrer) || '$direct',
        initial_utm_source: lUtm['utm_source'],
        initial_utm_medium: lUtm['utm_medium'],
        initial_utm_campaign: lUtm['utm_campaign']
      });
      posthog.capture('user_login_identified', lUserProperties);
    } catch { /* silence */ }
  }

  /**
   * Réinitialise l'identité de l'utilisateur (déconnexion)
   */
  public Reset(): void {
    if (!this._Initialized) return;
    try { posthog.reset(); } catch { /* silence */ }
  }

  /**
   * Définit des propriétés sur l'utilisateur courant
   * @param pProprietes Propriétés à définir
   */
  public SetPersonProperties(pProprietes: Record<string, any>): void {
    if (!this._Initialized) return;
    try { posthog.people.set(pProprietes); } catch { /* silence */ }
  }

  /**
   * Capture un événement même si la persistance (cookies/localStorage) est indisponible.
   * En cas d'échec de capture, génère un distinct_id anonyme temporaire en mémoire.
   * @param pEventName Nom de l'événement
   * @param pProperties Propriétés optionnelles
   */
  public CaptureResilient(pEventName: string, pProperties?: Record<string, any>): void {
    if (!this._Initialized) return;
    try {
      posthog.capture(pEventName, pProperties);
    } catch {
      try {
        // - cm - Fallback : distinct_id anonyme temporaire si persistence bloquée
        const lAnonId: string = 'anon_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
        posthog.capture(pEventName, { distinct_id: lAnonId, ...pProperties });
      } catch { /* silence */ }
    }
  }

  /**
   * Capture spécifique de la page estimation avec la ville, referrer, UTM et device info.
   * @param pCity Ville concernée par l'estimation
   * @param pProperties Propriétés optionnelles fusionnées par-dessus les propriétés enrichies
   */
  public CaptureEstimationPage(pCity: string, pProperties?: Record<string, any>): void {
    if (!this._Initialized) return;
    try {
      const lEnriched: Record<string, any> = { city: pCity, ...this.BuildPageViewProperties(), ...pProperties };
      posthog.capture('estimation_page_viewed', lEnriched);
    } catch { /* silence */ }
  }

  /**
   * Active/désactive le tracking (utile pour le consentement RGPD)
   * @param pEnabled true pour activer, false pour désactiver
   */
  public SetTrackingEnabled(pEnabled: boolean): void {
    if (!this._Initialized) return;
    try {
      if (pEnabled) {
        posthog.opt_in_capturing();
      } else {
        posthog.opt_out_capturing();
      }
    }
    catch { /* silence */ }
  }

  /**
   * Capture un profil anonyme pour les utilisateurs non identifiés
   * @param pEventName Nom de l'événement
   * @param pProperties Propriétés optionnelles
   */
  public CaptureAnonymousProfile(pEventName: string, pProperties?: Record<string, any>): void {
    if (!this._Initialized) return;
    try { 
      posthog.capture(pEventName, pProperties); 
    } catch { /* silence */ }
  }

  //#region Utils

  /**
   * Construit le dictionnaire de propriétés enrichies pour les pageviews : referrer, UTM, URL courante et device info.
   * @returns Objet contenant les propriétés enrichies prêtes à fusionner dans un event
   */
  private BuildPageViewProperties(): Record<string, any> {
    const lReferrer: string = document.referrer || '$direct';
    const lReferringDomain: string = this.ExtractDomain(document.referrer) || '$direct';
    const lUtm: Record<string, any> = this.ParseUtmParams();

    return {
      $referrer: lReferrer,
      $referring_domain: lReferringDomain,
      $current_url: window.location.href,
      $host: window.location.host,
      $pathname: window.location.pathname,
      $search: window.location.search,
      viewport_width: window.innerWidth,
      viewport_height: window.innerHeight,
      user_agent: navigator.userAgent,
      language: navigator.language,
      ...lUtm
    };
  }

  /**
   * Parse les paramètres UTM depuis la query string courante.
   * @returns Objet contenant les UTM présents (utm_source, utm_medium, utm_campaign, utm_content, utm_term)
   */
  private ParseUtmParams(): Record<string, any> {
    const lResult: Record<string, any> = {};
    try {
      const lParams: URLSearchParams = new URLSearchParams(window.location.search);
      const lKeys: string[] = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'];
      lKeys.forEach((pKey: string): void => {
        const lValue: string | null = lParams.get(pKey);
        if (lValue) {
          lResult[pKey] = lValue;
        }
      });
    } catch { /* silence */ }
    return lResult;
  }

  /**
   * Extrait le hostname d'une URL.
   * @param pUrl URL à analyser
   * @returns Hostname extrait, ou chaîne vide si l'URL est vide ou invalide
   */
  private ExtractDomain(pUrl: string): string {
    if (!pUrl) return '';
    try {
      return new URL(pUrl).hostname;
    } catch {
      return '';
    }
  }

  //#endregion

  //#endregion
}
