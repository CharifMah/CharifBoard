/**
 * Constantes du circuit breaker PostHog.
 * - cm - But : stopper les requêtes réseau vers posthog.sellmatch.fr quand
 * - cm - l'ingestion répond en 5xx (ou timeout réseau). Sans breaker, le SDK
 * - cm - retente jusqu'à retry_count=9+ en batchant des snapshots session
 * - cm - recording, ce qui génère ~150 entrées console par navigation.
 *
 * Réglages (août 2026, validé après tests sur recette) :
 * - seuil 5 erreurs consécutives → circuit ouvert.
 * - réarmement automatique après 5 min (probe d'une requête).
 * - persistance sessionStorage uniquement (meurt à la fermeture d'onglet).
 * - reset du compteur sur 2xx consécutif.
 */

/** Nombre d'erreurs 5xx ou timeout réseau avant ouverture du circuit. */
export const POSTHOG_CIRCUIT_FAILURE_THRESHOLD: number = 5;

/** Délai (ms) avant de retenter une seule requête pour tester si le service est revenu. */
export const POSTHOG_CIRCUIT_REARM_DELAY_MS: number = 5 * 60 * 1000; // 5 min

/** Clé sessionStorage du compteur d'échecs. */
export const POSTHOG_CIRCUIT_STORAGE_KEY: string = 'sm_posthog_circuit_fails';

/** Timestamp (ms epoch) de la prochaine tentative de réarmement. */
export const POSTHOG_CIRCUIT_REARM_AT_KEY: string = 'sm_posthog_circuit_rearm_at';

/** Marker global pour `window` quand le circuit est ouvert (debug / autres modules). */
export const POSTHOG_CIRCUIT_OPEN_FLAG: string = '__sm_posthog_circuit_open__';

/**
 * Délai (ms) entre 2 flushes du SDK Posthog (default SDK = 5000ms).
 * - cm - 60s = 12× moins de flushes par page active. Les events restent en mémoire
 * - cm - et partent au prochain unload (beacon) ou au flush manuel.
 */
export const POSTHOG_FLUSH_INTERVAL_MS: number = 60_000;

/**
 * Timeout (ms) d'une requête HTTP Posthog. Default SDK = 30000ms.
 * - cm - 8s = coupe avant que le navigateur n'affiche un warning "slow request".
 */
export const POSTHOG_REQUEST_TIMEOUT_MS: number = 8_000;
