import { Injectable, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SessionStorageService } from '../../../core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { UsersService } from '../../../core/sellmatchdb/services/users/users.service';
import { SettingsService } from '../../../core/sellmatchdb/services/settings/settings.service';
import { SettingsDTO } from '../../../core/sellmatchdb/dto/settings/settings.dto';

/**
 * Niveau de zoom courant de la grille generique SellMatch.
 * - cm - Suit le pattern de ThemeService pour la persistance BDD + localStorage.
 * Cle logique `grid.zoom`, scope par userId (table `settings` GENERIQUE).
 */
export type GridZoomLevel = number;

/**
 * Cle logique du setting BDD stockant la preference de zoom de grille utilisateur.
 * - cm - Namespace `grid.*` (coherent avec `ui.theme`). La valeur est serialisee
 * en string (cf. `valueType='int'` ci-dessous). Meme convention que les autres
 * prefs utilisateur (LangueService, ThemeService).
 */
export const GRID_ZOOM_SETTING_KEY: string = 'grid.zoom';

/**
 * Bornes et defaut partages entre le service et la grille.
 * - cm - Meme const que `GRID_ZOOM` dans grid-base.ts pour eviter un drift.
 * Si tu modifies une borne, modifie les deux (les valeurs sont identiques a
 * la compilation : c'est juste un miroir cote service pour le cast/coerce).
 */
export const GRID_ZOOM_LIMITS = {
  Default: 1.0,
  Min: 0.5,
  Max: 2.0
} as const;

/**
 * Service de gestion du zoom de la grille generique SellMatch.
 * Persiste le niveau de zoom (1.0 = 100%, range 0.5..2.0) dans le localStorage
 * ET dans la table BDD `settings` (cle `grid.zoom`, scope par userId) pour
 * suivre l'utilisateur d'un device a l'autre / d'un navigateur a l'autre.
 * SSR-safe : aucune interaction DOM cote serveur.
 */
@Injectable({
  providedIn: 'root'
})
export class GridZoomService
{
  //#region Attributes
  /** Cle de stockage du zoom en localStorage. */
  private readonly _StorageKey: string = 'sellmatch-grid-zoom';

  /** Indique si le code s'execute cote navigateur. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Service de sessionStorage pour fallback. */
  private readonly _SessionStorage: SessionStorageService = inject(SessionStorageService);

  /** Service utilisateur courant (pour lire/ecrire le setting BDD `grid.zoom`). */
  private readonly _UsersService: UsersService = inject(UsersService);

  /** Service settings generique (upsert cle/valeur en BDD). */
  private readonly _SettingsService: SettingsService = inject(SettingsService);

  /**
   * Cache memoire du dernier zoom applique depuis la BDD pour eviter
   * d'ecraser la pref serveur si l'utilisateur a plusieurs onglets ouverts.
   * - cm - Cle = `${userId}:${GRID_ZOOM_SETTING_KEY}` pour supporter le multi-user
   * (changement de compte sur la meme session navigateur).
   */
  private readonly _ServerZoomCache: Map<string, GridZoomLevel> = new Map<string, GridZoomLevel>();
  //#endregion

  //#region Properties
  /**
   * Signal reactif exposant le niveau de zoom courant de la grille.
   * - cm - La grille lit ce signal via un `effect()` pour mettre a jour la CSS
   * var `--grid-zoom` (cf. grid.component.ts).
   */
  public readonly CurrentZoom = signal<GridZoomLevel>(GRID_ZOOM_LIMITS.Default);

  /**
   * Indique qu'une persistance BDD du zoom est en cours (fire-and-forget).
   * - cm - Permet a un futur indicateur UI (skeleton de la grid settings ou
   * overlay discret sur la toolbar) d'afficher un feedback. Pattern identique
   * a `ThemeService.IsPersisting`.
   */
  public readonly IsPersisting = signal<boolean>(false);
  //#endregion

  //#region Methods
  /**
   * Initialise le zoom au demarrage de l'application.
   * Priorite : localStorage > defaut (1.0).
   * - cm - Ne touche PAS a la BDD : le chargement depuis le profil user
   * se fait via `SyncFromUserSettings()` une fois le UsersService charge.
   * Cela evite une race condition au boot (UsersService pas encore ready).
   * Idempotent : safe a appeler plusieurs fois.
   */
  public Init(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    const lStored = this._ReadStoredZoom();
    const lZoom: GridZoomLevel = lStored ?? GRID_ZOOM_LIMITS.Default;

    this.ApplyZoom(lZoom);
  }

  /**
   * Synchronise le zoom courant avec le setting BDD de l'utilisateur connecte.
   * - cm - Appele une fois que le UsersService a resolu `currentUser` (apres
   * login OU loadUserFromStorage + refreshFromServer). Si un setting
   * `grid.zoom` existe en BDD, il prend le pas sur le localStorage.
   * - cm - Idempotent : safe a appeler plusieurs fois (pas d'effet si
   * le zoom deja applique correspond au setting serveur).
   * @returns Promise resolue une fois la synchro terminee (best-effort).
   */
  public async SyncFromUserSettings(): Promise<void>
  {
    if (!this._IsBrowser) return;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id)
    {
      // - cm - Pas d'utilisateur connecte : on garde le zoom local (localStorage).
      return;
    }
    const lUserId: number = lUser.id;
    const lSetting = this._FindZoomSetting(lUser.userSettings);
    if (!lSetting || lSetting.value === undefined || lSetting.value === null)
    {
      // - cm - Pas de setting serveur : on conserve le zoom local. Pas de write auto
      // vers la BDD — l'utilisateur n'a pas explicitement bouge le zoom, donc on ne
      // pollue pas la table avec des valeurs implicites.
      return;
    }
    const lServerZoom = this._CoerceSettingValue(lSetting.value);
    if (lServerZoom === null)
    {
      // - cm - Valeur invalide cote serveur : on log et on garde le local.
      console.warn(`[GridZoomService] Valeur de setting '${GRID_ZOOM_SETTING_KEY}' invalide : '${lSetting.value}'`);
      return;
    }
    this._ServerZoomCache.set(this._CacheKey(lUserId), lServerZoom);
    // - cm - On n'applique QUE si different du zoom courant pour eviter un flash
    // inutile au boot (le localStorage a deja pu poser le bon zoom).
    if (Math.abs(this.CurrentZoom() - lServerZoom) > 0.001)
    {
      this.ApplyZoom(lServerZoom);
    }
  }

  /**
   * Met a jour le zoom a partir d'une action utilisateur (toolbar, raccourci, etc.).
   * Pose le signal `CurrentZoom` ; la grille reagit via son `effect()` pour
   * appliquer la CSS var `--grid-zoom`. Persiste en localStorage (synchrone)
   * ET en BDD (fire-and-forget) si user connecte.
   * - cm - Meme pattern que `ThemeService.ApplyTheme` : localStorage immediat
   * (UI instantanee), POST BDD en arriere-plan (sans bloquer l'UI).
   * @param pZoom Niveau de zoom souhaite (1.0 = 100%, range 0.5..2.0).
   */
  public ApplyZoom(pZoom: GridZoomLevel): void
  {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    const lClamped = this._Clamp(pZoom);
    this.CurrentZoom.set(lClamped);
    this._WriteStoredZoom(lClamped);

    // - cm - Persistance BDD best-effort : on lance en arriere-plan sans bloquer l'UI.
    // La resolution de la promesse est silencieuse (succes = cache, echec = warning console).
    void this._PersistZoomToServer(lClamped);
  }

  /**
   * Persiste le zoom en BDD via SettingsService.upsertUserSetting.
   * - cm - Best-effort : ne leve pas d'exception, ne bloque pas l'UI.
   * Si l'utilisateur n'est pas connecte, no-op silencieux (le localStorage
   * reste la seule source de verrite pour la session anonyme).
   * - cm - Compare avec `_ServerZoomCache` pour eviter une boucle d'ecriture
   * quand `SyncFromUserSettings` declenche un `ApplyZoom` (qui rappellerait
   * `_PersistZoomToServer` avec la meme valeur).
   * - cm - Met a jour `IsPersisting` (signal public) debut/fin pour que les
   * composants UI puissent afficher leur feedback pendant l'appel reseau.
   */
  private async _PersistZoomToServer(pZoom: GridZoomLevel): Promise<void>
  {
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return;
    const lUserId: number = lUser.id;
    const lCacheKey: string = this._CacheKey(lUserId);
    if (Math.abs((this._ServerZoomCache.get(lCacheKey) ?? -1) - pZoom) < 0.001)
    {
      // - cm - On vient de synchro depuis la BDD, pas la peine de re-POSTer la meme valeur.
      return;
    }
    this.IsPersisting.set(true);
    try
    {
      const lSaved = await this._SettingsService.upsertUserSetting(
        lUserId,
        GRID_ZOOM_SETTING_KEY,
        pZoom.toString(),
        'int'
      );
      if (lSaved)
      {
        this._ServerZoomCache.set(lCacheKey, pZoom);
        // - cm - On patche `currentUser.userSettings` pour qu'un futur
        // `getUserZoomSetting()` (cf. profil.component si expose plus tard)
        // reflete immediatement la nouvelle valeur sans devoir refetch
        // /api/Users/me.
        if (lUser.userSettings)
        {
          const lExisting = this._FindZoomSetting(lUser.userSettings);
          if (lExisting && lExisting.id !== undefined)
          {
            lExisting.value = pZoom.toString();
          }
          else
          {
            lUser.userSettings.push({
              id: lSaved.id,
              key: GRID_ZOOM_SETTING_KEY,
              value: pZoom.toString(),
              valueType: 'int',
              userId: lUserId
            });
          }
        }
      }
    }
    finally
    {
      this.IsPersisting.set(false);
    }
  }

  /**
   * Lit le zoom persiste depuis le localStorage.
   * - cm - Tolere des valeurs hors bornes (clamp + fallback defaut). Si la cle
   * existe mais est corrompue, on retombe sur le defaut sans bruit.
   * @returns Le zoom stocke (clamp dans les bornes) ou null si absent/invalide.
   */
  private _ReadStoredZoom(): GridZoomLevel | null
  {
    if (!this._IsBrowser) return null; // - cm - No-op cote serveur (SSR)

    const lRaw = localStorage.getItem(this._StorageKey);
    if (lRaw)
    {
      const lCoerced = this._CoerceSettingValue(lRaw);
      if (lCoerced !== null) return lCoerced;
    }

    // - cm - Fallback sessionStorage pour compat (cf. ThemeService pour le precedent)
    const lFallback = this._SessionStorage.Restore<GridZoomLevel>(this._StorageKey);
    if (lFallback !== null && lFallback !== undefined)
    {
      return this._CoerceSettingValue(String(lFallback));
    }

    return null;
  }

  /**
   * Persiste le zoom dans le localStorage.
   * - cm - Stocke en string parseable (cf. `_ReadStoredZoom`). Tolere
   * l'indisponibilite du localStorage en basculant sur sessionStorage.
   * @param pZoom Niveau de zoom a sauvegarder (clamp dans les bornes).
   */
  private _WriteStoredZoom(pZoom: GridZoomLevel): void
  {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    const lClamped = this._Clamp(pZoom);
    try
    {
      localStorage.setItem(this._StorageKey, lClamped.toString());
    }
    catch (pError)
    {
      // - cm - Fallback sessionStorage si localStorage indisponible (meme pattern que ThemeService).
      this._SessionStorage.Save(this._StorageKey, lClamped);
    }
  }

  /**
   * Cherche le setting `grid.zoom` dans le tableau `userSettings` du user.
   * - cm - Meme approche que `ThemeService._FindThemeSetting` : on accepte
   * les cles case-insensitive pour resister a une migration future du nom de cle.
   * @param pUserSettings Tableau de settings renvoye par `currentUser.userSettings`.
   * @returns Le setting trouve ou undefined.
   */
  private _FindZoomSetting(pUserSettings: SettingsDTO[] | undefined): SettingsDTO | undefined
  {
    if (!pUserSettings) return undefined;
    return pUserSettings.find(pS => (pS.key ?? '').toLowerCase() === GRID_ZOOM_SETTING_KEY.toLowerCase());
  }

  /**
   * Convertit une valeur BDD (string libre) en `GridZoomLevel` strict.
   * - cm - Accepte uniquement les nombres dans [GRID_ZOOM_LIMITS.Min, Max].
   * Toute autre valeur (null, vide, NaN, hors bornes) renvoie null — l'appelant
   * decide du fallback (localStorage, defaut).
   * @param pValue Valeur brute issue de la BDD ou du localStorage.
   * @returns Le zoom coerce, ou null si invalide.
   */
  private _CoerceSettingValue(pValue: string | undefined | null): GridZoomLevel | null
  {
    if (pValue === undefined || pValue === null) return null;
    const lNormalized = pValue.toString().trim();
    if (lNormalized === '') return null;
    const lParsed = Number(lNormalized);
    if (!Number.isFinite(lParsed)) return null;
    return this._Clamp(lParsed);
  }

  /**
   * Borne une valeur de zoom dans [GRID_ZOOM_LIMITS.Min, Max].
   * @param pZoom Niveau a clamper.
   * @returns Niveau clampe.
   */
  private _Clamp(pZoom: GridZoomLevel): GridZoomLevel
  {
    return Math.max(GRID_ZOOM_LIMITS.Min, Math.min(GRID_ZOOM_LIMITS.Max, pZoom));
  }

  /**
   * Construit la cle de cache memoire `_ServerZoomCache` pour un user donne.
   * - cm - Cf. ThemeService pour le precedent. Permet le multi-user sur la meme
   * session navigateur sans pollution croisee.
   */
  private _CacheKey(pUserId: number): string
  {
    return `${pUserId}:${GRID_ZOOM_SETTING_KEY}`;
  }
  //#endregion
}