import { Injectable, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/**
 * Variante visuelle disponible pour les cartes d'indicateur (`app-stat-card`).
 * Chaque variante est définie dans `stat-card.component.scss` et peut être
 * sélectionnée globalement via `StatCardVariantService`.
 */
export type EStatCardVariant = 'minimal-flat' | 'glass-morphism' | 'duotone-modern' | 'outline-tech';

/**
 * Liste exhaustive des variantes (utilisée pour le sélecteur dans le playground).
 */
export const STAT_CARD_VARIANTS: ReadonlyArray<EStatCardVariant> = [
  'minimal-flat',
  'glass-morphism',
  'duotone-modern',
  'outline-tech'
];

/**
 * Libellé humain de chaque variante (affiché dans le playground).
 */
export const STAT_CARD_VARIANT_LABELS: Readonly<Record<EStatCardVariant, string>> = {
  'minimal-flat': 'Variante A — minimal-flat',
  'glass-morphism': 'Variante B — glass-morphism',
  'duotone-modern': 'Variante C — duotone-modern',
  'outline-tech': 'Variante D — outline-tech'
};

/**
 * Service global (signal + localStorage) exposant la variante active des
 * cartes d'indicateur. Toutes les instances de `<app-stat-card>` lisent
 * ce signal via `effect()` ou directement en `@Input` côté composant parent.
 *
 * SSR-safe : aucune interaction DOM côté serveur.
 */
@Injectable({
  providedIn: 'root'
})
export class StatCardVariantService
{
  //#region Attributes
  /** Clé de stockage en localStorage. */
  private readonly _StorageKey: string = 'stat-card-variant';

  /** Indique si on s'exécute côté navigateur (pour l'accès au localStorage). */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));
  //#endregion

  //#region Properties
  /** Signal interne de la variante active. */
  private readonly _Variant = signal<EStatCardVariant>(this._ResolveInitialVariant());

  /** Signal readonly exposé aux consommateurs. */
  public readonly Variant = this._Variant.asReadonly();
  //#endregion

  //#region Methods
  /**
   * Met à jour la variante active et persiste le choix dans le localStorage.
   * @param pVariant La nouvelle variante à appliquer globalement.
   */
  public SetVariant(pVariant: EStatCardVariant): void
  {
    this._Variant.set(pVariant);
    if (this._IsBrowser)
    {
      try
      {
        localStorage.setItem(this._StorageKey, pVariant);
      }
      catch
      {
        // - cm - localStorage peut être indisponible (mode privé, quota). On ne lève pas d'erreur.
      }
    }
  }

  /**
   * Lit la variante initiale depuis le localStorage si présente, sinon 'minimal-flat'.
   * @returns La variante initiale à appliquer.
   */
  private _ResolveInitialVariant(): EStatCardVariant
  {
    if (!this._IsBrowser)
    {
      return 'minimal-flat';
    }

    try
    {
      const lStored: string | null = localStorage.getItem(this._StorageKey);
      if (lStored && (STAT_CARD_VARIANTS as ReadonlyArray<string>).includes(lStored))
      {
        return lStored as EStatCardVariant;
      }
    }
    catch
    {
      // - cm - localStorage inaccessible (mode privé strict), on retombe sur le défaut.
    }
    return 'minimal-flat';
  }
  //#endregion
}
