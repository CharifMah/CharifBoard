import { Injectable } from '@angular/core';
import type { GridColumn } from '../../../shared/components/grid/GridColumn';

/**
 * Type d'entite CRM reconnue par le parseur d'import unifie.
 * Couvre les 10 entites gerees par le MCP CRM (transactions, locations, properties, contacts,
 * historique, taches, objectifs, projets, prospections, recrutements) + un mode 'generic'
 * pour tout outil qui retourne une liste de DTOs non reconnus.
 */
export type EImportKind =
  | 'transactions'
  | 'locations'
  | 'properties'
  | 'contacts'
  | 'historique'
  | 'taches'
  | 'objectifs'
  | 'projets'
  | 'prospections'
  | 'recrutements'
  | 'generic';

/**
 * Resultat unifie du parseur d'import.
 * Une seule passe sur le JSON produit toutes les representations necessaires a l'UI,
 * evitant les cascades de parseurs (ParseImportedRows / ParseListResult / ParseDiff / ParsePlanFromMessage)
 * qui essaient chacune de deviner le meme format.
 */
export interface ParsedImport {
  /** Type d'entite CRM detecte, ou 'generic' si non reconnu. */
  Kind: EImportKind;
  /** Lignes a afficher dans une grille (unifie les 3 anciens parseurs). */
  Rows: Array<Record<string, unknown>>;
  /** Diffs structures pour affichage diff-view (uniquement pour Create/Update/Delete). */
  Diffs: ParsedDiff[];
  /** Format detecte a partir du JSON, pour debug/observabilite. */
  Format: 'array' | 'envelope' | 'diff' | 'rows' | 'unknown';
  /** Nom technique de l'outil, normalise en minuscules. */
  NormalizedTool: string;
  /** Indique si l'outil est considere comme mutant (necessite approbation). */
  IsMutating: boolean;
}

/**
 * Diff structure unifie (avant/apres) produit par le parseur.
 * Compatible avec le composant {@link DiffViewComponent} existant.
 */
export interface ParsedDiff {
  /** Action : insert, update, delete. */
  Action: 'insert' | 'update' | 'delete';
  /** Table / entite concernee. */
  Table: string;
  /** Etat avant (null pour insert). */
  Before: unknown;
  /** Etat apres (null pour delete). */
  After: unknown;
  /** Resume lisible. */
  Summary: string;
}

/**
 * Configuration d'une entite CRM pour la detection par le parseur.
 */
interface EntityRule {
  /** Identifiant du kind (cf. EImportKind). */
  Kind: EImportKind;
  /** Liste de mots-cles qui, presents dans le nom de l'outil, permettent de detecter l'entite. */
  ToolKeywords: readonly string[];
  /** Prefixes qui marquent un outil comme mutant (necessite approbation). */
  MutatingPrefixes: readonly string[];
  /** Liste des champs DTO probables, utilises pour le tri intelligent des colonnes. */
  PriorityFields: readonly string[];
}

/**
 * Regles de detection des 10 entites CRM + un mode 'generic' par defaut.
 * L'ordre est important : les regles les plus specifiques sont testees en premier.
 */
const ENTITY_RULES: readonly EntityRule[] = [
  { Kind: 'transactions', ToolKeywords: ['transaction'], MutatingPrefixes: ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'], PriorityFields: ['id', 'reference', 'titre', 'type', 'statut', 'prix', 'montant', 'createdAt'] },
  { Kind: 'locations', ToolKeywords: ['location'], MutatingPrefixes: ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'], PriorityFields: ['id', 'reference', 'type', 'loyer', 'surface', 'ville', 'statut', 'createdAt'] },
  { Kind: 'properties', ToolKeywords: ['propert'], MutatingPrefixes: ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'], PriorityFields: ['id', 'reference', 'type', 'prix', 'surface', 'ville', 'statut', 'createdAt'] },
  { Kind: 'contacts', ToolKeywords: ['contact'], MutatingPrefixes: ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'], PriorityFields: ['id', 'nom', 'prenom', 'email', 'telephone1', 'type', 'createdAt'] },
  { Kind: 'historique', ToolKeywords: ['historique', 'echange'], MutatingPrefixes: ['create', 'update', 'delete'], PriorityFields: ['id', 'titre', 'date', 'type', 'statut', 'createdAt'] },
  { Kind: 'taches', ToolKeywords: ['tache'], MutatingPrefixes: ['create', 'update', 'delete'], PriorityFields: ['id', 'titre', 'statut', 'priorite', 'dateEcheance', 'createdAt'] },
  { Kind: 'objectifs', ToolKeywords: ['objectif'], MutatingPrefixes: ['create', 'update', 'delete'], PriorityFields: ['id', 'titre', 'montant', 'dateEcheance', 'statut', 'createdAt'] },
  { Kind: 'prospections', ToolKeywords: ['prospection'], MutatingPrefixes: ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'], PriorityFields: ['id', 'nom', 'telephone', 'type', 'ville', 'budget', 'statut', 'createdAt'] },
  { Kind: 'recrutements', ToolKeywords: ['recrutement'], MutatingPrefixes: ['create', 'update', 'delete'], PriorityFields: ['id', 'titre', 'type', 'statut', 'createdAt'] },
  { Kind: 'projets', ToolKeywords: ['recherche', 'projet'], MutatingPrefixes: ['create', 'update', 'delete'], PriorityFields: ['id', 'reference', 'titre', 'type', 'statut', 'createdAt'] }
];

/**
 * Prefixes generaux consideres comme mutateurs (utilises si l'entite n'est pas reconnue).
 */
const GLOBAL_MUTATING_PREFIXES: readonly string[] = ['create', 'update', 'delete', 'import', 'batch', 'bulkcreate'];

/**
 * Service de parsing unifie des resultats d'outils MCP du CRM.
 * Remplace les 4 anciens parseurs (ParseImportedRows, ParseListResult, ParseDiff, ParsePlanFromMessage)
 * par une seule fonction pure et testable qui detecte automatiquement le format et l'entite.
 *
 * Formats JSON supportes :
 * - Tableau direct : [ DTO, DTO, ... ]
 * - Enveloppe : { rows | data | items : [ DTO, ... ] }
 * - Diff MCP : { action: 'insert' | 'update' | 'delete', table, before, after, summary }
 * - Plan markdown : non supporte ici (reste dans ParsePlanFromMessage, legacy)
 *
 * Detection d'entite par mots-cles sur le nom de l'outil (crm_create_contact -> contacts).
 */
@Injectable({ providedIn: 'root' })
export class ImportParserService
{
  /**
   * Parse le JSON d'un resultat d'outil MCP et renvoie toutes les representations utilisables.
   * @param pJson Le ResultJson brut
   * @param pToolName Le nom technique de l'outil (peut etre null)
   * @returns Un ParsedImport avec Rows / Diffs / Kind / Format / IsMutating, ou null si JSON vide/invalide
   */
  public parse(pJson: string | null, pToolName: string | null): ParsedImport | null
  {
    if (!pJson) return null;
    const lNormalizedTool: string = (pToolName ?? '').toLowerCase();

    // - cm - Detection de l'entite par mots-cles
    const lRule: EntityRule | undefined = ENTITY_RULES.find((pR: EntityRule): boolean =>
      pR.ToolKeywords.some((pKw: string): boolean => lNormalizedTool.includes(pKw))
    );
    const lKind: EImportKind = lRule?.Kind ?? 'generic';

    // - cm - Detection "outil mutant" : prefixes specifiques a l'entite, sinon prefixes globaux
    const lIsMutating: boolean = lRule
      ? lRule.MutatingPrefixes.some((pP: string): boolean => lNormalizedTool.includes(pP))
      : GLOBAL_MUTATING_PREFIXES.some((pP: string): boolean => lNormalizedTool.includes(pP));

    let lParsed: unknown;
    try {
      lParsed = JSON.parse(pJson);
    } catch {
      return null;
    }

    // - cm - Dispatch selon le format detecte
    const lFormat: ParsedImport['Format'] = this.DetectFormat(lParsed);
    switch (lFormat) {
      case 'array':
        return {
          Kind: lKind,
          Rows: lParsed as Array<Record<string, unknown>>,
          Diffs: this.RowsToDiffs(lParsed as Array<Record<string, unknown>>, lKind),
          Format: lFormat,
          NormalizedTool: lNormalizedTool,
          IsMutating: lIsMutating
        };

      case 'envelope':
        return this.ParseEnvelope(lParsed as Record<string, unknown>, lKind, lNormalizedTool, lIsMutating, lFormat);

      case 'diff':
        return this.ParseSingleDiff(lParsed as Record<string, unknown>, lKind, lNormalizedTool, lIsMutating, lFormat);

      default:
        return null;
    }
  }

  /**
   * Detecte le format d'un JSON parse.
   * - 'array' si c'est un tableau
   * - 'envelope' si c'est un objet contenant rows/data/items (tableau)
   * - 'diff' si c'est un objet avec action + table + after
   * - 'rows' si c'est un objet avec uniquement des champs (DTO unique)
   * - 'unknown' sinon
   */
  private DetectFormat(pValue: unknown): ParsedImport['Format']
  {
    if (Array.isArray(pValue)) return 'array';
    if (pValue && typeof pValue === 'object') {
      const lObj: Record<string, unknown> = pValue as Record<string, unknown>;
      // - cm - Enveloppe : { rows | data | items : [...] }
      const lCandidate: unknown = lObj['rows'] ?? lObj['data'] ?? lObj['items'];
      if (Array.isArray(lCandidate)) return 'envelope';
      // - cm - Diff MCP : { action, table, after }
      if (typeof lObj['action'] === 'string' && 'after' in lObj) return 'diff';
      // - cm - DTO unique : objet plat
      if (Object.keys(lObj).length > 0) return 'rows';
    }
    return 'unknown';
  }

  /**
   * Parse une enveloppe { rows | data | items : [ DTO, ... ] }.
   */
  private ParseEnvelope(pObj: Record<string, unknown>, pKind: EImportKind, pTool: string, pIsMutating: boolean, pFormat: ParsedImport['Format']): ParsedImport | null
  {
    const lRows: unknown = pObj['rows'] ?? pObj['data'] ?? pObj['items'];
    if (!Array.isArray(lRows)) return null;
    return {
      Kind: pKind,
      Rows: lRows as Array<Record<string, unknown>>,
      Diffs: this.RowsToDiffs(lRows as Array<Record<string, unknown>>, pKind),
      Format: pFormat,
      NormalizedTool: pTool,
      IsMutating: pIsMutating
    };
  }

  /**
   * Parse un diff MCP unique { action, table, before, after, summary }.
   */
  private ParseSingleDiff(pObj: Record<string, unknown>, pKind: EImportKind, pTool: string, pIsMutating: boolean, pFormat: ParsedImport['Format']): ParsedImport
  {
    const lAction: 'insert' | 'update' | 'delete' = (pObj['action'] as 'insert' | 'update' | 'delete') ?? 'insert';
    const lTable: string = (pObj['table'] as string) ?? pKind;
    const lBefore: unknown = pObj['before'] ?? null;
    const lAfter: unknown = pObj['after'] ?? null;
    const lSummary: string = (pObj['summary'] as string) ?? `${lAction} ${lTable}`;
    return {
      Kind: pKind,
      Rows: lAfter && typeof lAfter === 'object' ? [lAfter as Record<string, unknown>] : [],
      Diffs: [{ Action: lAction, Table: lTable, Before: lBefore, After: lAfter, Summary: lSummary }],
      Format: pFormat,
      NormalizedTool: pTool,
      IsMutating: pIsMutating
    };
  }

  /**
   * Convertit une liste de DTOs en diffs structures (insert par defaut, used pour les outils batch).
   */
  private RowsToDiffs(pRows: Array<Record<string, unknown>>, pKind: EImportKind): ParsedDiff[]
  {
    return pRows.map((pRow: Record<string, unknown>, pIdx: number): ParsedDiff => ({
      Action: 'insert',
      Table: pKind,
      Before: null,
      After: pRow,
      Summary: `+1 ligne dans ${pKind} (idx ${pIdx + 1})`
    }));
  }

  /**
   * Construit les colonnes d'une grille pour un ensemble de lignes, en privilegiant
   * les champs prioritaires de l'entite (cf. PriorityFields) puis en completant avec
   * les autres champs rencontres dans les 5 premieres lignes.
   * @param pRows Les lignes a afficher
   * @param pKind Le type d'entite (pour la priorisation des colonnes)
   * @returns Les colonnes triees et deduppliquees, pretes pour app-grid
   */
  public buildColumns(pRows: Array<Record<string, unknown>>, pKind: EImportKind): GridColumn<Record<string, unknown>>[]
  {
    if (pRows.length === 0) return [];

    const lRule: EntityRule | undefined = ENTITY_RULES.find((pR: EntityRule): boolean => pR.Kind === pKind);
    const lPriority: readonly string[] = lRule?.PriorityFields ?? [];

    // - cm - Decouverte des cles reelles sur les 5 premieres lignes (evite explosion sur 100 colonnes)
    const lSeenKeys: Set<string> = new Set<string>();
    for (let lIdx: number = 0; lIdx < Math.min(pRows.length, 5); lIdx++) {
      for (const lKey of Object.keys(pRows[lIdx])) {
        lSeenKeys.add(lKey);
      }
    }

    // - cm - Tri : priorites en premier (dans l'ordre declare), puis le reste par ordre alphabetique
    const lSortedKeys: string[] = [
      ...lPriority.filter((pP: string): boolean => lSeenKeys.has(pP)),
      ...Array.from(lSeenKeys).filter((pK: string): boolean => !lPriority.includes(pK)).sort()
    ];

    return lSortedKeys.map((pKey: string): GridColumn<Record<string, unknown>> => ({
      Key: pKey,
      Label: this.HumanizeKey(pKey),
      Hideable: true,
      Width: this.GuessWidth(pKey)
    }));
  }

  /**
   * Transforme une cle technique (snake_case ou camelCase) en libelle lisible.
   */
  private HumanizeKey(pKey: string): string
  {
    const lSpecial: Record<string, string> = {
      id: 'ID',
      reference: 'Référence',
      prenom: 'Prénom',
      nom: 'Nom',
      email: 'Email',
      telephone1: 'Téléphone',
      telephone2: 'Téléphone 2',
      adresseRue: 'Adresse',
      adresseCp: 'Code postal',
      adresseVille: 'Ville',
      intitule: 'Intitulé',
      prixAffiche: 'Prix affiché',
      surfaceHabitable: 'Surface habitable',
      budgetMax: 'Budget max',
      surfaceMin: 'Surface min',
      dateEcheance: 'Échéance',
      createdAt: 'Créé le',
      updatedAt: 'Mis à jour le'
    };
    if (lSpecial[pKey]) return lSpecial[pKey];
    const lWords: string = pKey.replace(/[_-]+/g, ' ').replace(/([A-Z])/g, ' $1').toLowerCase().trim();
    return lWords.charAt(0).toUpperCase() + lWords.slice(1);
  }

  /**
   * Devine une largeur de colonne raisonnable selon le type de champ.
   */
  private GuessWidth(pKey: string): string
  {
    if (pKey === 'id') return '60px';
    if (pKey.includes('email')) return '180px';
    if (pKey.includes('phone') || pKey.includes('tel')) return '120px';
    if (pKey.includes('ville') || pKey.includes('adresse')) return '140px';
    if (pKey.includes('prix') || pKey.includes('budget') || pKey.includes('montant') || pKey.includes('loyer')) return '100px';
    if (pKey.includes('date') || pKey.includes('At')) return '140px';
    if (pKey.includes('description') || pKey.includes('message') || pKey.includes('commentaire')) return '200px';
    return '120px';
  }
}
