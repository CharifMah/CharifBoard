import * as signalR from '@microsoft/signalr';
import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Subject } from 'rxjs';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { environment } from '../../../environments/environment';

/**
 * Type d'étape de la boucle agent CRM (aligné avec le backend ECrmAgentStepType).
 */
export type ECrmAgentStepType = 'Think' | 'ToolCall' | 'ToolResult' | 'Llm' | 'Error' | 'Approval';

/**
 * Action planifie par l'agent CRM necessitant l'approbation de l'utilisateur avant execution.
 * Aligne avec CrmAgentPlannedAction (backend).
 */
export interface CrmAgentPlannedAction {
  /** Nom de l'outil MCP a executer. */
  ToolName: string;
  /** Arguments JSON de l'appel d'outil (brut serialise). */
  ArgsJson: string | null;
  /** Resume humain lisible genere depuis le nom de l'outil + args. */
  Summary: string;
}

/**
 * Demande d'approbation d'actions mutantes envoyee par le backend (event SignalR AgentApprovalRequest).
 * Aligne avec CrmAgentApprovalRequest (backend).
 */
export interface CrmAgentApprovalRequest {
  /** Identifiant de la session agent concernee. */
  SessionId: string;
  /** Identifiant de la demande d'approbation (= sessionId pour simplifier). */
  ApprovalId: string;
  /** Liste des actions planifiees par l'agent. */
  Actions: CrmAgentPlannedAction[];
  /** Horodatage UTC de la demande. */
  RequestedAt: string;
}

/**
 * Forme camelCase recue sur le wire SignalR (le backend sérialise en camelCase).
 * Utilisée uniquement pour la normalisation vers {@link CrmAgentStepRecord}.
 */
interface WireCrmAgentStepRecord {
  type?: string;
  iteration?: number;
  toolName?: string | null;
  toolArgsJson?: string | null;
  resultJson?: string | null;
  message?: string | null;
  thinking?: string | null;
  promptTokens?: number | null;
  completionTokens?: number | null;
  durationMs?: number | null;
  timestamp?: string;
}

/**
 * Forme camelCase reçue sur le wire SignalR pour {@link CrmAgentTurnResult}.
 */
interface WireCrmAgentTurnResult {
  sessionId?: string;
  finalMessage?: string;
  steps?: WireCrmAgentStepRecord[];
  hasError?: boolean;
  provider?: string | null;
  model?: string | null;
  iterations?: number;
  toolCallCount?: number;
  toolNames?: string[];
  totalPromptTokens?: number;
  totalCompletionTokens?: number;
  durationMs?: number;
}

/**
 * Normalise une étape reçue en camelCase vers la forme PascalCase {@link CrmAgentStepRecord}.
 * @param pWire L'objet camelCase reçu du hub
 * @returns L'étape normalisée en PascalCase
 */
function NormalizeStep(pWire: WireCrmAgentStepRecord | null | undefined): CrmAgentStepRecord {
  return {
    Type: (pWire?.type ?? 'Error') as ECrmAgentStepType,
    Iteration: pWire?.iteration ?? 0,
    ToolName: pWire?.toolName ?? null,
    ToolArgsJson: pWire?.toolArgsJson ?? null,
    ResultJson: pWire?.resultJson ?? null,
    Message: pWire?.message ?? null,
    Thinking: pWire?.thinking ?? null,
    PromptTokens: pWire?.promptTokens ?? null,
    CompletionTokens: pWire?.completionTokens ?? null,
    DurationMs: pWire?.durationMs ?? null,
    Timestamp: pWire?.timestamp ?? new Date().toISOString()
  };
}

/**
 * Forme camelCase recue sur le wire SignalR pour {@link CrmAgentApprovalRequest}.
 */
interface WireCrmAgentApprovalRequest {
  sessionId?: string;
  approvalId?: string;
  actions?: WireCrmAgentPlannedAction[];
  requestedAt?: string;
}

/**
 * Forme camelCase recue sur le wire SignalR pour {@link CrmAgentPlannedAction}.
 */
interface WireCrmAgentPlannedAction {
  toolName?: string;
  argsJson?: string | null;
  summary?: string;
}

/**
 * Normalise une demande d'approbation recue en camelCase vers la forme PascalCase {@link CrmAgentApprovalRequest}.
 * @param pWire L'objet camelCase recu du hub
 * @returns La demande d'approbation normalisee en PascalCase
 */
function NormalizeApprovalRequest(pWire: WireCrmAgentApprovalRequest | null | undefined): CrmAgentApprovalRequest {
  return {
    SessionId: pWire?.sessionId ?? '',
    ApprovalId: pWire?.approvalId ?? '',
    Actions: (pWire?.actions ?? []).map((pA: WireCrmAgentPlannedAction): CrmAgentPlannedAction => ({
      ToolName: pA.toolName ?? '',
      ArgsJson: pA.argsJson ?? null,
      Summary: pA.summary ?? ''
    })),
    RequestedAt: pWire?.requestedAt ?? new Date().toISOString()
  };
}

/**
 * Normalise un résultat de tour reçu en camelCase vers la forme PascalCase {@link CrmAgentTurnResult}.
 * @param pWire L'objet camelCase reçu du hub
 * @returns Le résultat normalisé en PascalCase
 */
function NormalizeResult(pWire: WireCrmAgentTurnResult | null | undefined): CrmAgentTurnResult {
  return {
    SessionId: pWire?.sessionId ?? '',
    FinalMessage: pWire?.finalMessage ?? '',
    Steps: (pWire?.steps ?? []).map((pS: WireCrmAgentStepRecord) => NormalizeStep(pS)),
    HasError: pWire?.hasError ?? false,
    Provider: pWire?.provider ?? null,
    Model: pWire?.model ?? null,
    Iterations: pWire?.iterations ?? 0,
    ToolCallCount: pWire?.toolCallCount ?? 0,
    ToolNames: pWire?.toolNames ?? [],
    TotalPromptTokens: pWire?.totalPromptTokens ?? 0,
    TotalCompletionTokens: pWire?.totalCompletionTokens ?? 0,
    DurationMs: pWire?.durationMs ?? 0
  };
}

/**
 * Enregistrement d'une étape de la boucle agent CRM (aligné avec CrmAgentStepRecord).
 */
export interface CrmAgentStepRecord {
  /** Type d'étape. */
  Type: ECrmAgentStepType;
  /** Numéro d'itération de la boucle agent (0-based). */
  Iteration: number;
  /** Nom de l'outil appelé (si ToolCall/ToolResult), null sinon. */
  ToolName: string | null;
  /** Arguments JSON de l'outil (si ToolCall), null sinon. */
  ToolArgsJson: string | null;
  /** Résultat JSON de l'outil (si ToolResult), null sinon. */
  ResultJson: string | null;
  /** Message libre (texte LLM ou erreur), null sinon. */
  Message: string | null;
  /** Raisonnement / thinking du LLM (si Think), null sinon. */
  Thinking: string | null;
  /** Tokens d'entrée (prompt) consommés par cet échange LLM, null sinon. */
  PromptTokens: number | null;
  /** Tokens de sortie (completion) consommés par cet échange LLM, null sinon. */
  CompletionTokens: number | null;
  /** Durée de l'étape en millisecondes. */
  DurationMs: number | null;
  /** Horodatage UTC de l'étape. */
  Timestamp: string;
}

/**
 * Résultat complet d'un tour agent CRM (aligné avec CrmAgentTurnResult).
 */
export interface CrmAgentTurnResult {
  /** Identifiant de la session. */
  SessionId: string;
  /** Message final produit par l'agent. */
  FinalMessage: string;
  /** Liste ordonnée des étapes de la boucle agent. */
  Steps: CrmAgentStepRecord[];
  /** Indique si le tour s'est terminé par une erreur. */
  HasError: boolean;
  /** Nom du fournisseur LLM utilisé. */
  Provider: string | null;
  /** Modèle LLM utilisé. */
  Model: string | null;
  /** Nombre d'itérations de la boucle agent. */
  Iterations: number;
  /** Nombre total d'appels d'outils MCP exécutés. */
  ToolCallCount: number;
  /** Liste des noms d'outils MCP utilisés. */
  ToolNames: string[];
  /** Total des tokens d'entrée (prompt) consommés sur le tour. */
  TotalPromptTokens: number;
  /** Total des tokens de sortie (completion) consommés sur le tour. */
  TotalCompletionTokens: number;
  /** Durée totale du tour en millisecondes. */
  DurationMs: number;
}
/**
 * Rponse de dmarrage d'un tour agent CRM (align avec ChatStartResponse).
 */
export interface ChatStartResponse {
  /** Identifiant de la session agent  rejoindre sur le hub CrmAgentHub. */
  SessionId: string;
}

/**
 * Options de configuration LLM pour un tour agent CRM (transport WebSocket).
 */
export interface CrmAgentChatOptions {
  /** Fournisseur LLM (dfaut ollama-local). */
  Provider?: string;
  /** Modle LLM (dfaut qwen2.5:7b, doit supporter le tool-calling Ollama). */
  Model?: string;
  /** URL d'endpoint personnalise (optionnel). */
  EndpointUrl?: string;
  /** Cl API (optionnel, saisie masque). */
  ApiKey?: string;
  /** Identifiant de session optionnel (pour reprendre une conversation). */
  SessionId?: string;
  /** Contexte de la page CRM courante (vue + table/structure affiche). */
  Context?: string;
  /** Historique des messages prcdents (pour reconstruire le contexte si la session a t purge). */
  History?: HistoryMessage[];
}

/**
 * Message d'historique envoy au backend pour reconstruire le contexte d'une conversation reprise.
 */
export interface HistoryMessage {
  /** Rle du message (User, Assistant). */
  Role: string;
  /** Contenu textuel du message. */
  Content: string;
}

/**
 * Requte de dmarrage d'un tour agent CRM via le hub SignalR (align avec StartChatHubRequest).
 */
interface StartChatHubRequest {
  /** Prompt texte saisi par l'utilisateur. */
  Prompt: string;
  /** Contexte de la page CRM courante (vue + table/structure affiche). */
  Context?: string;
  /** Nom du fichier tlvers (optionnel). */
  FileName?: string;
  /** Contenu binaire du fichier encod en base64 (optionnel). */
  FileBase64?: string;
  /** Identifiant de session optionnel (pour reprendre une conversation). */
  SessionId?: string;
  /** Fournisseur LLM (dfaut ollama-local). */
  Provider?: string;
  /** Modle LLM (dfaut qwen2.5:7b, doit supporter le tool-calling Ollama). */
  Model?: string;
  /** URL d'endpoint personnalise (optionnel). */
  EndpointUrl?: string;
  /** Cl API (optionnel, saisie masque). */
  ApiKey?: string;
  /** Historique des messages prcdents (pour reconstruire le contexte si la session a t purge). */
  History?: HistoryMessage[];
}
/**
 * Service de connexion au hub SignalR `/crm-agent-hub` du chat agent CRM.
 * Reçoit en temps réel les étapes de la boucle agent (tool calls, résultats, messages, erreurs).
 */
@Injectable({ providedIn: 'root' })
export class CrmAgentHubService extends BaseComponent {
  /** Indique si l'on s'exécute côté navigateur (SSR-safe). */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Connexion SignalR au hub agent CRM. */
  private _HubConnection: signalR.HubConnection | null = null;

  //#region Observables
  /** Émis au démarrage d'un tour agent (payload = sessionId). */
  private readonly _AgentStartedSubject = new Subject<string>();
  /** Émis à chaque étape agent (payload = sessionId, étape). */
  private readonly _AgentStepSubject = new Subject<{ sessionId: string; step: CrmAgentStepRecord }>();
  /** Émis au message final agent (payload = sessionId, message). */
  private readonly _AgentMessageSubject = new Subject<{ sessionId: string; message: string }>();
  /** Émis en cas d'erreur agent (payload = sessionId, erreur). */
  private readonly _AgentErrorSubject = new Subject<{ sessionId: string; error: string }>();
  /** Émis à la fin d'un tour agent (payload = sessionId, résultat complet). */
  private readonly _AgentDoneSubject = new Subject<{ sessionId: string; result: CrmAgentTurnResult }>();
  /** Émis lors d'une demande d'approbation d'actions mutantes (payload = sessionId, demande). */
  private readonly _AgentApprovalRequestSubject = new Subject<{ sessionId: string; request: CrmAgentApprovalRequest }>();

  /** Observable public : démarrage d'un tour agent. */
  public agentStarted$ = this._AgentStartedSubject.asObservable();
  /** Observable public : étape agent (tool call / résultat / LLM / erreur). */
  public agentStep$ = this._AgentStepSubject.asObservable();
  /** Observable public : message final agent. */
  public agentMessage$ = this._AgentMessageSubject.asObservable();
  /** Observable public : erreur agent. */
  public agentError$ = this._AgentErrorSubject.asObservable();
  /** Observable public : fin d'un tour agent. */
  public agentDone$ = this._AgentDoneSubject.asObservable();
  /** Observable public : demande d'approbation d'actions mutantes. */
  public agentApprovalRequest$ = this._AgentApprovalRequestSubject.asObservable();
  //#endregion

  //#region Public Methods
  /**
   * Démarre la connexion au hub `/crm-agent-hub`.
   * No-op côté serveur (SSR). Le token JWT est envoyé via le cookie HttpOnly (withCredentials).
   * @returns Promise résolu quand la connexion est établie
   */
  public async startConnection(): Promise<void> {
    if (!this._IsBrowser) return; // - cm - No-op côté serveur (SSR)
    if (this._HubConnection) return; // - cm - Évite une double connexion

    this._HubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${environment.SignalUrl}/crm-agent-hub`, {
        // - cm - Le token JWT est envoyé via le cookie HttpOnly (withCredentials: true)
        withCredentials: true
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000, 60000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    this._HubConnection.serverTimeoutInMilliseconds = 30000;

    this.setupEventHandlers();
    try {
      await this._HubConnection.start();
    } catch (lError) {
      this._HubConnection = null;
      throw lError;
    }
  }

  /**
   * Ferme la connexion au hub agent CRM.
   */
  public stopConnection(): void {
    if (this._HubConnection) {
      void this._HubConnection.stop();
      this._HubConnection = null;
    }
  }

  /**
   * Rejoint le group d'une session agent pour recevoir ses événements temps réel.
   * @param pSessionId L'identifiant de la session agent
   */
  public async joinSession(pSessionId: string): Promise<void> {
    this.ensureConnected();
    await this._HubConnection!.invoke('JoinSessionAsync', pSessionId);
  }

  /**
   * Quitte le group d'une session agent.
   * @param pSessionId L'identifiant de la session agent
   */
  public async leaveSession(pSessionId: string): Promise<void> {
    if (this._HubConnection?.state === signalR.HubConnectionState.Connected) {
      await this._HubConnection.invoke('LeaveSessionAsync', pSessionId);
    }
  }

  /**
   * Dmarre un tour agent CRM via WebSocket (mthode hub StartChatAsync).
   * La connexion courante est automatiquement ajoute au group de la session par le hub
   * (pas besoin d'appeler joinSession sparment).
   * Le fichier optionnel est converti en base64 pour le transport binaire SignalR.
   * @param pPrompt Le prompt texte saisi par l'utilisateur
   * @param pFile Le fichier optionnel
   * @param pOptions Les options LLM / session
   * @returns La rponse contenant le sessionId de la session agent
   */
  public async startChat(pPrompt: string, pFile: File | null, pOptions: CrmAgentChatOptions = {}): Promise<ChatStartResponse> {
    this.ensureConnected();

    // - cm - Conversion du fichier en base64 pour le transport via WebSocket
    let lFileBase64: string | undefined;
    let lFileName: string | undefined;
    if (pFile) {
      lFileName = pFile.name;
      lFileBase64 = await this.fileToBase64(pFile);
    }

    const lRequest: StartChatHubRequest = {
      Prompt: pPrompt,
      Context: pOptions.Context,
      FileName: lFileName,
      FileBase64: lFileBase64,
      SessionId: pOptions.SessionId,
      Provider: pOptions.Provider,
      Model: pOptions.Model,
      EndpointUrl: pOptions.EndpointUrl,
      ApiKey: pOptions.ApiKey,
      History: pOptions.History
    };

    return await this._HubConnection!.invoke<ChatStartResponse>('StartChatAsync', lRequest);
  }

  /** Indique si la connexion SignalR est active. */
  public get isConnected(): boolean {
    return this._HubConnection?.state === signalR.HubConnectionState.Connected;
  }

  /**
   * Repond a une demande d'approbation d'actions mutantes (methode hub RespondApprovalAsync).
   * Selection granulaire : seules les actions dont l'index est dans pApprovedIndices sont executees.
   * @param pSessionId L'identifiant de la session agent
   * @param pApprovedIndices Indices (0-based) des actions approuves dans la liste Actions. Tableau vide = tout refus.
   * @param pFeedback Feedback optionnel (notamment en cas de refus partiel)
   */
  public async respondApproval(pSessionId: string, pApprovedIndices: number[], pFeedback?: string): Promise<void> {
    this.ensureConnected();
    await this._HubConnection!.invoke('RespondApprovalAsync', pSessionId, pApprovedIndices, pFeedback ?? null);
  }

  /**
   * Annule le tour agent en cours d'une session (methode hub StopChatAsync).
   * @param pSessionId L'identifiant de la session agent
   */
  public async stopChat(pSessionId: string): Promise<void> {
    this.ensureConnected();
    await this._HubConnection!.invoke('StopChatAsync', pSessionId);
  }
  //#endregion

  //#region Private Methods
  /**
   * Branche les handlers sur les événements serveur du hub agent CRM.
   */
  private setupEventHandlers(): void {
    if (!this._HubConnection) return;

    // - cm - Démarrage d'un tour agent
    this._HubConnection.on('AgentStarted', (pSessionId: string) => {
      this._AgentStartedSubject.next(pSessionId);
    });

    // - cm - Une étape agent (tool call / résultat / LLM / erreur) — normalisation camelCase -> PascalCase
    this._HubConnection.on('AgentStep', (pSessionId: string, pStep: WireCrmAgentStepRecord) => {
      this._AgentStepSubject.next({ sessionId: pSessionId, step: NormalizeStep(pStep) });
    });

    // - cm - Message final de l'agent
    this._HubConnection.on('AgentMessage', (pSessionId: string, pMessage: string) => {
      this._AgentMessageSubject.next({ sessionId: pSessionId, message: pMessage });
    });

    // - cm - Erreur agent
    this._HubConnection.on('AgentError', (pSessionId: string, pError: string) => {
      this._AgentErrorSubject.next({ sessionId: pSessionId, error: pError });
    });

    // - cm - Fin d'un tour agent (résultat complet) — normalisation camelCase -> PascalCase
    this._HubConnection.on('AgentDone', (pSessionId: string, pResult: WireCrmAgentTurnResult) => {
      this._AgentDoneSubject.next({ sessionId: pSessionId, result: NormalizeResult(pResult) });
    });

    // - cm - Demande d'approbation d'actions mutantes — normalisation camelCase -> PascalCase
    this._HubConnection.on('AgentApprovalRequest', (pSessionId: string, pRequest: WireCrmAgentApprovalRequest) => {
      this._AgentApprovalRequestSubject.next({ sessionId: pSessionId, request: NormalizeApprovalRequest(pRequest) });
    });
  }

  /**
   * Vérifie que la connexion SignalR est active avant un invoke.
   * @throws Error si la connexion n'est pas établie
   */
  private ensureConnected(): void {
    if (this._HubConnection?.state !== signalR.HubConnectionState.Connected) {
      throw new Error('SignalR agent CRM non connecté');
    }
  }
  /**
   * Convertit un fichier en chane base64 (sans le prfixe data:).
   * @param pFile Le fichier  convertir
   * @returns Le contenu binaire encod en base64
   */
  private fileToBase64(pFile: File): Promise<string> {
    return new Promise<string>((pResolve, pReject): void => {
      const lReader: FileReader = new FileReader();
      lReader.onload = (): void => {
        // - cm - Result de forme "data:<mime>;base64,<payload>" : on extrait le payload base64
        const lResult: string = lReader.result as string;
        const lCommaIdx: number = lResult.indexOf(',');
        pResolve(lCommaIdx >= 0 ? lResult.slice(lCommaIdx + 1) : lResult);
      };
      lReader.onerror = (): void => pReject(lReader.error ?? new Error('chec de lecture du fichier'));
      lReader.readAsDataURL(pFile);
    });
  }  //#endregion
}