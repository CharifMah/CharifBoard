import { Injectable } from '@angular/core';
import axios from 'axios';
import { environment } from '../../../environments/environment';

/**
 * Service d'appel API du chat agent CRM.
 * Le démarrage d'un tour agent se fait via le hub SignalR CrmAgentHub (CrmAgentHubService.startChat).
 * Ce service ne conserve que la lecture de l'historique d'une session (HTTP GET).
 */
@Injectable({ providedIn: 'root' })
export class CrmAgentApiService {
  /**
   * Récupère l'historique d'une session agent.
   * @param pSessionId L'identifiant de la session
   * @returns L'historique des messages ou null si introuvable
   */
  public async getHistory(pSessionId: string): Promise<unknown[] | null> {
    try {
      const lResponse = await axios.get<unknown[]>(
        `${environment.apiUrl}/crm-agent/sessions/${pSessionId}/history`,
        { withCredentials: true }
      );
      return lResponse.data;
    } catch (lError) {
      if (axios.isAxiosError(lError) && lError.response?.status === 404) {
        return null; // - cm - Session expirée ou inexistante
      }
      throw lError;
    }
  }
}