import * as signalR from '@microsoft/signalr';
import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Subject } from 'rxjs';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { environment } from '../../../environments/environment';

/**
 * Charge utile d'une mise a jour du dashboard CRM.
 */
interface CrmDashboardUpdate {
  /** Type de metrique concernee (ex: ca_encaisse, mandats, compromis) */
  Metric: string;
  /** Nouvelle valeur de la metrique */
  Value: number;
}

/**
 * Charge utile d'une activite CRM ajoutee.
 */
interface CrmActivity {
  /** Libelle de l'activite */
  Label: string;
  /** Date de l'activite (ISO 8601) */
  At: string;
}

/**
 * Charge utile d'une progression d'import IA.
 */
export interface AiImportProgressPayload {
  /** Identifiant du job */
  JobId: number;
  /** Statut courant du job */
  Status: string;
  /** Message de progression */
  Message: string;
}

/**
 * Charge utile d'une preview d'import IA prete.
 */
export interface AiImportPreviewReadyPayload {
  /** Identifiant du job */
  JobId: number;
  /** Resultat brut JSON extrait */
  ResultJson: string;
}

/**
 * Charge utile d'un echec d'import IA.
 */
export interface AiImportFailedPayload {
  /** Identifiant du job */
  JobId: number;
  /** Message d'erreur */
  Error: string;
}

/**
 * Charge utile d'un import IA termine.
 */
export interface AiImportCompletedPayload {
  /** Identifiant du job */
  JobId: number;
  /** Nombre de contacts importes */
  Contacts: number;
  /** Nombre de biens importes */
  Properties: number;
  /** Nombre d'affaires importees */
  Affaires: number;
  /** Nombre de prospections importees */
  Prospections: number;
}

/**
 * Service de connexion au hub SignalR `/crm-hub` du module CRM.
 * Gere la connexion temps reel (dashboard, alertes, activites) et expose
 * des observables pour les mises a jour recues du serveur.
 */
@Injectable({ providedIn: 'root' })
export class CrmHubService extends BaseComponent {
  /** Indique si l'on s'execute cote navigateur (SSR-safe) */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Connexion SignalR au hub CRM */
  private _HubConnection: signalR.HubConnection | null = null;

  //#region Observables
  private dashboardUpdatedSubject = new Subject<CrmDashboardUpdate>();
  /** Emet a chaque mise a jour d'une metrique du dashboard CRM */
  public dashboardUpdated$ = this.dashboardUpdatedSubject.asObservable();

  private alerteReceivedSubject = new Subject<string>();
  /** Emet a chaque alerte CRM recue */
  public alerteReceived$ = this.alerteReceivedSubject.asObservable();

  private activityAddedSubject = new Subject<CrmActivity>();
  /** Emet a chaque ajout d'activite dans le flux CRM */
  public activityAdded$ = this.activityAddedSubject.asObservable();

  private stateSubject = new BehaviorSubject<string>('Disconnected');
  /** Etat de la connexion SignalR (Connected, Reconnecting, Disconnected, Error) */
  public connectionState$ = this.stateSubject.asObservable();

  private aiImportProgressSubject = new Subject<AiImportProgressPayload>();
  /** Emet a chaque progression d'un import IA */
  public aiImportProgress$ = this.aiImportProgressSubject.asObservable();

  private aiImportPreviewReadySubject = new Subject<AiImportPreviewReadyPayload>();
  /** Emet quand la preview d'un import IA est prete */
  public aiImportPreviewReady$ = this.aiImportPreviewReadySubject.asObservable();

  private aiImportFailedSubject = new Subject<AiImportFailedPayload>();
  /** Emet quand un import IA echoue */
  public aiImportFailed$ = this.aiImportFailedSubject.asObservable();

  private aiImportCompletedSubject = new Subject<AiImportCompletedPayload>();
  /** Emet quand un import IA est termine */
  public aiImportCompleted$ = this.aiImportCompletedSubject.asObservable();
  //#endregion

  //#region Public Methods
  /**
   * Demarre la connexion au hub `/crm-hub`.
   * No-op cote serveur (SSR). Injecte le token JWT via le cookie HttpOnly
   * (withCredentials: true), comme le ChatService.
   * @returns Promise resolu quand la connexion est etablie
   */
  public async startConnection(): Promise<void> {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    // - cm - Evite une double connexion si deja connecte
    if (this._HubConnection) {
      return;
    }

    this._HubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${environment.SignalUrl}/crm-hub`, {
        // - cm - Le token JWT est envoye via le cookie HttpOnly (withCredentials: true)
        withCredentials: true
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000, 60000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    this._HubConnection.serverTimeoutInMilliseconds = 30000;

    this.setupEventHandlers();
    this.setupConnectionStateHandlers();

    try {
      await this._HubConnection.start();
      this.stateSubject.next('Connected');
    } catch (lError) {
      this.stateSubject.next('Error');
      throw lError;
    }
  }

  /**
   * Ferme la connexion au hub CRM.
   */
  public stopConnection(): void {
    if (this._HubConnection) {
      void this._HubConnection.stop();
      this._HubConnection = null;
      this.stateSubject.next('Disconnected');
    }
  }

  /**
   * Rejoint le groupe dashboard du CRM pour recevoir les mises a jour temps reel.
   */
  public async joinDashboard(): Promise<void> {
    this.ensureConnected();
    await this._HubConnection!.invoke('JoinDashboardAsync');
  }

  /**
   * Quitte le groupe dashboard du CRM.
   */
  public async leaveDashboard(): Promise<void> {
    if (this._HubConnection?.state === signalR.HubConnectionState.Connected) {
      await this._HubConnection.invoke('LeaveDashboardAsync');
    }
  }

  /** Indique si la connexion SignalR est active */
  public get isConnected(): boolean {
    return this._HubConnection?.state === signalR.HubConnectionState.Connected;
  }
  //#endregion

  //#region Private Methods
  /**
   * Branche les handlers sur les evenements serveur du hub CRM.
   */
  private setupEventHandlers(): void {
    if (!this._HubConnection) return;

    // - cm - Mise a jour d'une metrique du dashboard
    this._HubConnection.on('DashboardUpdated', (pMetric: string, pValue: number) => {
      this.dashboardUpdatedSubject.next({ Metric: pMetric, Value: pValue });
    });

    // - cm - Alerte CRM recue
    this._HubConnection.on('AlerteReceived', (pMessage: string) => {
      this.alerteReceivedSubject.next(pMessage);
    });

    // - cm - Activite ajoutee au flux CRM
    this._HubConnection.on('ActivityAdded', (pLabel: string, pAt: string) => {
      this.activityAddedSubject.next({ Label: pLabel, At: pAt });
    });

    // - cm - Progression d'un import IA
    this._HubConnection.on('AiImportProgress', (pJobId: number, pStatus: string, pMessage: string) => {
      this.aiImportProgressSubject.next({ JobId: pJobId, Status: pStatus, Message: pMessage });
    });

    // - cm - Preview d'import IA prete
    this._HubConnection.on('AiImportPreviewReady', (pJobId: number, pResultJson: string) => {
      this.aiImportPreviewReadySubject.next({ JobId: pJobId, ResultJson: pResultJson });
    });

    // - cm - Echec d'un import IA
    this._HubConnection.on('AiImportFailed', (pJobId: number, pError: string) => {
      this.aiImportFailedSubject.next({ JobId: pJobId, Error: pError });
    });

    // - cm - Import IA termine
    this._HubConnection.on('AiImportCompleted', (pJobId: number, pContacts: number, pProperties: number, pAffaires: number, pProspections: number) => {
      this.aiImportCompletedSubject.next({ JobId: pJobId, Contacts: pContacts, Properties: pProperties, Affaires: pAffaires, Prospections: pProspections });
    });
  }

  /**
   * Branche les handlers d'etat de connexion (reconnexion, fermeture).
   */
  private setupConnectionStateHandlers(): void {
    if (!this._HubConnection) return;

    this._HubConnection.onreconnecting(() => {
      this.stateSubject.next('Reconnecting');
    });

    this._HubConnection.onreconnected(() => {
      this.stateSubject.next('Connected');
    });

    this._HubConnection.onclose(() => {
      this.stateSubject.next('Disconnected');
    });
  }

  /**
   * Verifie que la connexion SignalR est active avant un invoke.
   * @throws Error si la connexion n'est pas etablie
   */
  private ensureConnected(): void {
    if (this._HubConnection?.state !== signalR.HubConnectionState.Connected) {
      throw new Error('SignalR CRM non connecté');
    }
  }
  //#endregion
}