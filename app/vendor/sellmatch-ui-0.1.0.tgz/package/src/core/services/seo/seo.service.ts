import { Injectable, inject, PLATFORM_ID, DOCUMENT } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Meta, Title } from '@angular/platform-browser';


/**
 * Interface décrivant les meta tags SEO d'une page.
 */
export interface ISeoPageMeta
{
  /** Titre de la page (balise <title>) */
  Title: string;
  /** Description de la page (meta description) */
  Description: string;
  /** URL canonique de la page */
  CanonicalUrl: string;
  /** Type Open Graph (défaut: 'website') */
  OgType?: string;
  /** Titre Open Graph (défaut: Title) */
  OgTitle?: string;
  /** Description Open Graph (défaut: Description) */
  OgDescription?: string;
  /** Image Open Graph (défaut: logo SellMatch) */
  OgImage?: string;
  /** Indique si la page doit être indexée (défaut: true) */
  Index?: boolean;
}

/**
 * Service centralisé pour la gestion des meta tags SEO par route.
 * SSR-safe : fonctionne côté serveur (prérendu) et côté navigateur.
 */
@Injectable({
  providedIn: 'root'
})
export class SeoService
{
  //#region Attributes
  private readonly _Title: Title = inject(Title);
  private readonly _Meta: Meta = inject(Meta);
  private readonly _Document: Document = inject(DOCUMENT);
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** URL de base du site */
  private readonly _BaseUrl: string = 'https://www.sellmatch.fr';
  /** Image par défaut pour Open Graph */
  private readonly _DefaultOgImage: string = 'https://www.sellmatch.fr/assets/logo.webp';
  //#endregion

  //#region Methods
  /**
   * Configure tous les meta tags SEO pour une page.
   * @param pMeta Les meta tags à appliquer
   */
  public SetPageMeta(pMeta: ISeoPageMeta): void
  {
    // - cm - Titre de la page
    this._Title.setTitle(pMeta.Title);

    // - cm - Meta description
    this._Meta.updateTag({ name: 'description', content: pMeta.Description });

    // - cm - Robots
    const lRobotsContent: string = pMeta.Index === false ? 'noindex, nofollow' : 'index, follow';
    this._Meta.updateTag({ name: 'robots', content: lRobotsContent });

    // - cm - Open Graph
    this._Meta.updateTag({ property: 'og:title', content: pMeta.OgTitle ?? pMeta.Title });
    this._Meta.updateTag({ property: 'og:description', content: pMeta.OgDescription ?? pMeta.Description });
    this._Meta.updateTag({ property: 'og:url', content: pMeta.CanonicalUrl });
    this._Meta.updateTag({ property: 'og:type', content: pMeta.OgType ?? 'website' });
    this._Meta.updateTag({ property: 'og:image', content: pMeta.OgImage ?? this._DefaultOgImage });

    // - cm - Twitter Card
    this._Meta.updateTag({ name: 'twitter:title', content: pMeta.OgTitle ?? pMeta.Title });
    this._Meta.updateTag({ name: 'twitter:description', content: pMeta.OgDescription ?? pMeta.Description });
    this._Meta.updateTag({ name: 'twitter:image', content: pMeta.OgImage ?? this._DefaultOgImage });

    // - cm - Balise canonique
    this._UpdateCanonical(pMeta.CanonicalUrl);
  }

  /**
   * Injecte un script JSON-LD dans le document pour les données structurées Schema.org.
   * @param pKey Identifiant unique du script (pour éviter les doublons)
   * @param pData L'objet JSON-LD à injecter
   */
  public SetJsonLd(pKey: string, pData: Record<string, any>): void
  {
    const lScriptId: string = `jsonld-${pKey}`;
    let lScript: HTMLScriptElement | null = this._Document.getElementById(lScriptId) as HTMLScriptElement | null;

    if (!lScript)
    {
      lScript = this._Document.createElement('script');
      lScript.id = lScriptId;
      lScript.setAttribute('type', 'application/ld+json');
      this._Document.body.appendChild(lScript);
    }

    lScript.textContent = JSON.stringify(pData);
  }

  /**
   * Met à jour ou crée la balise canonique.
   * @param pCanonicalUrl L'URL canonique de la page
   */
  private _UpdateCanonical(pCanonicalUrl: string): void
  {
    let lCanonicalLink: HTMLLinkElement | null = this._Document.querySelector('link[rel="canonical"]');

    if (!lCanonicalLink)
    {
      lCanonicalLink = this._Document.createElement('link');
      lCanonicalLink.setAttribute('rel', 'canonical');
      this._Document.head.appendChild(lCanonicalLink);
    }

    lCanonicalLink.setAttribute('href', pCanonicalUrl);
  }

  /**
   * Construit une URL absolue à partir d'un chemin relatif.
   * @param pPath Le chemin relatif (ex: '/estimation-immobiliere')
   * @returns L'URL absolue (ex: 'https://www.sellmatch.fr/estimation-immobiliere')
   */
  public BuildUrl(pPath: string): string
  {
    if (pPath.startsWith('http')) return pPath;
    return `${this._BaseUrl}${pPath.startsWith('/') ? '' : '/'}${pPath}`;
  }
  //#endregion
}