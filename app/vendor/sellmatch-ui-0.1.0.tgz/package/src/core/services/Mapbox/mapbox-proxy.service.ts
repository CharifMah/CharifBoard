import { Injectable } from '@angular/core';

/**
 * Service minimal qui compose l'URL du style spec Mapbox a partir d'un styleId.
 * Cf. https://docs.mapbox.com/api/maps/styles/
 * - cm - Format retourne : mapbox://styles/<styleId>
 * - cm - L'API publique de mapbox-gl se charge ensuite de fetcher le JSON,
 * - cm - signer les sous-requetes et de gerer le cache.
 *
 * Note : la désactivation de la telemetry Mapbox (`mapboxgl.config.EVENTS_URL = null`)
 * est faite dans map-card.component.ts :InitMap(), juste après le `await import('mapbox-gl')`,
 * parce que mapbox-gl est un lazy chunk et n'est pas dispo à l'instanciation de ce service.
 */
@Injectable({ providedIn: 'root' })
export class MapboxProxyService
{
  /**
   * Construit l'URL du style spec Mapbox a partir d'un identifiant.
   * @param pStyleId L'identifiant Mapbox Studio (ex: 'mapbox/streets-v12'
   *                 ou 'adminsellmatch/cmsk15ulf00wx01s8dg9278mv' pour un custom)
   * @returns L'URL 'mapbox://styles/<styleId>' que mapboxgl.Map() accepte
   */
  public GetStyleSpecUrl(pStyleId: string): string
  {
    return `mapbox://styles/${pStyleId}`;
  }
}
