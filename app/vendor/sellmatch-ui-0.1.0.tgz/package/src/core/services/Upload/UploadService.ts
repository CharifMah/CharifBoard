import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../core/base/ServiceBase';
import { EmptyCritereDTO } from '../../../core/base/EmptyCritereDTO';
import { EmptyDTO } from '../../../core/base/EmptyDTO';

@Injectable({
  providedIn: 'root'
})
export class UploadService extends ServiceBase<EmptyDTO, EmptyCritereDTO>
{
  constructor ()
  {
    super('Upload');
  }

  /**
   * Télécharge une image sur le serveur
   * @param file Le fichier image à uploader
   * @param pSignal Signal d'annulation optionnel pour permettre l'annulation de l'upload
   * @returns L'URL de l'image téléchargée
   */
  async uploadImage(file: File, pSignal?: AbortSignal): Promise<string>
  {
    const lUrl = `${this.apiUrl}/image`;
    const lFormData = new FormData();
    lFormData.append('file', file);

    // - cm - Timeout de 5 minutes pour les uploads volumineux, annulable via AbortController
    const lAbortController = new AbortController();
    const lTimeoutId = setTimeout(() => lAbortController.abort(), 5 * 60 * 1000);

    const lOnAbort = (): void => lAbortController.abort();
    pSignal?.addEventListener('abort', lOnAbort);

    try
    {
      // - cm - Axios génère automatiquement multipart/form-data avec le bon boundary pour FormData
      // On supprime explicitement Content-Type sur cette requête uniquement, sans toucher à l'instance globale
      const lResponse = await this.axiosInstance.post<{ url: string }>(lUrl, lFormData,
      {
        headers:
        {
          'Content-Type': undefined
        },
        signal: lAbortController.signal,
        // - cm - Désactive le timeout d'Axios car on gère l'annulation manuellement
        timeout: 0
      });

      return lResponse.data.url;
    }
    catch (lError: any)
    {
      if (lError.name === 'AbortError' || lError.code === 'ERR_CANCELED')
      {
        console.warn("Upload d'image annulé");
        throw new Error("L'upload a été annulé ou a expiré.");
      }

      console.error("Erreur lors de l'upload d'image:", lError);
      throw new Error(this.handleError(lError));
    }
    finally
    {
      clearTimeout(lTimeoutId);
      pSignal?.removeEventListener('abort', lOnAbort);
    }
  }

  /**
   * Supprime une image du serveur
   * @param imageUrl L'URL de l'image à supprimer
   * @returns Un objet indiquant le succès ou l'échec de l'opération
   */
  async deleteImage(imageUrl: string): Promise<{ success: boolean, message: string }>
  {
    try
    {
      if (!imageUrl)
      {
        return { success: false, message: "URL de l'image non fournie" };
      }

      const lUrl = `${this.apiUrl}/image`;

      const lResponse = await this.axiosInstance.delete<{ success: boolean, message: string }>(
        lUrl,
        {
          params: { imageUrl }
        }
      );

      return lResponse.data;
    } catch (lError: any)
    {
      console.error("Erreur lors de la suppression d'image:", lError);

      // Retour d'un objet structuré même en cas d'erreur
      if (lError.response && lError.response.status === 404)
      {
        return {
          success: false,
          message: "Image non trouvée ou déjà supprimée"
        };
      }

      return {
        success: false,
        message: this.handleError(lError)
      };
    }
  }
}
