import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { ITutorialConfig, ITutorialStep, TTutorialViewChangeCallback } from './tutorial.types';
import { TranslationService } from '../../../core/services/i18n/TranslationService';

/**
 * Default storage key suffix (used when no custom key is provided in the config).
 */
const DEFAULT_DONE_STORAGE_KEY: string = 'sellmatch.tutorial.done';

/**
 * Empty default flow — the playground / features supply their own steps at `Start` time.
 */
const EMPTY_DEFAULT_STEPS: ITutorialStep[] = [];

/**
 * i18n key prefix used to resolve step texts.
 * - cm - The full key is `tutorial.steps.<stepId>.title|description|tip|link`.
 */
const TUTORIAL_I18N_PREFIX: string = 'tutorial.steps';

/**
 * i18n key prefix used to resolve the overlay UI strings (buttons, counters).
 * - cm - Keys: `tutorial.ui.stepCounter`, `tutorial.ui.skip`, `tutorial.ui.previous`,
 *         `tutorial.ui.next`, `tutorial.ui.finish`, `tutorial.ui.tipLabel`, `tutorial.ui.linkLabel`.
 */
const TUTORIAL_UI_I18N_PREFIX: string = 'tutorial.ui';

/**
 * Generic, framework-wide service managing guided tutorial flows.
 *
 * Responsibilities:
 * - Store the list of steps and the current index (signals).
 * - Trigger a view change via the `OnViewChange` callback when a step requires one.
 * - Persist the "done" state in `localStorage` under a configurable key so a flow
 *   can be auto-launched only on first visit.
 * - Resolve i18n strings (Title/Description/Tip/Link) for each step via the
 *   `TranslationService`. Falls back to the raw FR values declared in the
 *   step object if the i18n key is missing (e.g. SSR, first frame, JSON not loaded).
 *
 * The service is **not** tied to the CRM. It is shared and configured per-flow by callers
 * (CRM, playground, etc.) via `Start(config)` or `Start(steps)`.
 */
@Injectable({
  providedIn: 'root'
})
export class TutorialService {
  //#region Attributes
  /** SSR-safe flag for `localStorage` access. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** localStorage key used to persist the "done" flag. */
  private _DoneStorageKey: string = DEFAULT_DONE_STORAGE_KEY;

  /** Optional global title shown in a launcher tooltip. */
  private _Title: string = '';

  /** Optional global icon shown alongside the title (Material Icons name). */
  private _Icon: string = '';

  /**
   * Translation service (singleton, injected via Angular DI).
   * - cm - Used to resolve step Title/Description/Tip/Link strings + UI labels
   *         (buttons, counter). Reads the `tutorial.steps.<id>.*` and `tutorial.ui.*`
   *         keys loaded via `loadPageTranslations('crm.tutorial')`.
   */
  private readonly _Translation: TranslationService = inject(TranslationService);
  //#endregion

  //#region Properties
  /** Signal: true while a tutorial overlay is being shown. */
  public readonly IsActive = signal<boolean>(false);

  /** Signal: current step index (0-based). */
  public readonly CurrentStepIndex = signal<number>(0);

  /** Signal: active steps for the current tutorial (defaults to empty until `Start` is called). */
  public readonly Steps = signal<ITutorialStep[]>(EMPTY_DEFAULT_STEPS);

  /**
   * Computed signal: current step with i18n-resolved Title/Description/Tip/Link.
   * - cm - Reads `_Translation.InstantTick()` so the computed re-evaluates on every
   *         language change. The fallback values are the raw FR strings declared on
   *         the step object (used when the i18n key is missing).
   *         Returns null if the current index is out of range.
   */
  public readonly CurrentStep = computed<ITutorialStep | null>(() => {
    // - cm - Read InstantTick so the computed re-evaluates on language change
    this._Translation.InstantTick();
    const lIndex: number = this.CurrentStepIndex();
    const lSteps: ITutorialStep[] = this.Steps();
    if (lIndex < 0 || lIndex >= lSteps.length) return null;
    const lStep: ITutorialStep = lSteps[lIndex];
    return this._ResolveStepI18n(lStep);
  });

  /**
   * Computed signal: localized step counter string (e.g. "Step 1 / 5").
   * - cm - Returned empty if the i18n key is missing so the overlay can hide it.
   */
  public readonly StepCounterLabel = computed<string>(() => {
    this._Translation.InstantTick();
    const lTemplate: string = this._Translation.translate(`${TUTORIAL_UI_I18N_PREFIX}.stepCounter`);
    if (!lTemplate || lTemplate.startsWith(TUTORIAL_UI_I18N_PREFIX)) {
      return '';
    }
    return lTemplate
      .replace('{{current}}', String(this.CurrentStepIndex() + 1))
      .replace('{{total}}', String(this.Steps().length));
  });

  /** Read-only view on the configured global title. */
  public get Title(): string {
    return this._Title;
  }

  /** Read-only view on the configured global icon. */
  public get Icon(): string {
    return this._Icon;
  }

  /** Read-only view on the active storage key. */
  public get DoneStorageKey(): string {
    return this._DoneStorageKey;
  }

  /** Callback invoked when a step requires a view change. */
  public OnViewChange: TTutorialViewChangeCallback | null = null;
  //#endregion

  //#region Methods
  /**
   * Indicates whether the current tutorial has already been completed or skipped.
   * @returns true if the user has seen the flow (and should not be auto-launched).
   */
  public IsDone(): boolean {
    if (!this._IsBrowser) return false;
    try {
      return localStorage.getItem(this._DoneStorageKey) === 'true';
    } catch {
      return false;
    }
  }

  /**
   * Starts a custom tutorial flow with the supplied steps.
   * Convenience wrapper around `StartConfig`.
   * @param pSteps The steps to play.
   */
  public Start(pSteps: ITutorialStep[]): void;

  /**
   * Starts a custom tutorial flow with the supplied configuration.
   * Navigates to the view of the first step if it declares one, then activates the overlay.
   * @param pConfig The tutorial configuration (steps, storage key, title, icon).
   */
  public Start(pConfig: ITutorialConfig): void;

  /**
   * Starts a custom tutorial flow with the supplied steps or config.
   * Navigates to the view of the first step if it declares one, then activates the overlay.
   * @param pInput Either an `ITutorialStep[]` or an `ITutorialConfig`.
   */
  public Start(pInput: ITutorialStep[] | ITutorialConfig): void {
    const lConfig: ITutorialConfig = Array.isArray(pInput)
      ? { Steps: pInput }
      : pInput;

    if (!lConfig.Steps || lConfig.Steps.length === 0) return;

    this._DoneStorageKey = lConfig.DoneStorageKey ?? DEFAULT_DONE_STORAGE_KEY;
    this._Title = lConfig.Title ?? '';
    this._Icon = lConfig.Icon ?? '';

    // - cm - Resolve the starting index. If a CurrentView is provided, jump to the first
    // step whose NavigateTo matches this view (so the tutorial opens on the page the
    // user is currently viewing). Otherwise start at 0 (welcome).
    const lStartIndex: number = this._ResolveStartIndex(lConfig);

    // - cm - Force re-evaluation chain: reset Steps + index first, then set the new steps,
    // then re-set index to the resolved start, then activate. This guarantees Angular
    // signals propagate a real change even if the previous state already had the same index.
    this.Steps.set([]);
    this.CurrentStepIndex.set(-1);
    this.Steps.set(lConfig.Steps);
    this.CurrentStepIndex.set(lStartIndex);
    this.IsActive.set(true);

    // - cm - If the starting step requires a navigation, trigger it through the callback
    // (only if we're not already on that view — avoids redundant navigation).
    const lStart: ITutorialStep | undefined = lConfig.Steps[lStartIndex];
    if (lStart?.NavigateTo && this.OnViewChange && lStart.NavigateTo !== lConfig.CurrentView) {
      this.OnViewChange(lStart.NavigateTo);
    }
  }

  /**
   * Resolves the index at which the tutorial should start. If a current view is
   * provided and matches a step's `NavigateTo`, the tutorial opens directly on that
   * step. Otherwise, returns 0 (the welcome step).
   * @param pConfig The tutorial configuration.
   * @returns The step index to start at (always >= 0 and < Steps.length).
   */
  private _ResolveStartIndex(pConfig: ITutorialConfig): number {
    const lView: string | undefined = pConfig.CurrentView;
    if (!lView) return 0;
    const lSteps: ITutorialStep[] = pConfig.Steps;
    for (let i = 0; i < lSteps.length; i++) {
      if (lSteps[i].NavigateTo === lView) {
        return i;
      }
    }
    return 0;
  }

  /**
   * Advances to the next step. If the next step requires a view change, the
   * `OnViewChange` callback is triggered. On the last step, completes the tutorial.
   */
  public Next(): void {
    const lCurrent: number = this.CurrentStepIndex();
    const lNext: number = lCurrent + 1;
    const lSteps: ITutorialStep[] = this.Steps();

    if (lNext >= lSteps.length) {
      this.Complete();
      return;
    }

    this.CurrentStepIndex.set(lNext);

    const lStep: ITutorialStep | undefined = lSteps[lNext];
    if (lStep?.NavigateTo && this.OnViewChange) {
      this.OnViewChange(lStep.NavigateTo);
    }
  }

  /**
   * Goes back to the previous step. Blocked at the first step (handled in the UI via disabled).
   */
  public Prev(): void {
    const lCurrent: number = this.CurrentStepIndex();
    const lPrev: number = lCurrent - 1;
    if (lPrev < 0) return; // - cm - First step: no previous

    this.CurrentStepIndex.set(lPrev);

    const lSteps: ITutorialStep[] = this.Steps();
    const lStep: ITutorialStep | undefined = lSteps[lPrev];
    if (lStep?.NavigateTo && this.OnViewChange) {
      this.OnViewChange(lStep.NavigateTo);
    }
  }

  /**
   * Skips / interrupts the tutorial. Marks `done=true` in `localStorage` so the flow
   * will not be auto-launched on the next visit.
   */
  public Skip(): void {
    this._MarkDone();
    this.IsActive.set(false);
    this.CurrentStepIndex.set(0);
  }

  /**
   * Completes the tutorial (semantically equivalent to Skip but means "finished").
   * Marks `done=true` and deactivates the overlay.
   */
  public Complete(): void {
    this._MarkDone();
    this.IsActive.set(false);
    this.CurrentStepIndex.set(0);
  }

  /**
   * Resets the state: clears the `done` flag from `localStorage`.
   * Useful for an admin / debug "Replay tutorial on next visit" button.
   */
  public Reset(): void {
    if (!this._IsBrowser) return;
    try {
      localStorage.removeItem(this._DoneStorageKey);
    } catch {
      // - cm - Storage unavailable (private mode, quota exceeded): silently ignored
    }
    this.IsActive.set(false);
    this.CurrentStepIndex.set(0);
  }

  /**
   * Indicates whether the current step is the last one (so the UI shows "Terminer" instead of "Suivant").
   * @returns true if the current step is the final one.
   */
  public IsLastStep(): boolean {
    return this.CurrentStepIndex() >= this.Steps().length - 1;
  }

  /**
   * Indicates whether the current step is the first one (so the UI disables the "Précédent" button).
   * @returns true if the current step is index 0.
   */
  public IsFirstStep(): boolean {
    return this.CurrentStepIndex() <= 0;
  }

  /**
   * Returns the localized label for a UI key (e.g. 'skip', 'previous', 'next', 'finish').
   * Returns the key if the i18n value is missing.
   * @param pKey One of 'skip' | 'previous' | 'next' | 'finish' | 'tipLabel' | 'linkLabel'.
   * @returns The translated string.
   */
  public GetUiLabel(pKey: 'skip' | 'previous' | 'next' | 'finish' | 'tipLabel' | 'linkLabel'): string {
    this._Translation.InstantTick();
    const lTranslated: string = this._Translation.translate(`${TUTORIAL_UI_I18N_PREFIX}.${pKey}`);
    if (lTranslated && !lTranslated.startsWith(TUTORIAL_UI_I18N_PREFIX)) {
      return lTranslated;
    }
    // - cm - Fallback FR (le service doit renvoyer la même langue que la valeur
    // locale sur l'objet step pour rester cohérent si le JSON n'a pas chargé).
    switch (pKey) {
      case 'skip': return 'Passer';
      case 'previous': return 'Précédent';
      case 'next': return 'Suivant';
      case 'finish': return 'Terminer';
      case 'tipLabel': return 'Astuce';
      case 'linkLabel': return 'En savoir plus';
      default: return pKey;
    }
  }
  //#endregion

  //#region Helpers
  /**
   * Marks the `done=true` flag in `localStorage` (best-effort).
   */
  private _MarkDone(): void {
    if (!this._IsBrowser) return;
    try {
      localStorage.setItem(this._DoneStorageKey, 'true');
    } catch {
      // - cm - Storage unavailable (private mode, quota exceeded): silently ignored
    }
  }

  /**
   * Returns a copy of the given step with Title/Description/Tip/Link resolved via i18n.
   * - cm - The raw values on the step object are kept as fallback (FR) when the i18n
   *         key is missing. Selector / NavigateTo / Placement / Icon / LinkUrl are
   *         NOT touched (they are not translated).
   * @param pStep The step to resolve.
   * @returns A new step object with localized strings.
   */
  private _ResolveStepI18n(pStep: ITutorialStep): ITutorialStep {
    const lId: string = pStep.Id;
    return {
      ...pStep,
      Title: this._TranslateStepField(lId, 'title', pStep.Title),
      Description: this._TranslateStepField(lId, 'description', pStep.Description),
      Tip: this._TranslateStepField(lId, 'tip', pStep.Tip),
      Link: this._TranslateStepField(lId, 'link', pStep.Link)
    };
  }

  /**
   * Translates a single field of a step (`title`, `description`, `tip`, `link`).
   * Returns the fallback if the i18n key is missing or the translated value is empty.
   * @param pStepId The step identifier (e.g. 'welcome').
   * @param pField The field name ('title', 'description', 'tip', 'link').
   * @param pFallback The fallback string (FR raw value).
   * @returns The translated string or the fallback.
   */
  private _TranslateStepField(pStepId: string, pField: 'title' | 'description' | 'tip' | 'link', pFallback: string | undefined): string {
    if (!pFallback) return '';
    const lKey: string = `${TUTORIAL_I18N_PREFIX}.${pStepId}.${pField}`;
    const lTranslated: string = this._Translation.translate(lKey);
    if (lTranslated && !lTranslated.startsWith(`${TUTORIAL_I18N_PREFIX}.${pStepId}.${pField}`)) {
      return lTranslated;
    }
    return pFallback;
  }
  //#endregion
}
