/**
 * Placement preferred for the tutorial tooltip card relative to the spotlighted element.
 * - cm - The overlay component auto-flips if the tooltip would go off-screen.
 */
export type ETutorialPlacement = 'top' | 'bottom' | 'left' | 'right' | 'center';

/**
 * Callback signature invoked when a tutorial step requires a view change.
 * Used by host components (e.g. CRM layout) to wire navigation into the tutorial flow.
 */
export type TTutorialViewChangeCallback = (pView: string) => void;

/**
 * Definition of a single tutorial step.
 */
export interface ITutorialStep {
  /** Unique stable identifier (used for analytics / debugging). */
  Id: string;
  /** Title displayed in the tooltip card (h3). */
  Title: string;
  /** Description / instructions shown below the title. */
  Description: string;
  /**
   * CSS selector of the element to spotlight inside the current view.
   * If null / undefined / not found in DOM, the spotlight covers the full content area.
   */
  Selector?: string;
  /**
   * View name to navigate to BEFORE showing this step.
   * The overlay triggers navigation through TutorialService.OnViewChange callback.
   */
  NavigateTo?: string;
  /** Preferred placement of the tooltip card relative to the target. */
  Placement?: ETutorialPlacement;
  /** Optional Material icon name shown at the top of the tooltip. */
  Icon?: string;
  /**
   * Short contextual tip displayed in the body of the tooltip card (italic, smaller).
   * - cm - The overlay only renders this block when the translated i18n value is non-empty.
   *         TranslationService is read by the tutorial overlay via TranslationService.translate().
   */
  Tip?: string;
  /**
   * Short link text or label shown at the bottom of the tooltip card.
   * - cm - Rendered as a clickable text by the overlay (link to settings page, doc, etc.).
   *         The actual URL is provided at the overlay level via TutorialService.GetStepLink(stepId).
   */
  Link?: string;
  /**
   * Optional URL the overlay opens when the user clicks the step Link label.
   * - cm - When null/undefined, the Link label is rendered as a non-clickable hint.
   */
  LinkUrl?: string;
}

/**
 * Optional configuration accepted by `TutorialService.Start` and the constructor
 * to customize a tutorial flow.
 */
export interface ITutorialConfig {
  /** Steps to play (overrides the default flow). */
  Steps: ITutorialStep[];
  /** localStorage key used to remember the user has completed the flow. */
  DoneStorageKey?: string;
  /** Optional global title (e.g. shown in a launcher tooltip). */
  Title?: string;
  /** Optional icon shown alongside the title (Material Icons name). */
  Icon?: string;
  /**
   * Optional current view name. When provided, the service starts the tutorial at the
   * first step whose `NavigateTo` matches this view (so the user sees the step
   * corresponding to the page they are on, not always the welcome step).
   * Falls back to index 0 if no match is found.
   */
  CurrentView?: string;
}
