import { ITutorialStep } from './tutorial.types';

/**
 * Default tutorial flow for the CRM module (15 steps).
 *
 * - cm - 2026-08-13 : refactor i18n. Les Title/Description/Tip/Link ne sont plus des
 *         chaînes FR codées en dur : chaque step déclare uniquement son Id (clé i18n
 *         « tuto.crm.steps.<id>.title » etc.) et le service `TutorialService` lit le
 *         `TranslationService.translate()` à la volée. Les valeurs par défaut (FR) sont
 *         conservées ici comme fallback si le JSON i18n ne charge pas (SSR, erreur de
 *         fetch, première frame). On évite aussi le flash FR lors du switch de langue :
 *         la lecture passe par `TranslationService` à chaque rendu.
 *         Le champ `Icon` (Material) reste ici car il n'est pas traduit.
 */
export const DEFAULT_CRM_TUTORIAL_STEPS: ITutorialStep[] = [
  {
    Id: 'welcome',
    Title: 'Bienvenue dans votre CRM',
    Description: 'Ce tutoriel guidé vous présente les principales fonctionnalités du CRM immobilier en quelques étapes. Vous pourrez le relancer à tout moment via le bouton "?" en bas à droite.',
    Tip: 'Toutes les vues du CRM sont accessibles depuis la barre latérale gauche. Le bouton "?" relance ce tutoriel à tout moment.',
    Link: 'Vous retrouverez ce guide complet dans Paramètres > Aide.',
    Placement: 'center',
    Icon: 'waving_hand'
  },
  {
    Id: 'dashboard-overview',
    Title: 'Tableau de bord',
    Description: 'Le dashboard synthétise votre activité : CA encaissé, potentiel, mandats, contacts, ainsi que vos tâches du jour et la carte de vos biens. Utilisez les cartes pour accéder rapidement à chaque module.',
    Tip: 'Chaque carte du dashboard est cliquable : un clic vous amène directement dans la vue correspondante (transactions, contacts, tâches…).',
    Link: 'La carte en bas à droite affiche vos biens géolocalisés.',
    Placement: 'center',
    Icon: 'dashboard'
  },
  {
    Id: 'sidebar',
    Title: 'Navigation latérale',
    Description: 'La barre latérale donne accès à toutes les sections du CRM : objectifs, indicateurs, prospection, contacts, biens, projets, tâches, paramètres et historique. Cliquez sur une entrée pour changer de vue.',
    Tip: 'Vous pouvez replier la barre latérale pour gagner de la place à l\'écran. Le raccourci clavier est disponible dans Paramètres.',
    Link: 'L\'icône en haut de la barre vous ramène toujours à la vue principale.',
    Selector: '.sidebar-container',
    Placement: 'right',
    Icon: 'menu'
  },
  {
    Id: 'objectifs',
    Title: 'Définissez vos objectifs',
    Description: 'Fixez vos objectifs commerciaux (CA annuel, nombre de mandats, etc.) et suivez leur progression dans le temps. Chaque objectif est associé à une période et à un résultat.',
    Tip: 'Définissez un objectif par période (annuel, mensuel, trimestriel) pour affiner le suivi. La barre de progression se met à jour à chaque transaction encaissée.',
    Link: 'Objectif par défaut suggéré : commission annuelle nette de l\'année précédente.',
    NavigateTo: 'objectifs',
    Placement: 'center',
    Icon: 'flag'
  },
  {
    Id: 'indicateurs',
    Title: 'Suivez vos indicateurs',
    Description: 'Les indicateurs calculent automatiquement vos ratios clés : taux de conversion, délai moyen de vente, panier moyen, etc. Lecture seule, basés sur vos données réelles.',
    Tip: 'Les indicateurs sont mis à jour en temps réel à chaque modification de transaction. Vous pouvez filtrer par période.',
    Link: 'Idéal pour préparer vos rendez-vous de suivi mensuel.',
    NavigateTo: 'indicateurs',
    Placement: 'center',
    Icon: 'insights'
  },
  {
    Id: 'prospection',
    Title: 'Votre prospection',
    Description: 'La prospection centralise vos actions commerciales sortantes : campagnes email, relances téléphoniques, prises de contact. Suivez vos taux de réponse et optimisez votre pipeline.',
    Tip: 'Créez des campagnes email en lot depuis vos listes de contacts. Le taux d\'ouverture et de clic est tracké automatiquement.',
    Link: 'Astuce : combinez prospection email et téléphonique pour multiplier le taux de réponse.',
    NavigateTo: 'prospection',
    Placement: 'center',
    Icon: 'travel_explore'
  },
  {
    Id: 'recrutement',
    Title: 'Recrutement de mandataires',
    Description: 'Suivez vos candidats au métier de mandataire : profils, entretiens, onboarding, suivi des premières ventes. Le recrutement alimente votre croissance réseau.',
    Tip: 'Chaque candidat a un statut (contact, entretien, signé, onboardé). Les candidatures sont associées à leur origine pour suivre vos meilleurs canaux.',
    Link: 'L\'onglet "Mes candidats" vous donne une vue pipeline.',
    NavigateTo: 'recrutement',
    Placement: 'center',
    Icon: 'person_add'
  },
  {
    Id: 'contacts',
    Title: 'Gérez vos contacts',
    Description: 'Centralisez vos acquéreurs, vendeurs, locataires et bailleurs. Tags, origines, consentements, préférences de contact — toutes les infos utiles pour une relation client efficace.',
    Tip: 'Cliquez sur une ligne pour ouvrir la fiche contact complète : coordonnées, historique, transactions, projets, documents.',
    Link: 'Importez votre ancien carnet d\'adresses via CSV depuis Paramètres > Import.',
    NavigateTo: 'contacts',
    Placement: 'center',
    Icon: 'contacts'
  },
  {
    Id: 'biens',
    Title: 'Vos biens (Transactions & Locations)',
    Description: 'Deux onglets : Transactions (ventes) et Locations (baux). Suivi des mandats, compromis, signatures, commissions, encaissements et coordonnées GPS pour la carte.',
    Tip: 'La barre de filtres en haut de chaque grille permet de filtrer par statut, nature d\'affaire, ville. Les filtres sont sauvegardés par utilisateur.',
    Link: 'Le sélecteur de bien dans la colonne Bien permet de rattacher la transaction à un bien existant.',
    NavigateTo: 'biens',
    Placement: 'center',
    Icon: 'home_work'
  },
  {
    Id: 'projets',
    Title: 'Projets acquéreurs / locataires',
    Description: 'Pour chaque contact, enregistrez ses critères de recherche (budget, secteur, surface, type de bien) et associez automatiquement les biens correspondants.',
    Tip: 'Définissez les critères minimaux (pas les maximums) pour élargir le matching. Le moteur recalcule les correspondances à chaque nouveau bien.',
    Link: 'Les biens correspondants sont accessibles en un clic depuis la fiche projet.',
    NavigateTo: 'projets',
    Placement: 'center',
    Icon: 'group'
  },
  {
    Id: 'taches',
    Title: 'Vos tâches',
    Description: 'Planifiez vos relances, visites et actions commerciales. Priorités, échéances, contacts liés — ne manquez plus aucune étape importante de votre pipeline.',
    Tip: 'Les tâches du jour apparaissent en haut de la liste. Cochez pour marquer comme fait, ou reprogrammez en drag-and-drop.',
    Link: 'Filtrez par priorité ou par contact lié.',
    NavigateTo: 'taches',
    Placement: 'center',
    Icon: 'task_alt'
  },
  {
    Id: 'parametres',
    Title: 'Paramètres du CRM',
    Description: 'Configurez votre objectif annuel de CA, votre part réseau et votre type de TVA. Ces réglages pilotent les calculs des indicateurs et du dashboard.',
    Tip: 'Le type de TVA sélectionné impacte directement le calcul des commissions et de la part réseau. Vérifiez-le au début de chaque exercice.',
    Link: 'Sauvegarde automatique à chaque modification.',
    NavigateTo: 'parametres',
    Placement: 'center',
    Icon: 'settings'
  },
  {
    Id: 'historique',
    Title: 'Historique des échanges',
    Description: 'Retrouvez tous vos échanges passés avec chaque contact : appels, emails, visites, signatures. Une mémoire commerciale pour ne rien oublier.',
    Tip: 'Chaque échange est horodaté et associé à un contact. Vous pouvez filtrer par type (appel, email, visite, signature).',
    Link: 'L\'historique est aussi visible depuis la fiche contact.',
    NavigateTo: 'historique',
    Placement: 'center',
    Icon: 'history'
  },
  {
    Id: 'chat-ia',
    Title: 'Votre assistant IA',
    Description: 'Le Chat IA vous aide à remplir vos tableaux par simple conversation : créez un contact, ajoutez une transaction, importez un bien — l\'agent pilote pour vous.',
    Tip: 'Demandez en langage naturel : "crée un contact Marie Dupont 06..." ou "ajoute une transaction 250000€ pour le bien TRX-001". L\'agent vous montre un récap avant validation.',
    Link: 'Les actions sont traçables et modifiables depuis la grille correspondante.',
    NavigateTo: 'chat-ia',
    Placement: 'center',
    Icon: 'auto_awesome'
  },
  {
    Id: 'completion',
    Title: 'Vous êtes prêt !',
    Description: 'Vous connaissez maintenant les grandes lignes du CRM. Le bouton "?" reste disponible en bas à droite pour relancer ce tutoriel à tout moment. Bonne utilisation !',
    Tip: 'Pour aller plus loin, explorez chaque section et testez l\'import de vos premières données. Le Chat IA reste votre meilleur allié pour les actions rapides.',
    Link: 'Bonne vente !',
    Placement: 'center',
    Icon: 'celebration'
  }
];

/** localStorage key used for the CRM tutorial flow. */
export const CRM_TUTORIAL_DONE_KEY: string = 'sellmatch.crm.tutorial.done';

/**
 * Default tutorial flow for the Pro dashboard (7 steps).
 * - cm - Covers the 5 main views (dashboard, opportunities, mandats, profil) plus
 *         the admin-only ones (blog, diffusion) when applicable, and the home/header.
 *         Steps with `NavigateTo` rely on the BaseViewComponent.OnViewChange wiring
 *         (commit 3442371c) to perform the actual page switch.
 * - cm - 2026-08-13 : titre/description conservés en dur FR (non traduit) ; hors scope
 *         du refactor i18n tuto CRM.
 */
export const DEFAULT_PRO_TUTORIAL_STEPS: ITutorialStep[] = [
  {
    Id: 'pro-welcome',
    Title: 'Bienvenue sur votre dashboard pro',
    Description: 'Ce tutoriel vous présente les principales fonctionnalités de votre espace pro. Vous pourrez le relancer à tout moment via le bouton "?" en bas à droite.',
    Placement: 'center',
    Icon: 'waving_hand'
  },
  {
    Id: 'pro-dashboard',
    Title: 'Tableau de bord',
    Description: 'Le dashboard synthétise votre activité : dossiers en cours, mandats actifs, contacts récents et indicateurs clés. Les cartes vous permettent d\'accéder rapidement à chaque section.',
    Placement: 'center',
    Icon: 'dashboard'
  },
  {
    Id: 'pro-sidebar',
    Title: 'Navigation latérale',
    Description: 'La barre latérale donne accès à toutes les sections pro : opportunités, mandats, profil, et (admin) blog et diffusion email. Cliquez sur une entrée pour changer de vue.',
    Selector: '.sidebar-container',
    Placement: 'right',
    Icon: 'menu'
  },
  {
    Id: 'pro-opportunities',
    Title: 'Vos opportunités',
    Description: 'Suivez vos dossiers en cours : biens en portefeuille, contacts associés, estimations et prix affichés. Chaque opportunité peut être convertie en mandat une fois signée.',
    NavigateTo: 'opportunities',
    Placement: 'center',
    Icon: 'folder_open'
  },
  {
    Id: 'pro-mandats',
    Title: 'Vos mandats',
    Description: 'Centralisez vos mandats de vente (exclusif, semi-exclusif, simple) et suivez leur avancement : signature, commercialisation, closing. Badge rouge si un mandat approche de l\'échéance.',
    NavigateTo: 'candidatures',
    Placement: 'center',
    Icon: 'people'
  },
  {
    Id: 'pro-profil',
    Title: 'Votre profil pro',
    Description: 'Renseignez vos informations professionnelles (carte pro, SIRET, zone géographique) et votre bio. Ce profil est visible par les vendeurs sur la page Estimation et votre fiche publique.',
    NavigateTo: 'profil',
    Placement: 'center',
    Icon: 'person'
  },
  {
    Id: 'pro-blog',
    Title: 'Blog (admin uniquement)',
    Description: 'En tant qu\'administrateur, vous avez accès à la gestion du blog : création d\'articles, SEO, mise en avant sur la page d\'accueil. Planifiez vos publications pour garder un calendrier éditorial actif.',
    NavigateTo: 'blog',
    Placement: 'center',
    Icon: 'article'
  },
  {
    Id: 'pro-diffusion',
    Title: 'Diffusion email (admin uniquement)',
    Description: 'Envoyez des campagnes email à vos contacts ou à votre base prospects. Segments, templates, statistiques d\'ouverture : tout pour animer votre relation client à grande échelle.',
    NavigateTo: 'diffusion',
    Placement: 'center',
    Icon: 'campaign'
  },
  {
    Id: 'pro-completion',
    Title: 'Vous êtes prêt !',
    Description: 'Vous connaissez maintenant les grandes lignes de votre dashboard pro. Le bouton "?" reste disponible en bas à droite pour relancer ce tutoriel à tout moment. Bonne utilisation !',
    Placement: 'center',
    Icon: 'celebration'
  }
];

/** localStorage key used for the Pro dashboard tutorial flow. */
export const PRO_TUTORIAL_DONE_KEY: string = 'sellmatch.pro.tutorial.done';

/**
 * Default tutorial flow for the Vendeur dashboard (7 steps).
 * - cm - Covers the 5 main views of the seller space (dashboard, dossiers, historique,
 *         candidats, profil) plus the new-sale button. Steps with `NavigateTo` rely on
 *         the BaseViewComponent.OnViewChange wiring (commit 3442371c) to perform the
 *         actual page switch.
 * - cm - 2026-08-13 : titre/description conservés en dur FR (non traduit) ; hors scope
 *         du refactor i18n tuto CRM.
 */
export const DEFAULT_VENDEUR_TUTORIAL_STEPS: ITutorialStep[] = [
  {
    Id: 'vendeur-welcome',
    Title: 'Bienvenue sur votre espace vendeur',
    Description: 'Ce tutoriel vous présente les principales fonctionnalités de votre espace vendeur SellMatch. Vous pourrez le relancer à tout moment via le bouton "?" en bas à droite.',
    Placement: 'center',
    Icon: 'waving_hand'
  },
  {
    Id: 'vendeur-dashboard',
    Title: 'Tableau de bord',
    Description: 'Le dashboard synthétise votre activité : dossiers en cours, historique, candidats, et estimations en cours. Utilisez les cartes pour accéder rapidement à chaque section.',
    Placement: 'center',
    Icon: 'dashboard'
  },
  {
    Id: 'vendeur-sidebar',
    Title: 'Navigation latérale',
    Description: 'La barre latérale donne accès à toutes vos sections : mes dossiers, historique, candidats et profil. Le bouton "Nouvelle vente" en haut vous permet de démarrer une nouvelle estimation à tout moment.',
    Selector: '.sidebar-container',
    Placement: 'right',
    Icon: 'menu'
  },
  {
    Id: 'vendeur-dossiers',
    Title: 'Vos dossiers en cours',
    Description: 'Retrouvez tous vos dossiers de vente en cours : estimation, mandat, commercialisation, signature. Suivez l\'état de chaque bien et les actions à mener pour conclure la vente.',
    NavigateTo: 'dossiers',
    Placement: 'center',
    Icon: 'folder_open'
  },
  {
    Id: 'vendeur-historique',
    Title: 'Historique de vos ventes',
    Description: 'Consultez l\'historique complet de vos transactions passées : biens vendus, prix de vente, commissions perçues, dates clés. Une mémoire utile pour vos déclarations fiscales et votre suivi.',
    NavigateTo: 'historique',
    Placement: 'center',
    Icon: 'history'
  },
  {
    Id: 'vendeur-candidats',
    Title: 'Candidats intéressés',
    Description: 'Suivez les acheteurs potentiels qui ont manifesté leur intérêt pour vos biens : demandes d\'estimation, visites, offres. Gardez le contact et relancez pour maximiser vos chances de closing.',
    NavigateTo: 'candidats',
    Placement: 'center',
    Icon: 'people'
  },
  {
    Id: 'vendeur-profil',
    Title: 'Votre profil vendeur',
    Description: 'Complétez votre profil vendeur : informations personnelles, préférences de contact, biens déjà vendus. Ces informations aident les professionnels à mieux vous accompagner.',
    NavigateTo: 'profil',
    Placement: 'center',
    Icon: 'person'
  },
  {
    Id: 'vendeur-completion',
    Title: 'Vous êtes prêt !',
    Description: 'Vous connaissez maintenant les grandes lignes de votre espace vendeur. Le bouton "?" reste disponible en bas à droite pour relancer ce tutoriel à tout moment. Bonne utilisation !',
    Placement: 'center',
    Icon: 'celebration'
  }
];

/** localStorage key used for the Vendeur dashboard tutorial flow. */
export const VENDEUR_TUTORIAL_DONE_KEY: string = 'sellmatch.vendeur.tutorial.done';
