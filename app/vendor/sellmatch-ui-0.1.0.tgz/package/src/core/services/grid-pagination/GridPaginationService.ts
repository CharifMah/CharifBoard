import { Injectable, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SessionStorageService } from '../../../core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { UsersService } from '../../../core/sellmatchdb/services/users/users.service';
import { SettingsService } from '../../../core/sellmatchdb/services/settings/settings.service';
import { SettingsDTO } from '../../../core/sellmatchdb/dto/settings/settings.dto';

/**
 * Taille de page courante d'une grille SellMatch.
 * - cm - Suit le pattern de GridZoomService pour la persistance BDD + localStorage.
 * Cle logique `grid.pageSize.<context>` (scope par userId, table `settings` GENERIQUE).
 * <context> = identifiant logique passe par chaque page parente (ex: 'crm-prospection',
 * 'crm-contacts', 'default'). Une valeur globale partagee peut etre obtenue avec le
 * contexte 'default'.
 */
export type GridPageSize = number;

/**
 * Prefixe de la cle logique du setting BDD stockant la preference de taille de page
 * d'une grille utilisateur. La cle finale est `${GRID_PAGE_SIZE_SETTING_KEY_PREFIX}.${context}`.
 * - cm - Meme convention de namespace que `ui.theme`, `grid.zoom` etc.
 */
export const GRID_PAGE_SIZE_SETTING_KEY_PREFIX: string = 'grid.pageSize';

/**
 * Defaut partage entre le service et la grille.
 * - cm - Miroir de la valeur `25` dans grid-base.ts (defaut actuel du composant).
 * Si tu modifies ce defaut, modifie aussi la valeur initiale du signal `_PageSize`
 * cote grid (sinon l'UI part sur 25 meme si le service dit autre chose au 1er cycle).
 */
export const GRID_PAGE_SIZE_DEFAULT: GridPageSize = 25;

/**
 * Bornes de la taille de page (clamp cote service pour eviter une corruption BDD).
 * - cm - Valeur min 1 (sinon pagination cass\u00e9e), valeur max 1000 (anti DoS sur l'API
 * meme si l'UI n'expose pas cette option). Tout `PageSize` sortant des bornes
 * est ramene a la borne la plus proche.
 */
export const GRID_PAGE_SIZE_LIMITS = {
  Min: 1,
  Max: 1000
} as const;

/**
 * Service de gestion de la taille de page (pagination) des grilles generiques SellMatch.
 * Persiste le `PageSize` (defaut 25) dans le localStorage ET dans la table BDD
 * `settings` (cle `grid.pageSize.<context>`, scope par userId) pour suivre
 * l'utilisateur d'un device a l'autre / d'un navigateur a l'autre.
 *
 * - cm - Meme architecture que `GridZoomService` :
 *  - `Init()` lit le localStorage immediat (peinture sans flash au boot)
 *  - `SyncFromUserSettings()` prend le pas sur la BDD une fois l'utilisateur connu
 *  - `ApplyPageSize(context, size)` pose le signal et persiste en localStorage + BDD
 *
 * - cm - SSR-safe : aucune interaction DOM cote serveur.
 * - cm - Idempotent : safe a appeler Init/Sync plusieurs fois.
 *
 * @example
 * ```typescript
 * // AppComponent
 * this._GridPagination.Init();
 * this._GridPagination.SyncFromUserSettings();
 *
 * // GridComponent
 * private readonly _GridPagination = inject(GridPaginationService);
 * protected OnPageSizeChange(pSize: number): void {
 *   this._GridPagination.ApplyPageSize(this.PaginationContext, pSize);
 * }
 * ```
 */
@Injectable({
  providedIn: 'root'
})
export class GridPaginationService
{
  //#region Attributes
  /**
   * Cle de stockage du localStorage. Memorisee sous forme d'objet serialise
   * `{ [context: string]: GridPageSize }` pour partager une seule entree
   * localStorage entre tous les contextes de grille.
   * - cm - Avantage : 1 seule cle localStorage au lieu de N (perf negligeable,
   * mais structure plus claire cote DevTools). La serialisation JSON evite
   * une collision avec les autres settings deja stockes (`sellmatch-grid-zoom`).
   */
  private readonly _StorageKey: string = 'sellmatch-grid-page-sizes';

  /** Indique si le code s'execute cote navigateur. */
  private readonly _IsBrowser: boolean = isPlatformBrowser(inject(PLATFORM_ID));

  /** Service de sessionStorage pour fallback. */
  private readonly _SessionStorage: SessionStorageService = inject(SessionStorageService);

  /** Service utilisateur courant (pour lire/ecrire le setting BDD `grid.pageSize.<context>`). */
  private readonly _UsersService: UsersService = inject(UsersService);

  /** Service settings generique (upsert cle/valeur en BDD). */
  private readonly _SettingsService: SettingsService = inject(SettingsService);

  /**
   * Cache memoire des dernieres tailles de page appliquees depuis la BDD pour
   * eviter d'ecraser la pref serveur si l'utilisateur a plusieurs onglets ouverts.
   * - cm - Cle = `${userId}:${context}` pour supporter le multi-user ET le
   * multi-grille (changement de compte ou navigation entre pages CRM sur la
   * meme session navigateur).
   */
  private readonly _ServerPageSizeCache: Map<string, GridPageSize> = new Map<string, GridPageSize>();
  //#endregion

  //#region Properties
  /**
   * Signal reactif exposant la taille de page courante pour le contexte donne.
   * - cm - Ce signal est global (taille de la derniere grille qui a demande
   * une persistance). Les grilles lisent leur propre valeur via `GetStoredPageSize()`
   * au moment de l'init plutot que de se brancher sur ce signal. On garde le
   * signal public pour les futurs indicateurs UI (meme pattern que
   * `GridZoomService.CurrentZoom`).
   */
  public readonly CurrentPageSize = signal<GridPageSize>(GRID_PAGE_SIZE_DEFAULT);

  /**
   * Indique qu'une persistance BDD de taille de page est en cours (fire-and-forget).
   * - cm - Meme pattern que `GridZoomService.IsPersisting`. Permet a un futur
   * indicateur UI (skeleton / spinner discret cote pagination) d'afficher un
   * feedback pendant l'appel reseau.
   */
  public readonly IsPersisting = signal<boolean>(false);
  //#endregion

  //#region Methods
  /**
   * Initialise le service au demarrage de l'application.
   * Lit le localStorage et pose `CurrentPageSize` sur la valeur memorisee pour
   * le contexte 'default' (le plus frequent).
   * - cm - Ne touche PAS a la BDD : le chargement depuis le profil user
   * se fait via `SyncFromUserSettings()` une fois le UsersService charge.
   * Cela evite une race condition au boot (UsersService pas encore ready).
   * - cm - Idempotent : safe a appeler plusieurs fois.
   */
  public Init(): void
  {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    const lStored = this._ReadAllStored();
    const lDefaultSize: GridPageSize = lStored['default'] ?? GRID_PAGE_SIZE_DEFAULT;

    this.CurrentPageSize.set(lDefaultSize);
  }

  /**
   * Synchronise les tailles de page stockees en BDD pour l'utilisateur connecte.
   * - cm - Appele une fois que le UsersService a resolu `currentUser` (apres
   * login OU loadUserFromStorage + refreshFromServer). Si des settings
   * `grid.pageSize.<context>` existent en BDD, ils prennent le pas sur le
   * localStorage.
   * - cm - Idempotent : safe a appeler plusieurs fois (pas d'effet si la
   * valeur deja appliquee correspond au setting serveur).
   * @returns Promise resolue une fois la synchro terminee (best-effort).
   */
  public async SyncFromUserSettings(): Promise<void>
  {
    if (!this._IsBrowser) return;
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id)
    {
      // - cm - Pas d'utilisateur connecte : on garde les prefs locales (localStorage).
      return;
    }
    const lUserId: number = lUser.id;
    if (!lUser.userSettings || lUser.userSettings.length === 0)
    {
      return;
    }
    const lSettings = lUser.userSettings.filter((pS) =>
      (pS.key ?? '').toLowerCase().startsWith(`${GRID_PAGE_SIZE_SETTING_KEY_PREFIX}.`)
    );
    for (const lSetting of lSettings)
    {
      const lContext: string = this._ExtractContextFromKey(lSetting.key);
      if (!lContext) continue;
      const lServerSize = this._CoerceSettingValue(lSetting.value);
      if (lServerSize === null)
      {
        // - cm - Valeur invalide cote serveur : on log et on garde le local.
        console.warn(`[GridPaginationService] Valeur de setting '${lSetting.key}' invalide : '${lSetting.value}'`);
        continue;
      }
      this._ServerPageSizeCache.set(this._CacheKey(lUserId, lContext), lServerSize);
      // - cm - On patche le localStorage pour que la prochaine ouverture de
      // l'app (boot sans user connecte) retombe sur la valeur serveur.
      const lStored = this._ReadAllStored();
      lStored[lContext] = lServerSize;
      this._WriteAllStored(lStored);
    }
  }

  /**
   * Lit la taille de page persistee pour un contexte donne (defaut 'default'
   * si le contexte n'a pas de pref memorisee).
   * - cm - Les grilles appellent cette methode a leur `ngOnInit` pour hydrater
   * leur `_PageSize` depuis le localStorage avant le 1er render. C'est la
   * methode principale cote UI.
   * @param pContext Identifiant logique de la grille (ex: 'crm-prospection').
   * @returns La taille de page persistee (clamp dans les bornes) ou le defaut.
   */
  public GetStoredPageSize(pContext: string): GridPageSize
  {
    if (!this._IsBrowser) return GRID_PAGE_SIZE_DEFAULT;
    const lContext: string = this._NormalizeContext(pContext);
    const lStored = this._ReadAllStored();
    const lRaw = lStored[lContext];
    if (lRaw === undefined) return GRID_PAGE_SIZE_DEFAULT;
    return this._CoerceSettingValue(String(lRaw)) ?? GRID_PAGE_SIZE_DEFAULT;
  }

  /**
   * Met a jour la taille de page pour le contexte donne suite a une action
   * utilisateur (changement du selecteur cote `app-pagination`).
   * Pose le signal `CurrentPageSize` ; persiste en localStorage (synchrone)
   * ET en BDD (fire-and-forget) si user connecte.
   * - cm - Meme pattern que `GridZoomService.ApplyZoom` : localStorage immediat
   * (UI instantanee), POST BDD en arriere-plan (sans bloquer l'UI).
   * @param pContext Identifiant logique de la grille (ex: 'crm-prospection').
   * @param pPageSize Taille de page souhaitee (clamp dans les bornes).
   */
  public ApplyPageSize(pContext: string, pPageSize: GridPageSize): void
  {
    if (!this._IsBrowser) return; // - cm - No-op cote serveur (SSR)

    const lContext: string = this._NormalizeContext(pContext);
    const lClamped = this._Clamp(pPageSize);
    this.CurrentPageSize.set(lClamped);

    // - cm - Patch localStorage : on relit tout, on pose la nouvelle valeur
    // pour ce contexte, on re-ecrit. Evite d'ecraser les autres contextes.
    const lStored = this._ReadAllStored();
    lStored[lContext] = lClamped;
    this._WriteAllStored(lStored);

    // - cm - Persistance BDD best-effort : on lance en arriere-plan sans bloquer l'UI.
    void this._PersistPageSizeToServer(lContext, lClamped);
  }

  /**
   * Persiste la taille de page en BDD via SettingsService.upsertUserSetting.
   * - cm - Best-effort : ne leve pas d'exception, ne bloque pas l'UI.
   * Si l'utilisateur n'est pas connecte, no-op silencieux (le localStorage
   * reste la seule source de verrite pour la session anonyme).
   * - cm - Compare avec `_ServerPageSizeCache` pour eviter une boucle d'ecriture
   * quand `SyncFromUserSettings` declenche un `ApplyPageSize` (qui rappellerait
   * `_PersistPageSizeToServer` avec la meme valeur).
   * - cm - Met a jour `IsPersisting` (signal public) debut/fin pour que les
   * composants UI puissent afficher leur feedback pendant l'appel reseau.
   */
  private async _PersistPageSizeToServer(pContext: string, pPageSize: GridPageSize): Promise<void>
  {
    const lUser = this._UsersService.currentUser;
    if (!lUser?.id) return;
    const lUserId: number = lUser.id;
    const lCacheKey: string = this._CacheKey(lUserId, pContext);
    if (this._ServerPageSizeCache.get(lCacheKey) === pPageSize)
    {
      // - cm - On vient de synchro depuis la BDD, pas la peine de re-POSTer la meme valeur.
      return;
    }
    this.IsPersisting.set(true);
    try
    {
      const lSettingKey: string = `${GRID_PAGE_SIZE_SETTING_KEY_PREFIX}.${pContext}`;
      const lSaved = await this._SettingsService.upsertUserSetting(
        lUserId,
        lSettingKey,
        pPageSize.toString(),
        'int'
      );
      if (lSaved)
      {
        this._ServerPageSizeCache.set(lCacheKey, pPageSize);
        // - cm - On patche `currentUser.userSettings` pour qu'un futur
        // `SyncFromUserSettings()` (au boot suivant) reflete immediatement
        // la nouvelle valeur sans devoir refetch /api/Users/me.
        if (lUser.userSettings)
        {
          const lExisting = lUser.userSettings.find(
            (pS) => (pS.key ?? '').toLowerCase() === lSettingKey.toLowerCase()
          );
          if (lExisting && lExisting.id !== undefined)
          {
            lExisting.value = pPageSize.toString();
          }
          else
          {
            lUser.userSettings.push({
              id: lSaved.id,
              key: lSettingKey,
              value: pPageSize.toString(),
              valueType: 'int',
              userId: lUserId
            });
          }
        }
      }
    }
    finally
    {
      this.IsPersisting.set(false);
    }
  }

  /**
   * Lit TOUTES les tailles de page persistees depuis le localStorage.
   * - cm - Renvoie un objet `{ [context: string]: GridPageSize }`. Tolere
   * un JSON corrompu en retombant sur un objet vide. Les valeurs hors
   * bornes sont coercees ulterieurement par `GetStoredPageSize()`.
   * @returns Dictionnaire des tailles par contexte (vide si aucune).
   */
  private _ReadAllStored(): Record<string, GridPageSize>
  {
    if (!this._IsBrowser) return {};

    const lRaw = localStorage.getItem(this._StorageKey);
    if (lRaw)
    {
      try
      {
        const lParsed = JSON.parse(lRaw);
        if (lParsed && typeof lParsed === 'object' && !Array.isArray(lParsed))
        {
          return lParsed as Record<string, GridPageSize>;
        }
      }
      catch
      {
        // - cm - JSON corrompu : on retombe sur un objet vide.
      }
    }

    // - cm - Fallback sessionStorage pour compat (cf. ThemeService pour le precedent).
    const lFallback = this._SessionStorage.Restore<Record<string, GridPageSize>>(this._StorageKey);
    if (lFallback && typeof lFallback === 'object' && !Array.isArray(lFallback))
    {
      return lFallback;
    }
    return {};
  }

  /**
   * Persiste TOUTES les tailles de page dans le localStorage sous forme JSON.
   * - cm - Tolere l'indisponibilite du localStorage en basculant sur sessionStorage.
   * @param pStored Dictionnaire des tailles par contexte a sauvegarder.
   */
  private _WriteAllStored(pStored: Record<string, GridPageSize>): void
  {
    if (!this._IsBrowser) return;
    try
    {
      localStorage.setItem(this._StorageKey, JSON.stringify(pStored));
    }
    catch
    {
      // - cm - Fallback sessionStorage si localStorage indisponible.
      this._SessionStorage.Save(this._StorageKey, pStored);
    }
  }

  /**
   * Extrait le contexte (suffixe apres `grid.pageSize.`) d'une cle de setting BDD.
   * - cm - Retourne une chaine vide si la cle n'a pas le bon prefixe.
   * @param pKey Cle de setting BDD (ex: 'grid.pageSize.crm-prospection').
   * @returns Le contexte extrait ou chaine vide si invalide.
   */
  private _ExtractContextFromKey(pKey: string | undefined | null): string
  {
    if (!pKey) return '';
    const lLower = pKey.toLowerCase();
    const lPrefix = `${GRID_PAGE_SIZE_SETTING_KEY_PREFIX}.`;
    if (!lLower.startsWith(lPrefix)) return '';
    const lRaw = pKey.substring(lPrefix.length).trim();
    return this._NormalizeContext(lRaw);
  }

  /**
   * Normalise un identifiant de contexte (lowercase, trim, fallback 'default').
   * - cm - Evite les espaces ou casses indesirables qui casseraient la cle
   * BDD ou la cle de cache memoire.
   * @param pContext Le contexte brut.
   * @returns Le contexte normalise (jamais vide).
   */
  private _NormalizeContext(pContext: string): string
  {
    const lTrimmed: string = (pContext ?? '').toString().trim().toLowerCase();
    return lTrimmed === '' ? 'default' : lTrimmed;
  }

  /**
   * Convertit une valeur BDD (string libre) en `GridPageSize` strict.
   * - cm - Accepte uniquement les nombres entiers dans
   * [GRID_PAGE_SIZE_LIMITS.Min, Max]. Toute autre valeur (null, vide, NaN,
   * hors bornes) renvoie null - l'appelant decide du fallback (localStorage,
   * defaut).
   * @param pValue Valeur brute issue de la BDD ou du localStorage.
   * @returns La taille coercee, ou null si invalide.
   */
  private _CoerceSettingValue(pValue: string | undefined | null): GridPageSize | null
  {
    if (pValue === undefined || pValue === null) return null;
    const lNormalized = pValue.toString().trim();
    if (lNormalized === '') return null;
    const lParsed = Number(lNormalized);
    if (!Number.isFinite(lParsed)) return null;
    if (!Number.isInteger(lParsed)) return null;
    return this._Clamp(lParsed);
  }

  /**
   * Borne une taille de page dans [GRID_PAGE_SIZE_LIMITS.Min, Max].
   * @param pPageSize Taille a clamper.
   * @returns Taille clampee (entier).
   */
  private _Clamp(pPageSize: GridPageSize): GridPageSize
  {
    const lRounded = Math.round(pPageSize);
    return Math.max(GRID_PAGE_SIZE_LIMITS.Min, Math.min(GRID_PAGE_SIZE_LIMITS.Max, lRounded));
  }

  /**
   * Construit la cle de cache memoire `_ServerPageSizeCache` pour un
   * (user, context) donne.
   * - cm - Permet le multi-user ET le multi-grille sur la meme session
   * navigateur sans pollution croisee.
   */
  private _CacheKey(pUserId: number, pContext: string): string
  {
    return `${pUserId}:${this._NormalizeContext(pContext)}`;
  }
  //#endregion
}