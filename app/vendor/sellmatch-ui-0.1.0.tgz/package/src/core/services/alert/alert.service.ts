import { Injectable, signal } from '@angular/core';

/**
 * Service Angular minimaliste pour afficher un message d'alerte à l'utilisateur final.
 * Conçu pour être ultra-simple : un seul message, un seul bouton OK, fermeture au clic.
 * Pas de stack trace technique, pas de callbacks — juste un message clair.
 * @example
 * ```typescript
 * private readonly _Alert: AlertService = inject(AlertService);
 * this._Alert.Error("L'export Excel a échoué. Veuillez réessayer.");
 * ```
 */
@Injectable({ providedIn: 'root' })
export class AlertService {
  /** Message courant à afficher (null si aucune alerte). */
  public readonly Message = signal<string | null>(null);

  /**
   * Indique si une alerte est actuellement affichée.
   */
  public get IsOpen(): boolean {
    return this.Message() !== null;
  }

  /**
   * Affiche un message d'alerte à l'utilisateur.
   * @param pMessage Le message à afficher.
   */
  public Show(pMessage: string): void {
    this.Message.set(pMessage);
  }

  /**
   * Ferme l'alerte courante.
   */
  public Close(): void {
    this.Message.set(null);
  }

  /**
   * Raccourci sémantique pour une alerte d'erreur destinée au client final.
   * @param pMessage Le message d'erreur convivial.
   */
  public Error(pMessage: string): void {
    this.Show(pMessage);
  }
}
