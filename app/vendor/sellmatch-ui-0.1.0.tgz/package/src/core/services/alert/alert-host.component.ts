import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { AlertService } from '../../../core/services/alert/alert.service';
import { PopupComponent } from '../../../shared/components/popup/popup.component';

/**
 * Composant hôte global qui affiche le message courant du {@link AlertService}.
 * À insérer UNE seule fois dans l'arbre (typiquement app.component.html).
 * Réagit automatiquement aux changements de signaux : tout appel à AlertService.Show()
 * ouvre la popup, AlertService.Close() la ferme.
 * Pas de styles propres : hérite du design system de app-popup.
 */
@Component({
  selector: 'app-alert-host',
  standalone: true,
  imports: [PopupComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (_Alert.IsOpen) {
    <app-popup
        [isOpen]="_Alert.IsOpen"
        [title]="'Information'"
        [subtitle]="_Alert.Message() ?? ''"
        [type]="'default'"
        [showConfirmButton]="true"
        [showCancelButton]="false"
        [confirmText]="'Fermer'"
        [size]="'small'"
        [closeOnOverlay]="false"
        [closeOnEscape]="true"
        (closed)="_Alert.Close()">
    </app-popup>
    }
  `
})
export class AlertHostComponent {
  //#region Dependencies
  /** Service d'alerte injecté (lecture seule). */
  protected readonly _Alert: AlertService = inject(AlertService);
  //#endregion
}
