import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../core/base/ServiceBase';
import { EmptyCritereDTO } from '../../../core/base/EmptyCritereDTO';
import { EmptyDTO } from '../../../core/base/EmptyDTO';

export interface SupportEmailRequest
{
  fromName?: string;
  fromEmail?: string;
  subject: string;
  message: string;
  sendConfirmation?: boolean;
}

/**
 * Requête d'envoi d'un email broadcast (diffusion admin).
 * La signature SellMatch est ajoutée automatiquement côté serveur.
 */
export interface BroadcastEmailRequest
{
  /** Liste des adresses email des destinataires (placées en BCC). */
  recipientEmails: string[];
  /** Sujet de l'email. */
  subject: string;
  /** Corps HTML de l'email (sans la signature). */
  body: string;
}

@Injectable({
  providedIn: 'root'
})
export class SmtpService extends ServiceBase<EmptyDTO, EmptyCritereDTO>
{
  constructor ()
  {
    super('smtp');
  }

  async sendEmailSupport(request: SupportEmailRequest): Promise<boolean>
  {
    const lUrl = `${this.apiUrl}/support`;
    try
    {
      const lResponse = await this.axiosInstance.post<{ success: boolean }>(lUrl, request);
      return lResponse.data.success;
    }
    catch (lError: any)
    {
      console.error("Erreur lors de l'envoi au support:", lError);
      throw new Error(this.handleError(lError));
    }
  }

  /**
   * Envoie un email broadcast à une liste de destinataires (admin uniquement).
   * Le corps est enveloppé dans le template SellMatch et la signature Contact est ajoutée côté serveur.
   * @param pRequest Destinataires (BCC), sujet et corps HTML de l'email
   * @returns True si l'envoi a réussi
   */
  async sendBroadcast(pRequest: BroadcastEmailRequest): Promise<boolean>
  {
    const lUrl = `${this.apiUrl}/broadcast`;
    try
    {
      const lResponse = await this.axiosInstance.post<{ success: boolean }>(lUrl, pRequest);
      return lResponse.data.success;
    }
    catch (lError: any)
    {
      console.error("Erreur lors de l'envoi du broadcast:", lError);
      throw new Error(this.handleError(lError));
    }
  }

  /**
   * Récupère le HTML de la signature Contact (source unique côté backend).
   * Sert à pré-charger la signature dans l'éditeur WYSIWYG de diffusion.
   * @returns Le HTML de la signature, ou chaîne vide si indisponible
   */
  async getSignature(): Promise<string>
  {
    const lUrl = `${this.apiUrl}/signature`;
    try
    {
      const lResponse = await this.axiosInstance.get<{ html: string }>(lUrl);
      return lResponse.data.html ?? '';
    }
    catch (lError: any)
    {
      console.error("Erreur lors de la récupération de la signature:", lError);
      return '';
    }
  }

  /**
   * Génère le HTML complet (template SellMatch + corps + signature) d'un aperçu d'email sans l'envoyer.
   * Source unique côté backend, aperçu 100% fidèle à l'email reçu.
   * @param pBody Corps HTML rédigé dans l'éditeur
   * @returns Le HTML complet de l'aperçu, ou chaîne vide si indisponible
   */
  async getPreview(pBody: string): Promise<string>
  {
    const lUrl = `${this.apiUrl}/preview`;
    try
    {
      const lResponse = await this.axiosInstance.post<{ html: string }>(lUrl, { Body: pBody });
      return lResponse.data.html ?? '';
    }
    catch (lError: any)
    {
      console.error("Erreur lors de la génération de l'aperçu:", lError);
      return '';
    }
  }
}
