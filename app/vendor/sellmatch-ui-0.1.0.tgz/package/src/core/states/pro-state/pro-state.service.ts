import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { OpportunitiesDTO, ApplicationsDTO, ApplicationServicesDTO } from '../../../core/sellmatchdb/dto';
import { OpportunitiesService, ApplicationsService } from '../../../core/sellmatchdb/services';
import { OpportunitiesCritereDTO } from '../../../core/sellmatchdb/dto/opportunities/opportunities.critere';
import { ApplicationsCritereDTO } from '../../../core/sellmatchdb/dto/applications/applications.critere';
import { BaseComponent } from '../../../core/base/BaseComponent';

import { ECollectionMatch } from '../../../core/base/ECollectionMatch';
import { EFeeType } from '@views/Dashboards/vendeur/candidats/candidature-popup/steps/step-honoraires/EFeeType';

//#region Interfaces
export interface SidebarStats
{
  DossiersEnCours: number;
  DossiersHistorique: number;
  TotalCandidatures: number;
  ChiffreAffaires: number;
  TauxConversion: number;
  MandatsActifs: number;
}

export interface SubmitCandidatureParams
{
  application: ApplicationsDTO;
  selectedServiceIds: Set<number>;
  opportunityId: number;
  professionalId: number;
}

type OpportuniteTab = 'nouvelles' | 'candidatures';
//#endregion

@Injectable({
  providedIn: 'root'
})
export class ProStateService extends BaseComponent
{
  //#region Services
  private readonly _OpportunitiesService: OpportunitiesService = inject(OpportunitiesService);
  private readonly _ApplicationsService: ApplicationsService = inject(ApplicationsService);
  //#endregion

  //#region State - Subjects
  private readonly _OpportunitesNouvelles$: BehaviorSubject<OpportunitiesDTO[]> = new BehaviorSubject<OpportunitiesDTO[]>([]);
  private readonly _OpportunitesCandidatures$: BehaviorSubject<OpportunitiesDTO[]> = new BehaviorSubject<OpportunitiesDTO[]>([]);
  private readonly _Historique$: BehaviorSubject<ApplicationsDTO[]> = new BehaviorSubject<ApplicationsDTO[]>([]);
  private readonly _MandatsAcceptes$: BehaviorSubject<ApplicationsDTO[]> = new BehaviorSubject<ApplicationsDTO[]>([]);
  private readonly _SelectedOpportunite$: BehaviorSubject<OpportunitiesDTO | null> = new BehaviorSubject<OpportunitiesDTO | null>(null);
  private readonly _Loading$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private readonly _LoadingMandats$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private readonly _Submitting$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  private readonly _OpportunitesNouvellesCount$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private readonly _OpportunitesCandidaturesCount$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  //#endregion

  //#region State - Observables
  public readonly OpportunitesNouvelles$: Observable<OpportunitiesDTO[]> = this._OpportunitesNouvelles$.asObservable();
  public readonly OpportunitesCandidatures$: Observable<OpportunitiesDTO[]> = this._OpportunitesCandidatures$.asObservable();
  public readonly Historique$: Observable<ApplicationsDTO[]> = this._Historique$.asObservable();
  public readonly MandatsAcceptes$: Observable<ApplicationsDTO[]> = this._MandatsAcceptes$.asObservable();
  public readonly SelectedOpportunite$: Observable<OpportunitiesDTO | null> = this._SelectedOpportunite$.asObservable();
  public readonly Loading$: Observable<boolean> = this._Loading$.asObservable();
  public readonly LoadingMandats$: Observable<boolean> = this._LoadingMandats$.asObservable();
  public readonly Submitting$: Observable<boolean> = this._Submitting$.asObservable();

  public readonly OpportunitesNouvellesCount$: Observable<number> = this._OpportunitesNouvellesCount$.asObservable();
  public readonly OpportunitesCandidaturesCount$: Observable<number> = this._OpportunitesCandidaturesCount$.asObservable();
  //#endregion

  //#region Private State
  private _CurrentUserId: number | null = null;

  // Anti reload simple (comme demandé)
  private _LastLoadKeyByTab: Record<OpportuniteTab, string> = {
    nouvelles: '',
    candidatures: ''
  };
  //#endregion

  //#region Load Data (server side pagination)
  public async LoadOpportunitesPage(
    pUserId: number,
    pTab: OpportuniteTab,
    pPage: number,
    pPageSize: number,
    pFilter: OpportunitiesCritereDTO = {}
  ): Promise<void>
  {
    if (!pUserId || pUserId <= 0)
    {
      return;
    }

    // Si user change => reset cache anti-reload
    if (this._CurrentUserId !== pUserId)
    {
      this._LastLoadKeyByTab.nouvelles = '';
      this._LastLoadKeyByTab.candidatures = '';
    }

    this._CurrentUserId = pUserId;

    // Skip si même requête exacte
    const lKey: string = JSON.stringify({ pUserId, pTab, pPage, pPageSize, pFilter });
    if (this._LastLoadKeyByTab[pTab] === lKey)
    {
      return;
    }
    this._LastLoadKeyByTab[pTab] = lKey;

    this._Loading$.next(true);

    try
    {
      const lSkip: number = Math.max(0, (pPage - 1) * pPageSize);
      const lLimit: number = Math.max(1, pPageSize);

      // Counts globaux (toujours rafraîchis pour init correcte des tabs)
      const lNouvellesCountPromise: Promise<number> = this._OpportunitiesService.count({
        ...pFilter,
        skip: undefined,
        limit: undefined,
        applicationsMatch: ECollectionMatch.All,
        applications: {
          professionalIdIsDifferent: this._CurrentUserId
        }
      } as OpportunitiesCritereDTO);

      const lCandidaturesCountPromise: Promise<number> = this._ApplicationsService.count({
        professionalId: this._CurrentUserId,
        selectedAtIsNull: true,
        opportunity: {},
        skip: undefined,
        limit: undefined
      } as ApplicationsCritereDTO);


      if (pTab === 'nouvelles')
      {
        // cm - Nouvelle candidatures
        const lCritere: OpportunitiesCritereDTO = {
          skip: lSkip,
          limit: lLimit,
          user: {},
          idStatusNavigation: {},
          applicationsMatch: ECollectionMatch.All,
          applications: {
            professionalIdIsDifferent: this._CurrentUserId,
          },
          address: {},
          ...pFilter
        };

        const [lItems, lNouvellesCount, lCandidaturesCount] = await Promise.all([
          this._OpportunitiesService.getAll(lCritere),
          lNouvellesCountPromise,
          lCandidaturesCountPromise
        ]);

        this._OpportunitesNouvelles$.next(lItems ?? []);
        this._OpportunitesNouvellesCount$.next(lNouvellesCount ?? 0);
        this._OpportunitesCandidaturesCount$.next(lCandidaturesCount ?? 0);
      }
      else
      {
        // cm - Candidature en cours
        const lCritere: ApplicationsCritereDTO = {
          professionalId: pUserId,
          selectedAtIsNull: true,
          skip: lSkip,
          limit: lLimit,
          opportunity: { address: {} }
        };

        const [lApps, lNouvellesCount, lCandidaturesCount] = await Promise.all([
          this._ApplicationsService.getAll(lCritere),
          lNouvellesCountPromise,
          lCandidaturesCountPromise
        ]);

        const lOpps: OpportunitiesDTO[] = (lApps ?? [])
          .map((pApp: ApplicationsDTO) => pApp.opportunity)
          .filter((pOpp: OpportunitiesDTO | undefined): pOpp is OpportunitiesDTO => !!pOpp);

        this._Historique$.next(lApps ?? []);
        this._OpportunitesCandidatures$.next(lOpps);
        this._OpportunitesNouvellesCount$.next(lNouvellesCount ?? 0);
        this._OpportunitesCandidaturesCount$.next(lCandidaturesCount ?? 0);
      }
    }
    catch (pError: unknown)
    {
      console.error('Erreur lors du chargement paginé des opportunités:', pError);

      if (pTab === 'nouvelles')
      {
        this._OpportunitesNouvelles$.next([]);
        this._OpportunitesNouvellesCount$.next(0);
      }
      else
      {
        this._OpportunitesCandidatures$.next([]);
        this._OpportunitesCandidaturesCount$.next(0);
      }
    }
    finally
    {
      this._Loading$.next(false);
    }
  }

  public async LoadMandatsAcceptes(pUserId: number): Promise<void>
  {
    if (!pUserId || pUserId <= 0)
    {
      return;
    }

    this._CurrentUserId = pUserId;
    this._LoadingMandats$.next(true);

    try
    {
      const lCritere: ApplicationsCritereDTO = {
        professionalId: pUserId,
        opportunity: {
          address: {},
          user: {},
        }
      };

      const lApplications: ApplicationsDTO[] = await this._ApplicationsService.getAll(lCritere);

      const lMandatsAcceptes: ApplicationsDTO[] = lApplications.filter(
        (app: ApplicationsDTO) => app.opportunity?.user != null
      );

      this._MandatsAcceptes$.next(lMandatsAcceptes);
    }
    catch (pError: unknown)
    {
      console.error('Erreur lors de la récupération des mandats acceptés:', pError);
      this._MandatsAcceptes$.next([]);
    }
    finally
    {
      this._LoadingMandats$.next(false);
    }
  }

  public async RefreshMandatsAcceptes(): Promise<void>
  {
    if (this._CurrentUserId)
    {
      await this.LoadMandatsAcceptes(this._CurrentUserId);
    }
  }
  //#endregion

  //#region Submit Candidature
  public async SubmitCandidature(pParams: SubmitCandidatureParams): Promise<ApplicationsDTO>
  {
    this._Submitting$.next(true);

    try
    {
      const lApplication: ApplicationsDTO = {
        ...pParams.application,
        opportunityId: pParams.opportunityId,
        professionalId: pParams.professionalId,
        status: 'pending',
        applicationServices: Array.from(pParams.selectedServiceIds).map(
          (serviceId): ApplicationServicesDTO => ({ serviceId })
        )
      };

      const lResult: ApplicationsDTO = await this._ApplicationsService.create(lApplication);

      this._AddToHistorique(lResult);
      this._RemoveFromNouvelles(pParams.opportunityId);

      return lResult;
    }
    finally
    {
      this._Submitting$.next(false);
    }
  }

  private _AddToHistorique(pApplication: ApplicationsDTO): void
  {
    const lHistorique: ApplicationsDTO[] = this._Historique$.getValue();
    this._Historique$.next([pApplication, ...lHistorique]);

    if (pApplication.opportunity)
    {
      const lCandidatures: OpportunitiesDTO[] = this._OpportunitesCandidatures$.getValue();
      this._OpportunitesCandidatures$.next([pApplication.opportunity, ...lCandidatures]);
    }

    this._OpportunitesCandidaturesCount$.next(this._OpportunitesCandidaturesCount$.getValue() + 1);
  }

  private _RemoveFromNouvelles(pOpportunityId: number): void
  {
    const lNouvelles: OpportunitiesDTO[] = this._OpportunitesNouvelles$.getValue();
    const lUpdated: OpportunitiesDTO[] = lNouvelles.filter(
      (pOpp: OpportunitiesDTO) => pOpp.id !== pOpportunityId
    );
    this._OpportunitesNouvelles$.next(lUpdated);

    this._OpportunitesNouvellesCount$.next(Math.max(0, this._OpportunitesNouvellesCount$.getValue() - 1));
  }
  //#endregion

  //#region Opportunites
  public SelectOpportunite(pOpportunite: OpportunitiesDTO | null): void
  {
    this._SelectedOpportunite$.next(pOpportunite);
  }

  public AddCandidature(pApplication: ApplicationsDTO): void
  {
    this._AddToHistorique(pApplication);

    if (pApplication.opportunityId)
    {
      this._RemoveFromNouvelles(pApplication.opportunityId);
    }
  }

  public OnApplicationAccepted(pApplication: ApplicationsDTO): void
  {
    const lHistorique: ApplicationsDTO[] = this._Historique$.getValue();
    const lUpdatedHistorique: ApplicationsDTO[] = lHistorique.filter(
      (pApp: ApplicationsDTO) => pApp.opportunityId !== pApplication.opportunityId
    );
    this._Historique$.next(lUpdatedHistorique);

    const lCandidatures: OpportunitiesDTO[] = this._OpportunitesCandidatures$.getValue();
    const lUpdatedCandidatures: OpportunitiesDTO[] = lCandidatures.filter(
      (pOpp: OpportunitiesDTO) => pOpp.id !== pApplication.opportunityId
    );
    this._OpportunitesCandidatures$.next(lUpdatedCandidatures);
    this._OpportunitesCandidaturesCount$.next(Math.max(0, this._OpportunitesCandidaturesCount$.getValue() - 1));

    const lMandats: ApplicationsDTO[] = this._MandatsAcceptes$.getValue();
    this._MandatsAcceptes$.next([...lMandats, pApplication]);
  }

  public GetOpportunitesCount(pTab: OpportuniteTab): number
  {
    return pTab === 'nouvelles'
      ? this._OpportunitesNouvellesCount$.getValue()
      : this._OpportunitesCandidaturesCount$.getValue();
  }
  //#endregion

  //#region Getters
  public get Historique(): ApplicationsDTO[]
  {
    return this._Historique$.getValue();
  }

  public get IsSubmitting(): boolean
  {
    return this._Submitting$.getValue();
  }

  public get SelectedOpportunite(): OpportunitiesDTO | null
  {
    return this._SelectedOpportunite$.getValue();
  }

  public get OpportunitesNouvelles(): OpportunitiesDTO[]
  {
    return this._OpportunitesNouvelles$.getValue();
  }

  public get OpportunitesCandidatures(): OpportunitiesDTO[]
  {
    return this._OpportunitesCandidatures$.getValue();
  }

  public get MandatsAcceptes(): ApplicationsDTO[]
  {
    return this._MandatsAcceptes$.getValue();
  }
  //#endregion

  //#region Stats
  public GetStats(): SidebarStats
  {
    const lMandats: ApplicationsDTO[] = this._MandatsAcceptes$.getValue();

    const lMandatsActifs: number = lMandats.filter((pApp: ApplicationsDTO) =>
    {
      const lOpp: OpportunitiesDTO | undefined = pApp.opportunity;
      if (!lOpp) return false;
      if (lOpp.closedAt) return false;
      if (lOpp.expiresAt && new Date(lOpp.expiresAt) < new Date()) return false;
      return true;
    }).length;

    const lMandatsVendus: number = lMandats.filter(
      (pApp: ApplicationsDTO) => pApp.opportunity?.closedAt != null
    ).length;

    const lChiffreAffaires: number = lMandats.reduce((pTotal: number, pApp: ApplicationsDTO) =>
    {
      if (pApp.opportunity?.closedAt)
      {
        return pTotal + this.GetCommissionEstimee(pApp.opportunity);
      }
      return pTotal;
    }, 0);

    const lTotalCandidatures: number = this._OpportunitesCandidaturesCount$.getValue() + lMandats.length;

    return {
      DossiersEnCours: this._OpportunitesNouvellesCount$.getValue(),
      DossiersHistorique: lMandatsVendus,
      TotalCandidatures: this._OpportunitesCandidaturesCount$.getValue(),
      ChiffreAffaires: lChiffreAffaires,
      TauxConversion: this._CalculerTauxConversion(lTotalCandidatures, lMandats.length),
      MandatsActifs: lMandatsActifs
    };
  }

  private _CalculerTauxConversion(pTotal: number, pAcceptes: number): number
  {
    if (pTotal === 0) return 0;
    return Math.round((pAcceptes / pTotal) * 100);
  }
  //#endregion

  //#region Helpers (inchangés)
  public GetMandatStatut(pApplication: ApplicationsDTO): string
  {
    const lOpp: OpportunitiesDTO | undefined = pApplication.opportunity;
    if (!lOpp) return 'inconnu';
    if (lOpp.closedAt) return 'vendu';
    if (lOpp.expiresAt && new Date(lOpp.expiresAt) < new Date()) return 'expire';
    return 'actif';
  }

  public GetMandatStatutLabel(pApplication: ApplicationsDTO): string
  {
    const lLabels: Record<string, string> = {
      'actif': 'Actif',
      'vendu': 'Vendu',
      'expire': 'Expiré',
      'inconnu': 'Inconnu'
    };
    return lLabels[this.GetMandatStatut(pApplication)] || 'Actif';
  }

  public GetMandatStatutClass(pApplication: ApplicationsDTO): string
  {
    return `statut-${this.GetMandatStatut(pApplication)}`;
  }

  public GetMandatCommission(pApplication: ApplicationsDTO): string
  {
    const lFeeTypeEnum: EFeeType = this.ConvertToEnum(pApplication.feeType || '', EFeeType);

    if (lFeeTypeEnum === EFeeType.POURCENTAGE && pApplication.feePercentage)
    {
      return `${pApplication.feePercentage}%`;
    }

    if (lFeeTypeEnum === EFeeType.FIXE && pApplication.feeFixedAmount)
    {
      return this.FormatPrice(pApplication.feeFixedAmount);
    }

    return '-';
  }

  public GetMandatPrixEstime(pApplication: ApplicationsDTO | null): string
  {
    if (pApplication != null)
    {
      const lOpp: OpportunitiesDTO | undefined = pApplication?.opportunity;
      if (!lOpp) return '-';

      if (lOpp.priceRangeMin && lOpp.priceRangeMax)
      {
        return `${this.FormatPrice(lOpp.priceRangeMin)} - ${this.FormatPrice(lOpp.priceRangeMax)}`;
      }

      if (lOpp.priceRangeMin) return this.FormatPrice(lOpp.priceRangeMin);
      if (lOpp.priceRangeMax) return this.FormatPrice(lOpp.priceRangeMax);
    }
    return '-';
  }

  public GetMandatAdresse(pApplication: ApplicationsDTO): string
  {
    const lOpp: OpportunitiesDTO | undefined = pApplication.opportunity;
    if (!lOpp) return 'Adresse non renseignée';

    const lParts: string[] = [];
    if (lOpp.address?.street) lParts.push(lOpp.address?.street);
    if (lOpp.address?.postcode || lOpp.address?.city)
    {
      lParts.push(`${lOpp.address?.postcode || ''} ${lOpp.address?.city || ''}`.trim());
    }

    return lParts.join(', ') || 'Adresse non renseignée';
  }

  public GetJoursRestants(pDate: Date | string | undefined): number
  {
    if (!pDate) return 0;
    const lDate: Date = typeof pDate === 'string' ? new Date(pDate) : pDate;
    const lNow: Date = new Date();
    const lDiff: number = lDate.getTime() - lNow.getTime();
    return Math.max(0, Math.ceil(lDiff / (1000 * 60 * 60 * 24)));
  }

  public GetApplicationStatusIcon(pOpportunityId: number | undefined): string
  {
    const lStatus: string = this.GetApplicationStatus(pOpportunityId);
    const lIcons: Record<string, string> = {
      'none': 'hourglass_top',
      'pending': 'hourglass_top',
      'accepted': 'check_circle'
    };
    return lIcons[lStatus] || 'hourglass_top';
  }

  public GetStatutLabel(pOpportunity: OpportunitiesDTO): string
  {
    const lStatus: string = (pOpportunity.idStatusNavigation?.status ?? '').toLowerCase();

    const lMapping: Record<string, string> = {
      'en_cours': 'En cours',
      'attente': 'En attente',
      'vendu': 'Vendu',
      'annule': 'Annulé'
    };

    return lMapping[lStatus] ?? (pOpportunity.idStatusNavigation?.status ?? 'En attente');
  }

  public GetStatutClass(pOpportunity: OpportunitiesDTO): string // - cm - Classe CSS basée sur le statut BDD (sans accents, _ → -)
  {
    const lStatus: string = (pOpportunity.idStatusNavigation?.status ?? 'attente').toLowerCase();
    return `statut-${lStatus.replace(/[\s_]+/g, '-')}`;
  }

  public GetApplicationForOpportunity(pOpportunityId: number | undefined): ApplicationsDTO | undefined
  {
    if (!pOpportunityId) return undefined;

    const lMandats: ApplicationsDTO[] = this._MandatsAcceptes$.getValue();
    return lMandats.find((pApp: ApplicationsDTO) => pApp.opportunityId === pOpportunityId);
  }

  public GetApplicationStatus(pOpportunityId: number | undefined): string
  {
    const lMandats: ApplicationsDTO[] = this._MandatsAcceptes$.getValue();
    if (lMandats.some((pApp: ApplicationsDTO) => pApp.opportunityId === pOpportunityId))
    {
      return 'accepted';
    }

    const lCandidatures: OpportunitiesDTO[] = this._OpportunitesCandidatures$.getValue();
    if (lCandidatures.some((pOpp: OpportunitiesDTO) => pOpp.id === pOpportunityId))
    {
      return 'pending';
    }

    return 'none';
  }

  public GetApplicationStatusLabel(pOpportunityId: number | undefined): string
  {
    const lStatus: string = this.GetApplicationStatus(pOpportunityId);
    const lLabels: Record<string, string> = {
      'none': 'Non candidate',
      'pending': 'En attente de réponse',
      'accepted': 'Mandat accepté'
    };
    return lLabels[lStatus] || 'Non candidate';
  }

  public GetCommissionEstimee(pOpportunity: OpportunitiesDTO | undefined): number
  {
    if (pOpportunity == undefined)
    {
      return -1;
    }
    const lPrix: number = pOpportunity.priceRangeMin || pOpportunity.priceRangeMax || 0;
    return Math.round(lPrix * 0.04);
  }

  public GetTimeAgo(pDate: Date | string | undefined): string
  {
    if (!pDate) return '';

    const lDate: Date = typeof pDate === 'string' ? new Date(pDate) : pDate;
    const lNow: Date = new Date();
    const lDiffMs: number = lNow.getTime() - lDate.getTime();
    const lDiffHours: number = Math.floor(lDiffMs / (1000 * 60 * 60));
    const lDiffDays: number = Math.floor(lDiffMs / (1000 * 60 * 60 * 24));

    if (lDiffHours < 1) return 'À l\'instant';
    if (lDiffHours < 24) return `Il y a ${lDiffHours}h`;
    if (lDiffDays === 1) return 'Hier';
    return `Il y a ${lDiffDays} jours`;
  }
  //#endregion
}
