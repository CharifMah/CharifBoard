import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { OpportunitiesDTO, ApplicationsDTO } from '../../../core/sellmatchdb/dto';
import { ApplicationsService, OpportunitiesService } from '../../../core/sellmatchdb/services';
import { BaseComponent } from '../../../core/base/BaseComponent';
import { OpportunitiesCritereDTO } from '../../../core/sellmatchdb/dto/opportunities/opportunities.critere';
import { ApplicationsCritereDTO } from '../../../core/sellmatchdb/dto/applications/applications.critere';
import { SidebarStats } from '../pro-state/pro-state.service';

type DossierTab = 'en_cours' | 'historique';

@Injectable({
  providedIn: 'root'
})
export class VendeurStateService extends BaseComponent
{
  //#region Properties
  public ShowNewDossier: boolean = false;

  private readonly _ApplicationsService: ApplicationsService = inject(ApplicationsService);
  private readonly _OpportunitiesService: OpportunitiesService = inject(OpportunitiesService);

  private readonly _DossiersEnCours$: BehaviorSubject<OpportunitiesDTO[]> = new BehaviorSubject<OpportunitiesDTO[]>([]);
  private readonly _HistoriqueVentes$: BehaviorSubject<OpportunitiesDTO[]> = new BehaviorSubject<OpportunitiesDTO[]>([]);
  private readonly _SelectedDossier$: BehaviorSubject<OpportunitiesDTO | null> = new BehaviorSubject<OpportunitiesDTO | null>(null);
  private readonly _Loading$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private readonly _ActiveTab$: BehaviorSubject<string> = new BehaviorSubject<string>('en_cours');

  private readonly _DossiersEnCoursCount$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private readonly _HistoriqueVentesCount$: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  public readonly DossiersEnCours$: Observable<OpportunitiesDTO[]> = this._DossiersEnCours$.asObservable();
  public readonly HistoriqueVentes$: Observable<OpportunitiesDTO[]> = this._HistoriqueVentes$.asObservable();
  public readonly SelectedDossier$: Observable<OpportunitiesDTO | null> = this._SelectedDossier$.asObservable();
  public readonly Loading$: Observable<boolean> = this._Loading$.asObservable();
  public readonly ActiveTab$: Observable<string> = this._ActiveTab$.asObservable();

  public readonly DossiersEnCoursCount$: Observable<number> = this._DossiersEnCoursCount$.asObservable();
  public readonly HistoriqueVentesCount$: Observable<number> = this._HistoriqueVentesCount$.asObservable();
  private _TotalCandidatures: number = 0;

  private _EnCoursPage: number = 1;
  private _HistoriquePage: number = 1;
  private _PageSize: number = 25;


  public get SelectedDossier(): OpportunitiesDTO | null
  {
    return this._SelectedDossier$.getValue();
  }

  public get DossiersEnCours(): OpportunitiesDTO[]
  {
    return this._DossiersEnCours$.getValue();
  }

  public get HistoriqueVentes(): OpportunitiesDTO[]
  {
    return this._HistoriqueVentes$.getValue();
  }

  public get ActiveTab(): string
  {
    return this._ActiveTab$.getValue();
  }

  public SetActiveTab(pTab: string): void
  {
    this._ActiveTab$.next(pTab);
  }
  //#endregion

  public constructor ()
  {
    super();
    this._LoadTotalCandidatures();
  }

  //#region Backend pagination
  public async LoadDossiersPage(
    pUserId: number,
    pTab: DossierTab,
    pPage: number,
    pPageSize: number,
    pTabFilters: OpportunitiesCritereDTO = {}
  ): Promise<void>
  {
    if (!pUserId || pUserId <= 0)
    {
      return;
    }

    this._Loading$.next(true);

    try
    {
      this._PageSize = Math.max(1, pPageSize);

      if (pTab === 'en_cours')
      {
        this._EnCoursPage = pPage;
      } else
      {
        this._HistoriquePage = pPage;
      }

      const lEnCoursSkip: number = Math.max(0, (this._EnCoursPage - 1) * this._PageSize);
      const lHistoriqueSkip: number = Math.max(0, (this._HistoriquePage - 1) * this._PageSize);

      const lAppEnCoursCritere: ApplicationsCritereDTO = {
        selectedAtIsNull: true,
        professional: {},
        applicationServices: {
          service: {}
        }
      };

      const lAppHistoriqueCritere: ApplicationsCritereDTO = {
        selectedAtIsNull: false,
        professional: {},
        applicationServices: {
          service: {}
        }
      };

      const lQueryEnCours: OpportunitiesCritereDTO = {
        userId: pUserId,
        skip: lEnCoursSkip,
        limit: this._PageSize,
        ...pTabFilters,
        applications: lAppEnCoursCritere,
        address: {},
        idStatusNavigation: {},
        includeApplicationsEmpty: true
      };

      const lQueryHistorique: OpportunitiesCritereDTO = {
        userId: pUserId,
        skip: lHistoriqueSkip,
        limit: this._PageSize,
        ...pTabFilters,
        applications: lAppHistoriqueCritere,
        idStatusNavigation: {},
        address: {}
      };

      const lCountEnCoursQuery: OpportunitiesCritereDTO = {
        userId: pUserId,
        ...pTabFilters,
        applications: lAppEnCoursCritere,
        includeApplicationsEmpty: true
      };

      const lCountHistoriqueQuery: OpportunitiesCritereDTO = {
        userId: pUserId,
        ...pTabFilters,
        applications: lAppHistoriqueCritere
      };

      const [lItems, lCount, lItemsHist, lCountHist] = await Promise.all([
        this._OpportunitiesService.getAll(lQueryEnCours),
        this._OpportunitiesService.count(lCountEnCoursQuery),
        this._OpportunitiesService.getAll(lQueryHistorique),
        this._OpportunitiesService.count(lCountHistoriqueQuery)
      ]);

      this._DossiersEnCours$.next(lItems ?? []);
      this._DossiersEnCoursCount$.next(lCount ?? 0);

      this._HistoriqueVentes$.next(lItemsHist ?? []);
      this._HistoriqueVentesCount$.next(lCountHist ?? 0);

      const lCurrent: OpportunitiesDTO[] = pTab === 'en_cours'
        ? this._DossiersEnCours$.getValue()
        : this._HistoriqueVentes$.getValue();

      if (lCurrent.length > 0)
      {
        const lSelected = this._SelectedDossier$.getValue();
        const lExists = !!lSelected && lCurrent.some((p: OpportunitiesDTO) => p.id === lSelected.id);
        if (!lExists)
        {
          this.SelectDossier(lCurrent[0]);
        }
      } else
      {
        this.SelectDossier(null);
      }
    } catch (pError: unknown)
    {
      console.error('Erreur lors du chargement paginé:', pError);
    } finally
    {
      this._Loading$.next(false);
    }
  }
  /**
   * Charge les opportunités du vendeur connecté avec au moins un candidat (application), en incluant l'adresse.
   * @returns Les opportunités du vendeur avec leurs candidatures et adresses
   */
  public async LoadCandidatsOpp(): Promise<OpportunitiesDTO[]>
  {
    if (this.CurrentUserId === null)
    {
      throw new Error("CurrentUserId cannot be null");
    }

    const lUserId: number = parseInt(this.CurrentUserId);

    const lCritere: OpportunitiesCritereDTO = {
      userId: lUserId,
      address: {},
      applications: {
        professional: {}
      }
    };

    return await this._OpportunitiesService.getAll(lCritere);
  }

  /**
   * Récupère les applications et leurs candidats pour un dossier du vendeur, en incluant l'adresse de l'opportunité.
   * @param pDossier Le dossier concerné
   * @returns Les candidatures avec professionnel et opportunité (avec adresse)
   */
  public async LoadCandidatsForDossier(pDossier: OpportunitiesDTO | null): Promise<ApplicationsDTO[]>
  {
    let lApplications: ApplicationsDTO[] = [];

    if (pDossier != null && this.CurrentUserId !== null)
    {
      const lUserId: number = parseInt(this.CurrentUserId);

      const lCritere: ApplicationsCritereDTO = {
        opportunityId: pDossier.id,
        professional: {},
        opportunity: {
          userId: lUserId,
          address: {}
        }
      };

      lApplications = await this._ApplicationsService.getAll(lCritere);
    }

    return lApplications;
  }

  private async _LoadTotalCandidatures(): Promise<number>
  {
    this._TotalCandidatures = 0;

    try
    {

      if (this.CurrentUserId === null)
      {
        throw new Error("CurrentUserId cannot be null");
      }

      const lUserId : number = parseInt(this.CurrentUserId);
      const lCritere: ApplicationsCritereDTO = {
        opportunity: { userId: lUserId },
        selectedAtIsNull: true,
      };

      this._TotalCandidatures = await this._ApplicationsService.count(lCritere);

    } catch (error)
    {
      console.error("Error in _LoadTotalCandidatures:", error);
      throw error;
    }

    return this._TotalCandidatures;
  }
  //#endregion

  //#region Dossiers
  public SelectDossier(pDossier: OpportunitiesDTO | null): void
  {
    this._SelectedDossier$.next(pDossier);
  }

  public async DeleteDossier(pDossierId: number): Promise<boolean>
  {
    try
    {
      await this._OpportunitiesService.delete({ id: pDossierId });

      const lCurrent: OpportunitiesDTO[] = this._DossiersEnCours$.getValue();
      const lUpdated: OpportunitiesDTO[] = lCurrent.filter((pD: OpportunitiesDTO) => pD.id !== pDossierId);
      this._DossiersEnCours$.next(lUpdated);

      const lCount = this._DossiersEnCoursCount$.getValue();
      this._DossiersEnCoursCount$.next(Math.max(0, lCount - 1));

      const lSelected: OpportunitiesDTO | null = this._SelectedDossier$.getValue();
      if (lSelected?.id === pDossierId)
      {
        this.SelectDossier(lUpdated[0] || null);
      }

      return true;
    } catch (pError: unknown)
    {
      console.error('Erreur lors de la suppression:', pError);
      return false;
    }
  }

  public GetDossiersCount(pTab: DossierTab): number
  {
    return pTab === 'en_cours'
      ? this._DossiersEnCoursCount$.getValue()
      : this._HistoriqueVentesCount$.getValue();
  }
  //#endregion

  //#region Actions
  public async SelectionnerCandidature(pApplication: ApplicationsDTO): Promise<ApplicationsDTO | null>
  {
    if (!pApplication.id)
    {
      return null;
    }

    try
    {
      const lAppCritere: ApplicationsCritereDTO = {
        id: pApplication.id,
      };

      pApplication.selectedAt = new Date().toISOString();

      const lResult: ApplicationsDTO | null = await this._ApplicationsService.update(pApplication, lAppCritere);

      return lResult;
    } catch (pError: unknown)
    {
      console.error('Erreur lors de la sélection du candidat:', pError);
    }

    return null;
  }
  //#endregion

  //#region Stats
  public GetStats():SidebarStats
  {
    const lDossiersVendus: number = this._HistoriqueVentesCount$.getValue();

    return {
      DossiersEnCours: this._DossiersEnCoursCount$.getValue(),
      DossiersHistorique: lDossiersVendus,
      TotalCandidatures: this._TotalCandidatures,
      ChiffreAffaires: 0,
      TauxConversion: 0,
      MandatsActifs: 0
    };
  }
  //#endregion
}
