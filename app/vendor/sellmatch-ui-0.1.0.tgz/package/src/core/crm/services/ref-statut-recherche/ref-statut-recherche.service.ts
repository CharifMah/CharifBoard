// gen-hash:4c95c1325617650fe589e700f8f0d587d46ab8b1dec2b2336e9c26e3398080f6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefStatutRechercheDTO } from '../../../../core/crm/dto/ref-statut-recherche/ref-statut-recherche.dto';
import { RefStatutRechercheCritereDTO } from '../../../../core/crm/dto/ref-statut-recherche/ref-statut-recherche.critere';

@Injectable({
  providedIn: 'root'
})
export class RefStatutRechercheService extends ServiceBase<RefStatutRechercheDTO, RefStatutRechercheCritereDTO> {
  constructor() {
    super('RefStatutRecherche');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
