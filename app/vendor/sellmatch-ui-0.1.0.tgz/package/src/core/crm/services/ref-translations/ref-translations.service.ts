// gen-hash:5b31a4ca31e9d07709e89caffad9d1c893ba8178a16a607aac611c2a4111ccba
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTranslationsDTO } from '../../../../core/crm/dto/ref-translations/ref-translations.dto';
import { RefTranslationsCritereDTO } from '../../../../core/crm/dto/ref-translations/ref-translations.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTranslationsService extends ServiceBase<RefTranslationsDTO, RefTranslationsCritereDTO> {
  constructor() {
    super('RefTranslations');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
