// gen-hash:03540677210fc3b1c3a36e22ef57f58aa8e08defe3bb99a47a200557cf348ef1
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefStatutAffaireDTO } from '../../../../core/crm/dto/ref-statut-affaire/ref-statut-affaire.dto';
import { RefStatutAffaireCritereDTO } from '../../../../core/crm/dto/ref-statut-affaire/ref-statut-affaire.critere';

@Injectable({
  providedIn: 'root'
})
export class RefStatutAffaireService extends ServiceBase<RefStatutAffaireDTO, RefStatutAffaireCritereDTO> {
  constructor() {
    super('RefStatutAffaire');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
