// gen-hash:5a7bf56b59a8356bf4a8c148dff31f73816482ca764a7dcdccac6b5c3458439e
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefVisualStyleDTO } from '../../../../core/crm/dto/ref-visual-style/ref-visual-style.dto';
import { RefVisualStyleCritereDTO } from '../../../../core/crm/dto/ref-visual-style/ref-visual-style.critere';

@Injectable({
  providedIn: 'root'
})
export class RefVisualStyleService extends ServiceBase<RefVisualStyleDTO, RefVisualStyleCritereDTO> {
  constructor() {
    super('RefVisualStyle');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
