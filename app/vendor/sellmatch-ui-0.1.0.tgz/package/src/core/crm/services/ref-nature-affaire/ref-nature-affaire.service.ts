// gen-hash:7d367e3ab004202d8596221a8d66da03bd94b9f46b0606c53ebe80829777b0c6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefNatureAffaireDTO } from '../../../../core/crm/dto/ref-nature-affaire/ref-nature-affaire.dto';
import { RefNatureAffaireCritereDTO } from '../../../../core/crm/dto/ref-nature-affaire/ref-nature-affaire.critere';

@Injectable({
  providedIn: 'root'
})
export class RefNatureAffaireService extends ServiceBase<RefNatureAffaireDTO, RefNatureAffaireCritereDTO> {
  constructor() {
    super('RefNatureAffaire');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
