// gen-hash:ae5333fbe05fd256b8f83ceb23c9196c4efc41ec6f8bdfb7f98ebd93c8bf6d63
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefPeriodeObjectifDTO } from '../../../../core/crm/dto/ref-periode-objectif/ref-periode-objectif.dto';
import { RefPeriodeObjectifCritereDTO } from '../../../../core/crm/dto/ref-periode-objectif/ref-periode-objectif.critere';

@Injectable({
  providedIn: 'root'
})
export class RefPeriodeObjectifService extends ServiceBase<RefPeriodeObjectifDTO, RefPeriodeObjectifCritereDTO> {
  constructor() {
    super('RefPeriodeObjectif');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
