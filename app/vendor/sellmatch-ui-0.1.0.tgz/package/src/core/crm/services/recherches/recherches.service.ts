// gen-hash:98c80e5aa715421fe156412b63f0936b7f2955ab51100eed830bef668b55d104
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RecherchesDTO } from '../../../../core/crm/dto/recherches/recherches.dto';
import { RecherchesCritereDTO } from '../../../../core/crm/dto/recherches/recherches.critere';

@Injectable({
  providedIn: 'root'
})
export class RecherchesService extends ServiceBase<RecherchesDTO, RecherchesCritereDTO> {
  constructor() {
    super('Recherches');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
