// gen-hash:b0e80ee4e32fd7c22a1b5fd6d7f6ce1c160d58dc0f6a08b2001220b6b1bca741
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RecrutementsDTO } from '../../../../core/crm/dto/recrutements/recrutements.dto';
import { RecrutementsCritereDTO } from '../../../../core/crm/dto/recrutements/recrutements.critere';

@Injectable({
  providedIn: 'root'
})
export class RecrutementsService extends ServiceBase<RecrutementsDTO, RecrutementsCritereDTO> {
  constructor() {
    super('Recrutements');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
