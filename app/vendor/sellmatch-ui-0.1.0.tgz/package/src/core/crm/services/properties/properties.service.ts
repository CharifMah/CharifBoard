// gen-hash:bb93eeffbc0b0d36b7002aa80c5669ddec0ddca615ed8b3d3b52820531e19ebc
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { PropertiesDTO } from '../../../../core/crm/dto/properties/properties.dto';
import { PropertiesCritereDTO } from '../../../../core/crm/dto/properties/properties.critere';

@Injectable({
  providedIn: 'root'
})
export class PropertiesService extends ServiceBase<PropertiesDTO, PropertiesCritereDTO> {
  constructor() {
    super('Properties');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
