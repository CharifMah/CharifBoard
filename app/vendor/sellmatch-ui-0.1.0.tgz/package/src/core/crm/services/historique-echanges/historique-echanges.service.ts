// gen-hash:9ea7674198606f48979b1d1e1e26dc9a740139a705ff8b3ebe88b057e0054014
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { HistoriqueEchangesDTO } from '../../../../core/crm/dto/historique-echanges/historique-echanges.dto';
import { HistoriqueEchangesCritereDTO } from '../../../../core/crm/dto/historique-echanges/historique-echanges.critere';

@Injectable({
  providedIn: 'root'
})
export class HistoriqueEchangesService extends ServiceBase<HistoriqueEchangesDTO, HistoriqueEchangesCritereDTO> {
  constructor() {
    super('HistoriqueEchanges');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
