import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { EmptyDTO } from '../../../../core/base/EmptyDTO';
import { EmptyCritereDTO } from '../../../../core/base/EmptyCritereDTO';
import { ContactsDTO } from '../../../../core/crm/dto/contacts/contacts.dto';
import { TachesDTO } from '../../../../core/crm/dto/taches/taches.dto';
import { ObjectifAnnuelDashboardDTO } from '../../../../core/crm/dto/dashboard/objectif-annuel.dashboard.dto';
import { ECADashboardPeriode } from '../../../../core/crm/dto/dashboard/ecadashboard-periode';

/**
 * Requête envoyée à `POST api/Dashboard/GetObjectifAnnuel`.
 */
export interface GetObjectifAnnuelRequest {
  /** Année ciblée pour le calcul de l'objectif annuel. */
  annee: number;
}

/**
 * Requête envoyée à `POST api/Dashboard/GetCaEncaisse`.
 */
export interface GetCaEncaisseRequest {
  /** Période de filtre (Année / Mois / Personnalisé). */
  periode: ECADashboardPeriode;
  /** Date de début (requis si période personnalisée). */
  debut?: Date;
  /** Date de fin (requis si période personnalisée). */
  fin?: Date;
}

/**
 * Requête envoyée aux endpoints de masquage d'un contact (`GetMasquageContact` / `SetMasquageContact`).
 */
export interface SetMasquageContactRequest {
  /** Identifiant du contact à masquer / démasquer. */
  contactId: number;
  /** true pour masquer, false pour démasquer. */
  masque: boolean;
}

/**
 * Service Angular du dashboard CRM.
 * Consomme les endpoints custom POST de `api/Dashboard` (le CRUD standard de ServiceBase
 * n'est pas utilisé ici : tous les endpoints sont des POST sans CritereDTO).
 */
@Injectable({
  providedIn: 'root'
})
export class DashboardService extends ServiceBase<EmptyDTO, EmptyCritereDTO> {
  constructor() {
    super('Dashboard');
  }

  /**
   * Calcule l'objectif annuel et la progression pour l'année donnée.
   * @param pAnnee L'année ciblée.
   * @returns L'objectif, le montant atteint, restant et le pourcentage.
   */
  public async GetObjectifAnnuelAsync(pAnnee: number): Promise<ObjectifAnnuelDashboardDTO> {
    try {
      const lPayload: GetObjectifAnnuelRequest = { annee: pAnnee };
      const lResponse = await this.axiosInstance.post<ObjectifAnnuelDashboardDTO>(
        `${this.apiUrl}/GetObjectifAnnuel`,
        lPayload
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_objectif_annuel`);
      return lResponse.data;
    } catch (pError) {
      this.handleError(pError);
      // - cm - Valeurs par défaut pour ne pas casser le rendu du dashboard
      return { objectif: 0, atteint: 0, restant: 0, pct: 0, venduSansDate: 0, loueSansDate: 0 };
    }
  }

  /**
   * Calcule le CA encaissé selon la période choisie.
   * @param pPeriode La période de filtre (Annee | Mois | Personnalise).
   * @param pDebut Date de début (utilisée uniquement si pPeriode = Personnalise).
   * @param pFin Date de fin (utilisée uniquement si pPeriode = Personnalise).
   * @returns Le montant total du CA encaissé.
   */
  public async GetCaEncaisseAsync(
    pPeriode: ECADashboardPeriode,
    pDebut?: Date,
    pFin?: Date
  ): Promise<number> {
    try {
      const lPayload: GetCaEncaisseRequest = {
        periode: pPeriode,
        debut: pDebut,
        fin: pFin
      };
      const lResponse = await this.axiosInstance.post<number>(
        `${this.apiUrl}/GetCaEncaisse`,
        lPayload
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_ca_encaisse`, { periode: pPeriode });
      return lResponse.data;
    } catch (pError) {
      this.handleError(pError);
      return 0;
    }
  }

  /**
   * Récupère les contacts dont l'anniversaire tombe aujourd'hui.
   * @returns Liste des contacts concernés (tableau vide en cas d'erreur).
   */
  public async GetAnniversairesJourAsync(): Promise<ContactsDTO[]> {
    try {
      const lResponse = await this.axiosInstance.post<ContactsDTO[]>(
        `${this.apiUrl}/GetAnniversairesJour`,
        {}
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_anniversaires_jour`);
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    } catch (pError) {
      this.handleError(pError);
      return [];
    }
  }

  /**
   * Récupère les tâches à suivre (non validées, non archivées, échéance entre hier et demain).
   * @returns Liste des tâches à effectuer (tableau vide en cas d'erreur).
   */
  public async GetTachesASuivreAsync(): Promise<TachesDTO[]> {
    try {
      const lResponse = await this.axiosInstance.post<TachesDTO[]>(
        `${this.apiUrl}/GetTachesASuivre`,
        {}
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_taches_a_suivre`);
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    } catch (pError) {
      this.handleError(pError);
      return [];
    }
  }

  /**
   * Récupère les contacts à relancer (pas d'échange depuis plus de 7 jours, hors masqués).
   * @returns Liste des contacts à relancer (tableau vide en cas d'erreur).
   */
  public async GetContactsARelancerAsync(): Promise<ContactsDTO[]> {
    try {
      const lResponse = await this.axiosInstance.post<ContactsDTO[]>(
        `${this.apiUrl}/GetContactsARelancer`,
        {}
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_contacts_a_relancer`);
      return Array.isArray(lResponse.data) ? lResponse.data : [];
    } catch (pError) {
      this.handleError(pError);
      return [];
    }
  }

  /**
   * Vérifie si un contact est masqué de la carte "Contacts à relancer".
   * @param pContactId Identifiant du contact.
   * @returns true si masqué, false sinon.
   */
  public async GetMasquageContactAsync(pContactId: number): Promise<boolean> {
    try {
      const lPayload: SetMasquageContactRequest = { contactId: pContactId, masque: true };
      const lResponse = await this.axiosInstance.post<boolean>(
        `${this.apiUrl}/GetMasquageContact`,
        lPayload
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_get_masquage_contact`);
      return lResponse.data;
    } catch (pError) {
      this.handleError(pError);
      return false;
    }
  }

  /**
   * Définit l'état de masquage d'un contact dans la carte "Contacts à relancer".
   * @param pContactId Identifiant du contact.
   * @param pMasque true pour masquer, false pour démasquer.
   */
  public async SetMasquageContactAsync(pContactId: number, pMasque: boolean): Promise<void> {
    try {
      const lPayload: SetMasquageContactRequest = { contactId: pContactId, masque: pMasque };
      await this.axiosInstance.post<{ success: boolean }>(
        `${this.apiUrl}/SetMasquageContact`,
        lPayload
      );
      this.PostHog.Capture(`api_${this.TrackingEndpoint}_set_masquage_contact`, { masque: pMasque });
    } catch (pError) {
      this.handleError(pError);
    }
  }
}
