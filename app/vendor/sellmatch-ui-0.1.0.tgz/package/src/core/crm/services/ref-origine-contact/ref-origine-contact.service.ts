// gen-hash:2d0fa21c4e14ed1deaaedc30c4742fe125f16ad302dbc4ac2232c7a50e2a384c
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefOrigineContactDTO } from '../../../../core/crm/dto/ref-origine-contact/ref-origine-contact.dto';
import { RefOrigineContactCritereDTO } from '../../../../core/crm/dto/ref-origine-contact/ref-origine-contact.critere';

@Injectable({
  providedIn: 'root'
})
export class RefOrigineContactService extends ServiceBase<RefOrigineContactDTO, RefOrigineContactCritereDTO> {
  constructor() {
    super('RefOrigineContact');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
