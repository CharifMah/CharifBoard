// gen-hash:b2b82b6d69f8aae19236a3f17bcc0651d04342f6add89c6ddfdf9c8ffade1e15
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefOrigineRecrutementDTO } from '../../../../core/crm/dto/ref-origine-recrutement/ref-origine-recrutement.dto';
import { RefOrigineRecrutementCritereDTO } from '../../../../core/crm/dto/ref-origine-recrutement/ref-origine-recrutement.critere';

@Injectable({
  providedIn: 'root'
})
export class RefOrigineRecrutementService extends ServiceBase<RefOrigineRecrutementDTO, RefOrigineRecrutementCritereDTO> {
  constructor() {
    super('RefOrigineRecrutement');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
