// gen-hash:fd5de35b4aafb123d8101f24a07708eca35c57afdafd6fae3079d95558370f8d
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { LocationContactsDTO } from '../../../../core/crm/dto/location-contacts/location-contacts.dto';
import { LocationContactsCritereDTO } from '../../../../core/crm/dto/location-contacts/location-contacts.critere';

@Injectable({
  providedIn: 'root'
})
export class LocationContactsService extends ServiceBase<LocationContactsDTO, LocationContactsCritereDTO> {
  constructor() {
    super('LocationContacts');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
