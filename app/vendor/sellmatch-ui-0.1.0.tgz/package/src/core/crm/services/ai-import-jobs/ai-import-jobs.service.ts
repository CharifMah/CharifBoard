// gen-hash:dfaa1132da7ea3ba09be459667c0486612bbdf34b60e1300f89b3eb7bdb2b3c7
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { AiImportJobsDTO } from '../../../../core/crm/dto/ai-import-jobs/ai-import-jobs.dto';
import { AiImportJobsCritereDTO } from '../../../../core/crm/dto/ai-import-jobs/ai-import-jobs.critere';

@Injectable({
  providedIn: 'root'
})
export class AiImportJobsService extends ServiceBase<AiImportJobsDTO, AiImportJobsCritereDTO> {
  constructor() {
    super('AiImportJobs');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
