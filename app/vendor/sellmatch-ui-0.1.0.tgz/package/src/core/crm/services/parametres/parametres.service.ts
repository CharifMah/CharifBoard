// gen-hash:f50f26d22ad65493cb69f0deb7e909fd2652b1844d4c0dc21f3098f8e57fddbc
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ParametresDTO } from '../../../../core/crm/dto/parametres/parametres.dto';
import { ParametresCritereDTO } from '../../../../core/crm/dto/parametres/parametres.critere';

@Injectable({
  providedIn: 'root'
})
export class ParametresService extends ServiceBase<ParametresDTO, ParametresCritereDTO> {
  constructor() {
    super('Parametres');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
