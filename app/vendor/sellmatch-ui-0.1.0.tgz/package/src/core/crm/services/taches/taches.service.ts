// gen-hash:956202a2f55cbbda2b5501d03a829cfcd87a2dca6a74f52085b635cc0e256f70
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { TachesDTO } from '../../../../core/crm/dto/taches/taches.dto';
import { TachesCritereDTO } from '../../../../core/crm/dto/taches/taches.critere';

@Injectable({
  providedIn: 'root'
})
export class TachesService extends ServiceBase<TachesDTO, TachesCritereDTO> {
  constructor() {
    super('Taches');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
