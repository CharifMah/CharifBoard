// gen-hash:c65be2f693658b87d3b4e0dffaded2e5c08a90f207f898eb185ac366c48d943f
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { TransactionContactsDTO } from '../../../../core/crm/dto/transaction-contacts/transaction-contacts.dto';
import { TransactionContactsCritereDTO } from '../../../../core/crm/dto/transaction-contacts/transaction-contacts.critere';

@Injectable({
  providedIn: 'root'
})
export class TransactionContactsService extends ServiceBase<TransactionContactsDTO, TransactionContactsCritereDTO> {
  constructor() {
    super('TransactionContacts');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
