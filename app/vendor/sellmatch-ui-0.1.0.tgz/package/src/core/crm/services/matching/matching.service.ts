import { Injectable } from '@angular/core';
import axios, { AxiosInstance } from 'axios';
import { environment } from '../../../../environments/environment';
import { PropositionMatchDTO } from '../../../../core/crm/dto/matching/proposition-match.dto';

/**
 * Requete d'entree des endpoints Matching cote front.
 * Le bien cible est identifie par `BienId`.
 */
export interface IMatchingRequest {
  /** Identifiant du bien (Transaction ou Location selon l'endpoint). */
  BienId: number;
}

/**
 * Service Angular consommant les endpoints de matching acquereur / locataire (rapport V2 §5).
 * Deux endpoints POST :
 * - `/api/matching/propose-acquereurs` : renvoie les candidats acquereurs pour une Transaction
 * - `/api/matching/propose-locataires` : renvoie les candidats locataires pour une Location
 *
 * Le service utilise son propre client Axios (pas de ServiceBase) car les endpoints
 * n'exposent pas de CRUD standard et n'ont pas de mapping DTO/critere.
 */
@Injectable({
  providedIn: 'root'
})
export class MatchingService {
  //#region Attribute
  /** Base URL de l'API (cf. environment.apiUrl). */
  private readonly _ApiUrl: string = environment.apiUrl;
  /** Instance Axios dediee (withCredentials=true pour envoyer le cookie HttpOnly d'auth). */
  private readonly _Axios: AxiosInstance;
  //#endregion

  //#region CTOR

  /**
   * Constructeur : initialise l'instance Axios sans interceptors (on delegue aux
   * cookies HttpOnly + au 401 handler global cote `main.ts` / `axios-with-cookie.ts`).
   */
  public constructor() {
    this._Axios = axios.create({
      headers: { 'Content-Type': 'application/json' },
      withCredentials: true
    });
  }

  //#endregion

  //#region Methods

  /**
   * Appelle POST /api/Matching/propose-acquereurs.
   * - cm - Le matching est declenche en arriere-plan par le hook
   * `TransactionsService.AfterCreateAsync` / `AfterUpdateAsync` (champ texte
   * `AcquereurPotentiel`). Cette methode sert a rafraichir la liste complete
   * cote UI (pop-up marker carte, agent chat) si on a besoin des details.
   * @param pTransactionId Identifiant de la transaction source.
   * @returns Liste triee par score descendant (top 20). Liste vide si rien ne matche.
   */
  public async ProposeAcquereursAsync(pTransactionId: number): Promise<PropositionMatchDTO[]> {
    if (!pTransactionId || pTransactionId <= 0) {
      return [];
    }

    const lPayload: IMatchingRequest = { BienId: pTransactionId };
    const lResponse = await this._Axios.post<PropositionMatchDTO[]>(
      `${this._ApiUrl}/Matching/propose-acquereurs`,
      lPayload
    );
    return Array.isArray(lResponse?.data) ? lResponse.data : [];
  }

  /**
   * Appelle POST /api/Matching/propose-locataires.
   * @param pLocationId Identifiant de la location source.
   * @returns Liste triee par score descendant (top 20). Liste vide si rien ne matche.
   */
  public async ProposeLocatairesAsync(pLocationId: number): Promise<PropositionMatchDTO[]> {
    if (!pLocationId || pLocationId <= 0) {
      return [];
    }

    const lPayload: IMatchingRequest = { BienId: pLocationId };
    const lResponse = await this._Axios.post<PropositionMatchDTO[]>(
      `${this._ApiUrl}/Matching/propose-locataires`,
      lPayload
    );
    return Array.isArray(lResponse?.data) ? lResponse.data : [];
  }
  //#endregion
}
