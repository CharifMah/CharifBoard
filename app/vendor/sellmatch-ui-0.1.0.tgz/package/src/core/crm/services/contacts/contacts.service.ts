// gen-hash:15ffbdd44e0209dd316c0b551dbd490349236312f9ad1877c16f44cf657392ad
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ContactsDTO } from '../../../../core/crm/dto/contacts/contacts.dto';
import { ContactsCritereDTO } from '../../../../core/crm/dto/contacts/contacts.critere';

@Injectable({
  providedIn: 'root'
})
export class ContactsService extends ServiceBase<ContactsDTO, ContactsCritereDTO> {
  constructor() {
    super('Contacts');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
