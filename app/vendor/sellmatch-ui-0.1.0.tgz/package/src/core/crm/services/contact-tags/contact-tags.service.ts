// gen-hash:6eeab4b5b9ff98f7df197615c29e3608200de8b345626187387dd0527c2039a7
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ContactTagsDTO } from '../../../../core/crm/dto/contact-tags/contact-tags.dto';
import { ContactTagsCritereDTO } from '../../../../core/crm/dto/contact-tags/contact-tags.critere';

@Injectable({
  providedIn: 'root'
})
export class ContactTagsService extends ServiceBase<ContactTagsDTO, ContactTagsCritereDTO> {
  constructor() {
    super('ContactTags');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
