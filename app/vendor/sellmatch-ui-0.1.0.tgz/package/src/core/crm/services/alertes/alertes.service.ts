// gen-hash:cc43d8ceab0ca23e442f2c217f89b7358c0ac187c8df6d79899222dd258c2f30
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { AlertesDTO } from '../../../../core/crm/dto/alertes/alertes.dto';
import { AlertesCritereDTO } from '../../../../core/crm/dto/alertes/alertes.critere';

@Injectable({
  providedIn: 'root'
})
export class AlertesService extends ServiceBase<AlertesDTO, AlertesCritereDTO> {
  constructor() {
    super('Alertes');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
