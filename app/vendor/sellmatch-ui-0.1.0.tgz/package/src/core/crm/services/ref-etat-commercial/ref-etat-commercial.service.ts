// gen-hash:fa402c9903f2a5b05ea6d1d517c00741df8c81b4036f84057a1b8ee34240d192
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefEtatCommercialDTO } from '../../../../core/crm/dto/ref-etat-commercial/ref-etat-commercial.dto';
import { RefEtatCommercialCritereDTO } from '../../../../core/crm/dto/ref-etat-commercial/ref-etat-commercial.critere';

@Injectable({
  providedIn: 'root'
})
export class RefEtatCommercialService extends ServiceBase<RefEtatCommercialDTO, RefEtatCommercialCritereDTO> {
  constructor() {
    super('RefEtatCommercial');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
