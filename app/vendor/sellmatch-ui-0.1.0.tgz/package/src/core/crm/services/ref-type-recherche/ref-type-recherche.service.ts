// gen-hash:2c4382e664713f014fa2d0aa540bad14d7ce653404cd9344eb3aaa4d3400b690
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeRechercheDTO } from '../../../../core/crm/dto/ref-type-recherche/ref-type-recherche.dto';
import { RefTypeRechercheCritereDTO } from '../../../../core/crm/dto/ref-type-recherche/ref-type-recherche.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeRechercheService extends ServiceBase<RefTypeRechercheDTO, RefTypeRechercheCritereDTO> {
  constructor() {
    super('RefTypeRecherche');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
