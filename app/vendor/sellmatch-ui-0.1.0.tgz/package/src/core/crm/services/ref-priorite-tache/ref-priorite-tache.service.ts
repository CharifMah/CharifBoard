// gen-hash:83a429b8eba2f9cf6a2aa98268f7c7c37b3a2d60d7f540b208aa08b67549fe44
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefPrioriteTacheDTO } from '../../../../core/crm/dto/ref-priorite-tache/ref-priorite-tache.dto';
import { RefPrioriteTacheCritereDTO } from '../../../../core/crm/dto/ref-priorite-tache/ref-priorite-tache.critere';

@Injectable({
  providedIn: 'root'
})
export class RefPrioriteTacheService extends ServiceBase<RefPrioriteTacheDTO, RefPrioriteTacheCritereDTO> {
  constructor() {
    super('RefPrioriteTache');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
