// gen-hash:6a47f6e1e843e0751d90644877ac36a7820b3447a451ede1efdd1a9b9f6f2245
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeTvaDTO } from '../../../../core/crm/dto/ref-type-tva/ref-type-tva.dto';
import { RefTypeTvaCritereDTO } from '../../../../core/crm/dto/ref-type-tva/ref-type-tva.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeTvaService extends ServiceBase<RefTypeTvaDTO, RefTypeTvaCritereDTO> {
  constructor() {
    super('RefTypeTva');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
