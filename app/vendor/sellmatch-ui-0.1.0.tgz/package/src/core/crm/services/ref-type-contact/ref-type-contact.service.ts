// gen-hash:8de68b71110cdbccb4840277aed510fb1765c861bd37fb6d4ddc41110dba8f11
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeContactDTO } from '../../../../core/crm/dto/ref-type-contact/ref-type-contact.dto';
import { RefTypeContactCritereDTO } from '../../../../core/crm/dto/ref-type-contact/ref-type-contact.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeContactService extends ServiceBase<RefTypeContactDTO, RefTypeContactCritereDTO> {
  constructor() {
    super('RefTypeContact');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
