// gen-hash:57fb92fc64382ff65aad409793d442833ce5e3b3858958c32536c9a0c821439a
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefStatutRecrutementDTO } from '../../../../core/crm/dto/ref-statut-recrutement/ref-statut-recrutement.dto';
import { RefStatutRecrutementCritereDTO } from '../../../../core/crm/dto/ref-statut-recrutement/ref-statut-recrutement.critere';

@Injectable({
  providedIn: 'root'
})
export class RefStatutRecrutementService extends ServiceBase<RefStatutRecrutementDTO, RefStatutRecrutementCritereDTO> {
  constructor() {
    super('RefStatutRecrutement');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
