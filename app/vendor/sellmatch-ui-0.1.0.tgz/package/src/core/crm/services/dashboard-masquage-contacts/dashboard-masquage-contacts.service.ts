// gen-hash:aa578b81fbcc7231523435bcc8fc246092225d49bea3c85b6c0cd932f1a27bb5
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { DashboardMasquageContactsDTO } from '../../../../core/crm/dto/dashboard-masquage-contacts/dashboard-masquage-contacts.dto';
import { DashboardMasquageContactsCritereDTO } from '../../../../core/crm/dto/dashboard-masquage-contacts/dashboard-masquage-contacts.critere';

@Injectable({
  providedIn: 'root'
})
export class DashboardMasquageContactsService extends ServiceBase<DashboardMasquageContactsDTO, DashboardMasquageContactsCritereDTO> {
  constructor() {
    super('DashboardMasquageContacts');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
