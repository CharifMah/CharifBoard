// gen-hash:796b92748029ea79b63f188f8197e04231f532820e802da0fecb8a20f9ea310b
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeBienDTO } from '../../../../core/crm/dto/ref-type-bien/ref-type-bien.dto';
import { RefTypeBienCritereDTO } from '../../../../core/crm/dto/ref-type-bien/ref-type-bien.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeBienService extends ServiceBase<RefTypeBienDTO, RefTypeBienCritereDTO> {
  constructor() {
    super('RefTypeBien');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
