// gen-hash:2f9d4434d456efed2d87e40eb70b5386552b92e9c2654a3d1fbcaf8af2528570
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeEchangeDTO } from '../../../../core/crm/dto/ref-type-echange/ref-type-echange.dto';
import { RefTypeEchangeCritereDTO } from '../../../../core/crm/dto/ref-type-echange/ref-type-echange.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeEchangeService extends ServiceBase<RefTypeEchangeDTO, RefTypeEchangeCritereDTO> {
  constructor() {
    super('RefTypeEchange');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
