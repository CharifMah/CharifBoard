// gen-hash:942677f39cd98ca73045087edf37f098a759272cdead606c581631b449581583
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefTypeProspectionDTO } from '../../../../core/crm/dto/ref-type-prospection/ref-type-prospection.dto';
import { RefTypeProspectionCritereDTO } from '../../../../core/crm/dto/ref-type-prospection/ref-type-prospection.critere';

@Injectable({
  providedIn: 'root'
})
export class RefTypeProspectionService extends ServiceBase<RefTypeProspectionDTO, RefTypeProspectionCritereDTO> {
  constructor() {
    super('RefTypeProspection');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
