// gen-hash:e187702ee1b6c6369c7e1f581e5c005962172d69bb3c2596aa851c50cbc5c737
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ObjectifsDTO } from '../../../../core/crm/dto/objectifs/objectifs.dto';
import { ObjectifsCritereDTO } from '../../../../core/crm/dto/objectifs/objectifs.critere';

@Injectable({
  providedIn: 'root'
})
export class ObjectifsService extends ServiceBase<ObjectifsDTO, ObjectifsCritereDTO> {
  constructor() {
    super('Objectifs');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
