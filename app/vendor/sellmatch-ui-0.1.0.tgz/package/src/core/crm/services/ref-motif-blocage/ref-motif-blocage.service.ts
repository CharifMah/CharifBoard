// gen-hash:1e5bcb5eca958e22885cc321f8927007bcb2ffaa921a8209659d45f3687b8164
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RefMotifBlocageDTO } from '../../../../core/crm/dto/ref-motif-blocage/ref-motif-blocage.dto';
import { RefMotifBlocageCritereDTO } from '../../../../core/crm/dto/ref-motif-blocage/ref-motif-blocage.critere';

@Injectable({
  providedIn: 'root'
})
export class RefMotifBlocageService extends ServiceBase<RefMotifBlocageDTO, RefMotifBlocageCritereDTO> {
  constructor() {
    super('RefMotifBlocage');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
