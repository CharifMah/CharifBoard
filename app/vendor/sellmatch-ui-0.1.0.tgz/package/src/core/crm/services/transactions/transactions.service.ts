// gen-hash:dbbafccbc3bab0358b7cb547e2cc7ca7778a2bd18366377313a51dd1c1873be6
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { TransactionsDTO } from '../../../../core/crm/dto/transactions/transactions.dto';
import { TransactionsCritereDTO } from '../../../../core/crm/dto/transactions/transactions.critere';

@Injectable({
  providedIn: 'root'
})
export class TransactionsService extends ServiceBase<TransactionsDTO, TransactionsCritereDTO> {
  constructor() {
    super('Transactions');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
