// gen-hash:ac77e5200575250708f15dc7a22c7b3ea8dbbd3bc7d3a4c408837cca080ba8ed
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { ProspectionsDTO } from '../../../../core/crm/dto/prospections/prospections.dto';
import { ProspectionsCritereDTO } from '../../../../core/crm/dto/prospections/prospections.critere';

@Injectable({
  providedIn: 'root'
})
export class ProspectionsService extends ServiceBase<ProspectionsDTO, ProspectionsCritereDTO> {
  constructor() {
    super('Prospections');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
