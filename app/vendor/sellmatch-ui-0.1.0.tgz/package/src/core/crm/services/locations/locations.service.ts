// gen-hash:711cd2a1216c01f0757f388c0250e2a5328cdc3eed1af84de1a10a2280ed9105
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { LocationsDTO } from '../../../../core/crm/dto/locations/locations.dto';
import { LocationsCritereDTO } from '../../../../core/crm/dto/locations/locations.critere';

@Injectable({
  providedIn: 'root'
})
export class LocationsService extends ServiceBase<LocationsDTO, LocationsCritereDTO> {
  constructor() {
    super('Locations');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
