// gen-hash:911d181e3defe2afe22ff0e330b939a75758e01dfa3724c3f6b495030de3d7a4
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { PropertyHistoriquePrixDTO } from '../../../../core/crm/dto/property-historique-prix/property-historique-prix.dto';
import { PropertyHistoriquePrixCritereDTO } from '../../../../core/crm/dto/property-historique-prix/property-historique-prix.critere';

@Injectable({
  providedIn: 'root'
})
export class PropertyHistoriquePrixService extends ServiceBase<PropertyHistoriquePrixDTO, PropertyHistoriquePrixCritereDTO> {
  constructor() {
    super('PropertyHistoriquePrix');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
