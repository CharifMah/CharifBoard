// gen-hash:36cac20b3d71401bc6f2b805eb05cd3d87a3382bce0c591c63ec2c10cdcb51f1
import { Injectable } from '@angular/core';
import { ServiceBase } from '../../../../core/base/ServiceBase';
import { RechercheBiensDTO } from '../../../../core/crm/dto/recherche-biens/recherche-biens.dto';
import { RechercheBiensCritereDTO } from '../../../../core/crm/dto/recherche-biens/recherche-biens.critere';

@Injectable({
  providedIn: 'root'
})
export class RechercheBiensService extends ServiceBase<RechercheBiensDTO, RechercheBiensCritereDTO> {
  constructor() {
    super('RechercheBiens');
  }

  // Vous pouvez ajouter des méthodes spécifiques ici
}
