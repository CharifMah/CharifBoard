// gen-hash:f7f351ab6ad13615ee540cf7f3a680252aec6aa2e9273a13d8485eeb3d253f4f
/**
 * Validator TypeScript pour AlertesDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { AlertesDTO } from './alertes.dto';

/**
 * Interface d'une règle de validation pour un champ de AlertesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface AlertesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof AlertesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: AlertesDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour AlertesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const AlertesValidator: Record<string, AlertesFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: AlertesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - typeAlerte : optionnel, longueur max 50
  typeAlerte: {
    Key: 'typeAlerte',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: AlertesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'typeAlerte ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - titre : optionnel, longueur max 255
  titre: {
    Key: 'titre',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: AlertesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'titre ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - entiteType : optionnel, longueur max 50
  entiteType: {
    Key: 'entiteType',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: AlertesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'entiteType ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de AlertesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetAlertesFieldValidator(pKey: string): ((pValue: unknown, pRow: AlertesDTO) => string | null) | null {
  const lRule: AlertesFieldRule | undefined = AlertesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
