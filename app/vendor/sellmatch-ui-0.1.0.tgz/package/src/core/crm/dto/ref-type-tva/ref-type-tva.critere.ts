// gen-hash:3e36a583cf2fefcb9cba195b09d76a785a6ce0b6c547b42e42cef9f1ad9cddfb
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { ParametresCritereDTO } from '../parametres/parametres.critere';

export interface RefTypeTvaCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de code */
  code?: string;
  /** Filtre IsNull sur code (true = IS NULL, false = IS NOT NULL) */
  codeIsNull?: boolean;
  /** Filtre code différent de cette valeur (NOT EQUAL) */
  codeIsDifferent?: string;
  /** Filtre par liste de valeurs pour code (IN) */
  codes?: string[];
  /** Filtre code différent de toutes ces valeurs (NOT IN) */
  codeIsDifferentList?: string[];

  /** Filtre code contenant cette valeur (LIKE %value%) */
  codeLike?: string;

  /** Filtre code commençant par cette valeur (LIKE value%) */
  codeStartsWith?: string;

  /** Filtre code terminant par cette valeur (LIKE %value) */
  codeEndsWith?: string;

  /** Filtre code ne contenant pas cette valeur (NOT LIKE %value%) */
  codeIsDifferentLike?: string;

  /** Filtre par valeur exacte de libelle */
  libelle?: string;
  /** Filtre IsNull sur libelle (true = IS NULL, false = IS NOT NULL) */
  libelleIsNull?: boolean;
  /** Filtre libelle différent de cette valeur (NOT EQUAL) */
  libelleIsDifferent?: string;
  /** Filtre par liste de valeurs pour libelle (IN) */
  libelles?: string[];
  /** Filtre libelle différent de toutes ces valeurs (NOT IN) */
  libelleIsDifferentList?: string[];

  /** Filtre libelle contenant cette valeur (LIKE %value%) */
  libelleLike?: string;

  /** Filtre libelle commençant par cette valeur (LIKE value%) */
  libelleStartsWith?: string;

  /** Filtre libelle terminant par cette valeur (LIKE %value) */
  libelleEndsWith?: string;

  /** Filtre libelle ne contenant pas cette valeur (NOT LIKE %value%) */
  libelleIsDifferentLike?: string;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre IsNull sur isActive (true = IS NULL, false = IS NOT NULL) */
  isActiveIsNull?: boolean;
  /** Filtre isActive différent de cette valeur (NOT EQUAL) */
  isActiveIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];
  /** Filtre isActive différent de toutes ces valeurs (NOT IN) */
  isActiveIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de displayOrder */
  displayOrder?: number;
  /** Filtre IsNull sur displayOrder (true = IS NULL, false = IS NOT NULL) */
  displayOrderIsNull?: boolean;
  /** Filtre par liste de valeurs pour displayOrder (IN) */
  displayOrders?: number[];
  /** Filtre displayOrder différent de toutes ces valeurs (NOT IN) */
  displayOrderIsDifferentList?: number[];

  /** Filtre displayOrder supérieur ou égal à cette valeur */
  displayOrderMin?: number;

  /** Filtre displayOrder inférieur ou égal à cette valeur */
  displayOrderMax?: number;

  /** Filtre displayOrder strictement supérieur à cette valeur */
  displayOrderGreaterThan?: number;

  /** Filtre displayOrder strictement inférieur à cette valeur */
  displayOrderLessThan?: number;

  /** Filtre displayOrder différent de cette valeur */
  displayOrderIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur parametres.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT parametres.
   */
  parametresFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont parametres est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT parametres.
   */
  includeParametresEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour parametres.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT parametres.
   */
  parametresMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection parametres. */
  parametres?: ParametresCritereDTO;

}
