// gen-hash:8a3350a2838f7a7ecb398dea986642d6692a153af04c6eeb92f0603087e2f9b1
/**
 * Validator TypeScript pour RefMotifBlocageDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefMotifBlocageDTO } from './ref-motif-blocage.dto';

/**
 * Interface d'une règle de validation pour un champ de RefMotifBlocageDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefMotifBlocageFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefMotifBlocageDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefMotifBlocageDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefMotifBlocageDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefMotifBlocageValidator: Record<string, RefMotifBlocageFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefMotifBlocageDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefMotifBlocageDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefMotifBlocageDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefMotifBlocageFieldValidator(pKey: string): ((pValue: unknown, pRow: RefMotifBlocageDTO) => string | null) | null {
  const lRule: RefMotifBlocageFieldRule | undefined = RefMotifBlocageValidator[pKey];
  return lRule ? lRule.Validate : null;
}
