// gen-hash:7a9265ffb1a7d28a621e5287e48038c1a3d5fc8348d2ad46a394857687a1f670
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { RefPeriodeObjectifCritereDTO } from '../ref-periode-objectif/ref-periode-objectif.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface ObjectifsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de objectif */
  objectif?: string;
  /** Filtre IsNull sur objectif (true = IS NULL, false = IS NOT NULL) */
  objectifIsNull?: boolean;
  /** Filtre objectif différent de cette valeur (NOT EQUAL) */
  objectifIsDifferent?: string;
  /** Filtre par liste de valeurs pour objectif (IN) */
  objectifs?: string[];
  /** Filtre objectif différent de toutes ces valeurs (NOT IN) */
  objectifIsDifferentList?: string[];

  /** Filtre objectif contenant cette valeur (LIKE %value%) */
  objectifLike?: string;

  /** Filtre objectif commençant par cette valeur (LIKE value%) */
  objectifStartsWith?: string;

  /** Filtre objectif terminant par cette valeur (LIKE %value) */
  objectifEndsWith?: string;

  /** Filtre objectif ne contenant pas cette valeur (NOT LIKE %value%) */
  objectifIsDifferentLike?: string;

  /** Filtre par valeur exacte de periodeId */
  periodeId?: number;
  /** Filtre IsNull sur periodeId (true = IS NULL, false = IS NOT NULL) */
  periodeIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour periodeId (IN) */
  periodeIds?: number[];
  /** Filtre periodeId différent de toutes ces valeurs (NOT IN) */
  periodeIdIsDifferentList?: number[];

  /** Filtre periodeId supérieur ou égal à cette valeur */
  periodeIdMin?: number;

  /** Filtre periodeId inférieur ou égal à cette valeur */
  periodeIdMax?: number;

  /** Filtre periodeId strictement supérieur à cette valeur */
  periodeIdGreaterThan?: number;

  /** Filtre periodeId strictement inférieur à cette valeur */
  periodeIdLessThan?: number;

  /** Filtre periodeId différent de cette valeur */
  periodeIdIsDifferent?: number;

  /** Filtre par valeur exacte de dateDebut */
  dateDebut?: Date | string;
  /** Filtre IsNull sur dateDebut (true = IS NULL, false = IS NOT NULL) */
  dateDebutIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateDebut (IN) */
  dateDebuts?: Date | string[];
  /** Filtre dateDebut différent de toutes ces valeurs (NOT IN) */
  dateDebutIsDifferentList?: Date | string[];

  /** Filtre dateDebut à partir de cette date (incluse) */
  dateDebutFrom?: Date | string;

  /** Filtre dateDebut jusqu'à cette date (incluse) */
  dateDebutTo?: Date | string;

  /** Filtre dateDebut strictement après cette date */
  dateDebutAfter?: Date | string;

  /** Filtre dateDebut strictement avant cette date */
  dateDebutBefore?: Date | string;

  /** Filtre dateDebut différent de cette date */
  dateDebutIsDifferent?: Date | string;

  /** Filtre par valeur exacte de dateFin */
  dateFin?: Date | string;
  /** Filtre IsNull sur dateFin (true = IS NULL, false = IS NOT NULL) */
  dateFinIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateFin (IN) */
  dateFins?: Date | string[];
  /** Filtre dateFin différent de toutes ces valeurs (NOT IN) */
  dateFinIsDifferentList?: Date | string[];

  /** Filtre dateFin à partir de cette date (incluse) */
  dateFinFrom?: Date | string;

  /** Filtre dateFin jusqu'à cette date (incluse) */
  dateFinTo?: Date | string;

  /** Filtre dateFin strictement après cette date */
  dateFinAfter?: Date | string;

  /** Filtre dateFin strictement avant cette date */
  dateFinBefore?: Date | string;

  /** Filtre dateFin différent de cette date */
  dateFinIsDifferent?: Date | string;

  /** Filtre par valeur exacte de cible */
  cible?: string;
  /** Filtre IsNull sur cible (true = IS NULL, false = IS NOT NULL) */
  cibleIsNull?: boolean;
  /** Filtre cible différent de cette valeur (NOT EQUAL) */
  cibleIsDifferent?: string;
  /** Filtre par liste de valeurs pour cible (IN) */
  cibles?: string[];
  /** Filtre cible différent de toutes ces valeurs (NOT IN) */
  cibleIsDifferentList?: string[];

  /** Filtre cible contenant cette valeur (LIKE %value%) */
  cibleLike?: string;

  /** Filtre cible commençant par cette valeur (LIKE value%) */
  cibleStartsWith?: string;

  /** Filtre cible terminant par cette valeur (LIKE %value) */
  cibleEndsWith?: string;

  /** Filtre cible ne contenant pas cette valeur (NOT LIKE %value%) */
  cibleIsDifferentLike?: string;

  /** Filtre par valeur exacte de resultat */
  resultat?: string;
  /** Filtre IsNull sur resultat (true = IS NULL, false = IS NOT NULL) */
  resultatIsNull?: boolean;
  /** Filtre resultat différent de cette valeur (NOT EQUAL) */
  resultatIsDifferent?: string;
  /** Filtre par liste de valeurs pour resultat (IN) */
  resultats?: string[];
  /** Filtre resultat différent de toutes ces valeurs (NOT IN) */
  resultatIsDifferentList?: string[];

  /** Filtre resultat contenant cette valeur (LIKE %value%) */
  resultatLike?: string;

  /** Filtre resultat commençant par cette valeur (LIKE value%) */
  resultatStartsWith?: string;

  /** Filtre resultat terminant par cette valeur (LIKE %value) */
  resultatEndsWith?: string;

  /** Filtre resultat ne contenant pas cette valeur (NOT LIKE %value%) */
  resultatIsDifferentLike?: string;

  /** Filtre par valeur exacte de validee */
  validee?: boolean;
  /** Filtre IsNull sur validee (true = IS NULL, false = IS NOT NULL) */
  valideeIsNull?: boolean;
  /** Filtre validee différent de cette valeur (NOT EQUAL) */
  valideeIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour validee (IN) */
  validees?: boolean[];
  /** Filtre validee différent de toutes ces valeurs (NOT IN) */
  valideeIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où periode est NULL).
   * false = INNER JOIN.
   * À configurer AVANT periode.
   */
  includePeriodeEmpty?: boolean;

  /** Filtre imbriqué sur la navigation periode. */
  periode?: RefPeriodeObjectifCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
