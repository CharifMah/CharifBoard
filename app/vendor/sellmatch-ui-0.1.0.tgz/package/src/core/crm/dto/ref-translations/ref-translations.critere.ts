// gen-hash:40c0e7ebfc2e48a17a18c2f3f89b9ead31fab4ce5dc98dc1b27fac82fc907bad
import { BaseCritereDTO } from '../../../../core/base/base.critere';

export interface RefTranslationsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de refTable */
  refTable?: string;
  /** Filtre IsNull sur refTable (true = IS NULL, false = IS NOT NULL) */
  refTableIsNull?: boolean;
  /** Filtre refTable différent de cette valeur (NOT EQUAL) */
  refTableIsDifferent?: string;
  /** Filtre par liste de valeurs pour refTable (IN) */
  refTables?: string[];
  /** Filtre refTable différent de toutes ces valeurs (NOT IN) */
  refTableIsDifferentList?: string[];

  /** Filtre refTable contenant cette valeur (LIKE %value%) */
  refTableLike?: string;

  /** Filtre refTable commençant par cette valeur (LIKE value%) */
  refTableStartsWith?: string;

  /** Filtre refTable terminant par cette valeur (LIKE %value) */
  refTableEndsWith?: string;

  /** Filtre refTable ne contenant pas cette valeur (NOT LIKE %value%) */
  refTableIsDifferentLike?: string;

  /** Filtre par valeur exacte de refId */
  refId?: number;
  /** Filtre par liste de valeurs pour refId (IN) */
  refIds?: number[];
  /** Filtre refId différent de toutes ces valeurs (NOT IN) */
  refIdIsDifferentList?: number[];

  /** Filtre refId supérieur ou égal à cette valeur */
  refIdMin?: number;

  /** Filtre refId inférieur ou égal à cette valeur */
  refIdMax?: number;

  /** Filtre refId strictement supérieur à cette valeur */
  refIdGreaterThan?: number;

  /** Filtre refId strictement inférieur à cette valeur */
  refIdLessThan?: number;

  /** Filtre refId différent de cette valeur */
  refIdIsDifferent?: number;

  /** Filtre par valeur exacte de lang */
  lang?: string;
  /** Filtre IsNull sur lang (true = IS NULL, false = IS NOT NULL) */
  langIsNull?: boolean;
  /** Filtre lang différent de cette valeur (NOT EQUAL) */
  langIsDifferent?: string;
  /** Filtre par liste de valeurs pour lang (IN) */
  langs?: string[];
  /** Filtre lang différent de toutes ces valeurs (NOT IN) */
  langIsDifferentList?: string[];

  /** Filtre lang contenant cette valeur (LIKE %value%) */
  langLike?: string;

  /** Filtre lang commençant par cette valeur (LIKE value%) */
  langStartsWith?: string;

  /** Filtre lang terminant par cette valeur (LIKE %value) */
  langEndsWith?: string;

  /** Filtre lang ne contenant pas cette valeur (NOT LIKE %value%) */
  langIsDifferentLike?: string;

  /** Filtre par valeur exacte de libelle */
  libelle?: string;
  /** Filtre IsNull sur libelle (true = IS NULL, false = IS NOT NULL) */
  libelleIsNull?: boolean;
  /** Filtre libelle différent de cette valeur (NOT EQUAL) */
  libelleIsDifferent?: string;
  /** Filtre par liste de valeurs pour libelle (IN) */
  libelles?: string[];
  /** Filtre libelle différent de toutes ces valeurs (NOT IN) */
  libelleIsDifferentList?: string[];

  /** Filtre libelle contenant cette valeur (LIKE %value%) */
  libelleLike?: string;

  /** Filtre libelle commençant par cette valeur (LIKE value%) */
  libelleStartsWith?: string;

  /** Filtre libelle terminant par cette valeur (LIKE %value) */
  libelleEndsWith?: string;

  /** Filtre libelle ne contenant pas cette valeur (NOT LIKE %value%) */
  libelleIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

}
