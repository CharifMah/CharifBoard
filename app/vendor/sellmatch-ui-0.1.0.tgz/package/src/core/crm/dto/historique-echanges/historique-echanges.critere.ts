// gen-hash:8d2e5ed95e33d501f98c11574cfa5740577131c304ec65f058a8b5aeb76afe5a
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { RefTypeEchangeCritereDTO } from '../ref-type-echange/ref-type-echange.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface HistoriqueEchangesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de actionEchange */
  actionEchange?: string;
  /** Filtre IsNull sur actionEchange (true = IS NULL, false = IS NOT NULL) */
  actionEchangeIsNull?: boolean;
  /** Filtre actionEchange différent de cette valeur (NOT EQUAL) */
  actionEchangeIsDifferent?: string;
  /** Filtre par liste de valeurs pour actionEchange (IN) */
  actionEchanges?: string[];
  /** Filtre actionEchange différent de toutes ces valeurs (NOT IN) */
  actionEchangeIsDifferentList?: string[];

  /** Filtre actionEchange contenant cette valeur (LIKE %value%) */
  actionEchangeLike?: string;

  /** Filtre actionEchange commençant par cette valeur (LIKE value%) */
  actionEchangeStartsWith?: string;

  /** Filtre actionEchange terminant par cette valeur (LIKE %value) */
  actionEchangeEndsWith?: string;

  /** Filtre actionEchange ne contenant pas cette valeur (NOT LIKE %value%) */
  actionEchangeIsDifferentLike?: string;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre IsNull sur contactId (true = IS NULL, false = IS NOT NULL) */
  contactIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de dateEchange */
  dateEchange?: Date | string;
  /** Filtre IsNull sur dateEchange (true = IS NULL, false = IS NOT NULL) */
  dateEchangeIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateEchange (IN) */
  dateEchanges?: Date | string[];
  /** Filtre dateEchange différent de toutes ces valeurs (NOT IN) */
  dateEchangeIsDifferentList?: Date | string[];

  /** Filtre dateEchange à partir de cette date (incluse) */
  dateEchangeFrom?: Date | string;

  /** Filtre dateEchange jusqu'à cette date (incluse) */
  dateEchangeTo?: Date | string;

  /** Filtre dateEchange strictement après cette date */
  dateEchangeAfter?: Date | string;

  /** Filtre dateEchange strictement avant cette date */
  dateEchangeBefore?: Date | string;

  /** Filtre dateEchange différent de cette date */
  dateEchangeIsDifferent?: Date | string;

  /** Filtre par valeur exacte de typeEchangeId */
  typeEchangeId?: number;
  /** Filtre IsNull sur typeEchangeId (true = IS NULL, false = IS NOT NULL) */
  typeEchangeIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeEchangeId (IN) */
  typeEchangeIds?: number[];
  /** Filtre typeEchangeId différent de toutes ces valeurs (NOT IN) */
  typeEchangeIdIsDifferentList?: number[];

  /** Filtre typeEchangeId supérieur ou égal à cette valeur */
  typeEchangeIdMin?: number;

  /** Filtre typeEchangeId inférieur ou égal à cette valeur */
  typeEchangeIdMax?: number;

  /** Filtre typeEchangeId strictement supérieur à cette valeur */
  typeEchangeIdGreaterThan?: number;

  /** Filtre typeEchangeId strictement inférieur à cette valeur */
  typeEchangeIdLessThan?: number;

  /** Filtre typeEchangeId différent de cette valeur */
  typeEchangeIdIsDifferent?: number;

  /** Filtre par valeur exacte de compteRendu */
  compteRendu?: string;
  /** Filtre IsNull sur compteRendu (true = IS NULL, false = IS NOT NULL) */
  compteRenduIsNull?: boolean;
  /** Filtre compteRendu différent de cette valeur (NOT EQUAL) */
  compteRenduIsDifferent?: string;
  /** Filtre par liste de valeurs pour compteRendu (IN) */
  compteRendus?: string[];
  /** Filtre compteRendu différent de toutes ces valeurs (NOT IN) */
  compteRenduIsDifferentList?: string[];

  /** Filtre compteRendu contenant cette valeur (LIKE %value%) */
  compteRenduLike?: string;

  /** Filtre compteRendu commençant par cette valeur (LIKE value%) */
  compteRenduStartsWith?: string;

  /** Filtre compteRendu terminant par cette valeur (LIKE %value) */
  compteRenduEndsWith?: string;

  /** Filtre compteRendu ne contenant pas cette valeur (NOT LIKE %value%) */
  compteRenduIsDifferentLike?: string;

  /** Filtre par valeur exacte de resultatProchaineAction */
  resultatProchaineAction?: string;
  /** Filtre IsNull sur resultatProchaineAction (true = IS NULL, false = IS NOT NULL) */
  resultatProchaineActionIsNull?: boolean;
  /** Filtre resultatProchaineAction différent de cette valeur (NOT EQUAL) */
  resultatProchaineActionIsDifferent?: string;
  /** Filtre par liste de valeurs pour resultatProchaineAction (IN) */
  resultatProchaineActions?: string[];
  /** Filtre resultatProchaineAction différent de toutes ces valeurs (NOT IN) */
  resultatProchaineActionIsDifferentList?: string[];

  /** Filtre resultatProchaineAction contenant cette valeur (LIKE %value%) */
  resultatProchaineActionLike?: string;

  /** Filtre resultatProchaineAction commençant par cette valeur (LIKE value%) */
  resultatProchaineActionStartsWith?: string;

  /** Filtre resultatProchaineAction terminant par cette valeur (LIKE %value) */
  resultatProchaineActionEndsWith?: string;

  /** Filtre resultatProchaineAction ne contenant pas cette valeur (NOT LIKE %value%) */
  resultatProchaineActionIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où typeEchange est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeEchange.
   */
  includeTypeechangeEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeEchange. */
  typeEchange?: RefTypeEchangeCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
