// gen-hash:3d8d10fcf2a5048fc4b92d418be4d8e9177fa13cab6b8f1378e6744f565959fc
/**
 * DTO for table: ref_type_tva
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ParametresDTO } from '../parametres/parametres.dto';

export interface RefTypeTvaDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Parametres */
  parametres?: ParametresDTO[];
}
