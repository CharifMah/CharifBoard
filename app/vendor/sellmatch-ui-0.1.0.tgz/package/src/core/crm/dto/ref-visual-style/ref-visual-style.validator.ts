// gen-hash:576f4f967da3470c45103056fb2216a6d510af118d7ea3edf3e0755fc97a50fd
/**
 * Validator TypeScript pour RefVisualStyleDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefVisualStyleDTO } from './ref-visual-style.dto';

/**
 * Interface d'une règle de validation pour un champ de RefVisualStyleDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefVisualStyleFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefVisualStyleDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefVisualStyleDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefVisualStyleDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefVisualStyleValidator: Record<string, RefVisualStyleFieldRule> = {
  // - cm - code : obligatoire, longueur max 80
  code: {
    Key: 'code',
    MaxLength: 80,
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 80) {
        return 'code ne doit pas dépasser 80 caractères.';
      }
      return null;
    }
  },

  // - cm - icon : obligatoire, longueur max 50
  icon: {
    Key: 'icon',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'icon est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'icon ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - color : obligatoire, longueur max 20
  color: {
    Key: 'color',
    MaxLength: 20,
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'color est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 20) {
        return 'color ne doit pas dépasser 20 caractères.';
      }
      return null;
    }
  },

  // - cm - variant : obligatoire, longueur max 20
  variant: {
    Key: 'variant',
    MaxLength: 20,
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'variant est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 20) {
        return 'variant ne doit pas dépasser 20 caractères.';
      }
      return null;
    }
  },

  // - cm - isActive : obligatoire
  isActive: {
    Key: 'isActive',
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'isActive est obligatoire.';
      }
      return null;
    }
  },

  // - cm - displayOrder : obligatoire
  displayOrder: {
    Key: 'displayOrder',
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'displayOrder est obligatoire.';
      }
      return null;
    }
  },

  // - cm - createdAt : obligatoire
  createdAt: {
    Key: 'createdAt',
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'createdAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - updatedAt : obligatoire
  updatedAt: {
    Key: 'updatedAt',
    Validate: (pValue: unknown, _pRow: RefVisualStyleDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'updatedAt est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefVisualStyleDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefVisualStyleFieldValidator(pKey: string): ((pValue: unknown, pRow: RefVisualStyleDTO) => string | null) | null {
  const lRule: RefVisualStyleFieldRule | undefined = RefVisualStyleValidator[pKey];
  return lRule ? lRule.Validate : null;
}
