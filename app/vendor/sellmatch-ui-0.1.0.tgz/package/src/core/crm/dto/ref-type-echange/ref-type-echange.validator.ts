// gen-hash:56eab3328fdae6e006c52272f9a13fafa71b91b1574ed2300f33cad84d07a37c
/**
 * Validator TypeScript pour RefTypeEchangeDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeEchangeDTO } from './ref-type-echange.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeEchangeDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeEchangeFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeEchangeDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeEchangeDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeEchangeDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeEchangeValidator: Record<string, RefTypeEchangeFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeEchangeDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeEchangeDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeEchangeDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeEchangeFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeEchangeDTO) => string | null) | null {
  const lRule: RefTypeEchangeFieldRule | undefined = RefTypeEchangeValidator[pKey];
  return lRule ? lRule.Validate : null;
}
