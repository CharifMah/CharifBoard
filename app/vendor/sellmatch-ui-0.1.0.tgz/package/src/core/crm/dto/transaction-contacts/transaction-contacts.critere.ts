// gen-hash:00427a13bfd87907f3143feecdc071d71455f7814d6d969f2c360089018f4be5
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { TransactionsCritereDTO } from '../transactions/transactions.critere';

export interface TransactionContactsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de transactionId */
  transactionId?: number;
  /** Filtre par liste de valeurs pour transactionId (IN) */
  transactionIds?: number[];
  /** Filtre transactionId différent de toutes ces valeurs (NOT IN) */
  transactionIdIsDifferentList?: number[];

  /** Filtre transactionId supérieur ou égal à cette valeur */
  transactionIdMin?: number;

  /** Filtre transactionId inférieur ou égal à cette valeur */
  transactionIdMax?: number;

  /** Filtre transactionId strictement supérieur à cette valeur */
  transactionIdGreaterThan?: number;

  /** Filtre transactionId strictement inférieur à cette valeur */
  transactionIdLessThan?: number;

  /** Filtre transactionId différent de cette valeur */
  transactionIdIsDifferent?: number;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de role */
  role?: string;
  /** Filtre IsNull sur role (true = IS NULL, false = IS NOT NULL) */
  roleIsNull?: boolean;
  /** Filtre role différent de cette valeur (NOT EQUAL) */
  roleIsDifferent?: string;
  /** Filtre par liste de valeurs pour role (IN) */
  roles?: string[];
  /** Filtre role différent de toutes ces valeurs (NOT IN) */
  roleIsDifferentList?: string[];

  /** Filtre role contenant cette valeur (LIKE %value%) */
  roleLike?: string;

  /** Filtre role commençant par cette valeur (LIKE value%) */
  roleStartsWith?: string;

  /** Filtre role terminant par cette valeur (LIKE %value) */
  roleEndsWith?: string;

  /** Filtre role ne contenant pas cette valeur (NOT LIKE %value%) */
  roleIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où transaction est NULL).
   * false = INNER JOIN.
   * À configurer AVANT transaction.
   */
  includeTransactionEmpty?: boolean;

  /** Filtre imbriqué sur la navigation transaction. */
  transaction?: TransactionsCritereDTO;

}
