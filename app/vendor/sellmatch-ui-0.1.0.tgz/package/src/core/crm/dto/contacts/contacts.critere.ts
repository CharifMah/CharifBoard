// gen-hash:f96e6aa0ae862d17b4d163ae657a883ff166c9b822d7c7ba94518ddf808a33e8
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';
import { ContactTagsCritereDTO } from '../contact-tags/contact-tags.critere';
import { DashboardMasquageContactsCritereDTO } from '../dashboard-masquage-contacts/dashboard-masquage-contacts.critere';
import { LocationContactsCritereDTO } from '../location-contacts/location-contacts.critere';
import { LocationsCritereDTO } from '../locations/locations.critere';
import { PropertiesCritereDTO } from '../properties/properties.critere';
import { RecherchesCritereDTO } from '../recherches/recherches.critere';
import { RecrutementsCritereDTO } from '../recrutements/recrutements.critere';
import { RefOrigineContactCritereDTO } from '../ref-origine-contact/ref-origine-contact.critere';
import { RefTypeContactCritereDTO } from '../ref-type-contact/ref-type-contact.critere';
import { TachesCritereDTO } from '../taches/taches.critere';
import { TransactionContactsCritereDTO } from '../transaction-contacts/transaction-contacts.critere';
import { TransactionsCritereDTO } from '../transactions/transactions.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface ContactsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de prenom */
  prenom?: string;
  /** Filtre IsNull sur prenom (true = IS NULL, false = IS NOT NULL) */
  prenomIsNull?: boolean;
  /** Filtre prenom différent de cette valeur (NOT EQUAL) */
  prenomIsDifferent?: string;
  /** Filtre par liste de valeurs pour prenom (IN) */
  prenoms?: string[];
  /** Filtre prenom différent de toutes ces valeurs (NOT IN) */
  prenomIsDifferentList?: string[];

  /** Filtre prenom contenant cette valeur (LIKE %value%) */
  prenomLike?: string;

  /** Filtre prenom commençant par cette valeur (LIKE value%) */
  prenomStartsWith?: string;

  /** Filtre prenom terminant par cette valeur (LIKE %value) */
  prenomEndsWith?: string;

  /** Filtre prenom ne contenant pas cette valeur (NOT LIKE %value%) */
  prenomIsDifferentLike?: string;

  /** Filtre par valeur exacte de nom */
  nom?: string;
  /** Filtre IsNull sur nom (true = IS NULL, false = IS NOT NULL) */
  nomIsNull?: boolean;
  /** Filtre nom différent de cette valeur (NOT EQUAL) */
  nomIsDifferent?: string;
  /** Filtre par liste de valeurs pour nom (IN) */
  noms?: string[];
  /** Filtre nom différent de toutes ces valeurs (NOT IN) */
  nomIsDifferentList?: string[];

  /** Filtre nom contenant cette valeur (LIKE %value%) */
  nomLike?: string;

  /** Filtre nom commençant par cette valeur (LIKE value%) */
  nomStartsWith?: string;

  /** Filtre nom terminant par cette valeur (LIKE %value) */
  nomEndsWith?: string;

  /** Filtre nom ne contenant pas cette valeur (NOT LIKE %value%) */
  nomIsDifferentLike?: string;

  /** Filtre par valeur exacte de dateNaissance */
  dateNaissance?: Date | string;
  /** Filtre IsNull sur dateNaissance (true = IS NULL, false = IS NOT NULL) */
  dateNaissanceIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateNaissance (IN) */
  dateNaissances?: Date | string[];
  /** Filtre dateNaissance différent de toutes ces valeurs (NOT IN) */
  dateNaissanceIsDifferentList?: Date | string[];

  /** Filtre dateNaissance à partir de cette date (incluse) */
  dateNaissanceFrom?: Date | string;

  /** Filtre dateNaissance jusqu'à cette date (incluse) */
  dateNaissanceTo?: Date | string;

  /** Filtre dateNaissance strictement après cette date */
  dateNaissanceAfter?: Date | string;

  /** Filtre dateNaissance strictement avant cette date */
  dateNaissanceBefore?: Date | string;

  /** Filtre dateNaissance différent de cette date */
  dateNaissanceIsDifferent?: Date | string;

  /** Filtre par valeur exacte de telephone */
  telephone?: string;
  /** Filtre IsNull sur telephone (true = IS NULL, false = IS NOT NULL) */
  telephoneIsNull?: boolean;
  /** Filtre telephone différent de cette valeur (NOT EQUAL) */
  telephoneIsDifferent?: string;
  /** Filtre par liste de valeurs pour telephone (IN) */
  telephones?: string[];
  /** Filtre telephone différent de toutes ces valeurs (NOT IN) */
  telephoneIsDifferentList?: string[];

  /** Filtre telephone contenant cette valeur (LIKE %value%) */
  telephoneLike?: string;

  /** Filtre telephone commençant par cette valeur (LIKE value%) */
  telephoneStartsWith?: string;

  /** Filtre telephone terminant par cette valeur (LIKE %value) */
  telephoneEndsWith?: string;

  /** Filtre telephone ne contenant pas cette valeur (NOT LIKE %value%) */
  telephoneIsDifferentLike?: string;

  /** Filtre par valeur exacte de email */
  email?: string;
  /** Filtre IsNull sur email (true = IS NULL, false = IS NOT NULL) */
  emailIsNull?: boolean;
  /** Filtre email différent de cette valeur (NOT EQUAL) */
  emailIsDifferent?: string;
  /** Filtre par liste de valeurs pour email (IN) */
  emails?: string[];
  /** Filtre email différent de toutes ces valeurs (NOT IN) */
  emailIsDifferentList?: string[];

  /** Filtre email contenant cette valeur (LIKE %value%) */
  emailLike?: string;

  /** Filtre email commençant par cette valeur (LIKE value%) */
  emailStartsWith?: string;

  /** Filtre email terminant par cette valeur (LIKE %value) */
  emailEndsWith?: string;

  /** Filtre email ne contenant pas cette valeur (NOT LIKE %value%) */
  emailIsDifferentLike?: string;

  /** Filtre par valeur exacte de adresseId */
  adresseId?: number;
  /** Filtre IsNull sur adresseId (true = IS NULL, false = IS NOT NULL) */
  adresseIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour adresseId (IN) */
  adresseIds?: number[];
  /** Filtre adresseId différent de toutes ces valeurs (NOT IN) */
  adresseIdIsDifferentList?: number[];

  /** Filtre adresseId supérieur ou égal à cette valeur */
  adresseIdMin?: number;

  /** Filtre adresseId inférieur ou égal à cette valeur */
  adresseIdMax?: number;

  /** Filtre adresseId strictement supérieur à cette valeur */
  adresseIdGreaterThan?: number;

  /** Filtre adresseId strictement inférieur à cette valeur */
  adresseIdLessThan?: number;

  /** Filtre adresseId différent de cette valeur */
  adresseIdIsDifferent?: number;

  /** Filtre par valeur exacte de typeContactId */
  typeContactId?: number;
  /** Filtre IsNull sur typeContactId (true = IS NULL, false = IS NOT NULL) */
  typeContactIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeContactId (IN) */
  typeContactIds?: number[];
  /** Filtre typeContactId différent de toutes ces valeurs (NOT IN) */
  typeContactIdIsDifferentList?: number[];

  /** Filtre typeContactId supérieur ou égal à cette valeur */
  typeContactIdMin?: number;

  /** Filtre typeContactId inférieur ou égal à cette valeur */
  typeContactIdMax?: number;

  /** Filtre typeContactId strictement supérieur à cette valeur */
  typeContactIdGreaterThan?: number;

  /** Filtre typeContactId strictement inférieur à cette valeur */
  typeContactIdLessThan?: number;

  /** Filtre typeContactId différent de cette valeur */
  typeContactIdIsDifferent?: number;

  /** Filtre par valeur exacte de origineId */
  origineId?: number;
  /** Filtre IsNull sur origineId (true = IS NULL, false = IS NOT NULL) */
  origineIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour origineId (IN) */
  origineIds?: number[];
  /** Filtre origineId différent de toutes ces valeurs (NOT IN) */
  origineIdIsDifferentList?: number[];

  /** Filtre origineId supérieur ou égal à cette valeur */
  origineIdMin?: number;

  /** Filtre origineId inférieur ou égal à cette valeur */
  origineIdMax?: number;

  /** Filtre origineId strictement supérieur à cette valeur */
  origineIdGreaterThan?: number;

  /** Filtre origineId strictement inférieur à cette valeur */
  origineIdLessThan?: number;

  /** Filtre origineId différent de cette valeur */
  origineIdIsDifferent?: number;

  /** Filtre par valeur exacte de notes */
  notes?: string;
  /** Filtre IsNull sur notes (true = IS NULL, false = IS NOT NULL) */
  notesIsNull?: boolean;
  /** Filtre notes différent de cette valeur (NOT EQUAL) */
  notesIsDifferent?: string;
  /** Filtre par liste de valeurs pour notes (IN) */
  notess?: string[];
  /** Filtre notes différent de toutes ces valeurs (NOT IN) */
  notesIsDifferentList?: string[];

  /** Filtre notes contenant cette valeur (LIKE %value%) */
  notesLike?: string;

  /** Filtre notes commençant par cette valeur (LIKE value%) */
  notesStartsWith?: string;

  /** Filtre notes terminant par cette valeur (LIKE %value) */
  notesEndsWith?: string;

  /** Filtre notes ne contenant pas cette valeur (NOT LIKE %value%) */
  notesIsDifferentLike?: string;

  /** Filtre par valeur exacte de dateDerniereAction */
  dateDerniereAction?: Date | string;
  /** Filtre IsNull sur dateDerniereAction (true = IS NULL, false = IS NOT NULL) */
  dateDerniereActionIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateDerniereAction (IN) */
  dateDerniereActions?: Date | string[];
  /** Filtre dateDerniereAction différent de toutes ces valeurs (NOT IN) */
  dateDerniereActionIsDifferentList?: Date | string[];

  /** Filtre dateDerniereAction à partir de cette date (incluse) */
  dateDerniereActionFrom?: Date | string;

  /** Filtre dateDerniereAction jusqu'à cette date (incluse) */
  dateDerniereActionTo?: Date | string;

  /** Filtre dateDerniereAction strictement après cette date */
  dateDerniereActionAfter?: Date | string;

  /** Filtre dateDerniereAction strictement avant cette date */
  dateDerniereActionBefore?: Date | string;

  /** Filtre dateDerniereAction différent de cette date */
  dateDerniereActionIsDifferent?: Date | string;

  /** Filtre par valeur exacte de consentement */
  consentement?: boolean;
  /** Filtre IsNull sur consentement (true = IS NULL, false = IS NOT NULL) */
  consentementIsNull?: boolean;
  /** Filtre consentement différent de cette valeur (NOT EQUAL) */
  consentementIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour consentement (IN) */
  consentements?: boolean[];
  /** Filtre consentement différent de toutes ces valeurs (NOT IN) */
  consentementIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de preferenceContact */
  preferenceContact?: string;
  /** Filtre IsNull sur preferenceContact (true = IS NULL, false = IS NOT NULL) */
  preferenceContactIsNull?: boolean;
  /** Filtre preferenceContact différent de cette valeur (NOT EQUAL) */
  preferenceContactIsDifferent?: string;
  /** Filtre par liste de valeurs pour preferenceContact (IN) */
  preferenceContacts?: string[];
  /** Filtre preferenceContact différent de toutes ces valeurs (NOT IN) */
  preferenceContactIsDifferentList?: string[];

  /** Filtre preferenceContact contenant cette valeur (LIKE %value%) */
  preferenceContactLike?: string;

  /** Filtre preferenceContact commençant par cette valeur (LIKE value%) */
  preferenceContactStartsWith?: string;

  /** Filtre preferenceContact terminant par cette valeur (LIKE %value) */
  preferenceContactEndsWith?: string;

  /** Filtre preferenceContact ne contenant pas cette valeur (NOT LIKE %value%) */
  preferenceContactIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où adresse est NULL).
   * false = INNER JOIN.
   * À configurer AVANT adresse.
   */
  includeAdresseEmpty?: boolean;

  /** Filtre imbriqué sur la navigation adresse. */
  adresse?: AdressesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où origine est NULL).
   * false = INNER JOIN.
   * À configurer AVANT origine.
   */
  includeOrigineEmpty?: boolean;

  /** Filtre imbriqué sur la navigation origine. */
  origine?: RefOrigineContactCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où typeContact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeContact.
   */
  includeTypecontactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeContact. */
  typeContact?: RefTypeContactCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur contactTags.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT contactTags.
   */
  contactTagsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont contactTags est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT contactTags.
   */
  includeContacttagsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour contactTags.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT contactTags.
   */
  contactTagsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection contactTags. */
  contactTags?: ContactTagsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur dashboardMasquageContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT dashboardMasquageContacts.
   */
  dashboardMasquageContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont dashboardMasquageContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT dashboardMasquageContacts.
   */
  includeDashboardmasquagecontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour dashboardMasquageContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT dashboardMasquageContacts.
   */
  dashboardMasquageContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection dashboardMasquageContacts. */
  dashboardMasquageContacts?: DashboardMasquageContactsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur locationContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT locationContacts.
   */
  locationContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont locationContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT locationContacts.
   */
  includeLocationcontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour locationContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT locationContacts.
   */
  locationContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection locationContacts. */
  locationContacts?: LocationContactsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur locations.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT locations.
   */
  locationsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont locations est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT locations.
   */
  includeLocationsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour locations.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT locations.
   */
  locationsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection locations. */
  locations?: LocationsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur properties.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT properties.
   */
  propertiesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont properties est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT properties.
   */
  includePropertiesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour properties.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT properties.
   */
  propertiesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection properties. */
  properties?: PropertiesCritereDTO;

  /**
   * Mode de filtrage de l'Include sur recherches.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT recherches.
   */
  recherchesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont recherches est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT recherches.
   */
  includeRecherchesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour recherches.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT recherches.
   */
  recherchesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection recherches. */
  recherches?: RecherchesCritereDTO;

  /**
   * Mode de filtrage de l'Include sur recrutements.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT recrutements.
   */
  recrutementsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont recrutements est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT recrutements.
   */
  includeRecrutementsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour recrutements.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT recrutements.
   */
  recrutementsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection recrutements. */
  recrutements?: RecrutementsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur taches.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT taches.
   */
  tachesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont taches est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT taches.
   */
  includeTachesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour taches.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT taches.
   */
  tachesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection taches. */
  taches?: TachesCritereDTO;

  /**
   * Mode de filtrage de l'Include sur transactionContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT transactionContacts.
   */
  transactionContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont transactionContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT transactionContacts.
   */
  includeTransactioncontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour transactionContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT transactionContacts.
   */
  transactionContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection transactionContacts. */
  transactionContacts?: TransactionContactsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur transactions.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT transactions.
   */
  transactionsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont transactions est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT transactions.
   */
  includeTransactionsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour transactions.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT transactions.
   */
  transactionsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection transactions. */
  transactions?: TransactionsCritereDTO;

}
