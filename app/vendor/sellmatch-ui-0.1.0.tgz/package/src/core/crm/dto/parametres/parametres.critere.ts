// gen-hash:2d39e3a8eaf3a2b730c287d408002b495dac73ca22fb6245b229eb5d4057b7d7
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { RefTypeTvaCritereDTO } from '../ref-type-tva/ref-type-tva.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface ParametresCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de objectifAnnuelCa */
  objectifAnnuelCa?: number;
  /** Filtre IsNull sur objectifAnnuelCa (true = IS NULL, false = IS NOT NULL) */
  objectifAnnuelCaIsNull?: boolean;
  /** Filtre par liste de valeurs pour objectifAnnuelCa (IN) */
  objectifAnnuelCas?: number[];
  /** Filtre objectifAnnuelCa différent de toutes ces valeurs (NOT IN) */
  objectifAnnuelCaIsDifferentList?: number[];

  /** Filtre objectifAnnuelCa supérieur ou égal à cette valeur */
  objectifAnnuelCaMin?: number;

  /** Filtre objectifAnnuelCa inférieur ou égal à cette valeur */
  objectifAnnuelCaMax?: number;

  /** Filtre objectifAnnuelCa strictement supérieur à cette valeur */
  objectifAnnuelCaGreaterThan?: number;

  /** Filtre objectifAnnuelCa strictement inférieur à cette valeur */
  objectifAnnuelCaLessThan?: number;

  /** Filtre objectifAnnuelCa différent de cette valeur */
  objectifAnnuelCaIsDifferent?: number;

  /** Filtre par valeur exacte de partReseauPct */
  partReseauPct?: number;
  /** Filtre IsNull sur partReseauPct (true = IS NULL, false = IS NOT NULL) */
  partReseauPctIsNull?: boolean;
  /** Filtre par liste de valeurs pour partReseauPct (IN) */
  partReseauPcts?: number[];
  /** Filtre partReseauPct différent de toutes ces valeurs (NOT IN) */
  partReseauPctIsDifferentList?: number[];

  /** Filtre partReseauPct supérieur ou égal à cette valeur */
  partReseauPctMin?: number;

  /** Filtre partReseauPct inférieur ou égal à cette valeur */
  partReseauPctMax?: number;

  /** Filtre partReseauPct strictement supérieur à cette valeur */
  partReseauPctGreaterThan?: number;

  /** Filtre partReseauPct strictement inférieur à cette valeur */
  partReseauPctLessThan?: number;

  /** Filtre partReseauPct différent de cette valeur */
  partReseauPctIsDifferent?: number;

  /** Filtre par valeur exacte de typeTvaId */
  typeTvaId?: number;
  /** Filtre IsNull sur typeTvaId (true = IS NULL, false = IS NOT NULL) */
  typeTvaIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeTvaId (IN) */
  typeTvaIds?: number[];
  /** Filtre typeTvaId différent de toutes ces valeurs (NOT IN) */
  typeTvaIdIsDifferentList?: number[];

  /** Filtre typeTvaId supérieur ou égal à cette valeur */
  typeTvaIdMin?: number;

  /** Filtre typeTvaId inférieur ou égal à cette valeur */
  typeTvaIdMax?: number;

  /** Filtre typeTvaId strictement supérieur à cette valeur */
  typeTvaIdGreaterThan?: number;

  /** Filtre typeTvaId strictement inférieur à cette valeur */
  typeTvaIdLessThan?: number;

  /** Filtre typeTvaId différent de cette valeur */
  typeTvaIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où typeTva est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeTva.
   */
  includeTypetvaEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeTva. */
  typeTva?: RefTypeTvaCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
