// gen-hash:d73d28d50fb5a6f5a90ea530964d0db98d2e4a1dd550612e6f2a9c494cf48d53
/**
 * DTO for table: objectifs
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RefPeriodeObjectifDTO } from '../ref-periode-objectif/ref-periode-objectif.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface ObjectifsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  objectif?: string;
  periodeId?: number;
  dateDebut?: Date | string;
  dateFin?: Date | string;
  cible?: string;
  resultat?: string;
  validee?: boolean;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefPeriodeObjectif */
  periode?: RefPeriodeObjectifDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
