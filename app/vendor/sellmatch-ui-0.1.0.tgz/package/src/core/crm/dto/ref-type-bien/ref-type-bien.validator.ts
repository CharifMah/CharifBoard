// gen-hash:0a3441cb0ece919ca3d6a6c0c9f188c7346df89523e0c0dc56be5227086c5c6c
/**
 * Validator TypeScript pour RefTypeBienDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeBienDTO } from './ref-type-bien.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeBienDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeBienFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeBienDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeBienDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeBienDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeBienValidator: Record<string, RefTypeBienFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeBienDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeBienDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeBienDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeBienFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeBienDTO) => string | null) | null {
  const lRule: RefTypeBienFieldRule | undefined = RefTypeBienValidator[pKey];
  return lRule ? lRule.Validate : null;
}
