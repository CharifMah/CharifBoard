// gen-hash:751bad9df0e36be09e39203d9f5bf60970c3926ce43d6e510ce87eb5a0972f52
/**
 * DTO for table: contacts
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import type { ContactTagsDTO } from '../contact-tags/contact-tags.dto';
import type { DashboardMasquageContactsDTO } from '../dashboard-masquage-contacts/dashboard-masquage-contacts.dto';
import type { LocationContactsDTO } from '../location-contacts/location-contacts.dto';
import type { LocationsDTO } from '../locations/locations.dto';
import type { PropertiesDTO } from '../properties/properties.dto';
import type { RecherchesDTO } from '../recherches/recherches.dto';
import type { RecrutementsDTO } from '../recrutements/recrutements.dto';
import type { RefOrigineContactDTO } from '../ref-origine-contact/ref-origine-contact.dto';
import type { RefTypeContactDTO } from '../ref-type-contact/ref-type-contact.dto';
import type { TachesDTO } from '../taches/taches.dto';
import type { TransactionContactsDTO } from '../transaction-contacts/transaction-contacts.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface ContactsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  prenom?: string;
  nom?: string;
  dateNaissance?: Date | string;
  telephone?: string;
  email?: string;
  adresseId?: number;
  typeContactId?: number;
  origineId?: number;
  notes?: string;
  dateDerniereAction?: Date | string;
  consentement?: boolean;
  preferenceContact?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  adresse?: AdressesDTO;
  /** Navigation property vers RefOrigineContact */
  origine?: RefOrigineContactDTO;
  /** Navigation property vers RefTypeContact */
  typeContact?: RefTypeContactDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de ContactTags */
  contactTags?: ContactTagsDTO[];
  /** Collection de DashboardMasquageContacts */
  dashboardMasquageContacts?: DashboardMasquageContactsDTO[];
  /** Collection de LocationContacts */
  locationContacts?: LocationContactsDTO[];
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de Properties */
  properties?: PropertiesDTO[];
  /** Collection de Recherches */
  recherches?: RecherchesDTO[];
  /** Collection de Recrutements */
  recrutements?: RecrutementsDTO[];
  /** Collection de Taches */
  taches?: TachesDTO[];
  /** Collection de TransactionContacts */
  transactionContacts?: TransactionContactsDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
