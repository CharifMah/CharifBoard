// gen-hash:e2347dd3307942e17a8013468395beaaaea3bec0128b83528664671011844332
/**
 * DTO for table: ref_etat_commercial
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { LocationsDTO } from '../locations/locations.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface RefEtatCommercialDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
