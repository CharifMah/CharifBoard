// gen-hash:1b6015a1981773ef3574660f53e011795f96a10267c8b672ef20ad2267afe8c1
/**
 * DTO for table: ai_import_jobs
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface AiImportJobsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  status?: string;
  provider?: string;
  apiKeyEncrypted?: string;
  model?: string;
  endpointUrl?: string;
  documentPath?: string;
  optionsJson?: string;
  resultJson?: string;
  error?: string;
  retryCount?: number;
  lockedBy?: string;
  lockedUntil?: Date | string;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  user?: UsersDTO;
}
