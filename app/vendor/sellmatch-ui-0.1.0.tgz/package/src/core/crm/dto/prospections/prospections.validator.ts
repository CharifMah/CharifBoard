// gen-hash:681eb70a6f9f0e00aebe1b86d843bbffedb0d2aa497b537721c47b7737bad198
/**
 * Validator TypeScript pour ProspectionsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { ProspectionsDTO } from './prospections.dto';

/**
 * Interface d'une règle de validation pour un champ de ProspectionsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface ProspectionsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof ProspectionsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: ProspectionsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour ProspectionsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const ProspectionsValidator: Record<string, ProspectionsFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: ProspectionsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de ProspectionsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetProspectionsFieldValidator(pKey: string): ((pValue: unknown, pRow: ProspectionsDTO) => string | null) | null {
  const lRule: ProspectionsFieldRule | undefined = ProspectionsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
