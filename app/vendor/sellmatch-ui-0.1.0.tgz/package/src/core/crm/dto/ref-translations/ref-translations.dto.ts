// gen-hash:d128ecf9c6e9bc6244d3e47c034c02bc5294587eb50da9eabd8e5c7deccdb509
/**
 * DTO for table: ref_translations
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
export interface RefTranslationsDTO extends BaseDTO {
  refTable?: string;
  refId?: number;
  lang?: string;
  libelle?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  /** Primary Key */
  id?: number;
}
