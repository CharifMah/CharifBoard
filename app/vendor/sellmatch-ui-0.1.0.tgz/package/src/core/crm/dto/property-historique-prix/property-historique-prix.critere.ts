// gen-hash:fe5a6c30c45292c9a053dd864cd62266654c4bed53c3a5541f0f2d2f9b51433d
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { PropertiesCritereDTO } from '../properties/properties.critere';

export interface PropertyHistoriquePrixCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de propertyId */
  propertyId?: number;
  /** Filtre par liste de valeurs pour propertyId (IN) */
  propertyIds?: number[];
  /** Filtre propertyId différent de toutes ces valeurs (NOT IN) */
  propertyIdIsDifferentList?: number[];

  /** Filtre propertyId supérieur ou égal à cette valeur */
  propertyIdMin?: number;

  /** Filtre propertyId inférieur ou égal à cette valeur */
  propertyIdMax?: number;

  /** Filtre propertyId strictement supérieur à cette valeur */
  propertyIdGreaterThan?: number;

  /** Filtre propertyId strictement inférieur à cette valeur */
  propertyIdLessThan?: number;

  /** Filtre propertyId différent de cette valeur */
  propertyIdIsDifferent?: number;

  /** Filtre par valeur exacte de ancienPrix */
  ancienPrix?: number;
  /** Filtre IsNull sur ancienPrix (true = IS NULL, false = IS NOT NULL) */
  ancienPrixIsNull?: boolean;
  /** Filtre par liste de valeurs pour ancienPrix (IN) */
  ancienPrixs?: number[];
  /** Filtre ancienPrix différent de toutes ces valeurs (NOT IN) */
  ancienPrixIsDifferentList?: number[];

  /** Filtre ancienPrix supérieur ou égal à cette valeur */
  ancienPrixMin?: number;

  /** Filtre ancienPrix inférieur ou égal à cette valeur */
  ancienPrixMax?: number;

  /** Filtre ancienPrix strictement supérieur à cette valeur */
  ancienPrixGreaterThan?: number;

  /** Filtre ancienPrix strictement inférieur à cette valeur */
  ancienPrixLessThan?: number;

  /** Filtre ancienPrix différent de cette valeur */
  ancienPrixIsDifferent?: number;

  /** Filtre par valeur exacte de nouveauPrix */
  nouveauPrix?: number;
  /** Filtre IsNull sur nouveauPrix (true = IS NULL, false = IS NOT NULL) */
  nouveauPrixIsNull?: boolean;
  /** Filtre par liste de valeurs pour nouveauPrix (IN) */
  nouveauPrixs?: number[];
  /** Filtre nouveauPrix différent de toutes ces valeurs (NOT IN) */
  nouveauPrixIsDifferentList?: number[];

  /** Filtre nouveauPrix supérieur ou égal à cette valeur */
  nouveauPrixMin?: number;

  /** Filtre nouveauPrix inférieur ou égal à cette valeur */
  nouveauPrixMax?: number;

  /** Filtre nouveauPrix strictement supérieur à cette valeur */
  nouveauPrixGreaterThan?: number;

  /** Filtre nouveauPrix strictement inférieur à cette valeur */
  nouveauPrixLessThan?: number;

  /** Filtre nouveauPrix différent de cette valeur */
  nouveauPrixIsDifferent?: number;

  /** Filtre par valeur exacte de dateChangement */
  dateChangement?: Date | string;
  /** Filtre IsNull sur dateChangement (true = IS NULL, false = IS NOT NULL) */
  dateChangementIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateChangement (IN) */
  dateChangements?: Date | string[];
  /** Filtre dateChangement différent de toutes ces valeurs (NOT IN) */
  dateChangementIsDifferentList?: Date | string[];

  /** Filtre dateChangement à partir de cette date (incluse) */
  dateChangementFrom?: Date | string;

  /** Filtre dateChangement jusqu'à cette date (incluse) */
  dateChangementTo?: Date | string;

  /** Filtre dateChangement strictement après cette date */
  dateChangementAfter?: Date | string;

  /** Filtre dateChangement strictement avant cette date */
  dateChangementBefore?: Date | string;

  /** Filtre dateChangement différent de cette date */
  dateChangementIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où property est NULL).
   * false = INNER JOIN.
   * À configurer AVANT property.
   */
  includePropertyEmpty?: boolean;

  /** Filtre imbriqué sur la navigation property. */
  property?: PropertiesCritereDTO;

}
