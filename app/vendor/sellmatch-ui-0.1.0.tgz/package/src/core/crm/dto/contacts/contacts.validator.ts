// gen-hash:cf4cbce22ebffd64f7a3740a9392334a1e4456acefeba802056f4e7fba862f40
/**
 * Validator TypeScript pour ContactsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { ContactsDTO } from './contacts.dto';

/**
 * Interface d'une règle de validation pour un champ de ContactsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface ContactsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof ContactsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: ContactsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour ContactsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const ContactsValidator: Record<string, ContactsFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - prenom : optionnel, longueur max 100
  prenom: {
    Key: 'prenom',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'prenom ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - nom : optionnel, longueur max 100
  nom: {
    Key: 'nom',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'nom ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - telephone : optionnel, longueur max 50
  telephone: {
    Key: 'telephone',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'telephone ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - email : optionnel, longueur max 255, format email
  email: {
    Key: 'email',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'email ne doit pas dépasser 255 caractères.';
      }
      if (typeof pValue === 'string' && pValue !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(pValue)) {
        return 'email doit être une adresse email valide.';
      }
      return null;
    }
  },

  // - cm - preferenceContact : optionnel, longueur max 50
  preferenceContact: {
    Key: 'preferenceContact',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: ContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'preferenceContact ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de ContactsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetContactsFieldValidator(pKey: string): ((pValue: unknown, pRow: ContactsDTO) => string | null) | null {
  const lRule: ContactsFieldRule | undefined = ContactsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
