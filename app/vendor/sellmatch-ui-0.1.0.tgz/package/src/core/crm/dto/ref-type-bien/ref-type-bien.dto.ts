// gen-hash:846c2e6caae042f67487c7517c84aa42c48392477e04c79b43fe93f48f24c620
/**
 * DTO for table: ref_type_bien
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { PropertiesDTO } from '../properties/properties.dto';
import type { RecherchesDTO } from '../recherches/recherches.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefTypeBienDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Properties */
  properties?: PropertiesDTO[];
  /** Collection de Recherches */
  recherches?: RecherchesDTO[];
}
