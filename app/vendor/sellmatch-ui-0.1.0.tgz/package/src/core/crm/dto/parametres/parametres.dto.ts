// gen-hash:179cb28a274f2ced9a3b351a0e17d1b79b7d6a6271a11c154fe3b7c69f5668b1
/**
 * DTO for table: parametres
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RefTypeTvaDTO } from '../ref-type-tva/ref-type-tva.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface ParametresDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  objectifAnnuelCa?: number;
  partReseauPct?: number;
  typeTvaId?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefTypeTva */
  typeTva?: RefTypeTvaDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
