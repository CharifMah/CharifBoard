// gen-hash:944573637bd908cb6687225c8d294de9f1c65bb80533939e8b20be7b0344504a
/**
 * Validator TypeScript pour RefEtatCommercialDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefEtatCommercialDTO } from './ref-etat-commercial.dto';

/**
 * Interface d'une règle de validation pour un champ de RefEtatCommercialDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefEtatCommercialFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefEtatCommercialDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefEtatCommercialDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefEtatCommercialDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefEtatCommercialValidator: Record<string, RefEtatCommercialFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefEtatCommercialDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefEtatCommercialDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefEtatCommercialDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefEtatCommercialFieldValidator(pKey: string): ((pValue: unknown, pRow: RefEtatCommercialDTO) => string | null) | null {
  const lRule: RefEtatCommercialFieldRule | undefined = RefEtatCommercialValidator[pKey];
  return lRule ? lRule.Validate : null;
}
