// gen-hash:8547554758da8b51462c8a710004473bf5c76cc8cd259c27a4ec6263e5caff8d
/**
 * DTO for table: ref_nature_affaire
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { LocationsDTO } from '../locations/locations.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface RefNatureAffaireDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
