// gen-hash:a596a8bcf4525a34d58236fc482cf5f28e3a8eac6af378b85956f2e6b1408bff
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { RefOrigineRecrutementCritereDTO } from '../ref-origine-recrutement/ref-origine-recrutement.critere';
import { RefStatutRecrutementCritereDTO } from '../ref-statut-recrutement/ref-statut-recrutement.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface RecrutementsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de classement */
  classement?: string;
  /** Filtre IsNull sur classement (true = IS NULL, false = IS NOT NULL) */
  classementIsNull?: boolean;
  /** Filtre classement différent de cette valeur (NOT EQUAL) */
  classementIsDifferent?: string;
  /** Filtre par liste de valeurs pour classement (IN) */
  classements?: string[];
  /** Filtre classement différent de toutes ces valeurs (NOT IN) */
  classementIsDifferentList?: string[];

  /** Filtre classement contenant cette valeur (LIKE %value%) */
  classementLike?: string;

  /** Filtre classement commençant par cette valeur (LIKE value%) */
  classementStartsWith?: string;

  /** Filtre classement terminant par cette valeur (LIKE %value) */
  classementEndsWith?: string;

  /** Filtre classement ne contenant pas cette valeur (NOT LIKE %value%) */
  classementIsDifferentLike?: string;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre IsNull sur contactId (true = IS NULL, false = IS NOT NULL) */
  contactIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de statutId */
  statutId?: number;
  /** Filtre IsNull sur statutId (true = IS NULL, false = IS NOT NULL) */
  statutIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour statutId (IN) */
  statutIds?: number[];
  /** Filtre statutId différent de toutes ces valeurs (NOT IN) */
  statutIdIsDifferentList?: number[];

  /** Filtre statutId supérieur ou égal à cette valeur */
  statutIdMin?: number;

  /** Filtre statutId inférieur ou égal à cette valeur */
  statutIdMax?: number;

  /** Filtre statutId strictement supérieur à cette valeur */
  statutIdGreaterThan?: number;

  /** Filtre statutId strictement inférieur à cette valeur */
  statutIdLessThan?: number;

  /** Filtre statutId différent de cette valeur */
  statutIdIsDifferent?: number;

  /** Filtre par valeur exacte de origineId */
  origineId?: number;
  /** Filtre IsNull sur origineId (true = IS NULL, false = IS NOT NULL) */
  origineIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour origineId (IN) */
  origineIds?: number[];
  /** Filtre origineId différent de toutes ces valeurs (NOT IN) */
  origineIdIsDifferentList?: number[];

  /** Filtre origineId supérieur ou égal à cette valeur */
  origineIdMin?: number;

  /** Filtre origineId inférieur ou égal à cette valeur */
  origineIdMax?: number;

  /** Filtre origineId strictement supérieur à cette valeur */
  origineIdGreaterThan?: number;

  /** Filtre origineId strictement inférieur à cette valeur */
  origineIdLessThan?: number;

  /** Filtre origineId différent de cette valeur */
  origineIdIsDifferent?: number;

  /** Filtre par valeur exacte de prochaineActionObjectif */
  prochaineActionObjectif?: string;
  /** Filtre IsNull sur prochaineActionObjectif (true = IS NULL, false = IS NOT NULL) */
  prochaineActionObjectifIsNull?: boolean;
  /** Filtre prochaineActionObjectif différent de cette valeur (NOT EQUAL) */
  prochaineActionObjectifIsDifferent?: string;
  /** Filtre par liste de valeurs pour prochaineActionObjectif (IN) */
  prochaineActionObjectifs?: string[];
  /** Filtre prochaineActionObjectif différent de toutes ces valeurs (NOT IN) */
  prochaineActionObjectifIsDifferentList?: string[];

  /** Filtre prochaineActionObjectif contenant cette valeur (LIKE %value%) */
  prochaineActionObjectifLike?: string;

  /** Filtre prochaineActionObjectif commençant par cette valeur (LIKE value%) */
  prochaineActionObjectifStartsWith?: string;

  /** Filtre prochaineActionObjectif terminant par cette valeur (LIKE %value) */
  prochaineActionObjectifEndsWith?: string;

  /** Filtre prochaineActionObjectif ne contenant pas cette valeur (NOT LIKE %value%) */
  prochaineActionObjectifIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où origine est NULL).
   * false = INNER JOIN.
   * À configurer AVANT origine.
   */
  includeOrigineEmpty?: boolean;

  /** Filtre imbriqué sur la navigation origine. */
  origine?: RefOrigineRecrutementCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où statut est NULL).
   * false = INNER JOIN.
   * À configurer AVANT statut.
   */
  includeStatutEmpty?: boolean;

  /** Filtre imbriqué sur la navigation statut. */
  statut?: RefStatutRecrutementCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
