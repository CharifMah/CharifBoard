// gen-hash:ef69af1c6f91a73c3f90a0a9c7a0ead12545bcab3606a26e2acf637a90fcbb77
/**
 * Validator TypeScript pour RefTranslationsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTranslationsDTO } from './ref-translations.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTranslationsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTranslationsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTranslationsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTranslationsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTranslationsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTranslationsValidator: Record<string, RefTranslationsFieldRule> = {
  // - cm - refTable : obligatoire, longueur max 50
  refTable: {
    Key: 'refTable',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTranslationsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'refTable est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'refTable ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - refId : obligatoire
  refId: {
    Key: 'refId',
    Validate: (pValue: unknown, _pRow: RefTranslationsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'refId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - lang : obligatoire, longueur max 5
  lang: {
    Key: 'lang',
    MaxLength: 5,
    Validate: (pValue: unknown, _pRow: RefTranslationsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'lang est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 5) {
        return 'lang ne doit pas dépasser 5 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 255
  libelle: {
    Key: 'libelle',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: RefTranslationsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'libelle ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTranslationsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTranslationsFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTranslationsDTO) => string | null) | null {
  const lRule: RefTranslationsFieldRule | undefined = RefTranslationsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
