// gen-hash:8870e471fcbeea44a825df6b709fe3d397bb2914436160814bc0ae89b1865ad9
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { RefPrioriteTacheCritereDTO } from '../ref-priorite-tache/ref-priorite-tache.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface TachesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de nom */
  nom?: string;
  /** Filtre IsNull sur nom (true = IS NULL, false = IS NOT NULL) */
  nomIsNull?: boolean;
  /** Filtre nom différent de cette valeur (NOT EQUAL) */
  nomIsDifferent?: string;
  /** Filtre par liste de valeurs pour nom (IN) */
  noms?: string[];
  /** Filtre nom différent de toutes ces valeurs (NOT IN) */
  nomIsDifferentList?: string[];

  /** Filtre nom contenant cette valeur (LIKE %value%) */
  nomLike?: string;

  /** Filtre nom commençant par cette valeur (LIKE value%) */
  nomStartsWith?: string;

  /** Filtre nom terminant par cette valeur (LIKE %value) */
  nomEndsWith?: string;

  /** Filtre nom ne contenant pas cette valeur (NOT LIKE %value%) */
  nomIsDifferentLike?: string;

  /** Filtre par valeur exacte de description */
  description?: string;
  /** Filtre IsNull sur description (true = IS NULL, false = IS NOT NULL) */
  descriptionIsNull?: boolean;
  /** Filtre description différent de cette valeur (NOT EQUAL) */
  descriptionIsDifferent?: string;
  /** Filtre par liste de valeurs pour description (IN) */
  descriptions?: string[];
  /** Filtre description différent de toutes ces valeurs (NOT IN) */
  descriptionIsDifferentList?: string[];

  /** Filtre description contenant cette valeur (LIKE %value%) */
  descriptionLike?: string;

  /** Filtre description commençant par cette valeur (LIKE value%) */
  descriptionStartsWith?: string;

  /** Filtre description terminant par cette valeur (LIKE %value) */
  descriptionEndsWith?: string;

  /** Filtre description ne contenant pas cette valeur (NOT LIKE %value%) */
  descriptionIsDifferentLike?: string;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre IsNull sur contactId (true = IS NULL, false = IS NOT NULL) */
  contactIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de dateEcheance */
  dateEcheance?: Date | string;
  /** Filtre IsNull sur dateEcheance (true = IS NULL, false = IS NOT NULL) */
  dateEcheanceIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateEcheance (IN) */
  dateEcheances?: Date | string[];
  /** Filtre dateEcheance différent de toutes ces valeurs (NOT IN) */
  dateEcheanceIsDifferentList?: Date | string[];

  /** Filtre dateEcheance à partir de cette date (incluse) */
  dateEcheanceFrom?: Date | string;

  /** Filtre dateEcheance jusqu'à cette date (incluse) */
  dateEcheanceTo?: Date | string;

  /** Filtre dateEcheance strictement après cette date */
  dateEcheanceAfter?: Date | string;

  /** Filtre dateEcheance strictement avant cette date */
  dateEcheanceBefore?: Date | string;

  /** Filtre dateEcheance différent de cette date */
  dateEcheanceIsDifferent?: Date | string;

  /** Filtre par valeur exacte de prioriteId */
  prioriteId?: number;
  /** Filtre IsNull sur prioriteId (true = IS NULL, false = IS NOT NULL) */
  prioriteIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour prioriteId (IN) */
  prioriteIds?: number[];
  /** Filtre prioriteId différent de toutes ces valeurs (NOT IN) */
  prioriteIdIsDifferentList?: number[];

  /** Filtre prioriteId supérieur ou égal à cette valeur */
  prioriteIdMin?: number;

  /** Filtre prioriteId inférieur ou égal à cette valeur */
  prioriteIdMax?: number;

  /** Filtre prioriteId strictement supérieur à cette valeur */
  prioriteIdGreaterThan?: number;

  /** Filtre prioriteId strictement inférieur à cette valeur */
  prioriteIdLessThan?: number;

  /** Filtre prioriteId différent de cette valeur */
  prioriteIdIsDifferent?: number;

  /** Filtre par valeur exacte de notes */
  notes?: string;
  /** Filtre IsNull sur notes (true = IS NULL, false = IS NOT NULL) */
  notesIsNull?: boolean;
  /** Filtre notes différent de cette valeur (NOT EQUAL) */
  notesIsDifferent?: string;
  /** Filtre par liste de valeurs pour notes (IN) */
  notess?: string[];
  /** Filtre notes différent de toutes ces valeurs (NOT IN) */
  notesIsDifferentList?: string[];

  /** Filtre notes contenant cette valeur (LIKE %value%) */
  notesLike?: string;

  /** Filtre notes commençant par cette valeur (LIKE value%) */
  notesStartsWith?: string;

  /** Filtre notes terminant par cette valeur (LIKE %value) */
  notesEndsWith?: string;

  /** Filtre notes ne contenant pas cette valeur (NOT LIKE %value%) */
  notesIsDifferentLike?: string;

  /** Filtre par valeur exacte de validee */
  validee?: boolean;
  /** Filtre IsNull sur validee (true = IS NULL, false = IS NOT NULL) */
  valideeIsNull?: boolean;
  /** Filtre validee différent de cette valeur (NOT EQUAL) */
  valideeIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour validee (IN) */
  validees?: boolean[];
  /** Filtre validee différent de toutes ces valeurs (NOT IN) */
  valideeIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de archivee */
  archivee?: boolean;
  /** Filtre IsNull sur archivee (true = IS NULL, false = IS NOT NULL) */
  archiveeIsNull?: boolean;
  /** Filtre archivee différent de cette valeur (NOT EQUAL) */
  archiveeIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour archivee (IN) */
  archivees?: boolean[];
  /** Filtre archivee différent de toutes ces valeurs (NOT IN) */
  archiveeIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où priorite est NULL).
   * false = INNER JOIN.
   * À configurer AVANT priorite.
   */
  includePrioriteEmpty?: boolean;

  /** Filtre imbriqué sur la navigation priorite. */
  priorite?: RefPrioriteTacheCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
