// gen-hash:6608277634af2a2babb9aa6a15d676215e57456276b8579f3b62e483d9fbde7e
/**
 * DTO for table: ref_motif_blocage
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { LocationsDTO } from '../locations/locations.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface RefMotifBlocageDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
