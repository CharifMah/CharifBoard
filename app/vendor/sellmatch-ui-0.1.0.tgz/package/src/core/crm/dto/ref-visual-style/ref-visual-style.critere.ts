// gen-hash:ca6f27ba87130b226c13d4f9c308b4d816fa08eac2cc6a2367393ff392fe0ef2
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { RefEtatCommercialCritereDTO } from '../ref-etat-commercial/ref-etat-commercial.critere';
import { RefMotifBlocageCritereDTO } from '../ref-motif-blocage/ref-motif-blocage.critere';
import { RefNatureAffaireCritereDTO } from '../ref-nature-affaire/ref-nature-affaire.critere';
import { RefOrigineContactCritereDTO } from '../ref-origine-contact/ref-origine-contact.critere';
import { RefOrigineRecrutementCritereDTO } from '../ref-origine-recrutement/ref-origine-recrutement.critere';
import { RefPeriodeObjectifCritereDTO } from '../ref-periode-objectif/ref-periode-objectif.critere';
import { RefPrioriteTacheCritereDTO } from '../ref-priorite-tache/ref-priorite-tache.critere';
import { RefStatutAffaireCritereDTO } from '../ref-statut-affaire/ref-statut-affaire.critere';
import { RefStatutRechercheCritereDTO } from '../ref-statut-recherche/ref-statut-recherche.critere';
import { RefStatutRecrutementCritereDTO } from '../ref-statut-recrutement/ref-statut-recrutement.critere';
import { RefTypeBienCritereDTO } from '../ref-type-bien/ref-type-bien.critere';
import { RefTypeContactCritereDTO } from '../ref-type-contact/ref-type-contact.critere';
import { RefTypeEchangeCritereDTO } from '../ref-type-echange/ref-type-echange.critere';
import { RefTypeProspectionCritereDTO } from '../ref-type-prospection/ref-type-prospection.critere';
import { RefTypeRechercheCritereDTO } from '../ref-type-recherche/ref-type-recherche.critere';

export interface RefVisualStyleCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de code */
  code?: string;
  /** Filtre IsNull sur code (true = IS NULL, false = IS NOT NULL) */
  codeIsNull?: boolean;
  /** Filtre code différent de cette valeur (NOT EQUAL) */
  codeIsDifferent?: string;
  /** Filtre par liste de valeurs pour code (IN) */
  codes?: string[];
  /** Filtre code différent de toutes ces valeurs (NOT IN) */
  codeIsDifferentList?: string[];

  /** Filtre code contenant cette valeur (LIKE %value%) */
  codeLike?: string;

  /** Filtre code commençant par cette valeur (LIKE value%) */
  codeStartsWith?: string;

  /** Filtre code terminant par cette valeur (LIKE %value) */
  codeEndsWith?: string;

  /** Filtre code ne contenant pas cette valeur (NOT LIKE %value%) */
  codeIsDifferentLike?: string;

  /** Filtre par valeur exacte de icon */
  icon?: string;
  /** Filtre IsNull sur icon (true = IS NULL, false = IS NOT NULL) */
  iconIsNull?: boolean;
  /** Filtre icon différent de cette valeur (NOT EQUAL) */
  iconIsDifferent?: string;
  /** Filtre par liste de valeurs pour icon (IN) */
  icons?: string[];
  /** Filtre icon différent de toutes ces valeurs (NOT IN) */
  iconIsDifferentList?: string[];

  /** Filtre icon contenant cette valeur (LIKE %value%) */
  iconLike?: string;

  /** Filtre icon commençant par cette valeur (LIKE value%) */
  iconStartsWith?: string;

  /** Filtre icon terminant par cette valeur (LIKE %value) */
  iconEndsWith?: string;

  /** Filtre icon ne contenant pas cette valeur (NOT LIKE %value%) */
  iconIsDifferentLike?: string;

  /** Filtre par valeur exacte de color */
  color?: string;
  /** Filtre IsNull sur color (true = IS NULL, false = IS NOT NULL) */
  colorIsNull?: boolean;
  /** Filtre color différent de cette valeur (NOT EQUAL) */
  colorIsDifferent?: string;
  /** Filtre par liste de valeurs pour color (IN) */
  colors?: string[];
  /** Filtre color différent de toutes ces valeurs (NOT IN) */
  colorIsDifferentList?: string[];

  /** Filtre color contenant cette valeur (LIKE %value%) */
  colorLike?: string;

  /** Filtre color commençant par cette valeur (LIKE value%) */
  colorStartsWith?: string;

  /** Filtre color terminant par cette valeur (LIKE %value) */
  colorEndsWith?: string;

  /** Filtre color ne contenant pas cette valeur (NOT LIKE %value%) */
  colorIsDifferentLike?: string;

  /** Filtre par valeur exacte de variant */
  variant?: string;
  /** Filtre IsNull sur variant (true = IS NULL, false = IS NOT NULL) */
  variantIsNull?: boolean;
  /** Filtre variant différent de cette valeur (NOT EQUAL) */
  variantIsDifferent?: string;
  /** Filtre par liste de valeurs pour variant (IN) */
  variants?: string[];
  /** Filtre variant différent de toutes ces valeurs (NOT IN) */
  variantIsDifferentList?: string[];

  /** Filtre variant contenant cette valeur (LIKE %value%) */
  variantLike?: string;

  /** Filtre variant commençant par cette valeur (LIKE value%) */
  variantStartsWith?: string;

  /** Filtre variant terminant par cette valeur (LIKE %value) */
  variantEndsWith?: string;

  /** Filtre variant ne contenant pas cette valeur (NOT LIKE %value%) */
  variantIsDifferentLike?: string;

  /** Filtre par valeur exacte de isActive */
  isActive?: boolean;
  /** Filtre isActive différent de cette valeur (NOT EQUAL) */
  isActiveIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour isActive (IN) */
  isActives?: boolean[];
  /** Filtre isActive différent de toutes ces valeurs (NOT IN) */
  isActiveIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de displayOrder */
  displayOrder?: number;
  /** Filtre par liste de valeurs pour displayOrder (IN) */
  displayOrders?: number[];
  /** Filtre displayOrder différent de toutes ces valeurs (NOT IN) */
  displayOrderIsDifferentList?: number[];

  /** Filtre displayOrder supérieur ou égal à cette valeur */
  displayOrderMin?: number;

  /** Filtre displayOrder inférieur ou égal à cette valeur */
  displayOrderMax?: number;

  /** Filtre displayOrder strictement supérieur à cette valeur */
  displayOrderGreaterThan?: number;

  /** Filtre displayOrder strictement inférieur à cette valeur */
  displayOrderLessThan?: number;

  /** Filtre displayOrder différent de cette valeur */
  displayOrderIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur refEtatCommercials.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refEtatCommercials.
   */
  refEtatCommercialsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refEtatCommercials est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refEtatCommercials.
   */
  includeRefetatcommercialsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refEtatCommercials.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refEtatCommercials.
   */
  refEtatCommercialsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refEtatCommercials. */
  refEtatCommercials?: RefEtatCommercialCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refMotifBlocages.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refMotifBlocages.
   */
  refMotifBlocagesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refMotifBlocages est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refMotifBlocages.
   */
  includeRefmotifblocagesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refMotifBlocages.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refMotifBlocages.
   */
  refMotifBlocagesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refMotifBlocages. */
  refMotifBlocages?: RefMotifBlocageCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refNatureAffaires.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refNatureAffaires.
   */
  refNatureAffairesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refNatureAffaires est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refNatureAffaires.
   */
  includeRefnatureaffairesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refNatureAffaires.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refNatureAffaires.
   */
  refNatureAffairesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refNatureAffaires. */
  refNatureAffaires?: RefNatureAffaireCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refOrigineContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refOrigineContacts.
   */
  refOrigineContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refOrigineContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refOrigineContacts.
   */
  includeReforiginecontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refOrigineContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refOrigineContacts.
   */
  refOrigineContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refOrigineContacts. */
  refOrigineContacts?: RefOrigineContactCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refOrigineRecrutements.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refOrigineRecrutements.
   */
  refOrigineRecrutementsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refOrigineRecrutements est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refOrigineRecrutements.
   */
  includeReforiginerecrutementsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refOrigineRecrutements.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refOrigineRecrutements.
   */
  refOrigineRecrutementsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refOrigineRecrutements. */
  refOrigineRecrutements?: RefOrigineRecrutementCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refPeriodeObjectifs.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refPeriodeObjectifs.
   */
  refPeriodeObjectifsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refPeriodeObjectifs est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refPeriodeObjectifs.
   */
  includeRefperiodeobjectifsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refPeriodeObjectifs.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refPeriodeObjectifs.
   */
  refPeriodeObjectifsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refPeriodeObjectifs. */
  refPeriodeObjectifs?: RefPeriodeObjectifCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refPrioriteTaches.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refPrioriteTaches.
   */
  refPrioriteTachesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refPrioriteTaches est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refPrioriteTaches.
   */
  includeRefprioritetachesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refPrioriteTaches.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refPrioriteTaches.
   */
  refPrioriteTachesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refPrioriteTaches. */
  refPrioriteTaches?: RefPrioriteTacheCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refStatutAffaires.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refStatutAffaires.
   */
  refStatutAffairesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refStatutAffaires est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refStatutAffaires.
   */
  includeRefstatutaffairesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refStatutAffaires.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refStatutAffaires.
   */
  refStatutAffairesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refStatutAffaires. */
  refStatutAffaires?: RefStatutAffaireCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refStatutRecherches.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refStatutRecherches.
   */
  refStatutRecherchesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refStatutRecherches est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refStatutRecherches.
   */
  includeRefstatutrecherchesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refStatutRecherches.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refStatutRecherches.
   */
  refStatutRecherchesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refStatutRecherches. */
  refStatutRecherches?: RefStatutRechercheCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refStatutRecrutements.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refStatutRecrutements.
   */
  refStatutRecrutementsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refStatutRecrutements est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refStatutRecrutements.
   */
  includeRefstatutrecrutementsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refStatutRecrutements.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refStatutRecrutements.
   */
  refStatutRecrutementsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refStatutRecrutements. */
  refStatutRecrutements?: RefStatutRecrutementCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refTypeBiens.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refTypeBiens.
   */
  refTypeBiensFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refTypeBiens est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refTypeBiens.
   */
  includeReftypebiensEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refTypeBiens.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refTypeBiens.
   */
  refTypeBiensMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refTypeBiens. */
  refTypeBiens?: RefTypeBienCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refTypeContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refTypeContacts.
   */
  refTypeContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refTypeContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refTypeContacts.
   */
  includeReftypecontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refTypeContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refTypeContacts.
   */
  refTypeContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refTypeContacts. */
  refTypeContacts?: RefTypeContactCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refTypeEchanges.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refTypeEchanges.
   */
  refTypeEchangesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refTypeEchanges est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refTypeEchanges.
   */
  includeReftypeechangesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refTypeEchanges.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refTypeEchanges.
   */
  refTypeEchangesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refTypeEchanges. */
  refTypeEchanges?: RefTypeEchangeCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refTypeProspections.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refTypeProspections.
   */
  refTypeProspectionsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refTypeProspections est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refTypeProspections.
   */
  includeReftypeprospectionsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refTypeProspections.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refTypeProspections.
   */
  refTypeProspectionsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refTypeProspections. */
  refTypeProspections?: RefTypeProspectionCritereDTO;

  /**
   * Mode de filtrage de l'Include sur refTypeRecherches.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT refTypeRecherches.
   */
  refTypeRecherchesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont refTypeRecherches est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT refTypeRecherches.
   */
  includeReftyperecherchesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour refTypeRecherches.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT refTypeRecherches.
   */
  refTypeRecherchesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection refTypeRecherches. */
  refTypeRecherches?: RefTypeRechercheCritereDTO;

}
