// gen-hash:c5ba090efe5d92b5136e569e58fd631430a69aa8667a51d3d3a4477a05657a09
/**
 * Validator TypeScript pour ContactTagsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { ContactTagsDTO } from './contact-tags.dto';

/**
 * Interface d'une règle de validation pour un champ de ContactTagsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface ContactTagsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof ContactTagsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: ContactTagsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour ContactTagsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const ContactTagsValidator: Record<string, ContactTagsFieldRule> = {
  // - cm - contactId : obligatoire
  contactId: {
    Key: 'contactId',
    Validate: (pValue: unknown, _pRow: ContactTagsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'contactId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - tag : obligatoire, longueur max 50
  tag: {
    Key: 'tag',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: ContactTagsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'tag est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'tag ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de ContactTagsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetContactTagsFieldValidator(pKey: string): ((pValue: unknown, pRow: ContactTagsDTO) => string | null) | null {
  const lRule: ContactTagsFieldRule | undefined = ContactTagsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
