// gen-hash:7bc60907bfee80d08aa9ca29cbba3340c764a509dfebf62cae29d6cd350027b9
/**
 * DTO for table: recrutements
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { RefOrigineRecrutementDTO } from '../ref-origine-recrutement/ref-origine-recrutement.dto';
import type { RefStatutRecrutementDTO } from '../ref-statut-recrutement/ref-statut-recrutement.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface RecrutementsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  classement?: string;
  contactId?: number;
  statutId?: number;
  origineId?: number;
  prochaineActionObjectif?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers RefOrigineRecrutement */
  origine?: RefOrigineRecrutementDTO;
  /** Navigation property vers RefStatutRecrutement */
  statut?: RefStatutRecrutementDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
