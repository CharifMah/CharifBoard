// gen-hash:468deb409cf450ec009681cc67416440df3d6ce519578f9872c993da420e0e36
/**
 * Validator TypeScript pour RecrutementsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RecrutementsDTO } from './recrutements.dto';

/**
 * Interface d'une règle de validation pour un champ de RecrutementsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RecrutementsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RecrutementsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RecrutementsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RecrutementsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RecrutementsValidator: Record<string, RecrutementsFieldRule> = {
  // - cm - classement : optionnel, longueur max 1
  classement: {
    Key: 'classement',
    MaxLength: 1,
    Validate: (pValue: unknown, _pRow: RecrutementsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 1) {
        return 'classement ne doit pas dépasser 1 caractères.';
      }
      return null;
    }
  },

  // - cm - createdAt : obligatoire
  createdAt: {
    Key: 'createdAt',
    Validate: (pValue: unknown, _pRow: RecrutementsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'createdAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - updatedAt : obligatoire
  updatedAt: {
    Key: 'updatedAt',
    Validate: (pValue: unknown, _pRow: RecrutementsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'updatedAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: RecrutementsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RecrutementsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRecrutementsFieldValidator(pKey: string): ((pValue: unknown, pRow: RecrutementsDTO) => string | null) | null {
  const lRule: RecrutementsFieldRule | undefined = RecrutementsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
