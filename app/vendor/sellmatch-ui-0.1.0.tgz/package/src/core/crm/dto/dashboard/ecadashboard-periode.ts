/**
 * Énumération côté front de `SellMatch.DTO.crm.DTO.Dashboard.ECADashboardPeriode`.
 * Permet de typer les appels de filtre du CA encaissé du dashboard.
 */
export const ECADashboardPeriode = {
  Annee: 'Annee' as const,
  Mois: 'Mois' as const,
  Personnalise: 'Personnalise' as const
};
export type ECADashboardPeriode = typeof ECADashboardPeriode[keyof typeof ECADashboardPeriode];
