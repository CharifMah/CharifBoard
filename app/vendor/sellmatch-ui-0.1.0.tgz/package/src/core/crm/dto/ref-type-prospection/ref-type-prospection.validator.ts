// gen-hash:5e8a7800bfdc23fffa4bb8ac44f1b737afda6652a1e93a759678fd233f9cd3ca
/**
 * Validator TypeScript pour RefTypeProspectionDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeProspectionDTO } from './ref-type-prospection.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeProspectionDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeProspectionFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeProspectionDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeProspectionDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeProspectionDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeProspectionValidator: Record<string, RefTypeProspectionFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeProspectionDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeProspectionDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeProspectionDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeProspectionFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeProspectionDTO) => string | null) | null {
  const lRule: RefTypeProspectionFieldRule | undefined = RefTypeProspectionValidator[pKey];
  return lRule ? lRule.Validate : null;
}
