// gen-hash:26595d2644106e5607074959c86524c4679a70bbb8d7106690b6192719eb0a7f
/**
 * Validator TypeScript pour TransactionContactsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { TransactionContactsDTO } from './transaction-contacts.dto';

/**
 * Interface d'une règle de validation pour un champ de TransactionContactsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface TransactionContactsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof TransactionContactsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: TransactionContactsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour TransactionContactsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const TransactionContactsValidator: Record<string, TransactionContactsFieldRule> = {
  // - cm - transactionId : obligatoire
  transactionId: {
    Key: 'transactionId',
    Validate: (pValue: unknown, _pRow: TransactionContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'transactionId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - contactId : obligatoire
  contactId: {
    Key: 'contactId',
    Validate: (pValue: unknown, _pRow: TransactionContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'contactId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - role : optionnel, longueur max 50
  role: {
    Key: 'role',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: TransactionContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'role ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de TransactionContactsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetTransactionContactsFieldValidator(pKey: string): ((pValue: unknown, pRow: TransactionContactsDTO) => string | null) | null {
  const lRule: TransactionContactsFieldRule | undefined = TransactionContactsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
