// gen-hash:4df61e7be5b723669f2fc279bf6d181e833a2836e6dcc992d8444d955e9fc899
/**
 * DTO for table: ref_statut_affaire
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { LocationsDTO } from '../locations/locations.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface RefStatutAffaireDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
