// gen-hash:0e730cf852206b8ab5551670081833feb32616f03f26a7705ce3ee417c7398a4
/**
 * Validator TypeScript pour PropertyHistoriquePrixDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { PropertyHistoriquePrixDTO } from './property-historique-prix.dto';

/**
 * Interface d'une règle de validation pour un champ de PropertyHistoriquePrixDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface PropertyHistoriquePrixFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof PropertyHistoriquePrixDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: PropertyHistoriquePrixDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour PropertyHistoriquePrixDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const PropertyHistoriquePrixValidator: Record<string, PropertyHistoriquePrixFieldRule> = {
  // - cm - propertyId : obligatoire
  propertyId: {
    Key: 'propertyId',
    Validate: (pValue: unknown, _pRow: PropertyHistoriquePrixDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'propertyId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de PropertyHistoriquePrixDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetPropertyHistoriquePrixFieldValidator(pKey: string): ((pValue: unknown, pRow: PropertyHistoriquePrixDTO) => string | null) | null {
  const lRule: PropertyHistoriquePrixFieldRule | undefined = PropertyHistoriquePrixValidator[pKey];
  return lRule ? lRule.Validate : null;
}
