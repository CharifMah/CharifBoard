// gen-hash:aac34bf09e9ddf425a5ef2dd3b65b21cb558ddc4d83a48f4285cc70172b2c39c
/**
 * DTO for table: dashboard_masquage_contacts
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface DashboardMasquageContactsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  contactId?: number;
  maskedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
