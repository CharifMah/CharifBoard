/**
 * DTO de transport pour le matching acquereur / locataire.
 * Mirror TypeScript du `SellMatch.DTO/crm/DTO/Matching/PropositionMatchDTO.cs`.
 * Aucun mapping BDD cote front : sert uniquement pour les endpoints de proposition.
 *
 * @see SellMatch.DTO/crm/DTO/Matching/PropositionMatchDTO.cs
 */

/**
 * Identifiant du contact candidat (acquereur ou locataire).
 */
export interface IPropositionMatchDTO {
  /** Identifiant du contact candidat. */
  ContactId: number;
  /** Nom du contact candidat. */
  ContactNom: string;
  /** Prenom du contact candidat. */
  ContactPrenom: string;
  /** Identifiant du projet de recherche a l'origine du candidat. */
  RechercheId: number;
  /** Nom du projet de recherche (ex : « Recherche Paris 11e T3 »). */
  NomProjet: string;
  /** Budget maximum declare par la recherche. */
  BudgetMax: number;
  /** Surface minimale declaree par la recherche (optionnelle). */
  SurfaceMin?: number | null;
  /** Nombre de chambres declare par la recherche (optionnel). */
  NbChambres?: number | null;
  /** Secteur geographique declare par la recherche. */
  SecteurRecherche: string;
  /** Rayon de recherche en km autour du secteur (optionnel). */
  RayonKm?: number | null;
  /** Score de matching (0 a 100, plus c'est eleve plus c'est pertinent). */
  Score: number;
  /** Code du type de recherche (ex : « achat_residence_principale »). */
  TypeCode: string;
}

/**
 * Implementation concrete du DTO Matching cote front.
 */
export class PropositionMatchDTO implements IPropositionMatchDTO {
  public ContactId: number = 0;
  public ContactNom: string = '';
  public ContactPrenom: string = '';
  public RechercheId: number = 0;
  public NomProjet: string = '';
  public BudgetMax: number = 0;
  public SurfaceMin: number | null = null;
  public NbChambres: number | null = null;
  public SecteurRecherche: string = '';
  public RayonKm: number | null = null;
  public Score: number = 0;
  public TypeCode: string = '';
}
