// gen-hash:f06698aef6be4bb043e479008c983254bf47ade903cd7bbd6b65c62ebb3e5f02
/**
 * DTO for table: location_contacts
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { LocationsDTO } from '../locations/locations.dto';

export interface LocationContactsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  locationId?: number;
  contactId?: number;
  role?: string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers Locations */
  location?: LocationsDTO;
}
