// gen-hash:cd84809a55dc7580cb390b0478c52c065e9e1f4251c1f6ad9a68d52fc7ca91ec
/**
 * Validator TypeScript pour LocationContactsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { LocationContactsDTO } from './location-contacts.dto';

/**
 * Interface d'une règle de validation pour un champ de LocationContactsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface LocationContactsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof LocationContactsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: LocationContactsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour LocationContactsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const LocationContactsValidator: Record<string, LocationContactsFieldRule> = {
  // - cm - locationId : obligatoire
  locationId: {
    Key: 'locationId',
    Validate: (pValue: unknown, _pRow: LocationContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'locationId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - contactId : obligatoire
  contactId: {
    Key: 'contactId',
    Validate: (pValue: unknown, _pRow: LocationContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'contactId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - role : optionnel, longueur max 50
  role: {
    Key: 'role',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: LocationContactsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'role ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de LocationContactsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetLocationContactsFieldValidator(pKey: string): ((pValue: unknown, pRow: LocationContactsDTO) => string | null) | null {
  const lRule: LocationContactsFieldRule | undefined = LocationContactsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
