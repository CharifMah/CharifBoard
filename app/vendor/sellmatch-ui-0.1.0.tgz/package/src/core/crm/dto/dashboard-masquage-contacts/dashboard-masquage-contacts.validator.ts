// gen-hash:b077417871dde7f71e29a6dd0851871cb0101f7b808ef0fc24e61da9b793d489
/**
 * Validator TypeScript pour DashboardMasquageContactsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { DashboardMasquageContactsDTO } from './dashboard-masquage-contacts.dto';

/**
 * Interface d'une règle de validation pour un champ de DashboardMasquageContactsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface DashboardMasquageContactsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof DashboardMasquageContactsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: DashboardMasquageContactsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour DashboardMasquageContactsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const DashboardMasquageContactsValidator: Record<string, DashboardMasquageContactsFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: DashboardMasquageContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - contactId : obligatoire
  contactId: {
    Key: 'contactId',
    Validate: (pValue: unknown, _pRow: DashboardMasquageContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'contactId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - maskedAt : obligatoire
  maskedAt: {
    Key: 'maskedAt',
    Validate: (pValue: unknown, _pRow: DashboardMasquageContactsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'maskedAt est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de DashboardMasquageContactsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetDashboardMasquageContactsFieldValidator(pKey: string): ((pValue: unknown, pRow: DashboardMasquageContactsDTO) => string | null) | null {
  const lRule: DashboardMasquageContactsFieldRule | undefined = DashboardMasquageContactsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
