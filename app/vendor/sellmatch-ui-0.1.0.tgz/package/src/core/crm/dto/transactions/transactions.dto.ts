// gen-hash:925071dc86cafca960ff6e8d2d4b615a1a7dd65167a2b36dc00f5eaed8c5fc16
/**
 * DTO for table: transactions
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { PropertiesDTO } from '../properties/properties.dto';
import type { RechercheBiensDTO } from '../recherche-biens/recherche-biens.dto';
import type { RefEtatCommercialDTO } from '../ref-etat-commercial/ref-etat-commercial.dto';
import type { RefMotifBlocageDTO } from '../ref-motif-blocage/ref-motif-blocage.dto';
import type { RefNatureAffaireDTO } from '../ref-nature-affaire/ref-nature-affaire.dto';
import type { RefStatutAffaireDTO } from '../ref-statut-affaire/ref-statut-affaire.dto';
import type { TransactionContactsDTO } from '../transaction-contacts/transaction-contacts.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface TransactionsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  reference?: string;
  propertyId?: number;
  adresseId?: number;
  natureAffaireId?: number;
  statutId?: number;
  etatCommercialId?: number;
  motifBlocageId?: number;
  clientId?: number;
  prixAffiche?: number;
  prixFinal?: number;
  honorairesPct?: number;
  commissionEstimee?: number;
  revenuVariable?: number;
  honorairesEncaisses?: number;
  revenuTotalEncaisse?: number;
  acquereurPotentiel?: string;
  dateEstimation?: Date | string;
  datePriseMandat?: Date | string;
  dateCommercialisation?: Date | string;
  dateSignatureAuthentique?: Date | string;
  notes?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  adresse?: AdressesDTO;
  /** Navigation property vers Contacts */
  client?: ContactsDTO;
  /** Navigation property vers RefEtatCommercial */
  etatCommercial?: RefEtatCommercialDTO;
  /** Navigation property vers RefMotifBlocage */
  motifBlocage?: RefMotifBlocageDTO;
  /** Navigation property vers RefNatureAffaire */
  natureAffaire?: RefNatureAffaireDTO;
  /** Navigation property vers Properties */
  property?: PropertiesDTO;
  /** Navigation property vers RefStatutAffaire */
  statut?: RefStatutAffaireDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de RechercheBiens */
  rechercheBiens?: RechercheBiensDTO[];
  /** Collection de TransactionContacts */
  transactionContacts?: TransactionContactsDTO[];
}
