// gen-hash:1c29a7ff80e2c552ff36ed6ba627c8957055b3bd013931518393aaff621dc3c0
/**
 * Validator TypeScript pour TachesDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { TachesDTO } from './taches.dto';

/**
 * Interface d'une règle de validation pour un champ de TachesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface TachesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof TachesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: TachesDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour TachesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const TachesValidator: Record<string, TachesFieldRule> = {
  // - cm - nom : optionnel, longueur max 255
  nom: {
    Key: 'nom',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: TachesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'nom ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: TachesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de TachesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetTachesFieldValidator(pKey: string): ((pValue: unknown, pRow: TachesDTO) => string | null) | null {
  const lRule: TachesFieldRule | undefined = TachesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
