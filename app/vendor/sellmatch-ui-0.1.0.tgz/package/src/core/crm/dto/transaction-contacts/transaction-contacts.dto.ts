// gen-hash:5055de55e4b8fb368c191292cc47deefa99bb5bf9fa7304d486d6d9af25dd942
/**
 * DTO for table: transaction_contacts
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface TransactionContactsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  transactionId?: number;
  contactId?: number;
  role?: string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers Transactions */
  transaction?: TransactionsDTO;
}
