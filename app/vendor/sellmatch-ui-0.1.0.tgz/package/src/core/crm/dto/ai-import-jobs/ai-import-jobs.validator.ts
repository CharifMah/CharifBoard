// gen-hash:c8b15a44883c3cf27e0888525a5950f865fcaa87271d21b931c5f2995698663b
/**
 * Validator TypeScript pour AiImportJobsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { AiImportJobsDTO } from './ai-import-jobs.dto';

/**
 * Interface d'une règle de validation pour un champ de AiImportJobsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface AiImportJobsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof AiImportJobsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: AiImportJobsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour AiImportJobsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const AiImportJobsValidator: Record<string, AiImportJobsFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - status : obligatoire, longueur max 20
  status: {
    Key: 'status',
    MaxLength: 20,
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'status est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 20) {
        return 'status ne doit pas dépasser 20 caractères.';
      }
      return null;
    }
  },

  // - cm - provider : obligatoire, longueur max 50
  provider: {
    Key: 'provider',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'provider est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'provider ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - model : obligatoire, longueur max 100
  model: {
    Key: 'model',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'model est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'model ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - documentPath : obligatoire
  documentPath: {
    Key: 'documentPath',
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'documentPath est obligatoire.';
      }
      return null;
    }
  },

  // - cm - retryCount : obligatoire
  retryCount: {
    Key: 'retryCount',
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'retryCount est obligatoire.';
      }
      return null;
    }
  },

  // - cm - lockedBy : optionnel, longueur max 100
  lockedBy: {
    Key: 'lockedBy',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'lockedBy ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - createdAt : obligatoire
  createdAt: {
    Key: 'createdAt',
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'createdAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - updatedAt : obligatoire
  updatedAt: {
    Key: 'updatedAt',
    Validate: (pValue: unknown, _pRow: AiImportJobsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'updatedAt est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de AiImportJobsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetAiImportJobsFieldValidator(pKey: string): ((pValue: unknown, pRow: AiImportJobsDTO) => string | null) | null {
  const lRule: AiImportJobsFieldRule | undefined = AiImportJobsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
