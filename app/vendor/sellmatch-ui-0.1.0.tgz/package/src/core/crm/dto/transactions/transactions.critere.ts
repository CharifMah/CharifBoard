// gen-hash:61d229c9bcf669313fd80c61d5916636419dec30b74f7ab9a5846cb2ee41dd13
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { PropertiesCritereDTO } from '../properties/properties.critere';
import { RechercheBiensCritereDTO } from '../recherche-biens/recherche-biens.critere';
import { RefEtatCommercialCritereDTO } from '../ref-etat-commercial/ref-etat-commercial.critere';
import { RefMotifBlocageCritereDTO } from '../ref-motif-blocage/ref-motif-blocage.critere';
import { RefNatureAffaireCritereDTO } from '../ref-nature-affaire/ref-nature-affaire.critere';
import { RefStatutAffaireCritereDTO } from '../ref-statut-affaire/ref-statut-affaire.critere';
import { TransactionContactsCritereDTO } from '../transaction-contacts/transaction-contacts.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface TransactionsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de reference */
  reference?: string;
  /** Filtre IsNull sur reference (true = IS NULL, false = IS NOT NULL) */
  referenceIsNull?: boolean;
  /** Filtre reference différent de cette valeur (NOT EQUAL) */
  referenceIsDifferent?: string;
  /** Filtre par liste de valeurs pour reference (IN) */
  references?: string[];
  /** Filtre reference différent de toutes ces valeurs (NOT IN) */
  referenceIsDifferentList?: string[];

  /** Filtre reference contenant cette valeur (LIKE %value%) */
  referenceLike?: string;

  /** Filtre reference commençant par cette valeur (LIKE value%) */
  referenceStartsWith?: string;

  /** Filtre reference terminant par cette valeur (LIKE %value) */
  referenceEndsWith?: string;

  /** Filtre reference ne contenant pas cette valeur (NOT LIKE %value%) */
  referenceIsDifferentLike?: string;

  /** Filtre par valeur exacte de propertyId */
  propertyId?: number;
  /** Filtre IsNull sur propertyId (true = IS NULL, false = IS NOT NULL) */
  propertyIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour propertyId (IN) */
  propertyIds?: number[];
  /** Filtre propertyId différent de toutes ces valeurs (NOT IN) */
  propertyIdIsDifferentList?: number[];

  /** Filtre propertyId supérieur ou égal à cette valeur */
  propertyIdMin?: number;

  /** Filtre propertyId inférieur ou égal à cette valeur */
  propertyIdMax?: number;

  /** Filtre propertyId strictement supérieur à cette valeur */
  propertyIdGreaterThan?: number;

  /** Filtre propertyId strictement inférieur à cette valeur */
  propertyIdLessThan?: number;

  /** Filtre propertyId différent de cette valeur */
  propertyIdIsDifferent?: number;

  /** Filtre par valeur exacte de adresseId */
  adresseId?: number;
  /** Filtre IsNull sur adresseId (true = IS NULL, false = IS NOT NULL) */
  adresseIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour adresseId (IN) */
  adresseIds?: number[];
  /** Filtre adresseId différent de toutes ces valeurs (NOT IN) */
  adresseIdIsDifferentList?: number[];

  /** Filtre adresseId supérieur ou égal à cette valeur */
  adresseIdMin?: number;

  /** Filtre adresseId inférieur ou égal à cette valeur */
  adresseIdMax?: number;

  /** Filtre adresseId strictement supérieur à cette valeur */
  adresseIdGreaterThan?: number;

  /** Filtre adresseId strictement inférieur à cette valeur */
  adresseIdLessThan?: number;

  /** Filtre adresseId différent de cette valeur */
  adresseIdIsDifferent?: number;

  /** Filtre par valeur exacte de natureAffaireId */
  natureAffaireId?: number;
  /** Filtre par liste de valeurs pour natureAffaireId (IN) */
  natureAffaireIds?: number[];
  /** Filtre natureAffaireId différent de toutes ces valeurs (NOT IN) */
  natureAffaireIdIsDifferentList?: number[];

  /** Filtre natureAffaireId supérieur ou égal à cette valeur */
  natureAffaireIdMin?: number;

  /** Filtre natureAffaireId inférieur ou égal à cette valeur */
  natureAffaireIdMax?: number;

  /** Filtre natureAffaireId strictement supérieur à cette valeur */
  natureAffaireIdGreaterThan?: number;

  /** Filtre natureAffaireId strictement inférieur à cette valeur */
  natureAffaireIdLessThan?: number;

  /** Filtre natureAffaireId différent de cette valeur */
  natureAffaireIdIsDifferent?: number;

  /** Filtre par valeur exacte de statutId */
  statutId?: number;
  /** Filtre IsNull sur statutId (true = IS NULL, false = IS NOT NULL) */
  statutIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour statutId (IN) */
  statutIds?: number[];
  /** Filtre statutId différent de toutes ces valeurs (NOT IN) */
  statutIdIsDifferentList?: number[];

  /** Filtre statutId supérieur ou égal à cette valeur */
  statutIdMin?: number;

  /** Filtre statutId inférieur ou égal à cette valeur */
  statutIdMax?: number;

  /** Filtre statutId strictement supérieur à cette valeur */
  statutIdGreaterThan?: number;

  /** Filtre statutId strictement inférieur à cette valeur */
  statutIdLessThan?: number;

  /** Filtre statutId différent de cette valeur */
  statutIdIsDifferent?: number;

  /** Filtre par valeur exacte de etatCommercialId */
  etatCommercialId?: number;
  /** Filtre IsNull sur etatCommercialId (true = IS NULL, false = IS NOT NULL) */
  etatCommercialIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour etatCommercialId (IN) */
  etatCommercialIds?: number[];
  /** Filtre etatCommercialId différent de toutes ces valeurs (NOT IN) */
  etatCommercialIdIsDifferentList?: number[];

  /** Filtre etatCommercialId supérieur ou égal à cette valeur */
  etatCommercialIdMin?: number;

  /** Filtre etatCommercialId inférieur ou égal à cette valeur */
  etatCommercialIdMax?: number;

  /** Filtre etatCommercialId strictement supérieur à cette valeur */
  etatCommercialIdGreaterThan?: number;

  /** Filtre etatCommercialId strictement inférieur à cette valeur */
  etatCommercialIdLessThan?: number;

  /** Filtre etatCommercialId différent de cette valeur */
  etatCommercialIdIsDifferent?: number;

  /** Filtre par valeur exacte de motifBlocageId */
  motifBlocageId?: number;
  /** Filtre IsNull sur motifBlocageId (true = IS NULL, false = IS NOT NULL) */
  motifBlocageIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour motifBlocageId (IN) */
  motifBlocageIds?: number[];
  /** Filtre motifBlocageId différent de toutes ces valeurs (NOT IN) */
  motifBlocageIdIsDifferentList?: number[];

  /** Filtre motifBlocageId supérieur ou égal à cette valeur */
  motifBlocageIdMin?: number;

  /** Filtre motifBlocageId inférieur ou égal à cette valeur */
  motifBlocageIdMax?: number;

  /** Filtre motifBlocageId strictement supérieur à cette valeur */
  motifBlocageIdGreaterThan?: number;

  /** Filtre motifBlocageId strictement inférieur à cette valeur */
  motifBlocageIdLessThan?: number;

  /** Filtre motifBlocageId différent de cette valeur */
  motifBlocageIdIsDifferent?: number;

  /** Filtre par valeur exacte de clientId */
  clientId?: number;
  /** Filtre IsNull sur clientId (true = IS NULL, false = IS NOT NULL) */
  clientIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour clientId (IN) */
  clientIds?: number[];
  /** Filtre clientId différent de toutes ces valeurs (NOT IN) */
  clientIdIsDifferentList?: number[];

  /** Filtre clientId supérieur ou égal à cette valeur */
  clientIdMin?: number;

  /** Filtre clientId inférieur ou égal à cette valeur */
  clientIdMax?: number;

  /** Filtre clientId strictement supérieur à cette valeur */
  clientIdGreaterThan?: number;

  /** Filtre clientId strictement inférieur à cette valeur */
  clientIdLessThan?: number;

  /** Filtre clientId différent de cette valeur */
  clientIdIsDifferent?: number;

  /** Filtre par valeur exacte de prixAffiche */
  prixAffiche?: number;
  /** Filtre IsNull sur prixAffiche (true = IS NULL, false = IS NOT NULL) */
  prixAfficheIsNull?: boolean;
  /** Filtre par liste de valeurs pour prixAffiche (IN) */
  prixAffiches?: number[];
  /** Filtre prixAffiche différent de toutes ces valeurs (NOT IN) */
  prixAfficheIsDifferentList?: number[];

  /** Filtre prixAffiche supérieur ou égal à cette valeur */
  prixAfficheMin?: number;

  /** Filtre prixAffiche inférieur ou égal à cette valeur */
  prixAfficheMax?: number;

  /** Filtre prixAffiche strictement supérieur à cette valeur */
  prixAfficheGreaterThan?: number;

  /** Filtre prixAffiche strictement inférieur à cette valeur */
  prixAfficheLessThan?: number;

  /** Filtre prixAffiche différent de cette valeur */
  prixAfficheIsDifferent?: number;

  /** Filtre par valeur exacte de prixFinal */
  prixFinal?: number;
  /** Filtre IsNull sur prixFinal (true = IS NULL, false = IS NOT NULL) */
  prixFinalIsNull?: boolean;
  /** Filtre par liste de valeurs pour prixFinal (IN) */
  prixFinals?: number[];
  /** Filtre prixFinal différent de toutes ces valeurs (NOT IN) */
  prixFinalIsDifferentList?: number[];

  /** Filtre prixFinal supérieur ou égal à cette valeur */
  prixFinalMin?: number;

  /** Filtre prixFinal inférieur ou égal à cette valeur */
  prixFinalMax?: number;

  /** Filtre prixFinal strictement supérieur à cette valeur */
  prixFinalGreaterThan?: number;

  /** Filtre prixFinal strictement inférieur à cette valeur */
  prixFinalLessThan?: number;

  /** Filtre prixFinal différent de cette valeur */
  prixFinalIsDifferent?: number;

  /** Filtre par valeur exacte de honorairesPct */
  honorairesPct?: number;
  /** Filtre IsNull sur honorairesPct (true = IS NULL, false = IS NOT NULL) */
  honorairesPctIsNull?: boolean;
  /** Filtre par liste de valeurs pour honorairesPct (IN) */
  honorairesPcts?: number[];
  /** Filtre honorairesPct différent de toutes ces valeurs (NOT IN) */
  honorairesPctIsDifferentList?: number[];

  /** Filtre honorairesPct supérieur ou égal à cette valeur */
  honorairesPctMin?: number;

  /** Filtre honorairesPct inférieur ou égal à cette valeur */
  honorairesPctMax?: number;

  /** Filtre honorairesPct strictement supérieur à cette valeur */
  honorairesPctGreaterThan?: number;

  /** Filtre honorairesPct strictement inférieur à cette valeur */
  honorairesPctLessThan?: number;

  /** Filtre honorairesPct différent de cette valeur */
  honorairesPctIsDifferent?: number;

  /** Filtre par valeur exacte de commissionEstimee */
  commissionEstimee?: number;
  /** Filtre IsNull sur commissionEstimee (true = IS NULL, false = IS NOT NULL) */
  commissionEstimeeIsNull?: boolean;
  /** Filtre par liste de valeurs pour commissionEstimee (IN) */
  commissionEstimees?: number[];
  /** Filtre commissionEstimee différent de toutes ces valeurs (NOT IN) */
  commissionEstimeeIsDifferentList?: number[];

  /** Filtre commissionEstimee supérieur ou égal à cette valeur */
  commissionEstimeeMin?: number;

  /** Filtre commissionEstimee inférieur ou égal à cette valeur */
  commissionEstimeeMax?: number;

  /** Filtre commissionEstimee strictement supérieur à cette valeur */
  commissionEstimeeGreaterThan?: number;

  /** Filtre commissionEstimee strictement inférieur à cette valeur */
  commissionEstimeeLessThan?: number;

  /** Filtre commissionEstimee différent de cette valeur */
  commissionEstimeeIsDifferent?: number;

  /** Filtre par valeur exacte de revenuVariable */
  revenuVariable?: number;
  /** Filtre IsNull sur revenuVariable (true = IS NULL, false = IS NOT NULL) */
  revenuVariableIsNull?: boolean;
  /** Filtre par liste de valeurs pour revenuVariable (IN) */
  revenuVariables?: number[];
  /** Filtre revenuVariable différent de toutes ces valeurs (NOT IN) */
  revenuVariableIsDifferentList?: number[];

  /** Filtre revenuVariable supérieur ou égal à cette valeur */
  revenuVariableMin?: number;

  /** Filtre revenuVariable inférieur ou égal à cette valeur */
  revenuVariableMax?: number;

  /** Filtre revenuVariable strictement supérieur à cette valeur */
  revenuVariableGreaterThan?: number;

  /** Filtre revenuVariable strictement inférieur à cette valeur */
  revenuVariableLessThan?: number;

  /** Filtre revenuVariable différent de cette valeur */
  revenuVariableIsDifferent?: number;

  /** Filtre par valeur exacte de honorairesEncaisses */
  honorairesEncaisses?: number;
  /** Filtre IsNull sur honorairesEncaisses (true = IS NULL, false = IS NOT NULL) */
  honorairesEncaissesIsNull?: boolean;
  /** Filtre par liste de valeurs pour honorairesEncaisses (IN) */
  honorairesEncaissess?: number[];
  /** Filtre honorairesEncaisses différent de toutes ces valeurs (NOT IN) */
  honorairesEncaissesIsDifferentList?: number[];

  /** Filtre honorairesEncaisses supérieur ou égal à cette valeur */
  honorairesEncaissesMin?: number;

  /** Filtre honorairesEncaisses inférieur ou égal à cette valeur */
  honorairesEncaissesMax?: number;

  /** Filtre honorairesEncaisses strictement supérieur à cette valeur */
  honorairesEncaissesGreaterThan?: number;

  /** Filtre honorairesEncaisses strictement inférieur à cette valeur */
  honorairesEncaissesLessThan?: number;

  /** Filtre honorairesEncaisses différent de cette valeur */
  honorairesEncaissesIsDifferent?: number;

  /** Filtre par valeur exacte de revenuTotalEncaisse */
  revenuTotalEncaisse?: number;
  /** Filtre IsNull sur revenuTotalEncaisse (true = IS NULL, false = IS NOT NULL) */
  revenuTotalEncaisseIsNull?: boolean;
  /** Filtre par liste de valeurs pour revenuTotalEncaisse (IN) */
  revenuTotalEncaisses?: number[];
  /** Filtre revenuTotalEncaisse différent de toutes ces valeurs (NOT IN) */
  revenuTotalEncaisseIsDifferentList?: number[];

  /** Filtre revenuTotalEncaisse supérieur ou égal à cette valeur */
  revenuTotalEncaisseMin?: number;

  /** Filtre revenuTotalEncaisse inférieur ou égal à cette valeur */
  revenuTotalEncaisseMax?: number;

  /** Filtre revenuTotalEncaisse strictement supérieur à cette valeur */
  revenuTotalEncaisseGreaterThan?: number;

  /** Filtre revenuTotalEncaisse strictement inférieur à cette valeur */
  revenuTotalEncaisseLessThan?: number;

  /** Filtre revenuTotalEncaisse différent de cette valeur */
  revenuTotalEncaisseIsDifferent?: number;

  /** Filtre par valeur exacte de acquereurPotentiel */
  acquereurPotentiel?: string;
  /** Filtre IsNull sur acquereurPotentiel (true = IS NULL, false = IS NOT NULL) */
  acquereurPotentielIsNull?: boolean;
  /** Filtre acquereurPotentiel différent de cette valeur (NOT EQUAL) */
  acquereurPotentielIsDifferent?: string;
  /** Filtre par liste de valeurs pour acquereurPotentiel (IN) */
  acquereurPotentiels?: string[];
  /** Filtre acquereurPotentiel différent de toutes ces valeurs (NOT IN) */
  acquereurPotentielIsDifferentList?: string[];

  /** Filtre acquereurPotentiel contenant cette valeur (LIKE %value%) */
  acquereurPotentielLike?: string;

  /** Filtre acquereurPotentiel commençant par cette valeur (LIKE value%) */
  acquereurPotentielStartsWith?: string;

  /** Filtre acquereurPotentiel terminant par cette valeur (LIKE %value) */
  acquereurPotentielEndsWith?: string;

  /** Filtre acquereurPotentiel ne contenant pas cette valeur (NOT LIKE %value%) */
  acquereurPotentielIsDifferentLike?: string;

  /** Filtre par valeur exacte de dateEstimation */
  dateEstimation?: Date | string;
  /** Filtre IsNull sur dateEstimation (true = IS NULL, false = IS NOT NULL) */
  dateEstimationIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateEstimation (IN) */
  dateEstimations?: Date | string[];
  /** Filtre dateEstimation différent de toutes ces valeurs (NOT IN) */
  dateEstimationIsDifferentList?: Date | string[];

  /** Filtre dateEstimation à partir de cette date (incluse) */
  dateEstimationFrom?: Date | string;

  /** Filtre dateEstimation jusqu'à cette date (incluse) */
  dateEstimationTo?: Date | string;

  /** Filtre dateEstimation strictement après cette date */
  dateEstimationAfter?: Date | string;

  /** Filtre dateEstimation strictement avant cette date */
  dateEstimationBefore?: Date | string;

  /** Filtre dateEstimation différent de cette date */
  dateEstimationIsDifferent?: Date | string;

  /** Filtre par valeur exacte de datePriseMandat */
  datePriseMandat?: Date | string;
  /** Filtre IsNull sur datePriseMandat (true = IS NULL, false = IS NOT NULL) */
  datePriseMandatIsNull?: boolean;
  /** Filtre par liste de valeurs pour datePriseMandat (IN) */
  datePriseMandats?: Date | string[];
  /** Filtre datePriseMandat différent de toutes ces valeurs (NOT IN) */
  datePriseMandatIsDifferentList?: Date | string[];

  /** Filtre datePriseMandat à partir de cette date (incluse) */
  datePriseMandatFrom?: Date | string;

  /** Filtre datePriseMandat jusqu'à cette date (incluse) */
  datePriseMandatTo?: Date | string;

  /** Filtre datePriseMandat strictement après cette date */
  datePriseMandatAfter?: Date | string;

  /** Filtre datePriseMandat strictement avant cette date */
  datePriseMandatBefore?: Date | string;

  /** Filtre datePriseMandat différent de cette date */
  datePriseMandatIsDifferent?: Date | string;

  /** Filtre par valeur exacte de dateCommercialisation */
  dateCommercialisation?: Date | string;
  /** Filtre IsNull sur dateCommercialisation (true = IS NULL, false = IS NOT NULL) */
  dateCommercialisationIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateCommercialisation (IN) */
  dateCommercialisations?: Date | string[];
  /** Filtre dateCommercialisation différent de toutes ces valeurs (NOT IN) */
  dateCommercialisationIsDifferentList?: Date | string[];

  /** Filtre dateCommercialisation à partir de cette date (incluse) */
  dateCommercialisationFrom?: Date | string;

  /** Filtre dateCommercialisation jusqu'à cette date (incluse) */
  dateCommercialisationTo?: Date | string;

  /** Filtre dateCommercialisation strictement après cette date */
  dateCommercialisationAfter?: Date | string;

  /** Filtre dateCommercialisation strictement avant cette date */
  dateCommercialisationBefore?: Date | string;

  /** Filtre dateCommercialisation différent de cette date */
  dateCommercialisationIsDifferent?: Date | string;

  /** Filtre par valeur exacte de dateSignatureAuthentique */
  dateSignatureAuthentique?: Date | string;
  /** Filtre IsNull sur dateSignatureAuthentique (true = IS NULL, false = IS NOT NULL) */
  dateSignatureAuthentiqueIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateSignatureAuthentique (IN) */
  dateSignatureAuthentiques?: Date | string[];
  /** Filtre dateSignatureAuthentique différent de toutes ces valeurs (NOT IN) */
  dateSignatureAuthentiqueIsDifferentList?: Date | string[];

  /** Filtre dateSignatureAuthentique à partir de cette date (incluse) */
  dateSignatureAuthentiqueFrom?: Date | string;

  /** Filtre dateSignatureAuthentique jusqu'à cette date (incluse) */
  dateSignatureAuthentiqueTo?: Date | string;

  /** Filtre dateSignatureAuthentique strictement après cette date */
  dateSignatureAuthentiqueAfter?: Date | string;

  /** Filtre dateSignatureAuthentique strictement avant cette date */
  dateSignatureAuthentiqueBefore?: Date | string;

  /** Filtre dateSignatureAuthentique différent de cette date */
  dateSignatureAuthentiqueIsDifferent?: Date | string;

  /** Filtre par valeur exacte de notes */
  notes?: string;
  /** Filtre IsNull sur notes (true = IS NULL, false = IS NOT NULL) */
  notesIsNull?: boolean;
  /** Filtre notes différent de cette valeur (NOT EQUAL) */
  notesIsDifferent?: string;
  /** Filtre par liste de valeurs pour notes (IN) */
  notess?: string[];
  /** Filtre notes différent de toutes ces valeurs (NOT IN) */
  notesIsDifferentList?: string[];

  /** Filtre notes contenant cette valeur (LIKE %value%) */
  notesLike?: string;

  /** Filtre notes commençant par cette valeur (LIKE value%) */
  notesStartsWith?: string;

  /** Filtre notes terminant par cette valeur (LIKE %value) */
  notesEndsWith?: string;

  /** Filtre notes ne contenant pas cette valeur (NOT LIKE %value%) */
  notesIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où adresse est NULL).
   * false = INNER JOIN.
   * À configurer AVANT adresse.
   */
  includeAdresseEmpty?: boolean;

  /** Filtre imbriqué sur la navigation adresse. */
  adresse?: AdressesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où client est NULL).
   * false = INNER JOIN.
   * À configurer AVANT client.
   */
  includeClientEmpty?: boolean;

  /** Filtre imbriqué sur la navigation client. */
  client?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où etatCommercial est NULL).
   * false = INNER JOIN.
   * À configurer AVANT etatCommercial.
   */
  includeEtatcommercialEmpty?: boolean;

  /** Filtre imbriqué sur la navigation etatCommercial. */
  etatCommercial?: RefEtatCommercialCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où motifBlocage est NULL).
   * false = INNER JOIN.
   * À configurer AVANT motifBlocage.
   */
  includeMotifblocageEmpty?: boolean;

  /** Filtre imbriqué sur la navigation motifBlocage. */
  motifBlocage?: RefMotifBlocageCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où natureAffaire est NULL).
   * false = INNER JOIN.
   * À configurer AVANT natureAffaire.
   */
  includeNatureaffaireEmpty?: boolean;

  /** Filtre imbriqué sur la navigation natureAffaire. */
  natureAffaire?: RefNatureAffaireCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où property est NULL).
   * false = INNER JOIN.
   * À configurer AVANT property.
   */
  includePropertyEmpty?: boolean;

  /** Filtre imbriqué sur la navigation property. */
  property?: PropertiesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où statut est NULL).
   * false = INNER JOIN.
   * À configurer AVANT statut.
   */
  includeStatutEmpty?: boolean;

  /** Filtre imbriqué sur la navigation statut. */
  statut?: RefStatutAffaireCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur rechercheBiens.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont rechercheBiens est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT rechercheBiens.
   */
  includeRecherchebiensEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour rechercheBiens.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection rechercheBiens. */
  rechercheBiens?: RechercheBiensCritereDTO;

  /**
   * Mode de filtrage de l'Include sur transactionContacts.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT transactionContacts.
   */
  transactionContactsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont transactionContacts est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT transactionContacts.
   */
  includeTransactioncontactsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour transactionContacts.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT transactionContacts.
   */
  transactionContactsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection transactionContacts. */
  transactionContacts?: TransactionContactsCritereDTO;

}
