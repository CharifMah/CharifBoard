// gen-hash:c7ed52156991c155635bb6fc8aa1d8dc9360541c0f3ee1d804e002936572815b
/**
 * DTO for table: recherches
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { RechercheBiensDTO } from '../recherche-biens/recherche-biens.dto';
import type { RefStatutRechercheDTO } from '../ref-statut-recherche/ref-statut-recherche.dto';
import type { RefTypeBienDTO } from '../ref-type-bien/ref-type-bien.dto';
import type { RefTypeRechercheDTO } from '../ref-type-recherche/ref-type-recherche.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface RecherchesDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  nomProjet?: string;
  contactId?: number;
  typeRechercheId?: number;
  typeBienId?: number;
  budgetMax?: number;
  secteurRecherche?: string;
  rayonKm?: number;
  surfaceMin?: number;
  nbChambres?: number;
  biensCorrespondants?: string;
  statutId?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers RefStatutRecherche */
  statut?: RefStatutRechercheDTO;
  /** Navigation property vers RefTypeBien */
  typeBien?: RefTypeBienDTO;
  /** Navigation property vers RefTypeRecherche */
  typeRecherche?: RefTypeRechercheDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de RechercheBiens */
  rechercheBiens?: RechercheBiensDTO[];
}
