// gen-hash:59898d0e368ba1a6b3385e63d36ec5975d154c6bab0accf5649e7b62b8ffa8be
/**
 * DTO for table: ref_periode_objectif
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ObjectifsDTO } from '../objectifs/objectifs.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefPeriodeObjectifDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Objectifs */
  objectifs?: ObjectifsDTO[];
}
