// gen-hash:a20a114a4d18dae1fe0694da0a20fea20e45068345e8f84e9b007b955889c517
/**
 * Validator TypeScript pour TransactionsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { TransactionsDTO } from './transactions.dto';

/**
 * Interface d'une règle de validation pour un champ de TransactionsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface TransactionsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof TransactionsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: TransactionsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour TransactionsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const TransactionsValidator: Record<string, TransactionsFieldRule> = {
  // - cm - reference : optionnel, longueur max 100
  reference: {
    Key: 'reference',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: TransactionsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'reference ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - natureAffaireId : obligatoire
  natureAffaireId: {
    Key: 'natureAffaireId',
    Validate: (pValue: unknown, _pRow: TransactionsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'natureAffaireId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: TransactionsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de TransactionsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetTransactionsFieldValidator(pKey: string): ((pValue: unknown, pRow: TransactionsDTO) => string | null) | null {
  const lRule: TransactionsFieldRule | undefined = TransactionsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
