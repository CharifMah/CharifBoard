// gen-hash:0180bb415970918a10fb417900ce5d0ba4d7424ee4cfcbb4b311c322ad3e31fe
/**
 * DTO for table: contact_tags
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';

export interface ContactTagsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  contactId?: number;
  tag?: string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
}
