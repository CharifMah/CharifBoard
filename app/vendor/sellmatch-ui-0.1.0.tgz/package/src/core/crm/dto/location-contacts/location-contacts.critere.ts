// gen-hash:e35c3a4efcaf2003ef2859c0ce32d63bc5be6a0e09148944656c1283cadd52c0
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { LocationsCritereDTO } from '../locations/locations.critere';

export interface LocationContactsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de locationId */
  locationId?: number;
  /** Filtre par liste de valeurs pour locationId (IN) */
  locationIds?: number[];
  /** Filtre locationId différent de toutes ces valeurs (NOT IN) */
  locationIdIsDifferentList?: number[];

  /** Filtre locationId supérieur ou égal à cette valeur */
  locationIdMin?: number;

  /** Filtre locationId inférieur ou égal à cette valeur */
  locationIdMax?: number;

  /** Filtre locationId strictement supérieur à cette valeur */
  locationIdGreaterThan?: number;

  /** Filtre locationId strictement inférieur à cette valeur */
  locationIdLessThan?: number;

  /** Filtre locationId différent de cette valeur */
  locationIdIsDifferent?: number;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de role */
  role?: string;
  /** Filtre IsNull sur role (true = IS NULL, false = IS NOT NULL) */
  roleIsNull?: boolean;
  /** Filtre role différent de cette valeur (NOT EQUAL) */
  roleIsDifferent?: string;
  /** Filtre par liste de valeurs pour role (IN) */
  roles?: string[];
  /** Filtre role différent de toutes ces valeurs (NOT IN) */
  roleIsDifferentList?: string[];

  /** Filtre role contenant cette valeur (LIKE %value%) */
  roleLike?: string;

  /** Filtre role commençant par cette valeur (LIKE value%) */
  roleStartsWith?: string;

  /** Filtre role terminant par cette valeur (LIKE %value) */
  roleEndsWith?: string;

  /** Filtre role ne contenant pas cette valeur (NOT LIKE %value%) */
  roleIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où location est NULL).
   * false = INNER JOIN.
   * À configurer AVANT location.
   */
  includeLocationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation location. */
  location?: LocationsCritereDTO;

}
