// gen-hash:fc8eb6044442765518ec9e7b0b201c78bb6bc223e7f4bab00cb2b916763bbe2a
/**
 * Validator TypeScript pour RefOrigineRecrutementDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefOrigineRecrutementDTO } from './ref-origine-recrutement.dto';

/**
 * Interface d'une règle de validation pour un champ de RefOrigineRecrutementDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefOrigineRecrutementFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefOrigineRecrutementDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefOrigineRecrutementDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefOrigineRecrutementDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefOrigineRecrutementValidator: Record<string, RefOrigineRecrutementFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefOrigineRecrutementDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefOrigineRecrutementDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefOrigineRecrutementDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefOrigineRecrutementFieldValidator(pKey: string): ((pValue: unknown, pRow: RefOrigineRecrutementDTO) => string | null) | null {
  const lRule: RefOrigineRecrutementFieldRule | undefined = RefOrigineRecrutementValidator[pKey];
  return lRule ? lRule.Validate : null;
}
