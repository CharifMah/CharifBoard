// gen-hash:47e845f827af4f428bc1ffe290aa5efcab66534b06b3125aee35da16db9c89ce
/**
 * Validator TypeScript pour HistoriqueEchangesDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { HistoriqueEchangesDTO } from './historique-echanges.dto';

/**
 * Interface d'une règle de validation pour un champ de HistoriqueEchangesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface HistoriqueEchangesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof HistoriqueEchangesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: HistoriqueEchangesDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour HistoriqueEchangesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const HistoriqueEchangesValidator: Record<string, HistoriqueEchangesFieldRule> = {
  // - cm - actionEchange : optionnel, longueur max 255
  actionEchange: {
    Key: 'actionEchange',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: HistoriqueEchangesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'actionEchange ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - 2026-08-13 : KAN-HISTORIQUE-CONTACT-OPTIONAL contactId devient OPTIONNEL
  //      (FK NULLABLE en BDD, voir migration crm_historique_echanges_contact_nullable.sql).
  //      Aligné sur le validator C# (rule ContactId.NotNull() commentée).
  //      Le backend autorise contact_id = NULL, et Postgres FK accepte NULL.
  // contactId: {
  //   Key: 'contactId',
  //   Validate: (pValue: unknown, _pRow: HistoriqueEchangesDTO): string | null => {
  //     if (pValue === null || pValue === undefined) {
  //       return 'contactId est obligatoire.';
  //     }
  //     return null;
  //   }
  // },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: HistoriqueEchangesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de HistoriqueEchangesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetHistoriqueEchangesFieldValidator(pKey: string): ((pValue: unknown, pRow: HistoriqueEchangesDTO) => string | null) | null {
  const lRule: HistoriqueEchangesFieldRule | undefined = HistoriqueEchangesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
