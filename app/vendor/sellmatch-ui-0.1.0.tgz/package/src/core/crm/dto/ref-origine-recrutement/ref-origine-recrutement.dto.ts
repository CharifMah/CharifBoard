// gen-hash:a1d0bfb7fc5730a87ff05f1e467c5d92cc9a376eb1a91b0a6ab0089fd3d8e3ec
/**
 * DTO for table: ref_origine_recrutement
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RecrutementsDTO } from '../recrutements/recrutements.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefOrigineRecrutementDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Recrutements */
  recrutements?: RecrutementsDTO[];
}
