// gen-hash:bf323d832c3b9435acbb9c1822cbc8f35c0252ac88da0b2a1969599a353052ee
/**
 * DTO for table: ref_statut_recherche
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RecherchesDTO } from '../recherches/recherches.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefStatutRechercheDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Recherches */
  recherches?: RecherchesDTO[];
}
