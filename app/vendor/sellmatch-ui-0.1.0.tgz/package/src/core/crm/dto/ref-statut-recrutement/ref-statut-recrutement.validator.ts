// gen-hash:fcd14f5b5ef806f5b7170bec565319c504f0933455ac921def18c5e72ef285ba
/**
 * Validator TypeScript pour RefStatutRecrutementDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefStatutRecrutementDTO } from './ref-statut-recrutement.dto';

/**
 * Interface d'une règle de validation pour un champ de RefStatutRecrutementDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefStatutRecrutementFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefStatutRecrutementDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefStatutRecrutementDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefStatutRecrutementDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefStatutRecrutementValidator: Record<string, RefStatutRecrutementFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefStatutRecrutementDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefStatutRecrutementDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefStatutRecrutementDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefStatutRecrutementFieldValidator(pKey: string): ((pValue: unknown, pRow: RefStatutRecrutementDTO) => string | null) | null {
  const lRule: RefStatutRecrutementFieldRule | undefined = RefStatutRecrutementValidator[pKey];
  return lRule ? lRule.Validate : null;
}
