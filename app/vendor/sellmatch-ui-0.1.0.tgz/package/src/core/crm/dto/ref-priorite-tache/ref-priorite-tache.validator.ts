// gen-hash:608f9107966c8ffc33c4c8c5f97abab22c3d38ababbbc869295e6f60b7735936
/**
 * Validator TypeScript pour RefPrioriteTacheDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefPrioriteTacheDTO } from './ref-priorite-tache.dto';

/**
 * Interface d'une règle de validation pour un champ de RefPrioriteTacheDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefPrioriteTacheFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefPrioriteTacheDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefPrioriteTacheDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefPrioriteTacheDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefPrioriteTacheValidator: Record<string, RefPrioriteTacheFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefPrioriteTacheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefPrioriteTacheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefPrioriteTacheDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefPrioriteTacheFieldValidator(pKey: string): ((pValue: unknown, pRow: RefPrioriteTacheDTO) => string | null) | null {
  const lRule: RefPrioriteTacheFieldRule | undefined = RefPrioriteTacheValidator[pKey];
  return lRule ? lRule.Validate : null;
}
