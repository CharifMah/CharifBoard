// gen-hash:806b58bae378bb44fc9a7a02590f1e732f5d4680288f749bc060baf1fe03d5bd
/**
 * DTO for table: taches
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { RefPrioriteTacheDTO } from '../ref-priorite-tache/ref-priorite-tache.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface TachesDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  nom?: string;
  description?: string;
  contactId?: number;
  dateEcheance?: Date | string;
  prioriteId?: number;
  notes?: string;
  validee?: boolean;
  archivee?: boolean;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Contacts */
  contact?: ContactsDTO;
  /** Navigation property vers RefPrioriteTache */
  priorite?: RefPrioriteTacheDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
