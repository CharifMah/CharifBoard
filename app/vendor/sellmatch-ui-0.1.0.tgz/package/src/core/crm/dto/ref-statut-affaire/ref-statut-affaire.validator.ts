// gen-hash:24f178c359aa70954ddf48d6d3e8b7ed93a5629d624050a7aebf35feef73e926
/**
 * Validator TypeScript pour RefStatutAffaireDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefStatutAffaireDTO } from './ref-statut-affaire.dto';

/**
 * Interface d'une règle de validation pour un champ de RefStatutAffaireDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefStatutAffaireFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefStatutAffaireDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefStatutAffaireDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefStatutAffaireDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefStatutAffaireValidator: Record<string, RefStatutAffaireFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefStatutAffaireDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefStatutAffaireDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefStatutAffaireDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefStatutAffaireFieldValidator(pKey: string): ((pValue: unknown, pRow: RefStatutAffaireDTO) => string | null) | null {
  const lRule: RefStatutAffaireFieldRule | undefined = RefStatutAffaireValidator[pKey];
  return lRule ? lRule.Validate : null;
}
