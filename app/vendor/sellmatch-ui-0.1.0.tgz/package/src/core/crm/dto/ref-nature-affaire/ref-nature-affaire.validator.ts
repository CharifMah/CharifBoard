// gen-hash:693d250ffc2bb7e924fe840a1286b53ee957123cbb69a2773c4b08869036d453
/**
 * Validator TypeScript pour RefNatureAffaireDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefNatureAffaireDTO } from './ref-nature-affaire.dto';

/**
 * Interface d'une règle de validation pour un champ de RefNatureAffaireDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefNatureAffaireFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefNatureAffaireDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefNatureAffaireDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefNatureAffaireDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefNatureAffaireValidator: Record<string, RefNatureAffaireFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefNatureAffaireDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefNatureAffaireDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefNatureAffaireDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefNatureAffaireFieldValidator(pKey: string): ((pValue: unknown, pRow: RefNatureAffaireDTO) => string | null) | null {
  const lRule: RefNatureAffaireFieldRule | undefined = RefNatureAffaireValidator[pKey];
  return lRule ? lRule.Validate : null;
}
