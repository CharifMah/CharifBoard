// gen-hash:9dfafca1a463c684b32fc19b389c67f1f8d3b2d846f25b6414d5051593f01bf9
/**
 * Validator TypeScript pour ObjectifsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { ObjectifsDTO } from './objectifs.dto';

/**
 * Interface d'une règle de validation pour un champ de ObjectifsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface ObjectifsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof ObjectifsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: ObjectifsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour ObjectifsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const ObjectifsValidator: Record<string, ObjectifsFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: ObjectifsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de ObjectifsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetObjectifsFieldValidator(pKey: string): ((pValue: unknown, pRow: ObjectifsDTO) => string | null) | null {
  const lRule: ObjectifsFieldRule | undefined = ObjectifsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
