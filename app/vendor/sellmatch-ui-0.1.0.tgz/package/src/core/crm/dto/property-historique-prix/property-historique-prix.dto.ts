// gen-hash:1a63c9cda5c9bf3f1f4aa9937275f968f9b9878df3429922b518e4822e776e49
/**
 * DTO for table: property_historique_prix
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { PropertiesDTO } from '../properties/properties.dto';

export interface PropertyHistoriquePrixDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  propertyId?: number;
  ancienPrix?: number;
  nouveauPrix?: number;
  dateChangement?: Date | string;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Properties */
  property?: PropertiesDTO;
}
