// gen-hash:cb73c2a227c047894b915488414e553b4a4d8610b6ff4bb8283e94b4289e6ffe
/**
 * DTO for table: historique_echanges
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RefTypeEchangeDTO } from '../ref-type-echange/ref-type-echange.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface HistoriqueEchangesDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  actionEchange?: string;
  contactId?: number;
  dateEchange?: Date | string;
  typeEchangeId?: number;
  compteRendu?: string;
  resultatProchaineAction?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefTypeEchange */
  typeEchange?: RefTypeEchangeDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
