// gen-hash:bcd5c31f6cb9f170e4c0e396bc765d632b04ed0ca3a1722ecfa1123b596cd482
/**
 * DTO for table: ref_statut_recrutement
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RecrutementsDTO } from '../recrutements/recrutements.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefStatutRecrutementDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Recrutements */
  recrutements?: RecrutementsDTO[];
}
