// gen-hash:5b90021a26060061318706d02ee3c89d4bea8dd6d16174b992905eabd7986861
/**
 * DTO for table: properties
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { LocationsDTO } from '../locations/locations.dto';
import type { PropertyHistoriquePrixDTO } from '../property-historique-prix/property-historique-prix.dto';
import type { RechercheBiensDTO } from '../recherche-biens/recherche-biens.dto';
import type { RefTypeBienDTO } from '../ref-type-bien/ref-type-bien.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface PropertiesDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  reference?: string;
  typeBienId?: number;
  adresseId?: number;
  proprietaireId?: number;
  surface?: number;
  surfaceTerrain?: number;
  nbPieces?: number;
  nbChambres?: number;
  etage?: number;
  ascenseur?: boolean;
  stationnement?: string;
  anneeConstruction?: number;
  dpe?: string;
  ges?: string;
  chauffage?: string;
  climatisation?: boolean;
  etatGeneral?: string;
  travaux?: string;
  prixAffiche?: number;
  charges?: number;
  disponibilite?: Date | string;
  dateCommercialisation?: Date | string;
  pointsForts?: string;
  pointsFaibles?: string;
  photos?: unknown;
  documents?: unknown;
  statut?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  adresse?: AdressesDTO;
  /** Navigation property vers Contacts */
  proprietaire?: ContactsDTO;
  /** Navigation property vers RefTypeBien */
  typeBien?: RefTypeBienDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Locations */
  locations?: LocationsDTO[];
  /** Collection de PropertyHistoriquePrix */
  propertyHistoriquePrixes?: PropertyHistoriquePrixDTO[];
  /** Collection de RechercheBiens */
  rechercheBiens?: RechercheBiensDTO[];
  /** Collection de Transactions */
  transactions?: TransactionsDTO[];
}
