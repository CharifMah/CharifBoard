// gen-hash:dbf5aca73b4f9e0b2d61dcfad96a169edee4e29ce5dcc166a84fed8d0ffaed6d
/**
 * Validator TypeScript pour ParametresDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { ParametresDTO } from './parametres.dto';

/**
 * Interface d'une règle de validation pour un champ de ParametresDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface ParametresFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof ParametresDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: ParametresDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour ParametresDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const ParametresValidator: Record<string, ParametresFieldRule> = {
  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: ParametresDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de ParametresDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetParametresFieldValidator(pKey: string): ((pValue: unknown, pRow: ParametresDTO) => string | null) | null {
  const lRule: ParametresFieldRule | undefined = ParametresValidator[pKey];
  return lRule ? lRule.Validate : null;
}
