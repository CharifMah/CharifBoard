// gen-hash:a3fee4c24645955c86500568f984742c4f8ea2e1b2704060c121dc4da96dcdb6
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { LocationsCritereDTO } from '../locations/locations.critere';
import { PropertiesCritereDTO } from '../properties/properties.critere';
import { RecherchesCritereDTO } from '../recherches/recherches.critere';
import { TransactionsCritereDTO } from '../transactions/transactions.critere';

export interface RechercheBiensCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de rechercheId */
  rechercheId?: number;
  /** Filtre par liste de valeurs pour rechercheId (IN) */
  rechercheIds?: number[];
  /** Filtre rechercheId différent de toutes ces valeurs (NOT IN) */
  rechercheIdIsDifferentList?: number[];

  /** Filtre rechercheId supérieur ou égal à cette valeur */
  rechercheIdMin?: number;

  /** Filtre rechercheId inférieur ou égal à cette valeur */
  rechercheIdMax?: number;

  /** Filtre rechercheId strictement supérieur à cette valeur */
  rechercheIdGreaterThan?: number;

  /** Filtre rechercheId strictement inférieur à cette valeur */
  rechercheIdLessThan?: number;

  /** Filtre rechercheId différent de cette valeur */
  rechercheIdIsDifferent?: number;

  /** Filtre par valeur exacte de propertyId */
  propertyId?: number;
  /** Filtre IsNull sur propertyId (true = IS NULL, false = IS NOT NULL) */
  propertyIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour propertyId (IN) */
  propertyIds?: number[];
  /** Filtre propertyId différent de toutes ces valeurs (NOT IN) */
  propertyIdIsDifferentList?: number[];

  /** Filtre propertyId supérieur ou égal à cette valeur */
  propertyIdMin?: number;

  /** Filtre propertyId inférieur ou égal à cette valeur */
  propertyIdMax?: number;

  /** Filtre propertyId strictement supérieur à cette valeur */
  propertyIdGreaterThan?: number;

  /** Filtre propertyId strictement inférieur à cette valeur */
  propertyIdLessThan?: number;

  /** Filtre propertyId différent de cette valeur */
  propertyIdIsDifferent?: number;

  /** Filtre par valeur exacte de transactionId */
  transactionId?: number;
  /** Filtre IsNull sur transactionId (true = IS NULL, false = IS NOT NULL) */
  transactionIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour transactionId (IN) */
  transactionIds?: number[];
  /** Filtre transactionId différent de toutes ces valeurs (NOT IN) */
  transactionIdIsDifferentList?: number[];

  /** Filtre transactionId supérieur ou égal à cette valeur */
  transactionIdMin?: number;

  /** Filtre transactionId inférieur ou égal à cette valeur */
  transactionIdMax?: number;

  /** Filtre transactionId strictement supérieur à cette valeur */
  transactionIdGreaterThan?: number;

  /** Filtre transactionId strictement inférieur à cette valeur */
  transactionIdLessThan?: number;

  /** Filtre transactionId différent de cette valeur */
  transactionIdIsDifferent?: number;

  /** Filtre par valeur exacte de locationId */
  locationId?: number;
  /** Filtre IsNull sur locationId (true = IS NULL, false = IS NOT NULL) */
  locationIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour locationId (IN) */
  locationIds?: number[];
  /** Filtre locationId différent de toutes ces valeurs (NOT IN) */
  locationIdIsDifferentList?: number[];

  /** Filtre locationId supérieur ou égal à cette valeur */
  locationIdMin?: number;

  /** Filtre locationId inférieur ou égal à cette valeur */
  locationIdMax?: number;

  /** Filtre locationId strictement supérieur à cette valeur */
  locationIdGreaterThan?: number;

  /** Filtre locationId strictement inférieur à cette valeur */
  locationIdLessThan?: number;

  /** Filtre locationId différent de cette valeur */
  locationIdIsDifferent?: number;

  /** Filtre par valeur exacte de score */
  score?: number;
  /** Filtre IsNull sur score (true = IS NULL, false = IS NOT NULL) */
  scoreIsNull?: boolean;
  /** Filtre par liste de valeurs pour score (IN) */
  scores?: number[];
  /** Filtre score différent de toutes ces valeurs (NOT IN) */
  scoreIsDifferentList?: number[];

  /** Filtre score supérieur ou égal à cette valeur */
  scoreMin?: number;

  /** Filtre score inférieur ou égal à cette valeur */
  scoreMax?: number;

  /** Filtre score strictement supérieur à cette valeur */
  scoreGreaterThan?: number;

  /** Filtre score strictement inférieur à cette valeur */
  scoreLessThan?: number;

  /** Filtre score différent de cette valeur */
  scoreIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où location est NULL).
   * false = INNER JOIN.
   * À configurer AVANT location.
   */
  includeLocationEmpty?: boolean;

  /** Filtre imbriqué sur la navigation location. */
  location?: LocationsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où property est NULL).
   * false = INNER JOIN.
   * À configurer AVANT property.
   */
  includePropertyEmpty?: boolean;

  /** Filtre imbriqué sur la navigation property. */
  property?: PropertiesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où recherche est NULL).
   * false = INNER JOIN.
   * À configurer AVANT recherche.
   */
  includeRechercheEmpty?: boolean;

  /** Filtre imbriqué sur la navigation recherche. */
  recherche?: RecherchesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où transaction est NULL).
   * false = INNER JOIN.
   * À configurer AVANT transaction.
   */
  includeTransactionEmpty?: boolean;

  /** Filtre imbriqué sur la navigation transaction. */
  transaction?: TransactionsCritereDTO;

}
