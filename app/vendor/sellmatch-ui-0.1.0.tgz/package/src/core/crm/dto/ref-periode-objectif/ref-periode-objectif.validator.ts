// gen-hash:a3610ee50a4f78367160f4b578c4028fdda12aff8189b3a1bcdfadcbdcd55f80
/**
 * Validator TypeScript pour RefPeriodeObjectifDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefPeriodeObjectifDTO } from './ref-periode-objectif.dto';

/**
 * Interface d'une règle de validation pour un champ de RefPeriodeObjectifDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefPeriodeObjectifFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefPeriodeObjectifDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefPeriodeObjectifDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefPeriodeObjectifDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefPeriodeObjectifValidator: Record<string, RefPeriodeObjectifFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefPeriodeObjectifDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefPeriodeObjectifDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefPeriodeObjectifDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefPeriodeObjectifFieldValidator(pKey: string): ((pValue: unknown, pRow: RefPeriodeObjectifDTO) => string | null) | null {
  const lRule: RefPeriodeObjectifFieldRule | undefined = RefPeriodeObjectifValidator[pKey];
  return lRule ? lRule.Validate : null;
}
