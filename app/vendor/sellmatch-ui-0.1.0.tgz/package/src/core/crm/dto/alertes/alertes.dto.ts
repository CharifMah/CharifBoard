// gen-hash:f1b2ea30d69f38d8ea4648f5e2d4acc73c857f5cb89e1db7b305cedeb0620418
/**
 * DTO for table: alertes
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface AlertesDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  userId?: number;
  typeAlerte?: string;
  titre?: string;
  message?: string;
  dateAlerte?: Date | string;
  lue?: boolean;
  entiteType?: string;
  entiteId?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Users */
  user?: UsersDTO;
}
