// gen-hash:24d4b55410cc4f8e468ecb4d2e84a4e4319c2a2357e7238e87293585c314ffbf
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface AiImportJobsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de status */
  status?: string;
  /** Filtre IsNull sur status (true = IS NULL, false = IS NOT NULL) */
  statusIsNull?: boolean;
  /** Filtre status différent de cette valeur (NOT EQUAL) */
  statusIsDifferent?: string;
  /** Filtre par liste de valeurs pour status (IN) */
  statuss?: string[];
  /** Filtre status différent de toutes ces valeurs (NOT IN) */
  statusIsDifferentList?: string[];

  /** Filtre status contenant cette valeur (LIKE %value%) */
  statusLike?: string;

  /** Filtre status commençant par cette valeur (LIKE value%) */
  statusStartsWith?: string;

  /** Filtre status terminant par cette valeur (LIKE %value) */
  statusEndsWith?: string;

  /** Filtre status ne contenant pas cette valeur (NOT LIKE %value%) */
  statusIsDifferentLike?: string;

  /** Filtre par valeur exacte de provider */
  provider?: string;
  /** Filtre IsNull sur provider (true = IS NULL, false = IS NOT NULL) */
  providerIsNull?: boolean;
  /** Filtre provider différent de cette valeur (NOT EQUAL) */
  providerIsDifferent?: string;
  /** Filtre par liste de valeurs pour provider (IN) */
  providers?: string[];
  /** Filtre provider différent de toutes ces valeurs (NOT IN) */
  providerIsDifferentList?: string[];

  /** Filtre provider contenant cette valeur (LIKE %value%) */
  providerLike?: string;

  /** Filtre provider commençant par cette valeur (LIKE value%) */
  providerStartsWith?: string;

  /** Filtre provider terminant par cette valeur (LIKE %value) */
  providerEndsWith?: string;

  /** Filtre provider ne contenant pas cette valeur (NOT LIKE %value%) */
  providerIsDifferentLike?: string;

  /** Filtre par valeur exacte de apiKeyEncrypted */
  apiKeyEncrypted?: string;
  /** Filtre IsNull sur apiKeyEncrypted (true = IS NULL, false = IS NOT NULL) */
  apiKeyEncryptedIsNull?: boolean;
  /** Filtre apiKeyEncrypted différent de cette valeur (NOT EQUAL) */
  apiKeyEncryptedIsDifferent?: string;
  /** Filtre par liste de valeurs pour apiKeyEncrypted (IN) */
  apiKeyEncrypteds?: string[];
  /** Filtre apiKeyEncrypted différent de toutes ces valeurs (NOT IN) */
  apiKeyEncryptedIsDifferentList?: string[];

  /** Filtre apiKeyEncrypted contenant cette valeur (LIKE %value%) */
  apiKeyEncryptedLike?: string;

  /** Filtre apiKeyEncrypted commençant par cette valeur (LIKE value%) */
  apiKeyEncryptedStartsWith?: string;

  /** Filtre apiKeyEncrypted terminant par cette valeur (LIKE %value) */
  apiKeyEncryptedEndsWith?: string;

  /** Filtre apiKeyEncrypted ne contenant pas cette valeur (NOT LIKE %value%) */
  apiKeyEncryptedIsDifferentLike?: string;

  /** Filtre par valeur exacte de model */
  model?: string;
  /** Filtre IsNull sur model (true = IS NULL, false = IS NOT NULL) */
  modelIsNull?: boolean;
  /** Filtre model différent de cette valeur (NOT EQUAL) */
  modelIsDifferent?: string;
  /** Filtre par liste de valeurs pour model (IN) */
  models?: string[];
  /** Filtre model différent de toutes ces valeurs (NOT IN) */
  modelIsDifferentList?: string[];

  /** Filtre model contenant cette valeur (LIKE %value%) */
  modelLike?: string;

  /** Filtre model commençant par cette valeur (LIKE value%) */
  modelStartsWith?: string;

  /** Filtre model terminant par cette valeur (LIKE %value) */
  modelEndsWith?: string;

  /** Filtre model ne contenant pas cette valeur (NOT LIKE %value%) */
  modelIsDifferentLike?: string;

  /** Filtre par valeur exacte de endpointUrl */
  endpointUrl?: string;
  /** Filtre IsNull sur endpointUrl (true = IS NULL, false = IS NOT NULL) */
  endpointUrlIsNull?: boolean;
  /** Filtre endpointUrl différent de cette valeur (NOT EQUAL) */
  endpointUrlIsDifferent?: string;
  /** Filtre par liste de valeurs pour endpointUrl (IN) */
  endpointUrls?: string[];
  /** Filtre endpointUrl différent de toutes ces valeurs (NOT IN) */
  endpointUrlIsDifferentList?: string[];

  /** Filtre endpointUrl contenant cette valeur (LIKE %value%) */
  endpointUrlLike?: string;

  /** Filtre endpointUrl commençant par cette valeur (LIKE value%) */
  endpointUrlStartsWith?: string;

  /** Filtre endpointUrl terminant par cette valeur (LIKE %value) */
  endpointUrlEndsWith?: string;

  /** Filtre endpointUrl ne contenant pas cette valeur (NOT LIKE %value%) */
  endpointUrlIsDifferentLike?: string;

  /** Filtre par valeur exacte de documentPath */
  documentPath?: string;
  /** Filtre IsNull sur documentPath (true = IS NULL, false = IS NOT NULL) */
  documentPathIsNull?: boolean;
  /** Filtre documentPath différent de cette valeur (NOT EQUAL) */
  documentPathIsDifferent?: string;
  /** Filtre par liste de valeurs pour documentPath (IN) */
  documentPaths?: string[];
  /** Filtre documentPath différent de toutes ces valeurs (NOT IN) */
  documentPathIsDifferentList?: string[];

  /** Filtre documentPath contenant cette valeur (LIKE %value%) */
  documentPathLike?: string;

  /** Filtre documentPath commençant par cette valeur (LIKE value%) */
  documentPathStartsWith?: string;

  /** Filtre documentPath terminant par cette valeur (LIKE %value) */
  documentPathEndsWith?: string;

  /** Filtre documentPath ne contenant pas cette valeur (NOT LIKE %value%) */
  documentPathIsDifferentLike?: string;

  /** Filtre par valeur exacte de optionsJson */
  optionsJson?: string;
  /** Filtre IsNull sur optionsJson (true = IS NULL, false = IS NOT NULL) */
  optionsJsonIsNull?: boolean;
  /** Filtre optionsJson différent de cette valeur (NOT EQUAL) */
  optionsJsonIsDifferent?: string;
  /** Filtre par liste de valeurs pour optionsJson (IN) */
  optionsJsons?: string[];
  /** Filtre optionsJson différent de toutes ces valeurs (NOT IN) */
  optionsJsonIsDifferentList?: string[];

  /** Filtre optionsJson contenant cette valeur (LIKE %value%) */
  optionsJsonLike?: string;

  /** Filtre optionsJson commençant par cette valeur (LIKE value%) */
  optionsJsonStartsWith?: string;

  /** Filtre optionsJson terminant par cette valeur (LIKE %value) */
  optionsJsonEndsWith?: string;

  /** Filtre optionsJson ne contenant pas cette valeur (NOT LIKE %value%) */
  optionsJsonIsDifferentLike?: string;

  /** Filtre par valeur exacte de resultJson */
  resultJson?: string;
  /** Filtre IsNull sur resultJson (true = IS NULL, false = IS NOT NULL) */
  resultJsonIsNull?: boolean;
  /** Filtre resultJson différent de cette valeur (NOT EQUAL) */
  resultJsonIsDifferent?: string;
  /** Filtre par liste de valeurs pour resultJson (IN) */
  resultJsons?: string[];
  /** Filtre resultJson différent de toutes ces valeurs (NOT IN) */
  resultJsonIsDifferentList?: string[];

  /** Filtre resultJson contenant cette valeur (LIKE %value%) */
  resultJsonLike?: string;

  /** Filtre resultJson commençant par cette valeur (LIKE value%) */
  resultJsonStartsWith?: string;

  /** Filtre resultJson terminant par cette valeur (LIKE %value) */
  resultJsonEndsWith?: string;

  /** Filtre resultJson ne contenant pas cette valeur (NOT LIKE %value%) */
  resultJsonIsDifferentLike?: string;

  /** Filtre par valeur exacte de error */
  error?: string;
  /** Filtre IsNull sur error (true = IS NULL, false = IS NOT NULL) */
  errorIsNull?: boolean;
  /** Filtre error différent de cette valeur (NOT EQUAL) */
  errorIsDifferent?: string;
  /** Filtre par liste de valeurs pour error (IN) */
  errors?: string[];
  /** Filtre error différent de toutes ces valeurs (NOT IN) */
  errorIsDifferentList?: string[];

  /** Filtre error contenant cette valeur (LIKE %value%) */
  errorLike?: string;

  /** Filtre error commençant par cette valeur (LIKE value%) */
  errorStartsWith?: string;

  /** Filtre error terminant par cette valeur (LIKE %value) */
  errorEndsWith?: string;

  /** Filtre error ne contenant pas cette valeur (NOT LIKE %value%) */
  errorIsDifferentLike?: string;

  /** Filtre par valeur exacte de retryCount */
  retryCount?: number;
  /** Filtre par liste de valeurs pour retryCount (IN) */
  retryCounts?: number[];
  /** Filtre retryCount différent de toutes ces valeurs (NOT IN) */
  retryCountIsDifferentList?: number[];

  /** Filtre retryCount supérieur ou égal à cette valeur */
  retryCountMin?: number;

  /** Filtre retryCount inférieur ou égal à cette valeur */
  retryCountMax?: number;

  /** Filtre retryCount strictement supérieur à cette valeur */
  retryCountGreaterThan?: number;

  /** Filtre retryCount strictement inférieur à cette valeur */
  retryCountLessThan?: number;

  /** Filtre retryCount différent de cette valeur */
  retryCountIsDifferent?: number;

  /** Filtre par valeur exacte de lockedBy */
  lockedBy?: string;
  /** Filtre IsNull sur lockedBy (true = IS NULL, false = IS NOT NULL) */
  lockedByIsNull?: boolean;
  /** Filtre lockedBy différent de cette valeur (NOT EQUAL) */
  lockedByIsDifferent?: string;
  /** Filtre par liste de valeurs pour lockedBy (IN) */
  lockedBys?: string[];
  /** Filtre lockedBy différent de toutes ces valeurs (NOT IN) */
  lockedByIsDifferentList?: string[];

  /** Filtre lockedBy contenant cette valeur (LIKE %value%) */
  lockedByLike?: string;

  /** Filtre lockedBy commençant par cette valeur (LIKE value%) */
  lockedByStartsWith?: string;

  /** Filtre lockedBy terminant par cette valeur (LIKE %value) */
  lockedByEndsWith?: string;

  /** Filtre lockedBy ne contenant pas cette valeur (NOT LIKE %value%) */
  lockedByIsDifferentLike?: string;

  /** Filtre par valeur exacte de lockedUntil */
  lockedUntil?: Date | string;
  /** Filtre IsNull sur lockedUntil (true = IS NULL, false = IS NOT NULL) */
  lockedUntilIsNull?: boolean;
  /** Filtre par liste de valeurs pour lockedUntil (IN) */
  lockedUntils?: Date | string[];
  /** Filtre lockedUntil différent de toutes ces valeurs (NOT IN) */
  lockedUntilIsDifferentList?: Date | string[];

  /** Filtre lockedUntil à partir de cette date (incluse) */
  lockedUntilFrom?: Date | string;

  /** Filtre lockedUntil jusqu'à cette date (incluse) */
  lockedUntilTo?: Date | string;

  /** Filtre lockedUntil strictement après cette date */
  lockedUntilAfter?: Date | string;

  /** Filtre lockedUntil strictement avant cette date */
  lockedUntilBefore?: Date | string;

  /** Filtre lockedUntil différent de cette date */
  lockedUntilIsDifferent?: Date | string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
