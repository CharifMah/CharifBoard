// gen-hash:6e6ff48b83d547952ce0549f6bdd24841f0140ebe30fa21ef2e0a1c7a21ec87f
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface AlertesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de typeAlerte */
  typeAlerte?: string;
  /** Filtre IsNull sur typeAlerte (true = IS NULL, false = IS NOT NULL) */
  typeAlerteIsNull?: boolean;
  /** Filtre typeAlerte différent de cette valeur (NOT EQUAL) */
  typeAlerteIsDifferent?: string;
  /** Filtre par liste de valeurs pour typeAlerte (IN) */
  typeAlertes?: string[];
  /** Filtre typeAlerte différent de toutes ces valeurs (NOT IN) */
  typeAlerteIsDifferentList?: string[];

  /** Filtre typeAlerte contenant cette valeur (LIKE %value%) */
  typeAlerteLike?: string;

  /** Filtre typeAlerte commençant par cette valeur (LIKE value%) */
  typeAlerteStartsWith?: string;

  /** Filtre typeAlerte terminant par cette valeur (LIKE %value) */
  typeAlerteEndsWith?: string;

  /** Filtre typeAlerte ne contenant pas cette valeur (NOT LIKE %value%) */
  typeAlerteIsDifferentLike?: string;

  /** Filtre par valeur exacte de titre */
  titre?: string;
  /** Filtre IsNull sur titre (true = IS NULL, false = IS NOT NULL) */
  titreIsNull?: boolean;
  /** Filtre titre différent de cette valeur (NOT EQUAL) */
  titreIsDifferent?: string;
  /** Filtre par liste de valeurs pour titre (IN) */
  titres?: string[];
  /** Filtre titre différent de toutes ces valeurs (NOT IN) */
  titreIsDifferentList?: string[];

  /** Filtre titre contenant cette valeur (LIKE %value%) */
  titreLike?: string;

  /** Filtre titre commençant par cette valeur (LIKE value%) */
  titreStartsWith?: string;

  /** Filtre titre terminant par cette valeur (LIKE %value) */
  titreEndsWith?: string;

  /** Filtre titre ne contenant pas cette valeur (NOT LIKE %value%) */
  titreIsDifferentLike?: string;

  /** Filtre par valeur exacte de message */
  message?: string;
  /** Filtre IsNull sur message (true = IS NULL, false = IS NOT NULL) */
  messageIsNull?: boolean;
  /** Filtre message différent de cette valeur (NOT EQUAL) */
  messageIsDifferent?: string;
  /** Filtre par liste de valeurs pour message (IN) */
  messages?: string[];
  /** Filtre message différent de toutes ces valeurs (NOT IN) */
  messageIsDifferentList?: string[];

  /** Filtre message contenant cette valeur (LIKE %value%) */
  messageLike?: string;

  /** Filtre message commençant par cette valeur (LIKE value%) */
  messageStartsWith?: string;

  /** Filtre message terminant par cette valeur (LIKE %value) */
  messageEndsWith?: string;

  /** Filtre message ne contenant pas cette valeur (NOT LIKE %value%) */
  messageIsDifferentLike?: string;

  /** Filtre par valeur exacte de dateAlerte */
  dateAlerte?: Date | string;
  /** Filtre IsNull sur dateAlerte (true = IS NULL, false = IS NOT NULL) */
  dateAlerteIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateAlerte (IN) */
  dateAlertes?: Date | string[];
  /** Filtre dateAlerte différent de toutes ces valeurs (NOT IN) */
  dateAlerteIsDifferentList?: Date | string[];

  /** Filtre dateAlerte à partir de cette date (incluse) */
  dateAlerteFrom?: Date | string;

  /** Filtre dateAlerte jusqu'à cette date (incluse) */
  dateAlerteTo?: Date | string;

  /** Filtre dateAlerte strictement après cette date */
  dateAlerteAfter?: Date | string;

  /** Filtre dateAlerte strictement avant cette date */
  dateAlerteBefore?: Date | string;

  /** Filtre dateAlerte différent de cette date */
  dateAlerteIsDifferent?: Date | string;

  /** Filtre par valeur exacte de lue */
  lue?: boolean;
  /** Filtre IsNull sur lue (true = IS NULL, false = IS NOT NULL) */
  lueIsNull?: boolean;
  /** Filtre lue différent de cette valeur (NOT EQUAL) */
  lueIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour lue (IN) */
  lues?: boolean[];
  /** Filtre lue différent de toutes ces valeurs (NOT IN) */
  lueIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de entiteType */
  entiteType?: string;
  /** Filtre IsNull sur entiteType (true = IS NULL, false = IS NOT NULL) */
  entiteTypeIsNull?: boolean;
  /** Filtre entiteType différent de cette valeur (NOT EQUAL) */
  entiteTypeIsDifferent?: string;
  /** Filtre par liste de valeurs pour entiteType (IN) */
  entiteTypes?: string[];
  /** Filtre entiteType différent de toutes ces valeurs (NOT IN) */
  entiteTypeIsDifferentList?: string[];

  /** Filtre entiteType contenant cette valeur (LIKE %value%) */
  entiteTypeLike?: string;

  /** Filtre entiteType commençant par cette valeur (LIKE value%) */
  entiteTypeStartsWith?: string;

  /** Filtre entiteType terminant par cette valeur (LIKE %value) */
  entiteTypeEndsWith?: string;

  /** Filtre entiteType ne contenant pas cette valeur (NOT LIKE %value%) */
  entiteTypeIsDifferentLike?: string;

  /** Filtre par valeur exacte de entiteId */
  entiteId?: number;
  /** Filtre IsNull sur entiteId (true = IS NULL, false = IS NOT NULL) */
  entiteIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour entiteId (IN) */
  entiteIds?: number[];
  /** Filtre entiteId différent de toutes ces valeurs (NOT IN) */
  entiteIdIsDifferentList?: number[];

  /** Filtre entiteId supérieur ou égal à cette valeur */
  entiteIdMin?: number;

  /** Filtre entiteId inférieur ou égal à cette valeur */
  entiteIdMax?: number;

  /** Filtre entiteId strictement supérieur à cette valeur */
  entiteIdGreaterThan?: number;

  /** Filtre entiteId strictement inférieur à cette valeur */
  entiteIdLessThan?: number;

  /** Filtre entiteId différent de cette valeur */
  entiteIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
