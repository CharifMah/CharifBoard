// gen-hash:b0ceccaca15134669eb00e8c00308e3034dec637b43a28b3256611e392c5d9bb
/**
 * Validator TypeScript pour PropertiesDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { PropertiesDTO } from './properties.dto';

/**
 * Interface d'une règle de validation pour un champ de PropertiesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface PropertiesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof PropertiesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: PropertiesDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour PropertiesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const PropertiesValidator: Record<string, PropertiesFieldRule> = {
  // - cm - reference : optionnel, longueur max 100
  reference: {
    Key: 'reference',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'reference ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - stationnement : optionnel, longueur max 255
  stationnement: {
    Key: 'stationnement',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'stationnement ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - dpe : optionnel, longueur max 10
  dpe: {
    Key: 'dpe',
    MaxLength: 10,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 10) {
        return 'dpe ne doit pas dépasser 10 caractères.';
      }
      return null;
    }
  },

  // - cm - ges : optionnel, longueur max 10
  ges: {
    Key: 'ges',
    MaxLength: 10,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 10) {
        return 'ges ne doit pas dépasser 10 caractères.';
      }
      return null;
    }
  },

  // - cm - chauffage : optionnel, longueur max 100
  chauffage: {
    Key: 'chauffage',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'chauffage ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - etatGeneral : optionnel, longueur max 100
  etatGeneral: {
    Key: 'etatGeneral',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'etatGeneral ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - statut : optionnel, longueur max 50
  statut: {
    Key: 'statut',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'statut ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: PropertiesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de PropertiesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetPropertiesFieldValidator(pKey: string): ((pValue: unknown, pRow: PropertiesDTO) => string | null) | null {
  const lRule: PropertiesFieldRule | undefined = PropertiesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
