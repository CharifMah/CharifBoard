// gen-hash:68eaf8ead142c61422cf254788632a3ed20fe1c841308a04325b88fc1c3a1485
/**
 * DTO for table: ref_type_echange
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { HistoriqueEchangesDTO } from '../historique-echanges/historique-echanges.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefTypeEchangeDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de HistoriqueEchanges */
  historiqueEchanges?: HistoriqueEchangesDTO[];
}
