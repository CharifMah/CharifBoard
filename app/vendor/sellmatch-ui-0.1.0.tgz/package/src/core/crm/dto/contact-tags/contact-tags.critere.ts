// gen-hash:a1199d623246ae3e1fb70bb014143e5c7eea723b985856dac54d513888f44ac2
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';

export interface ContactTagsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de tag */
  tag?: string;
  /** Filtre IsNull sur tag (true = IS NULL, false = IS NOT NULL) */
  tagIsNull?: boolean;
  /** Filtre tag différent de cette valeur (NOT EQUAL) */
  tagIsDifferent?: string;
  /** Filtre par liste de valeurs pour tag (IN) */
  tags?: string[];
  /** Filtre tag différent de toutes ces valeurs (NOT IN) */
  tagIsDifferentList?: string[];

  /** Filtre tag contenant cette valeur (LIKE %value%) */
  tagLike?: string;

  /** Filtre tag commençant par cette valeur (LIKE value%) */
  tagStartsWith?: string;

  /** Filtre tag terminant par cette valeur (LIKE %value) */
  tagEndsWith?: string;

  /** Filtre tag ne contenant pas cette valeur (NOT LIKE %value%) */
  tagIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

}
