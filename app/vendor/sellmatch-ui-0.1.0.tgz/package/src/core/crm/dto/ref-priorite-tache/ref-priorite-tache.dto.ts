// gen-hash:7c78e8845aa22b30d122afa49d1d145a37f03a1858e8e0788ee4287c15c857e9
/**
 * DTO for table: ref_priorite_tache
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';
import type { TachesDTO } from '../taches/taches.dto';

export interface RefPrioriteTacheDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Taches */
  taches?: TachesDTO[];
}
