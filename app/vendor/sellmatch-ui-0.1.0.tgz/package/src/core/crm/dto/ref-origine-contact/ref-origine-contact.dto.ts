// gen-hash:09e9b7fd622ea17c9a4c9dc411299f36f3f9b59f10cf2f079a880f541231db92
/**
 * DTO for table: ref_origine_contact
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefOrigineContactDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Contacts */
  contacts?: ContactsDTO[];
}
