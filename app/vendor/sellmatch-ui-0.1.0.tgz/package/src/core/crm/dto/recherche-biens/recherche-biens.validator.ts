// gen-hash:daf4f1d77e86409b46e390cf75bf454affba8bee029bb92db47dd56f08d12e89
/**
 * Validator TypeScript pour RechercheBiensDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RechercheBiensDTO } from './recherche-biens.dto';

/**
 * Interface d'une règle de validation pour un champ de RechercheBiensDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RechercheBiensFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RechercheBiensDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RechercheBiensDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RechercheBiensDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RechercheBiensValidator: Record<string, RechercheBiensFieldRule> = {
  // - cm - rechercheId : obligatoire
  rechercheId: {
    Key: 'rechercheId',
    Validate: (pValue: unknown, _pRow: RechercheBiensDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'rechercheId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - createdAt : obligatoire
  createdAt: {
    Key: 'createdAt',
    Validate: (pValue: unknown, _pRow: RechercheBiensDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'createdAt est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RechercheBiensDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRechercheBiensFieldValidator(pKey: string): ((pValue: unknown, pRow: RechercheBiensDTO) => string | null) | null {
  const lRule: RechercheBiensFieldRule | undefined = RechercheBiensValidator[pKey];
  return lRule ? lRule.Validate : null;
}
