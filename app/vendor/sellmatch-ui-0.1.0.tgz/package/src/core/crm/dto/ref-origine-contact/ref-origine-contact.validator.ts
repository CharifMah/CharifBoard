// gen-hash:661c55c40abbd7fc6e56beb09c46b5cdeab9ad9e3571e8f0885149a03dd716a2
/**
 * Validator TypeScript pour RefOrigineContactDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefOrigineContactDTO } from './ref-origine-contact.dto';

/**
 * Interface d'une règle de validation pour un champ de RefOrigineContactDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefOrigineContactFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefOrigineContactDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefOrigineContactDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefOrigineContactDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefOrigineContactValidator: Record<string, RefOrigineContactFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefOrigineContactDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefOrigineContactDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefOrigineContactDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefOrigineContactFieldValidator(pKey: string): ((pValue: unknown, pRow: RefOrigineContactDTO) => string | null) | null {
  const lRule: RefOrigineContactFieldRule | undefined = RefOrigineContactValidator[pKey];
  return lRule ? lRule.Validate : null;
}
