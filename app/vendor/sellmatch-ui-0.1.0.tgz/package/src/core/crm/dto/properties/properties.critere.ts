// gen-hash:3ec0260193c1f5047226ef7cea3a56c4d78c8393c53851b9abd18190cd4f094d
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { LocationsCritereDTO } from '../locations/locations.critere';
import { PropertyHistoriquePrixCritereDTO } from '../property-historique-prix/property-historique-prix.critere';
import { RechercheBiensCritereDTO } from '../recherche-biens/recherche-biens.critere';
import { RefTypeBienCritereDTO } from '../ref-type-bien/ref-type-bien.critere';
import { TransactionsCritereDTO } from '../transactions/transactions.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface PropertiesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de reference */
  reference?: string;
  /** Filtre IsNull sur reference (true = IS NULL, false = IS NOT NULL) */
  referenceIsNull?: boolean;
  /** Filtre reference différent de cette valeur (NOT EQUAL) */
  referenceIsDifferent?: string;
  /** Filtre par liste de valeurs pour reference (IN) */
  references?: string[];
  /** Filtre reference différent de toutes ces valeurs (NOT IN) */
  referenceIsDifferentList?: string[];

  /** Filtre reference contenant cette valeur (LIKE %value%) */
  referenceLike?: string;

  /** Filtre reference commençant par cette valeur (LIKE value%) */
  referenceStartsWith?: string;

  /** Filtre reference terminant par cette valeur (LIKE %value) */
  referenceEndsWith?: string;

  /** Filtre reference ne contenant pas cette valeur (NOT LIKE %value%) */
  referenceIsDifferentLike?: string;

  /** Filtre par valeur exacte de typeBienId */
  typeBienId?: number;
  /** Filtre IsNull sur typeBienId (true = IS NULL, false = IS NOT NULL) */
  typeBienIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeBienId (IN) */
  typeBienIds?: number[];
  /** Filtre typeBienId différent de toutes ces valeurs (NOT IN) */
  typeBienIdIsDifferentList?: number[];

  /** Filtre typeBienId supérieur ou égal à cette valeur */
  typeBienIdMin?: number;

  /** Filtre typeBienId inférieur ou égal à cette valeur */
  typeBienIdMax?: number;

  /** Filtre typeBienId strictement supérieur à cette valeur */
  typeBienIdGreaterThan?: number;

  /** Filtre typeBienId strictement inférieur à cette valeur */
  typeBienIdLessThan?: number;

  /** Filtre typeBienId différent de cette valeur */
  typeBienIdIsDifferent?: number;

  /** Filtre par valeur exacte de adresseId */
  adresseId?: number;
  /** Filtre IsNull sur adresseId (true = IS NULL, false = IS NOT NULL) */
  adresseIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour adresseId (IN) */
  adresseIds?: number[];
  /** Filtre adresseId différent de toutes ces valeurs (NOT IN) */
  adresseIdIsDifferentList?: number[];

  /** Filtre adresseId supérieur ou égal à cette valeur */
  adresseIdMin?: number;

  /** Filtre adresseId inférieur ou égal à cette valeur */
  adresseIdMax?: number;

  /** Filtre adresseId strictement supérieur à cette valeur */
  adresseIdGreaterThan?: number;

  /** Filtre adresseId strictement inférieur à cette valeur */
  adresseIdLessThan?: number;

  /** Filtre adresseId différent de cette valeur */
  adresseIdIsDifferent?: number;

  /** Filtre par valeur exacte de proprietaireId */
  proprietaireId?: number;
  /** Filtre IsNull sur proprietaireId (true = IS NULL, false = IS NOT NULL) */
  proprietaireIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour proprietaireId (IN) */
  proprietaireIds?: number[];
  /** Filtre proprietaireId différent de toutes ces valeurs (NOT IN) */
  proprietaireIdIsDifferentList?: number[];

  /** Filtre proprietaireId supérieur ou égal à cette valeur */
  proprietaireIdMin?: number;

  /** Filtre proprietaireId inférieur ou égal à cette valeur */
  proprietaireIdMax?: number;

  /** Filtre proprietaireId strictement supérieur à cette valeur */
  proprietaireIdGreaterThan?: number;

  /** Filtre proprietaireId strictement inférieur à cette valeur */
  proprietaireIdLessThan?: number;

  /** Filtre proprietaireId différent de cette valeur */
  proprietaireIdIsDifferent?: number;

  /** Filtre par valeur exacte de surface */
  surface?: number;
  /** Filtre IsNull sur surface (true = IS NULL, false = IS NOT NULL) */
  surfaceIsNull?: boolean;
  /** Filtre par liste de valeurs pour surface (IN) */
  surfaces?: number[];
  /** Filtre surface différent de toutes ces valeurs (NOT IN) */
  surfaceIsDifferentList?: number[];

  /** Filtre surface supérieur ou égal à cette valeur */
  surfaceMin?: number;

  /** Filtre surface inférieur ou égal à cette valeur */
  surfaceMax?: number;

  /** Filtre surface strictement supérieur à cette valeur */
  surfaceGreaterThan?: number;

  /** Filtre surface strictement inférieur à cette valeur */
  surfaceLessThan?: number;

  /** Filtre surface différent de cette valeur */
  surfaceIsDifferent?: number;

  /** Filtre par valeur exacte de surfaceTerrain */
  surfaceTerrain?: number;
  /** Filtre IsNull sur surfaceTerrain (true = IS NULL, false = IS NOT NULL) */
  surfaceTerrainIsNull?: boolean;
  /** Filtre par liste de valeurs pour surfaceTerrain (IN) */
  surfaceTerrains?: number[];
  /** Filtre surfaceTerrain différent de toutes ces valeurs (NOT IN) */
  surfaceTerrainIsDifferentList?: number[];

  /** Filtre surfaceTerrain supérieur ou égal à cette valeur */
  surfaceTerrainMin?: number;

  /** Filtre surfaceTerrain inférieur ou égal à cette valeur */
  surfaceTerrainMax?: number;

  /** Filtre surfaceTerrain strictement supérieur à cette valeur */
  surfaceTerrainGreaterThan?: number;

  /** Filtre surfaceTerrain strictement inférieur à cette valeur */
  surfaceTerrainLessThan?: number;

  /** Filtre surfaceTerrain différent de cette valeur */
  surfaceTerrainIsDifferent?: number;

  /** Filtre par valeur exacte de nbPieces */
  nbPieces?: number;
  /** Filtre IsNull sur nbPieces (true = IS NULL, false = IS NOT NULL) */
  nbPiecesIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbPieces (IN) */
  nbPiecess?: number[];
  /** Filtre nbPieces différent de toutes ces valeurs (NOT IN) */
  nbPiecesIsDifferentList?: number[];

  /** Filtre nbPieces supérieur ou égal à cette valeur */
  nbPiecesMin?: number;

  /** Filtre nbPieces inférieur ou égal à cette valeur */
  nbPiecesMax?: number;

  /** Filtre nbPieces strictement supérieur à cette valeur */
  nbPiecesGreaterThan?: number;

  /** Filtre nbPieces strictement inférieur à cette valeur */
  nbPiecesLessThan?: number;

  /** Filtre nbPieces différent de cette valeur */
  nbPiecesIsDifferent?: number;

  /** Filtre par valeur exacte de nbChambres */
  nbChambres?: number;
  /** Filtre IsNull sur nbChambres (true = IS NULL, false = IS NOT NULL) */
  nbChambresIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbChambres (IN) */
  nbChambress?: number[];
  /** Filtre nbChambres différent de toutes ces valeurs (NOT IN) */
  nbChambresIsDifferentList?: number[];

  /** Filtre nbChambres supérieur ou égal à cette valeur */
  nbChambresMin?: number;

  /** Filtre nbChambres inférieur ou égal à cette valeur */
  nbChambresMax?: number;

  /** Filtre nbChambres strictement supérieur à cette valeur */
  nbChambresGreaterThan?: number;

  /** Filtre nbChambres strictement inférieur à cette valeur */
  nbChambresLessThan?: number;

  /** Filtre nbChambres différent de cette valeur */
  nbChambresIsDifferent?: number;

  /** Filtre par valeur exacte de etage */
  etage?: number;
  /** Filtre IsNull sur etage (true = IS NULL, false = IS NOT NULL) */
  etageIsNull?: boolean;
  /** Filtre par liste de valeurs pour etage (IN) */
  etages?: number[];
  /** Filtre etage différent de toutes ces valeurs (NOT IN) */
  etageIsDifferentList?: number[];

  /** Filtre etage supérieur ou égal à cette valeur */
  etageMin?: number;

  /** Filtre etage inférieur ou égal à cette valeur */
  etageMax?: number;

  /** Filtre etage strictement supérieur à cette valeur */
  etageGreaterThan?: number;

  /** Filtre etage strictement inférieur à cette valeur */
  etageLessThan?: number;

  /** Filtre etage différent de cette valeur */
  etageIsDifferent?: number;

  /** Filtre par valeur exacte de ascenseur */
  ascenseur?: boolean;
  /** Filtre IsNull sur ascenseur (true = IS NULL, false = IS NOT NULL) */
  ascenseurIsNull?: boolean;
  /** Filtre ascenseur différent de cette valeur (NOT EQUAL) */
  ascenseurIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour ascenseur (IN) */
  ascenseurs?: boolean[];
  /** Filtre ascenseur différent de toutes ces valeurs (NOT IN) */
  ascenseurIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de stationnement */
  stationnement?: string;
  /** Filtre IsNull sur stationnement (true = IS NULL, false = IS NOT NULL) */
  stationnementIsNull?: boolean;
  /** Filtre stationnement différent de cette valeur (NOT EQUAL) */
  stationnementIsDifferent?: string;
  /** Filtre par liste de valeurs pour stationnement (IN) */
  stationnements?: string[];
  /** Filtre stationnement différent de toutes ces valeurs (NOT IN) */
  stationnementIsDifferentList?: string[];

  /** Filtre stationnement contenant cette valeur (LIKE %value%) */
  stationnementLike?: string;

  /** Filtre stationnement commençant par cette valeur (LIKE value%) */
  stationnementStartsWith?: string;

  /** Filtre stationnement terminant par cette valeur (LIKE %value) */
  stationnementEndsWith?: string;

  /** Filtre stationnement ne contenant pas cette valeur (NOT LIKE %value%) */
  stationnementIsDifferentLike?: string;

  /** Filtre par valeur exacte de anneeConstruction */
  anneeConstruction?: number;
  /** Filtre IsNull sur anneeConstruction (true = IS NULL, false = IS NOT NULL) */
  anneeConstructionIsNull?: boolean;
  /** Filtre par liste de valeurs pour anneeConstruction (IN) */
  anneeConstructions?: number[];
  /** Filtre anneeConstruction différent de toutes ces valeurs (NOT IN) */
  anneeConstructionIsDifferentList?: number[];

  /** Filtre anneeConstruction supérieur ou égal à cette valeur */
  anneeConstructionMin?: number;

  /** Filtre anneeConstruction inférieur ou égal à cette valeur */
  anneeConstructionMax?: number;

  /** Filtre anneeConstruction strictement supérieur à cette valeur */
  anneeConstructionGreaterThan?: number;

  /** Filtre anneeConstruction strictement inférieur à cette valeur */
  anneeConstructionLessThan?: number;

  /** Filtre anneeConstruction différent de cette valeur */
  anneeConstructionIsDifferent?: number;

  /** Filtre par valeur exacte de dpe */
  dpe?: string;
  /** Filtre IsNull sur dpe (true = IS NULL, false = IS NOT NULL) */
  dpeIsNull?: boolean;
  /** Filtre dpe différent de cette valeur (NOT EQUAL) */
  dpeIsDifferent?: string;
  /** Filtre par liste de valeurs pour dpe (IN) */
  dpes?: string[];
  /** Filtre dpe différent de toutes ces valeurs (NOT IN) */
  dpeIsDifferentList?: string[];

  /** Filtre dpe contenant cette valeur (LIKE %value%) */
  dpeLike?: string;

  /** Filtre dpe commençant par cette valeur (LIKE value%) */
  dpeStartsWith?: string;

  /** Filtre dpe terminant par cette valeur (LIKE %value) */
  dpeEndsWith?: string;

  /** Filtre dpe ne contenant pas cette valeur (NOT LIKE %value%) */
  dpeIsDifferentLike?: string;

  /** Filtre par valeur exacte de ges */
  ges?: string;
  /** Filtre IsNull sur ges (true = IS NULL, false = IS NOT NULL) */
  gesIsNull?: boolean;
  /** Filtre ges différent de cette valeur (NOT EQUAL) */
  gesIsDifferent?: string;
  /** Filtre par liste de valeurs pour ges (IN) */
  gess?: string[];
  /** Filtre ges différent de toutes ces valeurs (NOT IN) */
  gesIsDifferentList?: string[];

  /** Filtre ges contenant cette valeur (LIKE %value%) */
  gesLike?: string;

  /** Filtre ges commençant par cette valeur (LIKE value%) */
  gesStartsWith?: string;

  /** Filtre ges terminant par cette valeur (LIKE %value) */
  gesEndsWith?: string;

  /** Filtre ges ne contenant pas cette valeur (NOT LIKE %value%) */
  gesIsDifferentLike?: string;

  /** Filtre par valeur exacte de chauffage */
  chauffage?: string;
  /** Filtre IsNull sur chauffage (true = IS NULL, false = IS NOT NULL) */
  chauffageIsNull?: boolean;
  /** Filtre chauffage différent de cette valeur (NOT EQUAL) */
  chauffageIsDifferent?: string;
  /** Filtre par liste de valeurs pour chauffage (IN) */
  chauffages?: string[];
  /** Filtre chauffage différent de toutes ces valeurs (NOT IN) */
  chauffageIsDifferentList?: string[];

  /** Filtre chauffage contenant cette valeur (LIKE %value%) */
  chauffageLike?: string;

  /** Filtre chauffage commençant par cette valeur (LIKE value%) */
  chauffageStartsWith?: string;

  /** Filtre chauffage terminant par cette valeur (LIKE %value) */
  chauffageEndsWith?: string;

  /** Filtre chauffage ne contenant pas cette valeur (NOT LIKE %value%) */
  chauffageIsDifferentLike?: string;

  /** Filtre par valeur exacte de climatisation */
  climatisation?: boolean;
  /** Filtre IsNull sur climatisation (true = IS NULL, false = IS NOT NULL) */
  climatisationIsNull?: boolean;
  /** Filtre climatisation différent de cette valeur (NOT EQUAL) */
  climatisationIsDifferent?: boolean;
  /** Filtre par liste de valeurs pour climatisation (IN) */
  climatisations?: boolean[];
  /** Filtre climatisation différent de toutes ces valeurs (NOT IN) */
  climatisationIsDifferentList?: boolean[];

  /** Filtre par valeur exacte de etatGeneral */
  etatGeneral?: string;
  /** Filtre IsNull sur etatGeneral (true = IS NULL, false = IS NOT NULL) */
  etatGeneralIsNull?: boolean;
  /** Filtre etatGeneral différent de cette valeur (NOT EQUAL) */
  etatGeneralIsDifferent?: string;
  /** Filtre par liste de valeurs pour etatGeneral (IN) */
  etatGenerals?: string[];
  /** Filtre etatGeneral différent de toutes ces valeurs (NOT IN) */
  etatGeneralIsDifferentList?: string[];

  /** Filtre etatGeneral contenant cette valeur (LIKE %value%) */
  etatGeneralLike?: string;

  /** Filtre etatGeneral commençant par cette valeur (LIKE value%) */
  etatGeneralStartsWith?: string;

  /** Filtre etatGeneral terminant par cette valeur (LIKE %value) */
  etatGeneralEndsWith?: string;

  /** Filtre etatGeneral ne contenant pas cette valeur (NOT LIKE %value%) */
  etatGeneralIsDifferentLike?: string;

  /** Filtre par valeur exacte de travaux */
  travaux?: string;
  /** Filtre IsNull sur travaux (true = IS NULL, false = IS NOT NULL) */
  travauxIsNull?: boolean;
  /** Filtre travaux différent de cette valeur (NOT EQUAL) */
  travauxIsDifferent?: string;
  /** Filtre par liste de valeurs pour travaux (IN) */
  travauxs?: string[];
  /** Filtre travaux différent de toutes ces valeurs (NOT IN) */
  travauxIsDifferentList?: string[];

  /** Filtre travaux contenant cette valeur (LIKE %value%) */
  travauxLike?: string;

  /** Filtre travaux commençant par cette valeur (LIKE value%) */
  travauxStartsWith?: string;

  /** Filtre travaux terminant par cette valeur (LIKE %value) */
  travauxEndsWith?: string;

  /** Filtre travaux ne contenant pas cette valeur (NOT LIKE %value%) */
  travauxIsDifferentLike?: string;

  /** Filtre par valeur exacte de prixAffiche */
  prixAffiche?: number;
  /** Filtre IsNull sur prixAffiche (true = IS NULL, false = IS NOT NULL) */
  prixAfficheIsNull?: boolean;
  /** Filtre par liste de valeurs pour prixAffiche (IN) */
  prixAffiches?: number[];
  /** Filtre prixAffiche différent de toutes ces valeurs (NOT IN) */
  prixAfficheIsDifferentList?: number[];

  /** Filtre prixAffiche supérieur ou égal à cette valeur */
  prixAfficheMin?: number;

  /** Filtre prixAffiche inférieur ou égal à cette valeur */
  prixAfficheMax?: number;

  /** Filtre prixAffiche strictement supérieur à cette valeur */
  prixAfficheGreaterThan?: number;

  /** Filtre prixAffiche strictement inférieur à cette valeur */
  prixAfficheLessThan?: number;

  /** Filtre prixAffiche différent de cette valeur */
  prixAfficheIsDifferent?: number;

  /** Filtre par valeur exacte de charges */
  charges?: number;
  /** Filtre IsNull sur charges (true = IS NULL, false = IS NOT NULL) */
  chargesIsNull?: boolean;
  /** Filtre par liste de valeurs pour charges (IN) */
  chargess?: number[];
  /** Filtre charges différent de toutes ces valeurs (NOT IN) */
  chargesIsDifferentList?: number[];

  /** Filtre charges supérieur ou égal à cette valeur */
  chargesMin?: number;

  /** Filtre charges inférieur ou égal à cette valeur */
  chargesMax?: number;

  /** Filtre charges strictement supérieur à cette valeur */
  chargesGreaterThan?: number;

  /** Filtre charges strictement inférieur à cette valeur */
  chargesLessThan?: number;

  /** Filtre charges différent de cette valeur */
  chargesIsDifferent?: number;

  /** Filtre par valeur exacte de disponibilite */
  disponibilite?: Date | string;
  /** Filtre IsNull sur disponibilite (true = IS NULL, false = IS NOT NULL) */
  disponibiliteIsNull?: boolean;
  /** Filtre par liste de valeurs pour disponibilite (IN) */
  disponibilites?: Date | string[];
  /** Filtre disponibilite différent de toutes ces valeurs (NOT IN) */
  disponibiliteIsDifferentList?: Date | string[];

  /** Filtre disponibilite à partir de cette date (incluse) */
  disponibiliteFrom?: Date | string;

  /** Filtre disponibilite jusqu'à cette date (incluse) */
  disponibiliteTo?: Date | string;

  /** Filtre disponibilite strictement après cette date */
  disponibiliteAfter?: Date | string;

  /** Filtre disponibilite strictement avant cette date */
  disponibiliteBefore?: Date | string;

  /** Filtre disponibilite différent de cette date */
  disponibiliteIsDifferent?: Date | string;

  /** Filtre par valeur exacte de dateCommercialisation */
  dateCommercialisation?: Date | string;
  /** Filtre IsNull sur dateCommercialisation (true = IS NULL, false = IS NOT NULL) */
  dateCommercialisationIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateCommercialisation (IN) */
  dateCommercialisations?: Date | string[];
  /** Filtre dateCommercialisation différent de toutes ces valeurs (NOT IN) */
  dateCommercialisationIsDifferentList?: Date | string[];

  /** Filtre dateCommercialisation à partir de cette date (incluse) */
  dateCommercialisationFrom?: Date | string;

  /** Filtre dateCommercialisation jusqu'à cette date (incluse) */
  dateCommercialisationTo?: Date | string;

  /** Filtre dateCommercialisation strictement après cette date */
  dateCommercialisationAfter?: Date | string;

  /** Filtre dateCommercialisation strictement avant cette date */
  dateCommercialisationBefore?: Date | string;

  /** Filtre dateCommercialisation différent de cette date */
  dateCommercialisationIsDifferent?: Date | string;

  /** Filtre par valeur exacte de pointsForts */
  pointsForts?: string;
  /** Filtre IsNull sur pointsForts (true = IS NULL, false = IS NOT NULL) */
  pointsFortsIsNull?: boolean;
  /** Filtre pointsForts différent de cette valeur (NOT EQUAL) */
  pointsFortsIsDifferent?: string;
  /** Filtre par liste de valeurs pour pointsForts (IN) */
  pointsFortss?: string[];
  /** Filtre pointsForts différent de toutes ces valeurs (NOT IN) */
  pointsFortsIsDifferentList?: string[];

  /** Filtre pointsForts contenant cette valeur (LIKE %value%) */
  pointsFortsLike?: string;

  /** Filtre pointsForts commençant par cette valeur (LIKE value%) */
  pointsFortsStartsWith?: string;

  /** Filtre pointsForts terminant par cette valeur (LIKE %value) */
  pointsFortsEndsWith?: string;

  /** Filtre pointsForts ne contenant pas cette valeur (NOT LIKE %value%) */
  pointsFortsIsDifferentLike?: string;

  /** Filtre par valeur exacte de pointsFaibles */
  pointsFaibles?: string;
  /** Filtre IsNull sur pointsFaibles (true = IS NULL, false = IS NOT NULL) */
  pointsFaiblesIsNull?: boolean;
  /** Filtre pointsFaibles différent de cette valeur (NOT EQUAL) */
  pointsFaiblesIsDifferent?: string;
  /** Filtre par liste de valeurs pour pointsFaibles (IN) */
  pointsFaibless?: string[];
  /** Filtre pointsFaibles différent de toutes ces valeurs (NOT IN) */
  pointsFaiblesIsDifferentList?: string[];

  /** Filtre pointsFaibles contenant cette valeur (LIKE %value%) */
  pointsFaiblesLike?: string;

  /** Filtre pointsFaibles commençant par cette valeur (LIKE value%) */
  pointsFaiblesStartsWith?: string;

  /** Filtre pointsFaibles terminant par cette valeur (LIKE %value) */
  pointsFaiblesEndsWith?: string;

  /** Filtre pointsFaibles ne contenant pas cette valeur (NOT LIKE %value%) */
  pointsFaiblesIsDifferentLike?: string;

  /** Filtre par valeur exacte de photos */
  photos?: unknown;
  /** Filtre IsNull sur photos (true = IS NULL, false = IS NOT NULL) */
  photosIsNull?: boolean;
  /** Filtre photos différent de cette valeur (NOT EQUAL) */
  photosIsDifferent?: unknown;
  /** Filtre par liste de valeurs pour photos (IN) */
  photoss?: unknown[];
  /** Filtre photos différent de toutes ces valeurs (NOT IN) */
  photosIsDifferentList?: unknown[];

  /** Filtre par valeur exacte de documents */
  documents?: unknown;
  /** Filtre IsNull sur documents (true = IS NULL, false = IS NOT NULL) */
  documentsIsNull?: boolean;
  /** Filtre documents différent de cette valeur (NOT EQUAL) */
  documentsIsDifferent?: unknown;
  /** Filtre par liste de valeurs pour documents (IN) */
  documentss?: unknown[];
  /** Filtre documents différent de toutes ces valeurs (NOT IN) */
  documentsIsDifferentList?: unknown[];

  /** Filtre par valeur exacte de statut */
  statut?: string;
  /** Filtre IsNull sur statut (true = IS NULL, false = IS NOT NULL) */
  statutIsNull?: boolean;
  /** Filtre statut différent de cette valeur (NOT EQUAL) */
  statutIsDifferent?: string;
  /** Filtre par liste de valeurs pour statut (IN) */
  statuts?: string[];
  /** Filtre statut différent de toutes ces valeurs (NOT IN) */
  statutIsDifferentList?: string[];

  /** Filtre statut contenant cette valeur (LIKE %value%) */
  statutLike?: string;

  /** Filtre statut commençant par cette valeur (LIKE value%) */
  statutStartsWith?: string;

  /** Filtre statut terminant par cette valeur (LIKE %value) */
  statutEndsWith?: string;

  /** Filtre statut ne contenant pas cette valeur (NOT LIKE %value%) */
  statutIsDifferentLike?: string;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où adresse est NULL).
   * false = INNER JOIN.
   * À configurer AVANT adresse.
   */
  includeAdresseEmpty?: boolean;

  /** Filtre imbriqué sur la navigation adresse. */
  adresse?: AdressesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où proprietaire est NULL).
   * false = INNER JOIN.
   * À configurer AVANT proprietaire.
   */
  includeProprietaireEmpty?: boolean;

  /** Filtre imbriqué sur la navigation proprietaire. */
  proprietaire?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où typeBien est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeBien.
   */
  includeTypebienEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeBien. */
  typeBien?: RefTypeBienCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur locations.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT locations.
   */
  locationsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont locations est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT locations.
   */
  includeLocationsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour locations.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT locations.
   */
  locationsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection locations. */
  locations?: LocationsCritereDTO;

  /**
   * Mode de filtrage de l'Include sur propertyHistoriquePrixes.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT propertyHistoriquePrixes.
   */
  propertyHistoriquePrixesFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont propertyHistoriquePrixes est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT propertyHistoriquePrixes.
   */
  includePropertyhistoriqueprixesEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour propertyHistoriquePrixes.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT propertyHistoriquePrixes.
   */
  propertyHistoriquePrixesMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection propertyHistoriquePrixes. */
  propertyHistoriquePrixes?: PropertyHistoriquePrixCritereDTO;

  /**
   * Mode de filtrage de l'Include sur rechercheBiens.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont rechercheBiens est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT rechercheBiens.
   */
  includeRecherchebiensEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour rechercheBiens.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection rechercheBiens. */
  rechercheBiens?: RechercheBiensCritereDTO;

  /**
   * Mode de filtrage de l'Include sur transactions.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT transactions.
   */
  transactionsFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont transactions est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT transactions.
   */
  includeTransactionsEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour transactions.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT transactions.
   */
  transactionsMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection transactions. */
  transactions?: TransactionsCritereDTO;

}
