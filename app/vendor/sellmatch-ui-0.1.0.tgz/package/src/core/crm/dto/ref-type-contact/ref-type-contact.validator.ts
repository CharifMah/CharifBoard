// gen-hash:f59f735aeb1f1ca5b256dad9e676b4c68cd898a58f774af686e81ae05cf435af
/**
 * Validator TypeScript pour RefTypeContactDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeContactDTO } from './ref-type-contact.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeContactDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeContactFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeContactDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeContactDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeContactDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeContactValidator: Record<string, RefTypeContactFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeContactDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeContactDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeContactDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeContactFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeContactDTO) => string | null) | null {
  const lRule: RefTypeContactFieldRule | undefined = RefTypeContactValidator[pKey];
  return lRule ? lRule.Validate : null;
}
