// gen-hash:3304e8e9036aeea7decce65d7626e03496e7660cce768a77e4b62f78e695a772
/**
 * DTO for table: prospections
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import type { RefTypeProspectionDTO } from '../ref-type-prospection/ref-type-prospection.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface ProspectionsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  action?: string;
  dateAction?: Date | string;
  typeProspectionId?: number;
  quantite?: number;
  tempsPasseMinutes?: number;
  nbContacts?: number;
  nbRendezVous?: number;
  nbEstimations?: number;
  nbMandats?: number;
  caGenere?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;
  adresseId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  adresse?: AdressesDTO;
  /** Navigation property vers RefTypeProspection */
  typeProspection?: RefTypeProspectionDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;
}
