// gen-hash:b28c5b80679fa71e743788e6859139cf043399a306088a4666f690c3ba7e9e0d
/**
 * Validator TypeScript pour RefStatutRechercheDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefStatutRechercheDTO } from './ref-statut-recherche.dto';

/**
 * Interface d'une règle de validation pour un champ de RefStatutRechercheDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefStatutRechercheFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefStatutRechercheDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefStatutRechercheDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefStatutRechercheDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefStatutRechercheValidator: Record<string, RefStatutRechercheFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefStatutRechercheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefStatutRechercheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefStatutRechercheDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefStatutRechercheFieldValidator(pKey: string): ((pValue: unknown, pRow: RefStatutRechercheDTO) => string | null) | null {
  const lRule: RefStatutRechercheFieldRule | undefined = RefStatutRechercheValidator[pKey];
  return lRule ? lRule.Validate : null;
}
