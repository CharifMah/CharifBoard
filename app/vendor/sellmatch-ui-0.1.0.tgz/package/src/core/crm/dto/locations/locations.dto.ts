// gen-hash:9e4fa6890b7ee06528f5be3bde590f69eafaa30d951056a511c42c559dc07494
/**
 * DTO for table: locations
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { AdressesDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.dto';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { LocationContactsDTO } from '../location-contacts/location-contacts.dto';
import type { PropertiesDTO } from '../properties/properties.dto';
import type { RechercheBiensDTO } from '../recherche-biens/recherche-biens.dto';
import type { RefEtatCommercialDTO } from '../ref-etat-commercial/ref-etat-commercial.dto';
import type { RefMotifBlocageDTO } from '../ref-motif-blocage/ref-motif-blocage.dto';
import type { RefNatureAffaireDTO } from '../ref-nature-affaire/ref-nature-affaire.dto';
import type { RefStatutAffaireDTO } from '../ref-statut-affaire/ref-statut-affaire.dto';
import type { UsersDTO } from '../../../../core/sellmatchdb/dto/users/users.dto';

export interface LocationsDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  reference?: string;
  propertyId?: number;
  adresseId?: number;
  natureAffaireId?: number;
  statutId?: number;
  etatCommercialId?: number;
  motifBlocageId?: number;
  clientId?: number;
  locatairePotentiel?: string;
  dateEstimation?: Date | string;
  datePriseMandat?: Date | string;
  dateCommercialisation?: Date | string;
  dateSignatureBailEntree?: Date | string;
  notes?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  userId?: number;
  loyerHc?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Adresses */
  adresse?: AdressesDTO;
  /** Navigation property vers Contacts */
  client?: ContactsDTO;
  /** Navigation property vers RefEtatCommercial */
  etatCommercial?: RefEtatCommercialDTO;
  /** Navigation property vers RefMotifBlocage */
  motifBlocage?: RefMotifBlocageDTO;
  /** Navigation property vers RefNatureAffaire */
  natureAffaire?: RefNatureAffaireDTO;
  /** Navigation property vers Properties */
  property?: PropertiesDTO;
  /** Navigation property vers RefStatutAffaire */
  statut?: RefStatutAffaireDTO;
  /** Navigation property vers Users */
  user?: UsersDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de LocationContacts */
  locationContacts?: LocationContactsDTO[];
  /** Collection de RechercheBiens */
  rechercheBiens?: RechercheBiensDTO[];
}
