// gen-hash:95c34f2506c757a020c4fd87451ef77adebd9dac97dcc6172f66cb754177cefa
/**
 * Validator TypeScript pour RecherchesDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RecherchesDTO } from './recherches.dto';

/**
 * Interface d'une règle de validation pour un champ de RecherchesDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RecherchesFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RecherchesDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RecherchesDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RecherchesDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RecherchesValidator: Record<string, RecherchesFieldRule> = {
  // - cm - nomProjet : optionnel, longueur max 255
  nomProjet: {
    Key: 'nomProjet',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'nomProjet ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - contactId : obligatoire
  contactId: {
    Key: 'contactId',
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'contactId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - typeRechercheId : obligatoire
  typeRechercheId: {
    Key: 'typeRechercheId',
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'typeRechercheId est obligatoire.';
      }
      return null;
    }
  },

  // - cm - secteurRecherche : optionnel, longueur max 255
  secteurRecherche: {
    Key: 'secteurRecherche',
    MaxLength: 255,
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 255) {
        return 'secteurRecherche ne doit pas dépasser 255 caractères.';
      }
      return null;
    }
  },

  // - cm - createdAt : obligatoire
  createdAt: {
    Key: 'createdAt',
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'createdAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - updatedAt : obligatoire
  updatedAt: {
    Key: 'updatedAt',
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'updatedAt est obligatoire.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: RecherchesDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RecherchesDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRecherchesFieldValidator(pKey: string): ((pValue: unknown, pRow: RecherchesDTO) => string | null) | null {
  const lRule: RecherchesFieldRule | undefined = RecherchesValidator[pKey];
  return lRule ? lRule.Validate : null;
}
