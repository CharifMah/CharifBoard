// gen-hash:6b15595e17f8bb8f6b59cd92014c9950b5fb1d151cb9b56697fb474fa6ce4a9b
/**
 * DTO for table: recherche_biens
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { LocationsDTO } from '../locations/locations.dto';
import type { PropertiesDTO } from '../properties/properties.dto';
import type { RecherchesDTO } from '../recherches/recherches.dto';
import type { TransactionsDTO } from '../transactions/transactions.dto';

export interface RechercheBiensDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  rechercheId?: number;
  propertyId?: number;
  transactionId?: number;
  locationId?: number;
  score?: number;
  createdAt?: Date | string;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers Locations */
  location?: LocationsDTO;
  /** Navigation property vers Properties */
  property?: PropertiesDTO;
  /** Navigation property vers Recherches */
  recherche?: RecherchesDTO;
  /** Navigation property vers Transactions */
  transaction?: TransactionsDTO;
}
