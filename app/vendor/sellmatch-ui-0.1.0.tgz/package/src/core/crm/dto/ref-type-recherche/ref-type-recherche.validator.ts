// gen-hash:2d06ac536001ce669c235f49b4498442b2c5c5b1e58753f6972c8b11e980da58
/**
 * Validator TypeScript pour RefTypeRechercheDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeRechercheDTO } from './ref-type-recherche.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeRechercheDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeRechercheFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeRechercheDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeRechercheDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeRechercheDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeRechercheValidator: Record<string, RefTypeRechercheFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeRechercheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeRechercheDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeRechercheDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeRechercheFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeRechercheDTO) => string | null) | null {
  const lRule: RefTypeRechercheFieldRule | undefined = RefTypeRechercheValidator[pKey];
  return lRule ? lRule.Validate : null;
}
