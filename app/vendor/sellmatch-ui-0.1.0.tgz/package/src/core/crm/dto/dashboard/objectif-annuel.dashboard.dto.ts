/**
 * DTO front miroir de `SellMatch.DTO.crm.DTO.Dashboard.ObjectifAnnuelDashboardDTO`.
 * Représente le résultat de la carte "Objectif annuel" du dashboard.
 */
export interface ObjectifAnnuelDashboardDTO {
  /** Montant de l'objectif annuel défini dans les paramètres. */
  objectif: number;
  /** Montant déjà atteint (CA encaissé sur l'année). */
  atteint: number;
  /** Montant restant à atteindre (0 si dépassé). */
  restant: number;
  /** Pourcentage de progression (0-100). */
  pct: number;
  /**
   * Nombre d'affaires VENDU sans date de signature authentique renseignée.
   * Ces affaires sont exclues du calcul du CA encaissé (la date d'encaissement est inconnue).
   * Affiché en warning sur le dashboard pour inviter l'utilisateur à compléter la grille transactions.
   */
  venduSansDate: number;
  /**
   * Nombre d'affaires LOUE sans date de signature de bail d'entrée renseignée.
   * Mêmes règles que `venduSansDate` mais pour les locations.
   */
  loueSansDate: number;
}
