// gen-hash:62ef8a520278c34fb683a5ea2557c1a876c22ef697d5b404a48763598bf64c12
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { AdressesCritereDTO } from '../../../../core/sellmatchdb/dto/adresses/adresses.critere';
import { RefTypeProspectionCritereDTO } from '../ref-type-prospection/ref-type-prospection.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface ProspectionsCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de action */
  action?: string;
  /** Filtre IsNull sur action (true = IS NULL, false = IS NOT NULL) */
  actionIsNull?: boolean;
  /** Filtre action différent de cette valeur (NOT EQUAL) */
  actionIsDifferent?: string;
  /** Filtre par liste de valeurs pour action (IN) */
  actions?: string[];
  /** Filtre action différent de toutes ces valeurs (NOT IN) */
  actionIsDifferentList?: string[];

  /** Filtre action contenant cette valeur (LIKE %value%) */
  actionLike?: string;

  /** Filtre action commençant par cette valeur (LIKE value%) */
  actionStartsWith?: string;

  /** Filtre action terminant par cette valeur (LIKE %value) */
  actionEndsWith?: string;

  /** Filtre action ne contenant pas cette valeur (NOT LIKE %value%) */
  actionIsDifferentLike?: string;

  /** Filtre par valeur exacte de dateAction */
  dateAction?: Date | string;
  /** Filtre IsNull sur dateAction (true = IS NULL, false = IS NOT NULL) */
  dateActionIsNull?: boolean;
  /** Filtre par liste de valeurs pour dateAction (IN) */
  dateActions?: Date | string[];
  /** Filtre dateAction différent de toutes ces valeurs (NOT IN) */
  dateActionIsDifferentList?: Date | string[];

  /** Filtre dateAction à partir de cette date (incluse) */
  dateActionFrom?: Date | string;

  /** Filtre dateAction jusqu'à cette date (incluse) */
  dateActionTo?: Date | string;

  /** Filtre dateAction strictement après cette date */
  dateActionAfter?: Date | string;

  /** Filtre dateAction strictement avant cette date */
  dateActionBefore?: Date | string;

  /** Filtre dateAction différent de cette date */
  dateActionIsDifferent?: Date | string;

  /** Filtre par valeur exacte de typeProspectionId */
  typeProspectionId?: number;
  /** Filtre IsNull sur typeProspectionId (true = IS NULL, false = IS NOT NULL) */
  typeProspectionIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeProspectionId (IN) */
  typeProspectionIds?: number[];
  /** Filtre typeProspectionId différent de toutes ces valeurs (NOT IN) */
  typeProspectionIdIsDifferentList?: number[];

  /** Filtre typeProspectionId supérieur ou égal à cette valeur */
  typeProspectionIdMin?: number;

  /** Filtre typeProspectionId inférieur ou égal à cette valeur */
  typeProspectionIdMax?: number;

  /** Filtre typeProspectionId strictement supérieur à cette valeur */
  typeProspectionIdGreaterThan?: number;

  /** Filtre typeProspectionId strictement inférieur à cette valeur */
  typeProspectionIdLessThan?: number;

  /** Filtre typeProspectionId différent de cette valeur */
  typeProspectionIdIsDifferent?: number;

  /** Filtre par valeur exacte de quantite */
  quantite?: number;
  /** Filtre IsNull sur quantite (true = IS NULL, false = IS NOT NULL) */
  quantiteIsNull?: boolean;
  /** Filtre par liste de valeurs pour quantite (IN) */
  quantites?: number[];
  /** Filtre quantite différent de toutes ces valeurs (NOT IN) */
  quantiteIsDifferentList?: number[];

  /** Filtre quantite supérieur ou égal à cette valeur */
  quantiteMin?: number;

  /** Filtre quantite inférieur ou égal à cette valeur */
  quantiteMax?: number;

  /** Filtre quantite strictement supérieur à cette valeur */
  quantiteGreaterThan?: number;

  /** Filtre quantite strictement inférieur à cette valeur */
  quantiteLessThan?: number;

  /** Filtre quantite différent de cette valeur */
  quantiteIsDifferent?: number;

  /** Filtre par valeur exacte de tempsPasseMinutes */
  tempsPasseMinutes?: number;
  /** Filtre IsNull sur tempsPasseMinutes (true = IS NULL, false = IS NOT NULL) */
  tempsPasseMinutesIsNull?: boolean;
  /** Filtre par liste de valeurs pour tempsPasseMinutes (IN) */
  tempsPasseMinutess?: number[];
  /** Filtre tempsPasseMinutes différent de toutes ces valeurs (NOT IN) */
  tempsPasseMinutesIsDifferentList?: number[];

  /** Filtre tempsPasseMinutes supérieur ou égal à cette valeur */
  tempsPasseMinutesMin?: number;

  /** Filtre tempsPasseMinutes inférieur ou égal à cette valeur */
  tempsPasseMinutesMax?: number;

  /** Filtre tempsPasseMinutes strictement supérieur à cette valeur */
  tempsPasseMinutesGreaterThan?: number;

  /** Filtre tempsPasseMinutes strictement inférieur à cette valeur */
  tempsPasseMinutesLessThan?: number;

  /** Filtre tempsPasseMinutes différent de cette valeur */
  tempsPasseMinutesIsDifferent?: number;

  /** Filtre par valeur exacte de nbContacts */
  nbContacts?: number;
  /** Filtre IsNull sur nbContacts (true = IS NULL, false = IS NOT NULL) */
  nbContactsIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbContacts (IN) */
  nbContactss?: number[];
  /** Filtre nbContacts différent de toutes ces valeurs (NOT IN) */
  nbContactsIsDifferentList?: number[];

  /** Filtre nbContacts supérieur ou égal à cette valeur */
  nbContactsMin?: number;

  /** Filtre nbContacts inférieur ou égal à cette valeur */
  nbContactsMax?: number;

  /** Filtre nbContacts strictement supérieur à cette valeur */
  nbContactsGreaterThan?: number;

  /** Filtre nbContacts strictement inférieur à cette valeur */
  nbContactsLessThan?: number;

  /** Filtre nbContacts différent de cette valeur */
  nbContactsIsDifferent?: number;

  /** Filtre par valeur exacte de nbRendezVous */
  nbRendezVous?: number;
  /** Filtre IsNull sur nbRendezVous (true = IS NULL, false = IS NOT NULL) */
  nbRendezVousIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbRendezVous (IN) */
  nbRendezVouss?: number[];
  /** Filtre nbRendezVous différent de toutes ces valeurs (NOT IN) */
  nbRendezVousIsDifferentList?: number[];

  /** Filtre nbRendezVous supérieur ou égal à cette valeur */
  nbRendezVousMin?: number;

  /** Filtre nbRendezVous inférieur ou égal à cette valeur */
  nbRendezVousMax?: number;

  /** Filtre nbRendezVous strictement supérieur à cette valeur */
  nbRendezVousGreaterThan?: number;

  /** Filtre nbRendezVous strictement inférieur à cette valeur */
  nbRendezVousLessThan?: number;

  /** Filtre nbRendezVous différent de cette valeur */
  nbRendezVousIsDifferent?: number;

  /** Filtre par valeur exacte de nbEstimations */
  nbEstimations?: number;
  /** Filtre IsNull sur nbEstimations (true = IS NULL, false = IS NOT NULL) */
  nbEstimationsIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbEstimations (IN) */
  nbEstimationss?: number[];
  /** Filtre nbEstimations différent de toutes ces valeurs (NOT IN) */
  nbEstimationsIsDifferentList?: number[];

  /** Filtre nbEstimations supérieur ou égal à cette valeur */
  nbEstimationsMin?: number;

  /** Filtre nbEstimations inférieur ou égal à cette valeur */
  nbEstimationsMax?: number;

  /** Filtre nbEstimations strictement supérieur à cette valeur */
  nbEstimationsGreaterThan?: number;

  /** Filtre nbEstimations strictement inférieur à cette valeur */
  nbEstimationsLessThan?: number;

  /** Filtre nbEstimations différent de cette valeur */
  nbEstimationsIsDifferent?: number;

  /** Filtre par valeur exacte de nbMandats */
  nbMandats?: number;
  /** Filtre IsNull sur nbMandats (true = IS NULL, false = IS NOT NULL) */
  nbMandatsIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbMandats (IN) */
  nbMandatss?: number[];
  /** Filtre nbMandats différent de toutes ces valeurs (NOT IN) */
  nbMandatsIsDifferentList?: number[];

  /** Filtre nbMandats supérieur ou égal à cette valeur */
  nbMandatsMin?: number;

  /** Filtre nbMandats inférieur ou égal à cette valeur */
  nbMandatsMax?: number;

  /** Filtre nbMandats strictement supérieur à cette valeur */
  nbMandatsGreaterThan?: number;

  /** Filtre nbMandats strictement inférieur à cette valeur */
  nbMandatsLessThan?: number;

  /** Filtre nbMandats différent de cette valeur */
  nbMandatsIsDifferent?: number;

  /** Filtre par valeur exacte de caGenere */
  caGenere?: number;
  /** Filtre IsNull sur caGenere (true = IS NULL, false = IS NOT NULL) */
  caGenereIsNull?: boolean;
  /** Filtre par liste de valeurs pour caGenere (IN) */
  caGeneres?: number[];
  /** Filtre caGenere différent de toutes ces valeurs (NOT IN) */
  caGenereIsDifferentList?: number[];

  /** Filtre caGenere supérieur ou égal à cette valeur */
  caGenereMin?: number;

  /** Filtre caGenere inférieur ou égal à cette valeur */
  caGenereMax?: number;

  /** Filtre caGenere strictement supérieur à cette valeur */
  caGenereGreaterThan?: number;

  /** Filtre caGenere strictement inférieur à cette valeur */
  caGenereLessThan?: number;

  /** Filtre caGenere différent de cette valeur */
  caGenereIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre IsNull sur createdAt (true = IS NULL, false = IS NOT NULL) */
  createdAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre IsNull sur updatedAt (true = IS NULL, false = IS NOT NULL) */
  updatedAtIsNull?: boolean;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  /** Filtre par valeur exacte de adresseId */
  adresseId?: number;
  /** Filtre IsNull sur adresseId (true = IS NULL, false = IS NOT NULL) */
  adresseIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour adresseId (IN) */
  adresseIds?: number[];
  /** Filtre adresseId différent de toutes ces valeurs (NOT IN) */
  adresseIdIsDifferentList?: number[];

  /** Filtre adresseId supérieur ou égal à cette valeur */
  adresseIdMin?: number;

  /** Filtre adresseId inférieur ou égal à cette valeur */
  adresseIdMax?: number;

  /** Filtre adresseId strictement supérieur à cette valeur */
  adresseIdGreaterThan?: number;

  /** Filtre adresseId strictement inférieur à cette valeur */
  adresseIdLessThan?: number;

  /** Filtre adresseId différent de cette valeur */
  adresseIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où adresse est NULL).
   * false = INNER JOIN.
   * À configurer AVANT adresse.
   */
  includeAdresseEmpty?: boolean;

  /** Filtre imbriqué sur la navigation adresse. */
  adresse?: AdressesCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où typeProspection est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeProspection.
   */
  includeTypeprospectionEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeProspection. */
  typeProspection?: RefTypeProspectionCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

}
