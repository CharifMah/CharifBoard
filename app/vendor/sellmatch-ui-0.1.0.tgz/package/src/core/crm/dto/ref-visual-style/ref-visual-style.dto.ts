// gen-hash:710ff19fc8f94cd93a9a2caaf9dde81ab4c9d82c1baccbccbc9d81f9ba3bc7f7
/**
 * DTO for table: ref_visual_style
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { RefEtatCommercialDTO } from '../ref-etat-commercial/ref-etat-commercial.dto';
import type { RefMotifBlocageDTO } from '../ref-motif-blocage/ref-motif-blocage.dto';
import type { RefNatureAffaireDTO } from '../ref-nature-affaire/ref-nature-affaire.dto';
import type { RefOrigineContactDTO } from '../ref-origine-contact/ref-origine-contact.dto';
import type { RefOrigineRecrutementDTO } from '../ref-origine-recrutement/ref-origine-recrutement.dto';
import type { RefPeriodeObjectifDTO } from '../ref-periode-objectif/ref-periode-objectif.dto';
import type { RefPrioriteTacheDTO } from '../ref-priorite-tache/ref-priorite-tache.dto';
import type { RefStatutAffaireDTO } from '../ref-statut-affaire/ref-statut-affaire.dto';
import type { RefStatutRechercheDTO } from '../ref-statut-recherche/ref-statut-recherche.dto';
import type { RefStatutRecrutementDTO } from '../ref-statut-recrutement/ref-statut-recrutement.dto';
import type { RefTypeBienDTO } from '../ref-type-bien/ref-type-bien.dto';
import type { RefTypeContactDTO } from '../ref-type-contact/ref-type-contact.dto';
import type { RefTypeEchangeDTO } from '../ref-type-echange/ref-type-echange.dto';
import type { RefTypeProspectionDTO } from '../ref-type-prospection/ref-type-prospection.dto';
import type { RefTypeRechercheDTO } from '../ref-type-recherche/ref-type-recherche.dto';

export interface RefVisualStyleDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  icon?: string;
  color?: string;
  variant?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de RefEtatCommercial */
  refEtatCommercials?: RefEtatCommercialDTO[];
  /** Collection de RefMotifBlocage */
  refMotifBlocages?: RefMotifBlocageDTO[];
  /** Collection de RefNatureAffaire */
  refNatureAffaires?: RefNatureAffaireDTO[];
  /** Collection de RefOrigineContact */
  refOrigineContacts?: RefOrigineContactDTO[];
  /** Collection de RefOrigineRecrutement */
  refOrigineRecrutements?: RefOrigineRecrutementDTO[];
  /** Collection de RefPeriodeObjectif */
  refPeriodeObjectifs?: RefPeriodeObjectifDTO[];
  /** Collection de RefPrioriteTache */
  refPrioriteTaches?: RefPrioriteTacheDTO[];
  /** Collection de RefStatutAffaire */
  refStatutAffaires?: RefStatutAffaireDTO[];
  /** Collection de RefStatutRecherche */
  refStatutRecherches?: RefStatutRechercheDTO[];
  /** Collection de RefStatutRecrutement */
  refStatutRecrutements?: RefStatutRecrutementDTO[];
  /** Collection de RefTypeBien */
  refTypeBiens?: RefTypeBienDTO[];
  /** Collection de RefTypeContact */
  refTypeContacts?: RefTypeContactDTO[];
  /** Collection de RefTypeEchange */
  refTypeEchanges?: RefTypeEchangeDTO[];
  /** Collection de RefTypeProspection */
  refTypeProspections?: RefTypeProspectionDTO[];
  /** Collection de RefTypeRecherche */
  refTypeRecherches?: RefTypeRechercheDTO[];
}
