// gen-hash:e6288643823a1f3fe20c9c7c08c354e0ddb970a1d5b6bb7db08e18c522adf10b
/**
 * Validator TypeScript pour RefTypeTvaDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { RefTypeTvaDTO } from './ref-type-tva.dto';

/**
 * Interface d'une règle de validation pour un champ de RefTypeTvaDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface RefTypeTvaFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof RefTypeTvaDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: RefTypeTvaDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour RefTypeTvaDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const RefTypeTvaValidator: Record<string, RefTypeTvaFieldRule> = {
  // - cm - code : obligatoire, longueur max 50
  code: {
    Key: 'code',
    MaxLength: 50,
    Validate: (pValue: unknown, _pRow: RefTypeTvaDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'code est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 50) {
        return 'code ne doit pas dépasser 50 caractères.';
      }
      return null;
    }
  },

  // - cm - libelle : obligatoire, longueur max 100
  libelle: {
    Key: 'libelle',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: RefTypeTvaDTO): string | null => {
      if (pValue === null || pValue === undefined || pValue === '') {
        return 'libelle est obligatoire.';
      }
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'libelle ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de RefTypeTvaDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetRefTypeTvaFieldValidator(pKey: string): ((pValue: unknown, pRow: RefTypeTvaDTO) => string | null) | null {
  const lRule: RefTypeTvaFieldRule | undefined = RefTypeTvaValidator[pKey];
  return lRule ? lRule.Validate : null;
}
