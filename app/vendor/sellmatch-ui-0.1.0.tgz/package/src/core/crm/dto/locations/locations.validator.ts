// gen-hash:bc627f370f03e9220b0940140194695da37447a0feeca810bae5370cb259ee92
/**
 * Validator TypeScript pour LocationsDTO.
 * Règles issues du schéma BDD (longueurs max, NOT NULL, format email).
 * Équivalent frontend du validator FluentValidation côté backend.
 * Auto-generated - Do not modify manually
 */

import type { LocationsDTO } from './locations.dto';

/**
 * Interface d'une règle de validation pour un champ de LocationsDTO.
 * Retourne un message d'erreur si invalide, null si valide.
 */
export interface LocationsFieldRule {
  /** Clé du champ (propriété du DTO, camelCase). */
  Key: keyof LocationsDTO;
  /** Fonction de validation : retourne un message d'erreur ou null si valide. */
  Validate: (pValue: unknown, pRow: LocationsDTO) => string | null;
  /** Longueur max en caractères (miroir du `MaximumLength(n)` côté validator C#). Optionnel. */
  MaxLength?: number;
}

/**
 * Règles de validation pour LocationsDTO, indexées par clé de champ.
 * Utilisable avec app-input (customValidators) et app-grid (EditorValidator).
 */
export const LocationsValidator: Record<string, LocationsFieldRule> = {
  // - cm - reference : optionnel, longueur max 100
  reference: {
    Key: 'reference',
    MaxLength: 100,
    Validate: (pValue: unknown, _pRow: LocationsDTO): string | null => {
      if (typeof pValue === 'string' && pValue.length > 100) {
        return 'reference ne doit pas dépasser 100 caractères.';
      }
      return null;
    }
  },

  // - cm - userId : obligatoire
  userId: {
    Key: 'userId',
    Validate: (pValue: unknown, _pRow: LocationsDTO): string | null => {
      if (pValue === null || pValue === undefined) {
        return 'userId est obligatoire.';
      }
      return null;
    }
  },

};

/**
 * Récupère la fonction de validation pour un champ de LocationsDTO.
 * @param pKey La clé du champ.
 * @returns La fonction de validation ou null si aucune règle.
 */
export function GetLocationsFieldValidator(pKey: string): ((pValue: unknown, pRow: LocationsDTO) => string | null) | null {
  const lRule: LocationsFieldRule | undefined = LocationsValidator[pKey];
  return lRule ? lRule.Validate : null;
}
