// gen-hash:2144828eb5b96ada3c3c825cbc84aa2d7d2e4b007a92f7c04e73033d4200d38d
/**
 * DTO for table: ref_type_contact
 * Auto-generated - Do not modify manually
 */

import { BaseDTO } from '../../../../core/base/BaseDTO';
import type { ContactsDTO } from '../contacts/contacts.dto';
import type { RefVisualStyleDTO } from '../ref-visual-style/ref-visual-style.dto';

export interface RefTypeContactDTO extends BaseDTO {
  /** Primary Key */
  id?: number;
  code?: string;
  libelle?: string;
  isActive?: boolean;
  displayOrder?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  styleId?: number;

  // ----- Navigation properties (Many-to-One) -----
  /** Navigation property vers RefVisualStyle */
  style?: RefVisualStyleDTO;

  // ----- Navigation properties (One-to-Many) -----
  /** Collection de Contacts */
  contacts?: ContactsDTO[];
}
