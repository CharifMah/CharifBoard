// gen-hash:b1e8ea2a6b004d82aba95b77cfbe5357fb05c87ddc07d9b37287781cf3ce5248
import { BaseCritereDTO } from '../../../../core/base/base.critere';
import { ECollectionFilterMode } from '../../../../core/base/ECollectionFilterMode';
import { ECollectionMatch } from '../../../../core/base/ECollectionMatch';
import { ContactsCritereDTO } from '../contacts/contacts.critere';
import { RechercheBiensCritereDTO } from '../recherche-biens/recherche-biens.critere';
import { RefStatutRechercheCritereDTO } from '../ref-statut-recherche/ref-statut-recherche.critere';
import { RefTypeBienCritereDTO } from '../ref-type-bien/ref-type-bien.critere';
import { RefTypeRechercheCritereDTO } from '../ref-type-recherche/ref-type-recherche.critere';
import { UsersCritereDTO } from '../../../../core/sellmatchdb/dto/users/users.critere';

export interface RecherchesCritereDTO extends BaseCritereDTO {
  /** Filtre par valeur exacte de id */
  id?: number;
  /** Filtre par liste de valeurs pour id (IN) */
  ids?: number[];
  /** Filtre id différent de toutes ces valeurs (NOT IN) */
  idIsDifferentList?: number[];

  /** Filtre id supérieur ou égal à cette valeur */
  idMin?: number;

  /** Filtre id inférieur ou égal à cette valeur */
  idMax?: number;

  /** Filtre id strictement supérieur à cette valeur */
  idGreaterThan?: number;

  /** Filtre id strictement inférieur à cette valeur */
  idLessThan?: number;

  /** Filtre id différent de cette valeur */
  idIsDifferent?: number;

  /** Filtre par valeur exacte de nomProjet */
  nomProjet?: string;
  /** Filtre IsNull sur nomProjet (true = IS NULL, false = IS NOT NULL) */
  nomProjetIsNull?: boolean;
  /** Filtre nomProjet différent de cette valeur (NOT EQUAL) */
  nomProjetIsDifferent?: string;
  /** Filtre par liste de valeurs pour nomProjet (IN) */
  nomProjets?: string[];
  /** Filtre nomProjet différent de toutes ces valeurs (NOT IN) */
  nomProjetIsDifferentList?: string[];

  /** Filtre nomProjet contenant cette valeur (LIKE %value%) */
  nomProjetLike?: string;

  /** Filtre nomProjet commençant par cette valeur (LIKE value%) */
  nomProjetStartsWith?: string;

  /** Filtre nomProjet terminant par cette valeur (LIKE %value) */
  nomProjetEndsWith?: string;

  /** Filtre nomProjet ne contenant pas cette valeur (NOT LIKE %value%) */
  nomProjetIsDifferentLike?: string;

  /** Filtre par valeur exacte de contactId */
  contactId?: number;
  /** Filtre IsNull sur contactId (true = IS NULL, false = IS NOT NULL) */
  contactIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour contactId (IN) */
  contactIds?: number[];
  /** Filtre contactId différent de toutes ces valeurs (NOT IN) */
  contactIdIsDifferentList?: number[];

  /** Filtre contactId supérieur ou égal à cette valeur */
  contactIdMin?: number;

  /** Filtre contactId inférieur ou égal à cette valeur */
  contactIdMax?: number;

  /** Filtre contactId strictement supérieur à cette valeur */
  contactIdGreaterThan?: number;

  /** Filtre contactId strictement inférieur à cette valeur */
  contactIdLessThan?: number;

  /** Filtre contactId différent de cette valeur */
  contactIdIsDifferent?: number;

  /** Filtre par valeur exacte de typeRechercheId */
  typeRechercheId?: number;
  /** Filtre IsNull sur typeRechercheId (true = IS NULL, false = IS NOT NULL) */
  typeRechercheIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeRechercheId (IN) */
  typeRechercheIds?: number[];
  /** Filtre typeRechercheId différent de toutes ces valeurs (NOT IN) */
  typeRechercheIdIsDifferentList?: number[];

  /** Filtre typeRechercheId supérieur ou égal à cette valeur */
  typeRechercheIdMin?: number;

  /** Filtre typeRechercheId inférieur ou égal à cette valeur */
  typeRechercheIdMax?: number;

  /** Filtre typeRechercheId strictement supérieur à cette valeur */
  typeRechercheIdGreaterThan?: number;

  /** Filtre typeRechercheId strictement inférieur à cette valeur */
  typeRechercheIdLessThan?: number;

  /** Filtre typeRechercheId différent de cette valeur */
  typeRechercheIdIsDifferent?: number;

  /** Filtre par valeur exacte de typeBienId */
  typeBienId?: number;
  /** Filtre IsNull sur typeBienId (true = IS NULL, false = IS NOT NULL) */
  typeBienIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour typeBienId (IN) */
  typeBienIds?: number[];
  /** Filtre typeBienId différent de toutes ces valeurs (NOT IN) */
  typeBienIdIsDifferentList?: number[];

  /** Filtre typeBienId supérieur ou égal à cette valeur */
  typeBienIdMin?: number;

  /** Filtre typeBienId inférieur ou égal à cette valeur */
  typeBienIdMax?: number;

  /** Filtre typeBienId strictement supérieur à cette valeur */
  typeBienIdGreaterThan?: number;

  /** Filtre typeBienId strictement inférieur à cette valeur */
  typeBienIdLessThan?: number;

  /** Filtre typeBienId différent de cette valeur */
  typeBienIdIsDifferent?: number;

  /** Filtre par valeur exacte de budgetMax */
  budgetMax?: number;
  /** Filtre IsNull sur budgetMax (true = IS NULL, false = IS NOT NULL) */
  budgetMaxIsNull?: boolean;
  /** Filtre par liste de valeurs pour budgetMax (IN) */
  budgetMaxs?: number[];
  /** Filtre budgetMax différent de toutes ces valeurs (NOT IN) */
  budgetMaxIsDifferentList?: number[];

  /** Filtre budgetMax supérieur ou égal à cette valeur */
  budgetMaxMin?: number;

  /** Filtre budgetMax inférieur ou égal à cette valeur */
  budgetMaxMax?: number;

  /** Filtre budgetMax strictement supérieur à cette valeur */
  budgetMaxGreaterThan?: number;

  /** Filtre budgetMax strictement inférieur à cette valeur */
  budgetMaxLessThan?: number;

  /** Filtre budgetMax différent de cette valeur */
  budgetMaxIsDifferent?: number;

  /** Filtre par valeur exacte de secteurRecherche */
  secteurRecherche?: string;
  /** Filtre IsNull sur secteurRecherche (true = IS NULL, false = IS NOT NULL) */
  secteurRechercheIsNull?: boolean;
  /** Filtre secteurRecherche différent de cette valeur (NOT EQUAL) */
  secteurRechercheIsDifferent?: string;
  /** Filtre par liste de valeurs pour secteurRecherche (IN) */
  secteurRecherches?: string[];
  /** Filtre secteurRecherche différent de toutes ces valeurs (NOT IN) */
  secteurRechercheIsDifferentList?: string[];

  /** Filtre secteurRecherche contenant cette valeur (LIKE %value%) */
  secteurRechercheLike?: string;

  /** Filtre secteurRecherche commençant par cette valeur (LIKE value%) */
  secteurRechercheStartsWith?: string;

  /** Filtre secteurRecherche terminant par cette valeur (LIKE %value) */
  secteurRechercheEndsWith?: string;

  /** Filtre secteurRecherche ne contenant pas cette valeur (NOT LIKE %value%) */
  secteurRechercheIsDifferentLike?: string;

  /** Filtre par valeur exacte de rayonKm */
  rayonKm?: number;
  /** Filtre IsNull sur rayonKm (true = IS NULL, false = IS NOT NULL) */
  rayonKmIsNull?: boolean;
  /** Filtre par liste de valeurs pour rayonKm (IN) */
  rayonKms?: number[];
  /** Filtre rayonKm différent de toutes ces valeurs (NOT IN) */
  rayonKmIsDifferentList?: number[];

  /** Filtre rayonKm supérieur ou égal à cette valeur */
  rayonKmMin?: number;

  /** Filtre rayonKm inférieur ou égal à cette valeur */
  rayonKmMax?: number;

  /** Filtre rayonKm strictement supérieur à cette valeur */
  rayonKmGreaterThan?: number;

  /** Filtre rayonKm strictement inférieur à cette valeur */
  rayonKmLessThan?: number;

  /** Filtre rayonKm différent de cette valeur */
  rayonKmIsDifferent?: number;

  /** Filtre par valeur exacte de surfaceMin */
  surfaceMin?: number;
  /** Filtre IsNull sur surfaceMin (true = IS NULL, false = IS NOT NULL) */
  surfaceMinIsNull?: boolean;
  /** Filtre par liste de valeurs pour surfaceMin (IN) */
  surfaceMins?: number[];
  /** Filtre surfaceMin différent de toutes ces valeurs (NOT IN) */
  surfaceMinIsDifferentList?: number[];

  /** Filtre surfaceMin supérieur ou égal à cette valeur */
  surfaceMinMin?: number;

  /** Filtre surfaceMin inférieur ou égal à cette valeur */
  surfaceMinMax?: number;

  /** Filtre surfaceMin strictement supérieur à cette valeur */
  surfaceMinGreaterThan?: number;

  /** Filtre surfaceMin strictement inférieur à cette valeur */
  surfaceMinLessThan?: number;

  /** Filtre surfaceMin différent de cette valeur */
  surfaceMinIsDifferent?: number;

  /** Filtre par valeur exacte de nbChambres */
  nbChambres?: number;
  /** Filtre IsNull sur nbChambres (true = IS NULL, false = IS NOT NULL) */
  nbChambresIsNull?: boolean;
  /** Filtre par liste de valeurs pour nbChambres (IN) */
  nbChambress?: number[];
  /** Filtre nbChambres différent de toutes ces valeurs (NOT IN) */
  nbChambresIsDifferentList?: number[];

  /** Filtre nbChambres supérieur ou égal à cette valeur */
  nbChambresMin?: number;

  /** Filtre nbChambres inférieur ou égal à cette valeur */
  nbChambresMax?: number;

  /** Filtre nbChambres strictement supérieur à cette valeur */
  nbChambresGreaterThan?: number;

  /** Filtre nbChambres strictement inférieur à cette valeur */
  nbChambresLessThan?: number;

  /** Filtre nbChambres différent de cette valeur */
  nbChambresIsDifferent?: number;

  /** Filtre par valeur exacte de biensCorrespondants */
  biensCorrespondants?: string;
  /** Filtre IsNull sur biensCorrespondants (true = IS NULL, false = IS NOT NULL) */
  biensCorrespondantsIsNull?: boolean;
  /** Filtre biensCorrespondants différent de cette valeur (NOT EQUAL) */
  biensCorrespondantsIsDifferent?: string;
  /** Filtre par liste de valeurs pour biensCorrespondants (IN) */
  biensCorrespondantss?: string[];
  /** Filtre biensCorrespondants différent de toutes ces valeurs (NOT IN) */
  biensCorrespondantsIsDifferentList?: string[];

  /** Filtre biensCorrespondants contenant cette valeur (LIKE %value%) */
  biensCorrespondantsLike?: string;

  /** Filtre biensCorrespondants commençant par cette valeur (LIKE value%) */
  biensCorrespondantsStartsWith?: string;

  /** Filtre biensCorrespondants terminant par cette valeur (LIKE %value) */
  biensCorrespondantsEndsWith?: string;

  /** Filtre biensCorrespondants ne contenant pas cette valeur (NOT LIKE %value%) */
  biensCorrespondantsIsDifferentLike?: string;

  /** Filtre par valeur exacte de statutId */
  statutId?: number;
  /** Filtre IsNull sur statutId (true = IS NULL, false = IS NOT NULL) */
  statutIdIsNull?: boolean;
  /** Filtre par liste de valeurs pour statutId (IN) */
  statutIds?: number[];
  /** Filtre statutId différent de toutes ces valeurs (NOT IN) */
  statutIdIsDifferentList?: number[];

  /** Filtre statutId supérieur ou égal à cette valeur */
  statutIdMin?: number;

  /** Filtre statutId inférieur ou égal à cette valeur */
  statutIdMax?: number;

  /** Filtre statutId strictement supérieur à cette valeur */
  statutIdGreaterThan?: number;

  /** Filtre statutId strictement inférieur à cette valeur */
  statutIdLessThan?: number;

  /** Filtre statutId différent de cette valeur */
  statutIdIsDifferent?: number;

  /** Filtre par valeur exacte de createdAt */
  createdAt?: Date | string;
  /** Filtre par liste de valeurs pour createdAt (IN) */
  createdAts?: Date | string[];
  /** Filtre createdAt différent de toutes ces valeurs (NOT IN) */
  createdAtIsDifferentList?: Date | string[];

  /** Filtre createdAt à partir de cette date (incluse) */
  createdAtFrom?: Date | string;

  /** Filtre createdAt jusqu'à cette date (incluse) */
  createdAtTo?: Date | string;

  /** Filtre createdAt strictement après cette date */
  createdAtAfter?: Date | string;

  /** Filtre createdAt strictement avant cette date */
  createdAtBefore?: Date | string;

  /** Filtre createdAt différent de cette date */
  createdAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de updatedAt */
  updatedAt?: Date | string;
  /** Filtre par liste de valeurs pour updatedAt (IN) */
  updatedAts?: Date | string[];
  /** Filtre updatedAt différent de toutes ces valeurs (NOT IN) */
  updatedAtIsDifferentList?: Date | string[];

  /** Filtre updatedAt à partir de cette date (incluse) */
  updatedAtFrom?: Date | string;

  /** Filtre updatedAt jusqu'à cette date (incluse) */
  updatedAtTo?: Date | string;

  /** Filtre updatedAt strictement après cette date */
  updatedAtAfter?: Date | string;

  /** Filtre updatedAt strictement avant cette date */
  updatedAtBefore?: Date | string;

  /** Filtre updatedAt différent de cette date */
  updatedAtIsDifferent?: Date | string;

  /** Filtre par valeur exacte de userId */
  userId?: number;
  /** Filtre par liste de valeurs pour userId (IN) */
  userIds?: number[];
  /** Filtre userId différent de toutes ces valeurs (NOT IN) */
  userIdIsDifferentList?: number[];

  /** Filtre userId supérieur ou égal à cette valeur */
  userIdMin?: number;

  /** Filtre userId inférieur ou égal à cette valeur */
  userIdMax?: number;

  /** Filtre userId strictement supérieur à cette valeur */
  userIdGreaterThan?: number;

  /** Filtre userId strictement inférieur à cette valeur */
  userIdLessThan?: number;

  /** Filtre userId différent de cette valeur */
  userIdIsDifferent?: number;

  // Filtres imbriqués (Many-to-One)
  /**
   * true = LEFT JOIN (garder les lignes où contact est NULL).
   * false = INNER JOIN.
   * À configurer AVANT contact.
   */
  includeContactEmpty?: boolean;

  /** Filtre imbriqué sur la navigation contact. */
  contact?: ContactsCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où statut est NULL).
   * false = INNER JOIN.
   * À configurer AVANT statut.
   */
  includeStatutEmpty?: boolean;

  /** Filtre imbriqué sur la navigation statut. */
  statut?: RefStatutRechercheCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où typeBien est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeBien.
   */
  includeTypebienEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeBien. */
  typeBien?: RefTypeBienCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où typeRecherche est NULL).
   * false = INNER JOIN.
   * À configurer AVANT typeRecherche.
   */
  includeTyperechercheEmpty?: boolean;

  /** Filtre imbriqué sur la navigation typeRecherche. */
  typeRecherche?: RefTypeRechercheCritereDTO;

  /**
   * true = LEFT JOIN (garder les lignes où user est NULL).
   * false = INNER JOIN.
   * À configurer AVANT user.
   */
  includeUserEmpty?: boolean;

  /** Filtre imbriqué sur la navigation user. */
  user?: UsersCritereDTO;

  // Filtres imbriqués (One-to-Many)
  /**
   * Mode de filtrage de l'Include sur rechercheBiens.
   * Filter = Include non filtré. Both = Include filtré.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensFilterMode?: ECollectionFilterMode;

  /**
   * true = LEFT JOIN sémantique (garde les parents dont rechercheBiens est null/vide).
   * false = INNER JOIN sémantique (exige au moins un enfant).
   * À configurer AVANT rechercheBiens.
   */
  includeRecherchebiensEmpty?: boolean;

  /**
   * Quantificateur appliqué au prédicat enfant pour rechercheBiens.
   * Any = au moins un enfant matche (défaut).
   * None = aucun enfant ne matche.
   * All  = tous les enfants matchent.
   * À configurer AVANT rechercheBiens.
   */
  rechercheBiensMatch?: ECollectionMatch;

  /** Filtre imbriqué sur la collection rechercheBiens. */
  rechercheBiens?: RechercheBiensCritereDTO;

}
