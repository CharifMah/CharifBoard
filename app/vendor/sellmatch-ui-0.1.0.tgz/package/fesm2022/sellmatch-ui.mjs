import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component, Input, EventEmitter, signal, Output, inject, ElementRef, PLATFORM_ID, Inject, ViewContainerRef, Renderer2, DestroyRef, ViewChild, computed, ContentChild, ChangeDetectorRef } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { BaseComponent as BaseComponent$1 } from '../src/core/base/BaseComponent';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { DomPortalOutlet, TemplatePortal, PortalModule } from '@angular/cdk/portal';
import { SkeletonComponent as SkeletonComponent$1 } from '../src/shared/components/skeleton/skeleton.component';
import { ButtonComponent as ButtonComponent$1 } from '../src/shared/components/button/button.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ROUTE_PATHS } from '../src/routes/app.routes.constants';
import { UsersService, SettingsService } from '../src/core/sellmatchdb/services';
import { RouteUtils } from '../src/shared/utils/route-utils';
import { BusyService } from '../src/core/services/busy/BusyService';
import { NavigationService } from '../src/core/sellmatchdb/services/NavigationService/NavigationService';
import { environment } from '../src/environments/environment';
import { SessionStorageService } from '../src/core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { LocalStorageService } from '../src/core/sellmatchdb/services/LocalStorage/LocalStorageService';
import { PostHogService } from '../src/core/services/posthog/PostHogService';
import { TranslationService } from '../src/core/services/i18n/TranslationService';

function SkeletonComponent_Case_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵdomElement(0, "div", 0);
} }
function SkeletonComponent_Case_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵdomElement(0, "div", 2);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("width", ctx_r0.Width)("height", ctx_r0.Height);
} }
/**
 * Composant skeleton générique réutilisable.
 * Affiche un bloc shimmer (animation de chargement) qu'on peut placer n'importe où.
 *
 * @example
 * ```html
 * <!-- Barre skeleton simple -->
 * <app-skeleton />
 *
 * <!-- Barre skeleton avec largeur et hauteur personnalisées -->
 * <app-skeleton Width="60%" Height="20px" />
 *
 * <!-- Petit skeleton (checkbox, icône) -->
 * <app-skeleton Size="sm" />
 * ```
 */
class SkeletonComponent {
    /** Largeur CSS du skeleton (défaut: '80%'). */
    Width = '80%';
    /** Hauteur CSS du skeleton (défaut: '16px'). */
    Height = '16px';
    /** Tailur prédéfinie : 'sm' pour petit (40px large), sinon taille normale. */
    Size = 'default';
    static ɵfac = function SkeletonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SkeletonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SkeletonComponent, selectors: [["app-skeleton"]], inputs: { Width: "Width", Height: "Height", Size: "Size" }, decls: 2, vars: 1, consts: [[1, "skeleton", "skeleton--sm"], [1, "skeleton", 3, "width", "height"], [1, "skeleton"]], template: function SkeletonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, SkeletonComponent_Case_0_Template, 1, 0, "div", 0)(1, SkeletonComponent_Case_1_Template, 1, 4, "div", 1);
        } if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵconditional((tmp_0_0 = ctx.Size) === "sm" ? 0 : 1);
        } }, styles: ["@keyframes _ngcontent-%COMP%_spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes _ngcontent-%COMP%_fadeIn{0%{opacity:0}to{opacity:1}}@keyframes _ngcontent-%COMP%_fadeInUp{0%{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}@keyframes _ngcontent-%COMP%_slideUp{0%{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}@keyframes _ngcontent-%COMP%_slideDown{0%{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}@keyframes _ngcontent-%COMP%_float{0%,to{transform:translateY(0)}50%{transform:translateY(-10px)}}@keyframes _ngcontent-%COMP%_pulse{0%{opacity:.9}to{opacity:1}}@keyframes _ngcontent-%COMP%_pulse-glow{0%,to{box-shadow:0 4px 15px rgba(var(--%NS%sm-primary-rgb, 99, 102, 241),.4)}50%{box-shadow:0 4px 25px rgba(var(--%NS%sm-primary-rgb, 99, 102, 241),.7)}}@keyframes _ngcontent-%COMP%_shake{0%,to{transform:translate(0)}25%{transform:translate(-8px)}75%{transform:translate(8px)}}@keyframes _ngcontent-%COMP%_shimmer{0%{background-position:200% 0}to{background-position:-200% 0}}.skeleton[_ngcontent-%COMP%]{display:block;height:16px;width:80%;border-radius:8px;background:linear-gradient(90deg,rgba(var(--%NS%sm-primary-rgb),.06),rgba(var(--%NS%sm-primary-rgb),.32),rgba(var(--%NS%sm-primary-rgb),.06));background-size:200% 100%;animation:_ngcontent-%COMP%_shimmer 1.7s linear infinite;animation-delay:var(--%NS%shimmer-delay, 0s);pointer-events:none}.skeleton--sm[_ngcontent-%COMP%]{width:40px;height:16px;margin:0 auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SkeletonComponent, [{
        type: Component,
        args: [{ selector: 'app-skeleton', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<!-- - cm - Skeleton g\u00E9n\u00E9rique : bloc shimmer r\u00E9utilisable partout -->\n@switch (Size) {\n  @case ('sm') {\n  <div class=\"skeleton skeleton--sm\"></div>\n  }\n  @default {\n  <div class=\"skeleton\" [style.width]=\"Width\" [style.height]=\"Height\"></div>\n  }\n}", styles: ["@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeInUp{0%{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}@keyframes slideUp{0%{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}@keyframes slideDown{0%{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}@keyframes float{0%,to{transform:translateY(0)}50%{transform:translateY(-10px)}}@keyframes pulse{0%{opacity:.9}to{opacity:1}}@keyframes pulse-glow{0%,to{box-shadow:0 4px 15px rgba(var(--sm-primary-rgb, 99, 102, 241),.4)}50%{box-shadow:0 4px 25px rgba(var(--sm-primary-rgb, 99, 102, 241),.7)}}@keyframes shake{0%,to{transform:translate(0)}25%{transform:translate(-8px)}75%{transform:translate(8px)}}@keyframes shimmer{0%{background-position:200% 0}to{background-position:-200% 0}}.skeleton{display:block;height:16px;width:80%;border-radius:8px;background:linear-gradient(90deg,rgba(var(--sm-primary-rgb),.06),rgba(var(--sm-primary-rgb),.32),rgba(var(--sm-primary-rgb),.06));background-size:200% 100%;animation:shimmer 1.7s linear infinite;animation-delay:var(--shimmer-delay, 0s);pointer-events:none}.skeleton--sm{width:40px;height:16px;margin:0 auto}\n"] }]
    }], null, { Width: [{
            type: Input
        }], Height: [{
            type: Input
        }], Size: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SkeletonComponent, { className: "SkeletonComponent", filePath: "shared/components/skeleton/skeleton.component.ts", lineNumber: 26 }); })();

function BadgeComponent_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.DefaultIcon);
} }
function BadgeComponent_Conditional_0_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵlistener("click", function BadgeComponent_Conditional_0_Conditional_4_Template_span_click_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onClose($event)); });
    i0.ɵɵelementStart(1, "span", 6);
    i0.ɵɵtext(2, "close");
    i0.ɵɵelementEnd()();
} }
function BadgeComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵlistener("click", function BadgeComponent_Conditional_0_Template_span_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.clicked.emit()); });
    i0.ɵɵconditionalCreate(1, BadgeComponent_Conditional_0_Conditional_1_Template, 2, 1, "span", 2);
    i0.ɵɵelementStart(2, "span", 3);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(4, BadgeComponent_Conditional_0_Conditional_4_Template, 3, 0, "span", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleMap(ctx_r1.CustomStyles);
    i0.ɵɵproperty("ngClass", ctx_r1.BadgeClasses);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.showIcon && ctx_r1.DefaultIcon ? 1 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.displayLabel);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.showClose && !ctx_r1.disabled ? 4 : -1);
} }
class BadgeComponent extends BaseComponent$1 {
    //#region Inputs
    type = 'default';
    size = 'md';
    position = 'inline';
    variant = 'solid';
    shape = 'pill';
    icon;
    label;
    count;
    maxCount = 99;
    animated = false;
    pulse = false;
    IsVisible = true;
    glow = false;
    clickable = false;
    disabled = false;
    removable = false;
    showIcon = true;
    showClose = false;
    customColor;
    customBgColor;
    tooltip;
    //#endregion
    //#region Outputs
    closed = new EventEmitter();
    clicked = new EventEmitter();
    //#endregion
    //#region Internal State
    _isVisible = signal(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_isVisible" }] : /* istanbul ignore next */ []));
    //#endregion
    //#region Computed Properties
    get displayLabel() {
        if (this.count !== undefined) {
            return this.count > this.maxCount ? `${this.maxCount}+` : this.count.toString();
        }
        return this.label || this.DefaultLabel;
    }
    get CustomStyles() {
        const styles = {};
        if (this.customColor) {
            styles['color'] = this.customColor;
        }
        if (this.customBgColor) {
            if (this.variant === 'outline') {
                styles['border-color'] = this.customBgColor;
                styles['background'] = 'transparent';
            }
            else if (this.variant === 'soft') {
                styles['background'] = this.hexToRgba(this.customBgColor, 0.15);
                styles['color'] = this.customBgColor;
            }
            else {
                styles['background'] = this.customBgColor;
            }
        }
        return styles;
    }
    get BadgeClasses() {
        const classes = [
            'badge',
            `badge-${this.type}`,
            `badge-${this.size}`,
            `badge-${this.position}`,
            `badge-${this.variant}`,
            `badge-${this.shape}`
        ];
        if (this.animated && !this.disabled)
            classes.push('badge-animated');
        if (this.pulse && !this.disabled)
            classes.push('badge-pulse');
        if (this.glow)
            classes.push('badge-glow');
        if (this.clickable && !this.disabled)
            classes.push('badge-clickable');
        if (this.disabled)
            classes.push('badge-disabled');
        if (!this._isVisible())
            classes.push('badge-hidden');
        return classes;
    }
    get DefaultIcon() {
        if (this.icon === '')
            return '';
        const icons = {
            new: 'fiber_new',
            hot: 'local_fire_department',
            premium: 'star',
            urgent: 'priority_high',
            success: 'check_circle',
            warning: 'warning',
            info: 'info',
            error: 'error',
            default: 'circle'
        };
        return this.icon || icons[this.type];
    }
    get DefaultLabel() {
        if (this.count !== undefined)
            return '';
        const labels = {
            new: 'Nouveau',
            hot: 'Tendance',
            premium: 'Premium',
            urgent: 'Urgent',
            success: 'Succès',
            warning: 'Attention',
            info: 'Information',
            error: 'Erreur',
            default: 'Badge'
        };
        return this.label || labels[this.type];
    }
    //#endregion
    //#region Public Methods
    onClose(event) {
        event.stopPropagation();
        if (!this.disabled) {
            this._isVisible.set(false);
            this.PostHog.Capture(this.BuildTrackingName('badge_ferme', 'tracking'), { type: this.type, label: this.displayLabel });
            this.closed.emit();
        }
    }
    onClick() {
        if (this.clickable && !this.disabled && this._isVisible()) {
            this.PostHog.Capture(this.BuildTrackingName('badge_clique', 'tracking'), { type: this.type, label: this.displayLabel });
            this.clicked.emit();
        }
    }
    show() {
        this._isVisible.set(true);
    }
    hide() {
        this._isVisible.set(false);
    }
    //#endregion
    //#region Private Methods
    hexToRgba(hex, alpha) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    static ɵfac = /*@__PURE__*/ (() => { let ɵBadgeComponent_BaseFactory; return function BadgeComponent_Factory(__ngFactoryType__) { return (ɵBadgeComponent_BaseFactory || (ɵBadgeComponent_BaseFactory = i0.ɵɵgetInheritedFactory(BadgeComponent)))(__ngFactoryType__ || BadgeComponent); }; })();
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: BadgeComponent, selectors: [["app-badge"]], inputs: { type: "type", size: "size", position: "position", variant: "variant", shape: "shape", icon: "icon", label: "label", count: "count", maxCount: "maxCount", animated: "animated", pulse: "pulse", IsVisible: "IsVisible", glow: "glow", clickable: "clickable", disabled: "disabled", removable: "removable", showIcon: "showIcon", showClose: "showClose", customColor: "customColor", customBgColor: "customBgColor", tooltip: "tooltip" }, outputs: { closed: "closed", clicked: "clicked" }, features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[1, "badge", 3, "ngClass", "style"], [1, "badge", 3, "click", "ngClass"], [1, "material-icons", "badge-icon"], [1, "badge-label"], [1, "badge-close"], [1, "badge-close", 3, "click"], [1, "material-icons"]], template: function BadgeComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, BadgeComponent_Conditional_0_Template, 5, 6, "span", 0);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.IsVisible ? 0 : -1);
        } }, dependencies: [CommonModule, i1.NgClass], styles: [".badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:6px;font-weight:600;white-space:nowrap;transition:all .2s cubic-bezier(.4,0,.2,1);z-index:1;cursor:default;position:relative;margin:4px;border:1px solid transparent;-webkit-user-select:none;user-select:none}.badge.badge-xs[_ngcontent-%COMP%]{padding:2px 8px;font-size:10px;min-height:18px;margin:2px;border-radius:4px}.badge.badge-xs[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%]{font-size:10px;width:10px;height:10px;line-height:1}.badge.badge-xs[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{width:12px;height:12px;border-radius:50%}.badge.badge-xs[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:8px;line-height:1}.badge.badge-xs.badge-circle[_ngcontent-%COMP%]{width:18px;height:18px;padding:0;border-radius:50%;margin:2px}.badge.badge-xs.badge-pill[_ngcontent-%COMP%]{border-radius:9999px}.badge.badge-sm[_ngcontent-%COMP%]{padding:4px 12px;font-size:11px;min-height:22px;margin:3px;border-radius:6px}.badge.badge-sm[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%]{font-size:12px;width:12px;height:12px;line-height:1}.badge.badge-sm[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{width:14px;height:14px;border-radius:50%}.badge.badge-sm[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:10px;line-height:1}.badge.badge-sm.badge-circle[_ngcontent-%COMP%]{width:22px;height:22px;padding:0;border-radius:50%;margin:3px}.badge.badge-sm.badge-pill[_ngcontent-%COMP%]{border-radius:9999px}.badge.badge-md[_ngcontent-%COMP%]{padding:6px 16px;font-size:12px;min-height:28px;margin:4px;border-radius:8px}.badge.badge-md[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%]{font-size:14px;width:14px;height:14px;line-height:1}.badge.badge-md[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%}.badge.badge-md[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:12px;line-height:1}.badge.badge-md.badge-circle[_ngcontent-%COMP%]{width:28px;height:28px;padding:0;border-radius:50%;margin:4px}.badge.badge-md.badge-pill[_ngcontent-%COMP%]{border-radius:9999px}.badge.badge-lg[_ngcontent-%COMP%]{padding:8px 20px;font-size:14px;min-height:34px;margin:5px;border-radius:10px}.badge.badge-lg[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px;line-height:1}.badge.badge-lg[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{width:22px;height:22px;border-radius:50%}.badge.badge-lg[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:14px;line-height:1}.badge.badge-lg.badge-circle[_ngcontent-%COMP%]{width:34px;height:34px;padding:0;border-radius:50%;margin:5px}.badge.badge-lg.badge-pill[_ngcontent-%COMP%]{border-radius:9999px}.badge.badge-xl[_ngcontent-%COMP%]{padding:10px 24px;font-size:16px;min-height:40px;margin:6px;border-radius:12px}.badge.badge-xl[_ngcontent-%COMP%]   .badge-icon[_ngcontent-%COMP%]{font-size:22px;width:22px;height:22px;line-height:1}.badge.badge-xl[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{width:26px;height:26px;border-radius:50%}.badge.badge-xl[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:16px;line-height:1}.badge.badge-xl.badge-circle[_ngcontent-%COMP%]{width:40px;height:40px;padding:0;border-radius:50%;margin:6px}.badge.badge-xl.badge-pill[_ngcontent-%COMP%]{border-radius:9999px}.badge.badge-rounded[_ngcontent-%COMP%]{border-radius:8px}.badge.badge-square[_ngcontent-%COMP%]{border-radius:0}.badge.badge-top-left[_ngcontent-%COMP%]{position:absolute;top:-8px;left:-8px;margin:0}.badge.badge-top-right[_ngcontent-%COMP%]{position:absolute;top:-8px;right:-8px;margin:0}.badge.badge-bottom-left[_ngcontent-%COMP%]{position:absolute;bottom:-8px;left:-8px;margin:0}.badge.badge-bottom-right[_ngcontent-%COMP%]{position:absolute;bottom:-8px;right:-8px;margin:0}.badge.badge-primary.badge-solid[_ngcontent-%COMP%]{background:#9c27b0;color:#fff;box-shadow:0 2px 8px #9c27b04d;border:1px solid rgba(255,255,255,.1)}.badge.badge-primary.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #9c27b04d;transform:translateY(-1px)}.badge.badge-primary.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #9c27b0;color:#9c27b0;box-shadow:none}.badge.badge-primary.badge-outline[_ngcontent-%COMP%]:hover{background:#9c27b01f!important;transform:translateY(-1px)}.badge.badge-primary.badge-soft[_ngcontent-%COMP%]{background:#9c27b01f;color:#9c27b0;border:1px solid rgba(156,39,176,.1)}.badge.badge-primary.badge-soft[_ngcontent-%COMP%]:hover{background:#9c27b033}.badge.badge-primary.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#9c27b0,#7b1fa2);color:#fff;border:none;box-shadow:0 2px 8px #9c27b04d}.badge.badge-primary.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #9c27b04d;transform:translateY(-1px)}.badge.badge-primary.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-primary.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-success.badge-solid[_ngcontent-%COMP%]{background:#4caf50;color:#fff;box-shadow:0 2px 8px #4caf504d;border:1px solid rgba(255,255,255,.1)}.badge.badge-success.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #4caf504d;transform:translateY(-1px)}.badge.badge-success.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #4caf50;color:#4caf50;box-shadow:none}.badge.badge-success.badge-outline[_ngcontent-%COMP%]:hover{background:#4caf501f!important;transform:translateY(-1px)}.badge.badge-success.badge-soft[_ngcontent-%COMP%]{background:#4caf501f;color:#4caf50;border:1px solid rgba(76,175,80,.1)}.badge.badge-success.badge-soft[_ngcontent-%COMP%]:hover{background:#4caf5033}.badge.badge-success.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#4caf50,#2e7d32);color:#fff;border:none;box-shadow:0 2px 8px #4caf504d}.badge.badge-success.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #4caf504d;transform:translateY(-1px)}.badge.badge-success.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-success.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-error.badge-solid[_ngcontent-%COMP%]{background:#f44336;color:#fff;box-shadow:0 2px 8px #f443364d;border:1px solid rgba(255,255,255,.1)}.badge.badge-error.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #f443364d;transform:translateY(-1px)}.badge.badge-error.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #f44336;color:#f44336;box-shadow:none}.badge.badge-error.badge-outline[_ngcontent-%COMP%]:hover{background:#f443361f!important;transform:translateY(-1px)}.badge.badge-error.badge-soft[_ngcontent-%COMP%]{background:#f443361f;color:#f44336;border:1px solid rgba(244,67,54,.1)}.badge.badge-error.badge-soft[_ngcontent-%COMP%]:hover{background:#f4433633}.badge.badge-error.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#f44336,#c62828);color:#fff;border:none;box-shadow:0 2px 8px #f443364d}.badge.badge-error.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #f443364d;transform:translateY(-1px)}.badge.badge-error.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-error.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-warning.badge-solid[_ngcontent-%COMP%]{background:#ff9800;color:#fff;box-shadow:0 2px 8px #ff98004d;border:1px solid rgba(255,255,255,.1)}.badge.badge-warning.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #ff98004d;transform:translateY(-1px)}.badge.badge-warning.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #ff9800;color:#ff9800;box-shadow:none}.badge.badge-warning.badge-outline[_ngcontent-%COMP%]:hover{background:#ff98001f!important;transform:translateY(-1px)}.badge.badge-warning.badge-soft[_ngcontent-%COMP%]{background:#ff98001f;color:#ff9800;border:1px solid rgba(255,152,0,.1)}.badge.badge-warning.badge-soft[_ngcontent-%COMP%]:hover{background:#ff980033}.badge.badge-warning.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#ff9800,#f57c00);color:#fff;border:none;box-shadow:0 2px 8px #ff98004d}.badge.badge-warning.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #ff98004d;transform:translateY(-1px)}.badge.badge-warning.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-warning.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-info.badge-solid[_ngcontent-%COMP%]{background:#2196f3;color:#fff;box-shadow:0 2px 8px #2196f34d;border:1px solid rgba(255,255,255,.1)}.badge.badge-info.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #2196f34d;transform:translateY(-1px)}.badge.badge-info.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #2196f3;color:#2196f3;box-shadow:none}.badge.badge-info.badge-outline[_ngcontent-%COMP%]:hover{background:#2196f31f!important;transform:translateY(-1px)}.badge.badge-info.badge-soft[_ngcontent-%COMP%]{background:#2196f31f;color:#2196f3;border:1px solid rgba(33,150,243,.1)}.badge.badge-info.badge-soft[_ngcontent-%COMP%]:hover{background:#2196f333}.badge.badge-info.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#2196f3,#1976d2);color:#fff;border:none;box-shadow:0 2px 8px #2196f34d}.badge.badge-info.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #2196f34d;transform:translateY(-1px)}.badge.badge-info.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-info.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-hot.badge-solid[_ngcontent-%COMP%]{background:#ff5722;color:#fff;box-shadow:0 2px 8px #ff57224d;border:1px solid rgba(255,255,255,.1)}.badge.badge-hot.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #ff57224d;transform:translateY(-1px)}.badge.badge-hot.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #ff5722;color:#ff5722;box-shadow:none}.badge.badge-hot.badge-outline[_ngcontent-%COMP%]:hover{background:#ff57221f!important;transform:translateY(-1px)}.badge.badge-hot.badge-soft[_ngcontent-%COMP%]{background:#ff57221f;color:#ff5722;border:1px solid rgba(255,87,34,.1)}.badge.badge-hot.badge-soft[_ngcontent-%COMP%]:hover{background:#ff572233}.badge.badge-hot.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#ff5722,#e64a19);color:#fff;border:none;box-shadow:0 2px 8px #ff57224d}.badge.badge-hot.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #ff57224d;transform:translateY(-1px)}.badge.badge-hot.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-hot.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-new.badge-solid[_ngcontent-%COMP%]{background:#4caf50;color:#fff;box-shadow:0 2px 8px #4caf504d;border:1px solid rgba(255,255,255,.1)}.badge.badge-new.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #4caf504d;transform:translateY(-1px)}.badge.badge-new.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #4caf50;color:#4caf50;box-shadow:none}.badge.badge-new.badge-outline[_ngcontent-%COMP%]:hover{background:#4caf501f!important;transform:translateY(-1px)}.badge.badge-new.badge-soft[_ngcontent-%COMP%]{background:#4caf501f;color:#4caf50;border:1px solid rgba(76,175,80,.1)}.badge.badge-new.badge-soft[_ngcontent-%COMP%]:hover{background:#4caf5033}.badge.badge-new.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#4caf50,#2e7d32);color:#fff;border:none;box-shadow:0 2px 8px #4caf504d}.badge.badge-new.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #4caf504d;transform:translateY(-1px)}.badge.badge-new.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-new.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-default.badge-solid[_ngcontent-%COMP%]{background:#6b7280;color:#fff;box-shadow:0 2px 8px #6b72804d;border:1px solid rgba(255,255,255,.1)}.badge.badge-default.badge-solid[_ngcontent-%COMP%]:hover{box-shadow:0 4px 12px #6b72804d;transform:translateY(-1px)}.badge.badge-default.badge-outline[_ngcontent-%COMP%]{background:transparent!important;border:2px solid #6b7280;color:#6b7280;box-shadow:none}.badge.badge-default.badge-outline[_ngcontent-%COMP%]:hover{background:#6b72801f!important;transform:translateY(-1px)}.badge.badge-default.badge-soft[_ngcontent-%COMP%]{background:#6b72801f;color:#4b5563;border:1px solid rgba(107,114,128,.1)}.badge.badge-default.badge-soft[_ngcontent-%COMP%]:hover{background:#6b728033}.badge.badge-default.badge-gradient[_ngcontent-%COMP%]{background:linear-gradient(135deg,#6b7280,#4b5563);color:#fff;border:none;box-shadow:0 2px 8px #6b72804d}.badge.badge-default.badge-gradient[_ngcontent-%COMP%]:hover{box-shadow:0 4px 16px #6b72804d;transform:translateY(-1px)}.badge.badge-default.badge-glow[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-glow 2s ease-in-out infinite}.badge.badge-default.badge-pulse[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-pulse 2s ease-in-out infinite}.badge.badge-clickable[_ngcontent-%COMP%]{cursor:pointer}.badge.badge-clickable[_ngcontent-%COMP%]:hover{transform:translateY(-2px)}.badge.badge-clickable[_ngcontent-%COMP%]:active{transform:translateY(0) scale(.96)}.badge.badge-disabled[_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed;filter:grayscale(.3);pointer-events:none}.badge.badge-hidden[_ngcontent-%COMP%]{display:none}.badge.badge-animated[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_badge-enter .3s cubic-bezier(.4,0,.2,1)}.badge[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s cubic-bezier(.4,0,.2,1);margin-left:4px;background:#0000000d}.badge[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]:hover{background:#00000026;transform:scale(1.15)}.badge[_ngcontent-%COMP%]   .badge-close[_ngcontent-%COMP%]:active{transform:scale(.9)}@keyframes _ngcontent-%COMP%_badge-pulse{0%,to{transform:scale(1);opacity:1}50%{transform:scale(1.05);opacity:.9}}@keyframes _ngcontent-%COMP%_badge-glow{0%,to{box-shadow:0 0 5px currentColor}50%{box-shadow:0 0 20px currentColor}}@keyframes _ngcontent-%COMP%_badge-enter{0%{opacity:0;transform:scale(.8) translateY(-10px)}60%{transform:scale(1.05) translateY(2px)}to{opacity:1;transform:scale(1) translateY(0)}}@media(max-width:768px){.badge.badge-xs[_ngcontent-%COMP%]{font-size:9px;min-height:15.3px;margin:1.2px;padding:2px 8px}.badge.badge-xs.badge-circle[_ngcontent-%COMP%]{width:14.4px;height:14.4px;margin:1.2px}.badge.badge-sm[_ngcontent-%COMP%]{font-size:9.9px;min-height:18.7px;margin:1.8px;padding:4px 12px}.badge.badge-sm.badge-circle[_ngcontent-%COMP%]{width:17.6px;height:17.6px;margin:1.8px}.badge.badge-md[_ngcontent-%COMP%]{font-size:10.8px;min-height:23.8px;margin:2.4px;padding:6px 16px}.badge.badge-md.badge-circle[_ngcontent-%COMP%]{width:22.4px;height:22.4px;margin:2.4px}.badge.badge-lg[_ngcontent-%COMP%]{font-size:12.6px;min-height:28.9px;margin:3px;padding:8px 20px}.badge.badge-lg.badge-circle[_ngcontent-%COMP%]{width:27.2px;height:27.2px;margin:3px}.badge.badge-xl[_ngcontent-%COMP%]{font-size:14.4px;min-height:34px;margin:3.6px;padding:10px 24px}.badge.badge-xl.badge-circle[_ngcontent-%COMP%]{width:32px;height:32px;margin:3.6px}}"], changeDetection: 1 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(BadgeComponent, [{
        type: Component,
        args: [{ selector: 'app-badge', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.Eager, template: "@if(IsVisible)\n{\n<span class=\"badge\" [ngClass]=\"BadgeClasses\" [style]=\"CustomStyles\" (click)=\"clicked.emit()\">\n    @if (showIcon && DefaultIcon) {\n    <span class=\"material-icons badge-icon\">{{ DefaultIcon }}</span>\n    }\n\n    <span class=\"badge-label\">{{ displayLabel }}</span>\n\n    @if (showClose && !disabled) {\n    <span class=\"badge-close\" (click)=\"onClose($event)\">\n        <span class=\"material-icons\">close</span>\n    </span>\n    }\n</span>\n}\n", styles: [".badge{display:inline-flex;align-items:center;justify-content:center;gap:6px;font-weight:600;white-space:nowrap;transition:all .2s cubic-bezier(.4,0,.2,1);z-index:1;cursor:default;position:relative;margin:4px;border:1px solid transparent;-webkit-user-select:none;user-select:none}.badge.badge-xs{padding:2px 8px;font-size:10px;min-height:18px;margin:2px;border-radius:4px}.badge.badge-xs .badge-icon{font-size:10px;width:10px;height:10px;line-height:1}.badge.badge-xs .badge-close{width:12px;height:12px;border-radius:50%}.badge.badge-xs .badge-close .material-icons{font-size:8px;line-height:1}.badge.badge-xs.badge-circle{width:18px;height:18px;padding:0;border-radius:50%;margin:2px}.badge.badge-xs.badge-pill{border-radius:9999px}.badge.badge-sm{padding:4px 12px;font-size:11px;min-height:22px;margin:3px;border-radius:6px}.badge.badge-sm .badge-icon{font-size:12px;width:12px;height:12px;line-height:1}.badge.badge-sm .badge-close{width:14px;height:14px;border-radius:50%}.badge.badge-sm .badge-close .material-icons{font-size:10px;line-height:1}.badge.badge-sm.badge-circle{width:22px;height:22px;padding:0;border-radius:50%;margin:3px}.badge.badge-sm.badge-pill{border-radius:9999px}.badge.badge-md{padding:6px 16px;font-size:12px;min-height:28px;margin:4px;border-radius:8px}.badge.badge-md .badge-icon{font-size:14px;width:14px;height:14px;line-height:1}.badge.badge-md .badge-close{width:18px;height:18px;border-radius:50%}.badge.badge-md .badge-close .material-icons{font-size:12px;line-height:1}.badge.badge-md.badge-circle{width:28px;height:28px;padding:0;border-radius:50%;margin:4px}.badge.badge-md.badge-pill{border-radius:9999px}.badge.badge-lg{padding:8px 20px;font-size:14px;min-height:34px;margin:5px;border-radius:10px}.badge.badge-lg .badge-icon{font-size:18px;width:18px;height:18px;line-height:1}.badge.badge-lg .badge-close{width:22px;height:22px;border-radius:50%}.badge.badge-lg .badge-close .material-icons{font-size:14px;line-height:1}.badge.badge-lg.badge-circle{width:34px;height:34px;padding:0;border-radius:50%;margin:5px}.badge.badge-lg.badge-pill{border-radius:9999px}.badge.badge-xl{padding:10px 24px;font-size:16px;min-height:40px;margin:6px;border-radius:12px}.badge.badge-xl .badge-icon{font-size:22px;width:22px;height:22px;line-height:1}.badge.badge-xl .badge-close{width:26px;height:26px;border-radius:50%}.badge.badge-xl .badge-close .material-icons{font-size:16px;line-height:1}.badge.badge-xl.badge-circle{width:40px;height:40px;padding:0;border-radius:50%;margin:6px}.badge.badge-xl.badge-pill{border-radius:9999px}.badge.badge-rounded{border-radius:8px}.badge.badge-square{border-radius:0}.badge.badge-top-left{position:absolute;top:-8px;left:-8px;margin:0}.badge.badge-top-right{position:absolute;top:-8px;right:-8px;margin:0}.badge.badge-bottom-left{position:absolute;bottom:-8px;left:-8px;margin:0}.badge.badge-bottom-right{position:absolute;bottom:-8px;right:-8px;margin:0}.badge.badge-primary.badge-solid{background:#9c27b0;color:#fff;box-shadow:0 2px 8px #9c27b04d;border:1px solid rgba(255,255,255,.1)}.badge.badge-primary.badge-solid:hover{box-shadow:0 4px 12px #9c27b04d;transform:translateY(-1px)}.badge.badge-primary.badge-outline{background:transparent!important;border:2px solid #9c27b0;color:#9c27b0;box-shadow:none}.badge.badge-primary.badge-outline:hover{background:#9c27b01f!important;transform:translateY(-1px)}.badge.badge-primary.badge-soft{background:#9c27b01f;color:#9c27b0;border:1px solid rgba(156,39,176,.1)}.badge.badge-primary.badge-soft:hover{background:#9c27b033}.badge.badge-primary.badge-gradient{background:linear-gradient(135deg,#9c27b0,#7b1fa2);color:#fff;border:none;box-shadow:0 2px 8px #9c27b04d}.badge.badge-primary.badge-gradient:hover{box-shadow:0 4px 16px #9c27b04d;transform:translateY(-1px)}.badge.badge-primary.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-primary.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-success.badge-solid{background:#4caf50;color:#fff;box-shadow:0 2px 8px #4caf504d;border:1px solid rgba(255,255,255,.1)}.badge.badge-success.badge-solid:hover{box-shadow:0 4px 12px #4caf504d;transform:translateY(-1px)}.badge.badge-success.badge-outline{background:transparent!important;border:2px solid #4caf50;color:#4caf50;box-shadow:none}.badge.badge-success.badge-outline:hover{background:#4caf501f!important;transform:translateY(-1px)}.badge.badge-success.badge-soft{background:#4caf501f;color:#4caf50;border:1px solid rgba(76,175,80,.1)}.badge.badge-success.badge-soft:hover{background:#4caf5033}.badge.badge-success.badge-gradient{background:linear-gradient(135deg,#4caf50,#2e7d32);color:#fff;border:none;box-shadow:0 2px 8px #4caf504d}.badge.badge-success.badge-gradient:hover{box-shadow:0 4px 16px #4caf504d;transform:translateY(-1px)}.badge.badge-success.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-success.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-error.badge-solid{background:#f44336;color:#fff;box-shadow:0 2px 8px #f443364d;border:1px solid rgba(255,255,255,.1)}.badge.badge-error.badge-solid:hover{box-shadow:0 4px 12px #f443364d;transform:translateY(-1px)}.badge.badge-error.badge-outline{background:transparent!important;border:2px solid #f44336;color:#f44336;box-shadow:none}.badge.badge-error.badge-outline:hover{background:#f443361f!important;transform:translateY(-1px)}.badge.badge-error.badge-soft{background:#f443361f;color:#f44336;border:1px solid rgba(244,67,54,.1)}.badge.badge-error.badge-soft:hover{background:#f4433633}.badge.badge-error.badge-gradient{background:linear-gradient(135deg,#f44336,#c62828);color:#fff;border:none;box-shadow:0 2px 8px #f443364d}.badge.badge-error.badge-gradient:hover{box-shadow:0 4px 16px #f443364d;transform:translateY(-1px)}.badge.badge-error.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-error.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-warning.badge-solid{background:#ff9800;color:#fff;box-shadow:0 2px 8px #ff98004d;border:1px solid rgba(255,255,255,.1)}.badge.badge-warning.badge-solid:hover{box-shadow:0 4px 12px #ff98004d;transform:translateY(-1px)}.badge.badge-warning.badge-outline{background:transparent!important;border:2px solid #ff9800;color:#ff9800;box-shadow:none}.badge.badge-warning.badge-outline:hover{background:#ff98001f!important;transform:translateY(-1px)}.badge.badge-warning.badge-soft{background:#ff98001f;color:#ff9800;border:1px solid rgba(255,152,0,.1)}.badge.badge-warning.badge-soft:hover{background:#ff980033}.badge.badge-warning.badge-gradient{background:linear-gradient(135deg,#ff9800,#f57c00);color:#fff;border:none;box-shadow:0 2px 8px #ff98004d}.badge.badge-warning.badge-gradient:hover{box-shadow:0 4px 16px #ff98004d;transform:translateY(-1px)}.badge.badge-warning.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-warning.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-info.badge-solid{background:#2196f3;color:#fff;box-shadow:0 2px 8px #2196f34d;border:1px solid rgba(255,255,255,.1)}.badge.badge-info.badge-solid:hover{box-shadow:0 4px 12px #2196f34d;transform:translateY(-1px)}.badge.badge-info.badge-outline{background:transparent!important;border:2px solid #2196f3;color:#2196f3;box-shadow:none}.badge.badge-info.badge-outline:hover{background:#2196f31f!important;transform:translateY(-1px)}.badge.badge-info.badge-soft{background:#2196f31f;color:#2196f3;border:1px solid rgba(33,150,243,.1)}.badge.badge-info.badge-soft:hover{background:#2196f333}.badge.badge-info.badge-gradient{background:linear-gradient(135deg,#2196f3,#1976d2);color:#fff;border:none;box-shadow:0 2px 8px #2196f34d}.badge.badge-info.badge-gradient:hover{box-shadow:0 4px 16px #2196f34d;transform:translateY(-1px)}.badge.badge-info.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-info.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-hot.badge-solid{background:#ff5722;color:#fff;box-shadow:0 2px 8px #ff57224d;border:1px solid rgba(255,255,255,.1)}.badge.badge-hot.badge-solid:hover{box-shadow:0 4px 12px #ff57224d;transform:translateY(-1px)}.badge.badge-hot.badge-outline{background:transparent!important;border:2px solid #ff5722;color:#ff5722;box-shadow:none}.badge.badge-hot.badge-outline:hover{background:#ff57221f!important;transform:translateY(-1px)}.badge.badge-hot.badge-soft{background:#ff57221f;color:#ff5722;border:1px solid rgba(255,87,34,.1)}.badge.badge-hot.badge-soft:hover{background:#ff572233}.badge.badge-hot.badge-gradient{background:linear-gradient(135deg,#ff5722,#e64a19);color:#fff;border:none;box-shadow:0 2px 8px #ff57224d}.badge.badge-hot.badge-gradient:hover{box-shadow:0 4px 16px #ff57224d;transform:translateY(-1px)}.badge.badge-hot.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-hot.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-new.badge-solid{background:#4caf50;color:#fff;box-shadow:0 2px 8px #4caf504d;border:1px solid rgba(255,255,255,.1)}.badge.badge-new.badge-solid:hover{box-shadow:0 4px 12px #4caf504d;transform:translateY(-1px)}.badge.badge-new.badge-outline{background:transparent!important;border:2px solid #4caf50;color:#4caf50;box-shadow:none}.badge.badge-new.badge-outline:hover{background:#4caf501f!important;transform:translateY(-1px)}.badge.badge-new.badge-soft{background:#4caf501f;color:#4caf50;border:1px solid rgba(76,175,80,.1)}.badge.badge-new.badge-soft:hover{background:#4caf5033}.badge.badge-new.badge-gradient{background:linear-gradient(135deg,#4caf50,#2e7d32);color:#fff;border:none;box-shadow:0 2px 8px #4caf504d}.badge.badge-new.badge-gradient:hover{box-shadow:0 4px 16px #4caf504d;transform:translateY(-1px)}.badge.badge-new.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-new.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-default.badge-solid{background:#6b7280;color:#fff;box-shadow:0 2px 8px #6b72804d;border:1px solid rgba(255,255,255,.1)}.badge.badge-default.badge-solid:hover{box-shadow:0 4px 12px #6b72804d;transform:translateY(-1px)}.badge.badge-default.badge-outline{background:transparent!important;border:2px solid #6b7280;color:#6b7280;box-shadow:none}.badge.badge-default.badge-outline:hover{background:#6b72801f!important;transform:translateY(-1px)}.badge.badge-default.badge-soft{background:#6b72801f;color:#4b5563;border:1px solid rgba(107,114,128,.1)}.badge.badge-default.badge-soft:hover{background:#6b728033}.badge.badge-default.badge-gradient{background:linear-gradient(135deg,#6b7280,#4b5563);color:#fff;border:none;box-shadow:0 2px 8px #6b72804d}.badge.badge-default.badge-gradient:hover{box-shadow:0 4px 16px #6b72804d;transform:translateY(-1px)}.badge.badge-default.badge-glow{animation:badge-glow 2s ease-in-out infinite}.badge.badge-default.badge-pulse{animation:badge-pulse 2s ease-in-out infinite}.badge.badge-clickable{cursor:pointer}.badge.badge-clickable:hover{transform:translateY(-2px)}.badge.badge-clickable:active{transform:translateY(0) scale(.96)}.badge.badge-disabled{opacity:.5;cursor:not-allowed;filter:grayscale(.3);pointer-events:none}.badge.badge-hidden{display:none}.badge.badge-animated{animation:badge-enter .3s cubic-bezier(.4,0,.2,1)}.badge .badge-close{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s cubic-bezier(.4,0,.2,1);margin-left:4px;background:#0000000d}.badge .badge-close:hover{background:#00000026;transform:scale(1.15)}.badge .badge-close:active{transform:scale(.9)}@keyframes badge-pulse{0%,to{transform:scale(1);opacity:1}50%{transform:scale(1.05);opacity:.9}}@keyframes badge-glow{0%,to{box-shadow:0 0 5px currentColor}50%{box-shadow:0 0 20px currentColor}}@keyframes badge-enter{0%{opacity:0;transform:scale(.8) translateY(-10px)}60%{transform:scale(1.05) translateY(2px)}to{opacity:1;transform:scale(1) translateY(0)}}@media(max-width:768px){.badge.badge-xs{font-size:9px;min-height:15.3px;margin:1.2px;padding:2px 8px}.badge.badge-xs.badge-circle{width:14.4px;height:14.4px;margin:1.2px}.badge.badge-sm{font-size:9.9px;min-height:18.7px;margin:1.8px;padding:4px 12px}.badge.badge-sm.badge-circle{width:17.6px;height:17.6px;margin:1.8px}.badge.badge-md{font-size:10.8px;min-height:23.8px;margin:2.4px;padding:6px 16px}.badge.badge-md.badge-circle{width:22.4px;height:22.4px;margin:2.4px}.badge.badge-lg{font-size:12.6px;min-height:28.9px;margin:3px;padding:8px 20px}.badge.badge-lg.badge-circle{width:27.2px;height:27.2px;margin:3px}.badge.badge-xl{font-size:14.4px;min-height:34px;margin:3.6px;padding:10px 24px}.badge.badge-xl.badge-circle{width:32px;height:32px;margin:3.6px}}\n"] }]
    }], null, { type: [{
            type: Input
        }], size: [{
            type: Input
        }], position: [{
            type: Input
        }], variant: [{
            type: Input
        }], shape: [{
            type: Input
        }], icon: [{
            type: Input
        }], label: [{
            type: Input
        }], count: [{
            type: Input
        }], maxCount: [{
            type: Input
        }], animated: [{
            type: Input
        }], pulse: [{
            type: Input
        }], IsVisible: [{
            type: Input
        }], glow: [{
            type: Input
        }], clickable: [{
            type: Input
        }], disabled: [{
            type: Input
        }], removable: [{
            type: Input
        }], showIcon: [{
            type: Input
        }], showClose: [{
            type: Input
        }], customColor: [{
            type: Input
        }], customBgColor: [{
            type: Input
        }], tooltip: [{
            type: Input
        }], closed: [{
            type: Output
        }], clicked: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(BadgeComponent, { className: "BadgeComponent", filePath: "shared/components/badge/badge.component.ts", lineNumber: 19 }); })();

const _c0$2 = ["*"];
const _c1$2 = () => ({ exact: false });
function ButtonComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵstyleMap(ctx_r0.iconStyle);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.icon, " ");
} }
function ButtonComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 4);
} }
function ButtonComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵstyleMap(ctx_r0.iconStyle);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.icon, " ");
} }
class ButtonComponent extends BaseComponent$1 {
    variant = 'primary';
    size = 'md';
    type = 'button';
    fullWidth = false;
    disabled = false;
    loading = false;
    icon = null;
    iconPosition = 'left';
    rounded = false;
    outline = false;
    ariaLabel = null;
    circle = false;
    active = false;
    /**
     * Style CSS inline appliqué au `<span class="material-icons">` interne.
     * Utile pour piloter une transformation dynamique (ex: rotation du compass
     * selon le bearing de la carte). Vide = aucun style inline.
     */
    iconStyle = null;
    routerLink = null;
    // - cm - Classe appliquee quand la route est active (deleguee a la directive routerLinkActive sur le bouton interne)
    routerLinkActive = null;
    // - cm - Options de matching de la route active (ex: { exact: boolean })
    routerLinkActiveOptions = null;
    /** Délai avant l'animation d'entrée CSS (ms). -1 = pas d'animation */
    animDelay = -1;
    /** Déclencheur : 'auto' = immédiat avec animDelay, 'scroll' = au scroll */
    animTrigger = 'auto';
    ButtonClick = new EventEmitter();
    toggleable = false; // Active le mode "bascule automatique"
    activeChange = new EventEmitter(); // Permet le two-way binding [(active)]
    // - cm - Palette de gradient anime plein bouton (voir ButtonGradient).
    // - cm - Si defini, le bouton affiche en permanence le gradient choisi au lieu du bg variant.
    gradient = null;
    _ElementRef = inject(ElementRef);
    _IsBrowser;
    _TrackingName = null;
    _Observer = null;
    constructor(pPlatformId) {
        super();
        this._IsBrowser = isPlatformBrowser(pPlatformId);
    }
    ngAfterViewInit() {
        if (!this._IsBrowser)
            return;
        // - cm - Tracking
        const lText = this._ElementRef.nativeElement.textContent?.trim() ?? '';
        if (lText) {
            this._TrackingName = this.BuildTrackingName(lText);
        }
        // - cm - Animation d'entrée
        if (this.animTrigger === 'scroll') {
            this._Hide(this._ElementRef.nativeElement);
            this._SetupScrollReveal();
        }
        else if (this.animTrigger === 'auto' && this.animDelay >= 0) {
            this._Hide(this._ElementRef.nativeElement);
            setTimeout(() => this._PlayEnter(), this.animDelay);
        }
    }
    ngOnDestroy() {
        this._Observer?.disconnect();
    }
    async onClick(pEvent) {
        // Ne rien faire si désactivé ou en chargement
        if (this.disabled || this.loading) {
            return;
        }
        // --- Gestion du basculement automatique ---
        // On bascule uniquement si toggleable est true ET qu'il n'y a PAS de routerLink
        // (pour éviter un conflit avec la navigation qui gère déjà l'état actif)
        if (this.toggleable && !this.routerLink) {
            this.active = !this.active;
            this.activeChange.emit(this.active);
        }
        // --- Émission de l'événement clic pour le parent ---
        this.ButtonClick.emit(pEvent);
        // --- Tracking (inchangé) ---
        if (this._TrackingName) {
            this.PostHog.Capture(this._TrackingName);
        }
    }
    get classes() {
        const classes = [
            'btn',
            `btn-${this.variant}`,
            `btn-${this.size}`,
            this.fullWidth ? 'btn-full-width' : '',
            this.rounded ? 'btn-rounded' : '',
            this.outline ? `btn-outline-${this.variant}` : '',
            this.disabled || this.loading ? 'btn-disabled' : '',
            this.icon ? 'btn-with-icon' : '',
            this.circle ? 'btn-circle' : '',
            this.active ? 'btn-active' : '',
            this.gradient ? `btn-gradient-${this.gradient}` : ''
        ];
        return classes.filter(Boolean).join(' ');
    }
    //#region Animation
    _SetupScrollReveal() {
        const lEl = this._ElementRef.nativeElement;
        this._Hide(lEl);
        this._Observer = new IntersectionObserver((pEntries) => {
            for (const lEntry of pEntries) {
                if (lEntry.isIntersecting) {
                    this._Observer?.unobserve(lEl);
                    const lDelay = this.animDelay >= 0 ? this.animDelay : 200;
                    setTimeout(() => this._Show(lEl), lDelay);
                    break;
                }
            }
        }, { threshold: 0.15 });
        this._Observer.observe(lEl);
    }
    _PlayEnter() {
        this._Show(this._ElementRef.nativeElement);
    }
    _Hide(pEl) {
        pEl.style.opacity = '0';
        pEl.style.transform = 'translateY(30px)';
        pEl.style.transition = 'none';
    }
    _Show(pEl) {
        pEl.style.transition = 'opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
        pEl.style.opacity = '1';
        pEl.style.transform = 'translateY(0)';
    }
    static ɵfac = function ButtonComponent_Factory(__ngFactoryType__) { /* @ts-ignore */
    return new (__ngFactoryType__ || ButtonComponent)(i0.ɵɵdirectiveInject(PLATFORM_ID)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ButtonComponent, selectors: [["app-button"]], inputs: { variant: "variant", size: "size", type: "type", fullWidth: "fullWidth", disabled: "disabled", loading: "loading", icon: "icon", iconPosition: "iconPosition", rounded: "rounded", outline: "outline", ariaLabel: "ariaLabel", circle: "circle", active: "active", iconStyle: "iconStyle", routerLink: "routerLink", routerLinkActive: "routerLinkActive", routerLinkActiveOptions: "routerLinkActiveOptions", animDelay: "animDelay", animTrigger: "animTrigger", toggleable: "toggleable", gradient: "gradient" }, outputs: { ButtonClick: "ButtonClick", activeChange: "activeChange" }, features: [i0.ɵɵInheritDefinitionFeature], ngContentSelectors: _c0$2, decls: 7, vars: 13, consts: [[3, "click", "type", "disabled", "routerLink", "routerLinkActive", "routerLinkActiveOptions"], ["aria-hidden", "true", 1, "material-icons", 3, "style"], [1, "btn-content"], [1, "btn-text"], ["aria-hidden", "true", 1, "loading-spinner"], ["aria-hidden", "true", 1, "material-icons"]], template: function ButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function ButtonComponent_Template_button_click_0_listener($event) { return ctx.onClick($event); });
            i0.ɵɵconditionalCreate(1, ButtonComponent_Conditional_1_Template, 2, 3, "span", 1);
            i0.ɵɵelementStart(2, "span", 2)(3, "span", 3);
            i0.ɵɵprojection(4);
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, ButtonComponent_Conditional_5_Template, 1, 0, "span", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(6, ButtonComponent_Conditional_6_Template, 2, 3, "span", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap(ctx.classes);
            i0.ɵɵproperty("type", ctx.type)("disabled", ctx.disabled || ctx.loading)("routerLink", ctx.routerLink)("routerLinkActive", ctx.routerLinkActive ?? "")("routerLinkActiveOptions", ctx.routerLinkActiveOptions ?? i0.ɵɵpureFunction0(12, _c1$2));
            i0.ɵɵattribute("aria-busy", ctx.loading ? "true" : null)("aria-label", ctx.ariaLabel || null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.icon && ctx.iconPosition === "left" ? 1 : -1);
            i0.ɵɵadvance(4);
            i0.ɵɵconditional(ctx.loading ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.icon && ctx.iconPosition === "right" ? 6 : -1);
        } }, dependencies: [RouterModule, i1$1.RouterLink, i1$1.RouterLinkActive], styles: ["@keyframes _ngcontent-%COMP%_btn-gradient-shift{0%{background-position:0% 50%}50%{background-position:100% 50%}to{background-position:0% 50%}}.btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 16px;font-weight:600;font-size:14px;line-height:1.4;letter-spacing:0;text-align:center;vertical-align:middle;white-space:nowrap;border-radius:12px;cursor:pointer;border:1px solid transparent;position:relative;overflow:hidden;transition:background-color .16s ease,color .16s ease,box-shadow .18s ease,border-color .16s ease,transform .12s ease;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.btn[_ngcontent-%COMP%]:before{content:\"\";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(135deg,#a78bfa,#f472b6,#38bdf8);background-size:200% auto;opacity:0;transition:opacity .22s ease;pointer-events:none;z-index:0}.btn[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{position:relative;z-index:1}.btn[_ngcontent-%COMP%]:hover{box-shadow:0 2px 10px #0000001a}.btn[_ngcontent-%COMP%]:active{transform:scale(.97)}.btn[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:2px}.btn.btn-sm[_ngcontent-%COMP%]{padding:8px 12px;font-size:12px;border-radius:8px}.btn.btn-md[_ngcontent-%COMP%]{padding:10px 16px;font-size:14px}.btn.btn-lg[_ngcontent-%COMP%]{padding:14px 20px;font-size:16px;border-radius:12px}.btn.btn-xl[_ngcontent-%COMP%]{padding:1.125rem 2.5rem;font-size:1.125rem;border-radius:9999px}.btn.btn-full-width[_ngcontent-%COMP%]{width:100%;display:flex}.btn.btn-rounded[_ngcontent-%COMP%]{border-radius:50px}.btn.btn-circle[_ngcontent-%COMP%]{width:32px;height:32px;border:none;padding:0;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:.5;transition:all .2s ease}.btn.btn-circle.btn-sm[_ngcontent-%COMP%]{width:28px;height:28px}.btn.btn-circle.btn-md[_ngcontent-%COMP%]{width:32px;height:32px}.btn.btn-circle.btn-lg[_ngcontent-%COMP%]{width:42px;height:42px}.btn.btn-circle[class*=btn-primary][_ngcontent-%COMP%]{background:#9c27b01a}.btn.btn-circle[class*=btn-primary][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#9c27b0;font-size:1rem}.btn.btn-circle[class*=btn-primary][_ngcontent-%COMP%]:hover{background:#9c27b033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-secondary][_ngcontent-%COMP%]{background:rgba(var(--%NS%sm-text-secondary-rgb),.1)}.btn.btn-circle[class*=btn-secondary][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%sm-text-secondary);font-size:1rem}.btn.btn-circle[class*=btn-secondary][_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-text-secondary-rgb),.2);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-success][_ngcontent-%COMP%]{background:#4caf501a}.btn.btn-circle[class*=btn-success][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#4caf50;font-size:1rem}.btn.btn-circle[class*=btn-success][_ngcontent-%COMP%]:hover{background:#4caf5033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-danger][_ngcontent-%COMP%]{background:#f443361a}.btn.btn-circle[class*=btn-danger][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#f44336;font-size:1rem}.btn.btn-circle[class*=btn-danger][_ngcontent-%COMP%]:hover{background:#f4433633;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-warning][_ngcontent-%COMP%]{background:#ff98001a}.btn.btn-circle[class*=btn-warning][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#ff9800;font-size:1rem}.btn.btn-circle[class*=btn-warning][_ngcontent-%COMP%]:hover{background:#ff980033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-info][_ngcontent-%COMP%]{background:#2196f31a}.btn.btn-circle[class*=btn-info][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#2196f3;font-size:1rem}.btn.btn-circle[class*=btn-info][_ngcontent-%COMP%]:hover{background:#2196f333;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-light][_ngcontent-%COMP%]{background:rgba(var(--%NS%sm-border-color-rgb),.1)}.btn.btn-circle[class*=btn-light][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%sm-btn-light-color);font-size:1rem}.btn.btn-circle[class*=btn-light][_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-border-color-rgb),.2);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-dark][_ngcontent-%COMP%]{background:rgba(var(--%NS%sm-border-color-rgb),.1)}.btn.btn-circle[class*=btn-dark][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%sm-btn-dark-color);font-size:1rem}.btn.btn-circle[class*=btn-dark][_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-border-color-rgb),.25);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-ghost][_ngcontent-%COMP%]{border:none;background:transparent;box-shadow:none;opacity:.7}.btn.btn-circle[class*=btn-ghost][_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%sm-btn-ghost-icon-color);font-size:1.125rem}.btn.btn-circle[class*=btn-ghost][_ngcontent-%COMP%]:hover{background:var(--%NS%sm-btn-ghost-hover-bg);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-ghost][_ngcontent-%COMP%]:hover   .material-icons[_ngcontent-%COMP%]{color:#7b1fa2}.btn.btn-circle[_ngcontent-%COMP%]:hover{transform:translateY(0)}.btn.btn-circle[_ngcontent-%COMP%]   .btn-content[_ngcontent-%COMP%]{display:none}.btn.btn-disabled[_ngcontent-%COMP%]{opacity:var(--%NS%sm-btn-disabled-opacity);cursor:not-allowed;pointer-events:none}.btn.btn-gradient-default[_ngcontent-%COMP%]{background:linear-gradient(135deg,#a78bfa,#f472b6,#38bdf8);background-size:200% auto;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--%NS%sm-shadow)}.btn.btn-gradient-default[_ngcontent-%COMP%]:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-sunset[_ngcontent-%COMP%]{background:linear-gradient(135deg,#fb923c,#f43f5e,#d946ef);background-size:200% auto;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--%NS%sm-shadow)}.btn.btn-gradient-sunset[_ngcontent-%COMP%]:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-ocean[_ngcontent-%COMP%]{background:linear-gradient(135deg,#22d3ee,#3b82f6,#6366f1);background-size:200% auto;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--%NS%sm-shadow)}.btn.btn-gradient-ocean[_ngcontent-%COMP%]:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-neon[_ngcontent-%COMP%]{background:linear-gradient(135deg,#84cc16,#06b6d4,#8b5cf6);background-size:200% auto;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--%NS%sm-shadow)}.btn.btn-gradient-neon[_ngcontent-%COMP%]:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-aurora[_ngcontent-%COMP%]{background:linear-gradient(135deg,#34d399,#60a5fa,#c084fc 66%,#f0abfc);background-size:200% auto;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--%NS%sm-shadow)}.btn.btn-gradient-aurora[_ngcontent-%COMP%]:hover{box-shadow:0 20px 60px #0003}.btn.btn-primary[_ngcontent-%COMP%]{background:#9c27b0;color:#fff;box-shadow:none}.btn.btn-primary[_ngcontent-%COMP%]:hover{background:#7b1fa2;box-shadow:var(--%NS%sm-shadow)}.btn.btn-primary[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-secondary[_ngcontent-%COMP%]{background:var(--%NS%sm-text-secondary);color:#fff;box-shadow:none}.btn.btn-secondary[_ngcontent-%COMP%]:hover{box-shadow:var(--%NS%sm-shadow)}.btn.btn-secondary[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-success[_ngcontent-%COMP%]{background:#4caf50;color:#fff;box-shadow:none}.btn.btn-success[_ngcontent-%COMP%]:hover{background:#409343;box-shadow:var(--%NS%sm-shadow)}.btn.btn-success[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-danger[_ngcontent-%COMP%]{background:#f44336;color:#fff;box-shadow:none}.btn.btn-danger[_ngcontent-%COMP%]:hover{background:#f21f0f;box-shadow:var(--%NS%sm-shadow)}.btn.btn-danger[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-warning[_ngcontent-%COMP%]{background:#ff9800;color:#fff;box-shadow:none;--%NS%sm-btn-warning-text: #1a1a1a;color:var(--%NS%sm-btn-warning-text, #1a1a1a)}.btn.btn-warning[_ngcontent-%COMP%]:hover{background:#d68000;box-shadow:var(--%NS%sm-shadow)}.btn.btn-warning[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-info[_ngcontent-%COMP%]{background:#2196f3;color:#fff;box-shadow:none}.btn.btn-info[_ngcontent-%COMP%]:hover{background:#0c82df;box-shadow:var(--%NS%sm-shadow)}.btn.btn-info[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-light[_ngcontent-%COMP%]{background:var(--%NS%sm-btn-light-bg);color:var(--%NS%sm-btn-light-color);border:1px solid var(--%NS%sm-btn-light-border);box-shadow:none}.btn.btn-light[_ngcontent-%COMP%]:before{background:linear-gradient(135deg,#7c4dff52,#9c27b03d,#2196f352)}.btn.btn-light[_ngcontent-%COMP%]:hover{background:#9c27b01a;box-shadow:var(--%NS%sm-shadow)}.btn.btn-light[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-dark[_ngcontent-%COMP%]{background:var(--%NS%sm-btn-dark-bg);color:var(--%NS%sm-btn-dark-color);box-shadow:none}.btn.btn-dark[_ngcontent-%COMP%]:before{background:radial-gradient(circle at 0% 50%,rgba(124,77,255,.55) 0%,transparent 50%),radial-gradient(circle at 100% 50%,rgba(33,150,243,.55) 0%,transparent 50%)}.btn.btn-dark[_ngcontent-%COMP%]:hover{background:var(--%NS%sm-surface-hover, var(--%NS%sm-btn-dark-bg));box-shadow:var(--%NS%sm-shadow)}.btn.btn-dark[_ngcontent-%COMP%]:hover:before{opacity:1;animation:_ngcontent-%COMP%_btn-gradient-shift 6s ease-in-out infinite}.btn.btn-active[_ngcontent-%COMP%]{background:#9c27b02e;color:#7b1fa2;border-color:#9c27b0}.btn.btn-active[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#7b1fa2}.btn.btn-active[_ngcontent-%COMP%]:hover{background:#9c27b047;color:#7b1fa2}.btn.btn-active[_ngcontent-%COMP%]:focus-visible{outline:2px solid #7b1fa2;outline-offset:1px;box-shadow:0 0 0 2px #9c27b066}.btn.btn-ghost.btn-active[_ngcontent-%COMP%]{background:#9c27b038;color:#7b1fa2;border-color:#9c27b0}.btn.btn-ghost.btn-active[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#7b1fa2}.btn.btn-ghost.btn-active[_ngcontent-%COMP%]:hover{background:#9c27b052}.btn.btn-outline-primary.btn-active[_ngcontent-%COMP%]{background:#9c27b0;color:#fff;border-color:#9c27b0}.btn.btn-outline-primary.btn-active[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#fff}.btn.btn-outline-primary.btn-active[_ngcontent-%COMP%]:hover{background:#9c27b0}.btn.btn-ghost[_ngcontent-%COMP%]{background:var(--%NS%sm-btn-ghost-bg);color:#9c27b0;border:2px solid var(--%NS%sm-btn-ghost-border);box-shadow:0 2px 10px #0000001a}.btn.btn-ghost[_ngcontent-%COMP%]:before{background:var(--%NS%sm-btn-ghost-hover-bg)}.btn.btn-ghost[_ngcontent-%COMP%]:hover{border-color:var(--%NS%sm-btn-ghost-hover-border);box-shadow:var(--%NS%sm-shadow)}.btn.btn-ghost[_ngcontent-%COMP%]:hover:before{opacity:1}.btn[class*=btn-outline-][_ngcontent-%COMP%]{background:transparent;box-shadow:none}.btn.btn-outline-primary[_ngcontent-%COMP%]{color:#9c27b0;border:1px solid #9c27b0}.btn.btn-outline-primary[_ngcontent-%COMP%]:hover{background:#9c27b01a}.btn.btn-outline-secondary[_ngcontent-%COMP%]{color:var(--%NS%sm-text-secondary);border:1px solid var(--%NS%sm-text-secondary)}.btn.btn-outline-secondary[_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-text-secondary-rgb),.1)}.btn.btn-outline-success[_ngcontent-%COMP%]{color:#4caf50;border:1px solid #4caf50}.btn.btn-outline-success[_ngcontent-%COMP%]:hover{background:#4caf501a}.btn.btn-outline-danger[_ngcontent-%COMP%]{color:#f44336;border:1px solid #f44336}.btn.btn-outline-danger[_ngcontent-%COMP%]:hover{background:#f443361a}.btn.btn-outline-warning[_ngcontent-%COMP%]{color:#ff9800;border:1px solid #ff9800}.btn.btn-outline-warning[_ngcontent-%COMP%]:hover{background:#ff98001a}.btn.btn-outline-info[_ngcontent-%COMP%]{color:#2196f3;border:1px solid #2196f3}.btn.btn-outline-info[_ngcontent-%COMP%]:hover{background:#2196f31a}.btn.btn-outline-light[_ngcontent-%COMP%]{color:var(--%NS%sm-btn-light-color);border:1px solid var(--%NS%sm-btn-light-border)}.btn.btn-outline-light[_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-border-color-rgb),.15)}.btn.btn-outline-dark[_ngcontent-%COMP%]{color:var(--%NS%sm-btn-dark-bg);border:1px solid var(--%NS%sm-btn-dark-bg)}.btn.btn-outline-dark[_ngcontent-%COMP%]:hover{background:rgba(var(--%NS%sm-border-color-rgb),.2)}.btn.btn-with-icon[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:1.125rem}.btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%]{width:16px;height:16px;border:2px solid var(--%NS%sm-spinner-track);border-radius:50%;border-top-color:#fff;animation:spin .8s linear infinite;margin-left:8px;display:inline-block}@media(max-width:768px){.btn.btn-sm[_ngcontent-%COMP%]{padding:6px 10px;font-size:11px}.btn.btn-md[_ngcontent-%COMP%]{padding:8px 14px;font-size:13px}.btn.btn-lg[_ngcontent-%COMP%]{padding:10px 16px;font-size:14px}.btn.btn-circle.btn-sm[_ngcontent-%COMP%]{width:24px;height:24px}.btn.btn-circle.btn-md[_ngcontent-%COMP%]{width:28px;height:28px}.btn.btn-circle.btn-lg[_ngcontent-%COMP%]{width:36px;height:36px}}.nav-link[_nghost-%COMP%]{display:flex}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:transparent;border:none;border-radius:0;box-shadow:none;font-family:inherit;font-weight:500;font-size:.85rem;line-height:1.5;padding:.4rem;color:var(--%NS%sm-text-primary);text-decoration:none;white-space:nowrap;position:relative;transition:color .3s ease;overflow:visible;transform:none}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:before{display:none}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover{transform:none;background:transparent;border:none;box-shadow:none;color:#9c27b0}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:after{content:\"\";position:absolute;bottom:0;left:0;width:0;height:2px;background:linear-gradient(135deg,#9c27b0,#f06292);transition:width .3s ease;z-index:0}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:after{width:100%}.nav-link[_nghost-%COMP%]   .btn.active[_ngcontent-%COMP%]{color:#9c27b0}.nav-link[_nghost-%COMP%]   .btn.active[_ngcontent-%COMP%]:after{width:100%}@media(max-width:1200px){.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{padding:.75rem 0;font-size:1rem;border-bottom:1px solid var(--%NS%sm-border-color);min-height:42px;display:flex;align-items:center;box-sizing:border-box;width:100%;justify-content:flex-start}.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:after{display:none}.nav-link[_nghost-%COMP%]   .btn.active[_ngcontent-%COMP%]{color:#9c27b0;background:linear-gradient(90deg,rgba(156,39,176,.1) 0%,transparent 100%);margin:0 -1.5rem;padding:.75rem 1.5rem}}@media(max-width:1200px)and (max-width:375px){.nav-link[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{padding:.5rem 0;font-size:.95rem;min-height:38px}.nav-link[_nghost-%COMP%]   .btn.active[_ngcontent-%COMP%]{margin:0 -1rem;padding:.5rem 1rem}}.nav-link--estimation[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{color:#9c27b0;font-weight:700}.nav-link--estimation[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:1rem;vertical-align:middle;margin-right:.2rem}.nav-link--estimation[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover{color:#9c27b0}.btn-close[_nghost-%COMP%]{flex-shrink:0;display:inline-flex}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{width:36px;height:36px;min-width:36px;padding:0;margin:0;gap:0;border:none;border-radius:50%;background:#9c27b00d;color:var(--%NS%sm-text-secondary);cursor:pointer;display:flex;align-items:center;justify-content:center;box-sizing:border-box;transform:rotate(0);transform-origin:center center;transition:transform .3s ease,background .3s ease,color .2s ease}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .btn-content[_ngcontent-%COMP%]{display:none}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:20px;line-height:1;color:var(--%NS%sm-text-secondary);transition:color .2s ease}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover{background:#9c27b01a;transform:rotate(90deg)}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover   .material-icons[_ngcontent-%COMP%]{color:var(--%NS%sm-text-primary)}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:active{transform:rotate(90deg) scale(.95)}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{outline:none;box-shadow:0 0 0 3px #9c27b033}@media(max-width:600px){.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{width:32px;height:32px;min-width:32px}.btn-close[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}}.btn-fullscreen[_nghost-%COMP%]{flex-shrink:0;display:inline-flex}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{width:36px;height:36px;min-width:36px;padding:0;margin:0;gap:0;border:none;border-radius:50%;background:#9c27b00d;color:var(--%NS%sm-text-secondary);cursor:pointer;display:flex;align-items:center;justify-content:center;box-sizing:border-box;transition:transform .3s ease,background .3s ease,color .2s ease}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .btn-content[_ngcontent-%COMP%]{display:none}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:20px;line-height:1;color:var(--%NS%sm-text-secondary);transition:color .2s ease}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover{background:#9c27b01a}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover   .material-icons[_ngcontent-%COMP%]{color:#9c27b0}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:active{transform:scale(.95)}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{outline:none}@media(max-width:600px){.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{width:32px;height:32px;min-width:32px}.btn-fullscreen[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%], .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%], .custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{padding:12px 24px;min-width:100px;border-radius:12px;border:none}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%], .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%], .custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus, .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus, .custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{outline:none}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:disabled, .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:disabled, .custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:disabled{opacity:.5;cursor:not-allowed;transform:none!important}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%], .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%], .custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%]{width:18px;height:18px}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:#9c27b00d;color:var(--%NS%sm-text-primary);border:1px solid rgba(156,39,176,.15)}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){background:#9c27b01a;border-color:#9c27b040}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:active:not(:disabled){transform:scale(.98)}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px #9c27b026}.btn-cancel[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%]{border:2px solid var(--%NS%sm-spinner-track);border-top-color:currentColor}.btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#9c27b0,#f06292);color:#fff;box-shadow:0 4px 15px #9c27b04d}.btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 6px 20px #9c27b066}.btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:active:not(:disabled){transform:translateY(0);box-shadow:0 2px 10px #9c27b04d}.btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{box-shadow:0 4px 15px #9c27b04d,0 0 0 3px #9c27b033}.btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%]{border-top-color:#fff}.popup-type-success   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#4caf50,color-mix(in srgb,#4caf50,white 10%));box-shadow:0 4px 15px #4caf504d}.popup-type-success   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){box-shadow:0 6px 20px #4caf5066}.popup-type-warning   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#ff9800,color-mix(in srgb,#ff9800,white 10%));box-shadow:0 4px 15px #ff98004d}.popup-type-warning   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){box-shadow:0 6px 20px #ff980066}.popup-type-error   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#f44336,color-mix(in srgb,#f44336,white 10%));box-shadow:0 4px 15px #f443364d}.popup-type-error   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){box-shadow:0 6px 20px #f4433666}.popup-type-info   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:linear-gradient(135deg,#2196f3,color-mix(in srgb,#2196f3,white 10%));box-shadow:0 4px 15px #2196f34d}.popup-type-info   .btn-confirm[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){box-shadow:0 6px 20px #2196f366}.btn-confirm.loading[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{pointer-events:none}.custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]{background:rgba(var(--%NS%sm-text-secondary-rgb),.1);color:var(--%NS%sm-text-secondary)}.custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:hover:not(:disabled){background:rgba(var(--%NS%sm-text-secondary-rgb),.2)}.custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:active:not(:disabled){transform:scale(.98)}.custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px rgba(var(--%NS%sm-text-secondary-rgb),.15)}.custom-action[_nghost-%COMP%]   .btn[_ngcontent-%COMP%]   .loading-spinner[_ngcontent-%COMP%]{border:2px solid var(--%NS%sm-spinner-track);border-top-color:currentColor}.custom-action[_nghost-%COMP%]   .btn.btn-danger[_ngcontent-%COMP%]{background:#f443361a;color:#f44336}.custom-action[_nghost-%COMP%]   .btn.btn-danger[_ngcontent-%COMP%]:hover:not(:disabled){background:#f4433633}.custom-action[_nghost-%COMP%]   .btn.btn-danger[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px #f4433626}.custom-action[_nghost-%COMP%]   .btn.btn-success[_ngcontent-%COMP%]{background:#4caf501a;color:#4caf50}.custom-action[_nghost-%COMP%]   .btn.btn-success[_ngcontent-%COMP%]:hover:not(:disabled){background:#4caf5033}.custom-action[_nghost-%COMP%]   .btn.btn-success[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px #4caf5026}.custom-action[_nghost-%COMP%]   .btn.btn-warning[_ngcontent-%COMP%]{background:#ff98001a;color:#ff9800}.custom-action[_nghost-%COMP%]   .btn.btn-warning[_ngcontent-%COMP%]:hover:not(:disabled){background:#ff980033}.custom-action[_nghost-%COMP%]   .btn.btn-warning[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px #ff980026}.custom-action[_nghost-%COMP%]   .btn.btn-info[_ngcontent-%COMP%]{background:#2196f31a;color:#2196f3}.custom-action[_nghost-%COMP%]   .btn.btn-info[_ngcontent-%COMP%]:hover:not(:disabled){background:#2196f333}.custom-action[_nghost-%COMP%]   .btn.btn-info[_ngcontent-%COMP%]:focus{box-shadow:0 0 0 3px #2196f326}"], changeDetection: 1 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ButtonComponent, [{
        type: Component,
        args: [{ selector: 'app-button', standalone: true, changeDetection: ChangeDetectionStrategy.Eager, imports: [RouterModule], template: "<button [type]=\"type\" [disabled]=\"disabled || loading\" [class]=\"classes\" [attr.aria-busy]=\"loading ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel || null\" (click)=\"onClick($event)\"\n  [routerLink]=\"routerLink\" [routerLinkActive]=\"routerLinkActive ?? ''\"\n  [routerLinkActiveOptions]=\"routerLinkActiveOptions ?? { exact: false }\">\n\n  @if (icon && iconPosition === 'left') {\n    <span class=\"material-icons\" aria-hidden=\"true\" [style]=\"iconStyle\">\n      {{ icon }}\n    </span>\n  }\n\n  <span class=\"btn-content\">\n    <span class=\"btn-text\">\n      <ng-content></ng-content>\n    </span>\n\n    @if (loading) {\n      <span class=\"loading-spinner\" aria-hidden=\"true\"></span>\n    }\n  </span>\n\n  @if (icon && iconPosition === 'right') {\n    <span class=\"material-icons\" aria-hidden=\"true\" [style]=\"iconStyle\">\n      {{ icon }}\n    </span>\n  }\n</button>", styles: ["@keyframes btn-gradient-shift{0%{background-position:0% 50%}50%{background-position:100% 50%}to{background-position:0% 50%}}.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 16px;font-weight:600;font-size:14px;line-height:1.4;letter-spacing:0;text-align:center;vertical-align:middle;white-space:nowrap;border-radius:12px;cursor:pointer;border:1px solid transparent;position:relative;overflow:hidden;transition:background-color .16s ease,color .16s ease,box-shadow .18s ease,border-color .16s ease,transform .12s ease;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.btn:before{content:\"\";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(135deg,#a78bfa,#f472b6,#38bdf8);background-size:200% auto;opacity:0;transition:opacity .22s ease;pointer-events:none;z-index:0}.btn>*{position:relative;z-index:1}.btn:hover{box-shadow:0 2px 10px #0000001a}.btn:active{transform:scale(.97)}.btn:focus-visible{outline:2px solid currentColor;outline-offset:2px}.btn.btn-sm{padding:8px 12px;font-size:12px;border-radius:8px}.btn.btn-md{padding:10px 16px;font-size:14px}.btn.btn-lg{padding:14px 20px;font-size:16px;border-radius:12px}.btn.btn-xl{padding:1.125rem 2.5rem;font-size:1.125rem;border-radius:9999px}.btn.btn-full-width{width:100%;display:flex}.btn.btn-rounded{border-radius:50px}.btn.btn-circle{width:32px;height:32px;border:none;padding:0;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:.5;transition:all .2s ease}.btn.btn-circle.btn-sm{width:28px;height:28px}.btn.btn-circle.btn-md{width:32px;height:32px}.btn.btn-circle.btn-lg{width:42px;height:42px}.btn.btn-circle[class*=btn-primary]{background:#9c27b01a}.btn.btn-circle[class*=btn-primary] .material-icons{color:#9c27b0;font-size:1rem}.btn.btn-circle[class*=btn-primary]:hover{background:#9c27b033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-secondary]{background:rgba(var(--sm-text-secondary-rgb),.1)}.btn.btn-circle[class*=btn-secondary] .material-icons{color:var(--sm-text-secondary);font-size:1rem}.btn.btn-circle[class*=btn-secondary]:hover{background:rgba(var(--sm-text-secondary-rgb),.2);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-success]{background:#4caf501a}.btn.btn-circle[class*=btn-success] .material-icons{color:#4caf50;font-size:1rem}.btn.btn-circle[class*=btn-success]:hover{background:#4caf5033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-danger]{background:#f443361a}.btn.btn-circle[class*=btn-danger] .material-icons{color:#f44336;font-size:1rem}.btn.btn-circle[class*=btn-danger]:hover{background:#f4433633;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-warning]{background:#ff98001a}.btn.btn-circle[class*=btn-warning] .material-icons{color:#ff9800;font-size:1rem}.btn.btn-circle[class*=btn-warning]:hover{background:#ff980033;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-info]{background:#2196f31a}.btn.btn-circle[class*=btn-info] .material-icons{color:#2196f3;font-size:1rem}.btn.btn-circle[class*=btn-info]:hover{background:#2196f333;opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-light]{background:rgba(var(--sm-border-color-rgb),.1)}.btn.btn-circle[class*=btn-light] .material-icons{color:var(--sm-btn-light-color);font-size:1rem}.btn.btn-circle[class*=btn-light]:hover{background:rgba(var(--sm-border-color-rgb),.2);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-dark]{background:rgba(var(--sm-border-color-rgb),.1)}.btn.btn-circle[class*=btn-dark] .material-icons{color:var(--sm-btn-dark-color);font-size:1rem}.btn.btn-circle[class*=btn-dark]:hover{background:rgba(var(--sm-border-color-rgb),.25);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-ghost]{border:none;background:transparent;box-shadow:none;opacity:.7}.btn.btn-circle[class*=btn-ghost] .material-icons{color:var(--sm-btn-ghost-icon-color);font-size:1.125rem}.btn.btn-circle[class*=btn-ghost]:hover{background:var(--sm-btn-ghost-hover-bg);opacity:1;transform:translateY(0);box-shadow:none}.btn.btn-circle[class*=btn-ghost]:hover .material-icons{color:#7b1fa2}.btn.btn-circle:hover{transform:translateY(0)}.btn.btn-circle .btn-content{display:none}.btn.btn-disabled{opacity:var(--sm-btn-disabled-opacity);cursor:not-allowed;pointer-events:none}.btn.btn-gradient-default{background:linear-gradient(135deg,#a78bfa,#f472b6,#38bdf8);background-size:200% auto;animation:btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--sm-shadow)}.btn.btn-gradient-default:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-sunset{background:linear-gradient(135deg,#fb923c,#f43f5e,#d946ef);background-size:200% auto;animation:btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--sm-shadow)}.btn.btn-gradient-sunset:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-ocean{background:linear-gradient(135deg,#22d3ee,#3b82f6,#6366f1);background-size:200% auto;animation:btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--sm-shadow)}.btn.btn-gradient-ocean:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-neon{background:linear-gradient(135deg,#84cc16,#06b6d4,#8b5cf6);background-size:200% auto;animation:btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--sm-shadow)}.btn.btn-gradient-neon:hover{box-shadow:0 20px 60px #0003}.btn.btn-gradient-aurora{background:linear-gradient(135deg,#34d399,#60a5fa,#c084fc 66%,#f0abfc);background-size:200% auto;animation:btn-gradient-shift 6s ease-in-out infinite;color:#fff;box-shadow:var(--sm-shadow)}.btn.btn-gradient-aurora:hover{box-shadow:0 20px 60px #0003}.btn.btn-primary{background:#9c27b0;color:#fff;box-shadow:none}.btn.btn-primary:hover{background:#7b1fa2;box-shadow:var(--sm-shadow)}.btn.btn-primary:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-secondary{background:var(--sm-text-secondary);color:#fff;box-shadow:none}.btn.btn-secondary:hover{box-shadow:var(--sm-shadow)}.btn.btn-secondary:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-success{background:#4caf50;color:#fff;box-shadow:none}.btn.btn-success:hover{background:#409343;box-shadow:var(--sm-shadow)}.btn.btn-success:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-danger{background:#f44336;color:#fff;box-shadow:none}.btn.btn-danger:hover{background:#f21f0f;box-shadow:var(--sm-shadow)}.btn.btn-danger:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-warning{background:#ff9800;color:#fff;box-shadow:none;--sm-btn-warning-text: #1a1a1a;color:var(--sm-btn-warning-text, #1a1a1a)}.btn.btn-warning:hover{background:#d68000;box-shadow:var(--sm-shadow)}.btn.btn-warning:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-info{background:#2196f3;color:#fff;box-shadow:none}.btn.btn-info:hover{background:#0c82df;box-shadow:var(--sm-shadow)}.btn.btn-info:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-light{background:var(--sm-btn-light-bg);color:var(--sm-btn-light-color);border:1px solid var(--sm-btn-light-border);box-shadow:none}.btn.btn-light:before{background:linear-gradient(135deg,#7c4dff52,#9c27b03d,#2196f352)}.btn.btn-light:hover{background:#9c27b01a;box-shadow:var(--sm-shadow)}.btn.btn-light:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-dark{background:var(--sm-btn-dark-bg);color:var(--sm-btn-dark-color);box-shadow:none}.btn.btn-dark:before{background:radial-gradient(circle at 0% 50%,rgba(124,77,255,.55) 0%,transparent 50%),radial-gradient(circle at 100% 50%,rgba(33,150,243,.55) 0%,transparent 50%)}.btn.btn-dark:hover{background:var(--sm-surface-hover, var(--sm-btn-dark-bg));box-shadow:var(--sm-shadow)}.btn.btn-dark:hover:before{opacity:1;animation:btn-gradient-shift 6s ease-in-out infinite}.btn.btn-active{background:#9c27b02e;color:#7b1fa2;border-color:#9c27b0}.btn.btn-active .material-icons{color:#7b1fa2}.btn.btn-active:hover{background:#9c27b047;color:#7b1fa2}.btn.btn-active:focus-visible{outline:2px solid #7b1fa2;outline-offset:1px;box-shadow:0 0 0 2px #9c27b066}.btn.btn-ghost.btn-active{background:#9c27b038;color:#7b1fa2;border-color:#9c27b0}.btn.btn-ghost.btn-active .material-icons{color:#7b1fa2}.btn.btn-ghost.btn-active:hover{background:#9c27b052}.btn.btn-outline-primary.btn-active{background:#9c27b0;color:#fff;border-color:#9c27b0}.btn.btn-outline-primary.btn-active .material-icons{color:#fff}.btn.btn-outline-primary.btn-active:hover{background:#9c27b0}.btn.btn-ghost{background:var(--sm-btn-ghost-bg);color:#9c27b0;border:2px solid var(--sm-btn-ghost-border);box-shadow:0 2px 10px #0000001a}.btn.btn-ghost:before{background:var(--sm-btn-ghost-hover-bg)}.btn.btn-ghost:hover{border-color:var(--sm-btn-ghost-hover-border);box-shadow:var(--sm-shadow)}.btn.btn-ghost:hover:before{opacity:1}.btn[class*=btn-outline-]{background:transparent;box-shadow:none}.btn.btn-outline-primary{color:#9c27b0;border:1px solid #9c27b0}.btn.btn-outline-primary:hover{background:#9c27b01a}.btn.btn-outline-secondary{color:var(--sm-text-secondary);border:1px solid var(--sm-text-secondary)}.btn.btn-outline-secondary:hover{background:rgba(var(--sm-text-secondary-rgb),.1)}.btn.btn-outline-success{color:#4caf50;border:1px solid #4caf50}.btn.btn-outline-success:hover{background:#4caf501a}.btn.btn-outline-danger{color:#f44336;border:1px solid #f44336}.btn.btn-outline-danger:hover{background:#f443361a}.btn.btn-outline-warning{color:#ff9800;border:1px solid #ff9800}.btn.btn-outline-warning:hover{background:#ff98001a}.btn.btn-outline-info{color:#2196f3;border:1px solid #2196f3}.btn.btn-outline-info:hover{background:#2196f31a}.btn.btn-outline-light{color:var(--sm-btn-light-color);border:1px solid var(--sm-btn-light-border)}.btn.btn-outline-light:hover{background:rgba(var(--sm-border-color-rgb),.15)}.btn.btn-outline-dark{color:var(--sm-btn-dark-bg);border:1px solid var(--sm-btn-dark-bg)}.btn.btn-outline-dark:hover{background:rgba(var(--sm-border-color-rgb),.2)}.btn.btn-with-icon .material-icons{font-size:1.125rem}.btn .loading-spinner{width:16px;height:16px;border:2px solid var(--sm-spinner-track);border-radius:50%;border-top-color:#fff;animation:spin .8s linear infinite;margin-left:8px;display:inline-block}@media(max-width:768px){.btn.btn-sm{padding:6px 10px;font-size:11px}.btn.btn-md{padding:8px 14px;font-size:13px}.btn.btn-lg{padding:10px 16px;font-size:14px}.btn.btn-circle.btn-sm{width:24px;height:24px}.btn.btn-circle.btn-md{width:28px;height:28px}.btn.btn-circle.btn-lg{width:36px;height:36px}}:host(.nav-link){display:flex}:host(.nav-link) .btn{background:transparent;border:none;border-radius:0;box-shadow:none;font-family:inherit;font-weight:500;font-size:.85rem;line-height:1.5;padding:.4rem;color:var(--sm-text-primary);text-decoration:none;white-space:nowrap;position:relative;transition:color .3s ease;overflow:visible;transform:none}:host(.nav-link) .btn:before{display:none}:host(.nav-link) .btn:hover{transform:none;background:transparent;border:none;box-shadow:none;color:#9c27b0}:host(.nav-link) .btn:after{content:\"\";position:absolute;bottom:0;left:0;width:0;height:2px;background:linear-gradient(135deg,#9c27b0,#f06292);transition:width .3s ease;z-index:0}:host(.nav-link) .btn:hover:after{width:100%}:host(.nav-link) .btn.active{color:#9c27b0}:host(.nav-link) .btn.active:after{width:100%}@media(max-width:1200px){:host(.nav-link) .btn{padding:.75rem 0;font-size:1rem;border-bottom:1px solid var(--sm-border-color);min-height:42px;display:flex;align-items:center;box-sizing:border-box;width:100%;justify-content:flex-start}:host(.nav-link) .btn:after{display:none}:host(.nav-link) .btn.active{color:#9c27b0;background:linear-gradient(90deg,rgba(156,39,176,.1) 0%,transparent 100%);margin:0 -1.5rem;padding:.75rem 1.5rem}}@media(max-width:1200px)and (max-width:375px){:host(.nav-link) .btn{padding:.5rem 0;font-size:.95rem;min-height:38px}:host(.nav-link) .btn.active{margin:0 -1rem;padding:.5rem 1rem}}:host(.nav-link--estimation) .btn{color:#9c27b0;font-weight:700}:host(.nav-link--estimation) .btn .material-icons{font-size:1rem;vertical-align:middle;margin-right:.2rem}:host(.nav-link--estimation) .btn:hover{color:#9c27b0}:host(.btn-close){flex-shrink:0;display:inline-flex}:host(.btn-close) .btn{width:36px;height:36px;min-width:36px;padding:0;margin:0;gap:0;border:none;border-radius:50%;background:#9c27b00d;color:var(--sm-text-secondary);cursor:pointer;display:flex;align-items:center;justify-content:center;box-sizing:border-box;transform:rotate(0);transform-origin:center center;transition:transform .3s ease,background .3s ease,color .2s ease}:host(.btn-close) .btn .btn-content{display:none}:host(.btn-close) .btn .material-icons{font-size:20px;line-height:1;color:var(--sm-text-secondary);transition:color .2s ease}:host(.btn-close) .btn:hover{background:#9c27b01a;transform:rotate(90deg)}:host(.btn-close) .btn:hover .material-icons{color:var(--sm-text-primary)}:host(.btn-close) .btn:active{transform:rotate(90deg) scale(.95)}:host(.btn-close) .btn:focus{outline:none;box-shadow:0 0 0 3px #9c27b033}@media(max-width:600px){:host(.btn-close) .btn{width:32px;height:32px;min-width:32px}:host(.btn-close) .btn .material-icons{font-size:18px}}:host(.btn-fullscreen){flex-shrink:0;display:inline-flex}:host(.btn-fullscreen) .btn{width:36px;height:36px;min-width:36px;padding:0;margin:0;gap:0;border:none;border-radius:50%;background:#9c27b00d;color:var(--sm-text-secondary);cursor:pointer;display:flex;align-items:center;justify-content:center;box-sizing:border-box;transition:transform .3s ease,background .3s ease,color .2s ease}:host(.btn-fullscreen) .btn .btn-content{display:none}:host(.btn-fullscreen) .btn .material-icons{font-size:20px;line-height:1;color:var(--sm-text-secondary);transition:color .2s ease}:host(.btn-fullscreen) .btn:hover{background:#9c27b01a}:host(.btn-fullscreen) .btn:hover .material-icons{color:#9c27b0}:host(.btn-fullscreen) .btn:active{transform:scale(.95)}:host(.btn-fullscreen) .btn:focus{outline:none}@media(max-width:600px){:host(.btn-fullscreen) .btn{width:32px;height:32px;min-width:32px}:host(.btn-fullscreen) .btn .material-icons{font-size:18px}}:host(.btn-cancel) .btn,:host(.btn-confirm) .btn,:host(.custom-action) .btn{padding:12px 24px;min-width:100px;border-radius:12px;border:none}:host(.btn-cancel) .btn .material-icons,:host(.btn-confirm) .btn .material-icons,:host(.custom-action) .btn .material-icons{font-size:18px}:host(.btn-cancel) .btn:focus,:host(.btn-confirm) .btn:focus,:host(.custom-action) .btn:focus{outline:none}:host(.btn-cancel) .btn:disabled,:host(.btn-confirm) .btn:disabled,:host(.custom-action) .btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}:host(.btn-cancel) .btn .loading-spinner,:host(.btn-confirm) .btn .loading-spinner,:host(.custom-action) .btn .loading-spinner{width:18px;height:18px}:host(.btn-cancel) .btn{background:#9c27b00d;color:var(--sm-text-primary);border:1px solid rgba(156,39,176,.15)}:host(.btn-cancel) .btn:hover:not(:disabled){background:#9c27b01a;border-color:#9c27b040}:host(.btn-cancel) .btn:active:not(:disabled){transform:scale(.98)}:host(.btn-cancel) .btn:focus{box-shadow:0 0 0 3px #9c27b026}:host(.btn-cancel) .btn .loading-spinner{border:2px solid var(--sm-spinner-track);border-top-color:currentColor}:host(.btn-confirm) .btn{background:linear-gradient(135deg,#9c27b0,#f06292);color:#fff;box-shadow:0 4px 15px #9c27b04d}:host(.btn-confirm) .btn:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 6px 20px #9c27b066}:host(.btn-confirm) .btn:active:not(:disabled){transform:translateY(0);box-shadow:0 2px 10px #9c27b04d}:host(.btn-confirm) .btn:focus{box-shadow:0 4px 15px #9c27b04d,0 0 0 3px #9c27b033}:host(.btn-confirm) .btn .loading-spinner{border-top-color:#fff}:host-context(.popup-type-success) :host(.btn-confirm) .btn{background:linear-gradient(135deg,#4caf50,color-mix(in srgb,#4caf50,white 10%));box-shadow:0 4px 15px #4caf504d}:host-context(.popup-type-success) :host(.btn-confirm) .btn:hover:not(:disabled){box-shadow:0 6px 20px #4caf5066}:host-context(.popup-type-warning) :host(.btn-confirm) .btn{background:linear-gradient(135deg,#ff9800,color-mix(in srgb,#ff9800,white 10%));box-shadow:0 4px 15px #ff98004d}:host-context(.popup-type-warning) :host(.btn-confirm) .btn:hover:not(:disabled){box-shadow:0 6px 20px #ff980066}:host-context(.popup-type-error) :host(.btn-confirm) .btn{background:linear-gradient(135deg,#f44336,color-mix(in srgb,#f44336,white 10%));box-shadow:0 4px 15px #f443364d}:host-context(.popup-type-error) :host(.btn-confirm) .btn:hover:not(:disabled){box-shadow:0 6px 20px #f4433666}:host-context(.popup-type-info) :host(.btn-confirm) .btn{background:linear-gradient(135deg,#2196f3,color-mix(in srgb,#2196f3,white 10%));box-shadow:0 4px 15px #2196f34d}:host-context(.popup-type-info) :host(.btn-confirm) .btn:hover:not(:disabled){box-shadow:0 6px 20px #2196f366}:host(.btn-confirm).loading .btn{pointer-events:none}:host(.custom-action) .btn{background:rgba(var(--sm-text-secondary-rgb),.1);color:var(--sm-text-secondary)}:host(.custom-action) .btn:hover:not(:disabled){background:rgba(var(--sm-text-secondary-rgb),.2)}:host(.custom-action) .btn:active:not(:disabled){transform:scale(.98)}:host(.custom-action) .btn:focus{box-shadow:0 0 0 3px rgba(var(--sm-text-secondary-rgb),.15)}:host(.custom-action) .btn .loading-spinner{border:2px solid var(--sm-spinner-track);border-top-color:currentColor}:host(.custom-action) .btn.btn-danger{background:#f443361a;color:#f44336}:host(.custom-action) .btn.btn-danger:hover:not(:disabled){background:#f4433633}:host(.custom-action) .btn.btn-danger:focus{box-shadow:0 0 0 3px #f4433626}:host(.custom-action) .btn.btn-success{background:#4caf501a;color:#4caf50}:host(.custom-action) .btn.btn-success:hover:not(:disabled){background:#4caf5033}:host(.custom-action) .btn.btn-success:focus{box-shadow:0 0 0 3px #4caf5026}:host(.custom-action) .btn.btn-warning{background:#ff98001a;color:#ff9800}:host(.custom-action) .btn.btn-warning:hover:not(:disabled){background:#ff980033}:host(.custom-action) .btn.btn-warning:focus{box-shadow:0 0 0 3px #ff980026}:host(.custom-action) .btn.btn-info{background:#2196f31a;color:#2196f3}:host(.custom-action) .btn.btn-info:hover:not(:disabled){background:#2196f333}:host(.custom-action) .btn.btn-info:focus{box-shadow:0 0 0 3px #2196f326}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [PLATFORM_ID]
            }] }], { variant: [{
            type: Input
        }], size: [{
            type: Input
        }], type: [{
            type: Input
        }], fullWidth: [{
            type: Input
        }], disabled: [{
            type: Input
        }], loading: [{
            type: Input
        }], icon: [{
            type: Input
        }], iconPosition: [{
            type: Input
        }], rounded: [{
            type: Input
        }], outline: [{
            type: Input
        }], ariaLabel: [{
            type: Input
        }], circle: [{
            type: Input
        }], active: [{
            type: Input
        }], iconStyle: [{
            type: Input
        }], routerLink: [{
            type: Input
        }], routerLinkActive: [{
            type: Input
        }], routerLinkActiveOptions: [{
            type: Input
        }], animDelay: [{
            type: Input
        }], animTrigger: [{
            type: Input
        }], ButtonClick: [{
            type: Output
        }], toggleable: [{
            type: Input
        }], activeChange: [{
            type: Output
        }], gradient: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ButtonComponent, { className: "ButtonComponent", filePath: "shared/components/button/button.component.ts", lineNumber: 25 }); })();

const _c0$1 = ["bubbleTemplate"];
const _c1$1 = ["*"];
function TooltipComponent_Conditional_2_ng_template_0_Conditional_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function TooltipComponent_Conditional_2_ng_template_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 3);
    i0.ɵɵtemplate(1, TooltipComponent_Conditional_2_ng_template_0_Conditional_1_ng_container_1_Template, 1, 0, "ng-container", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r1.Template)("ngTemplateOutletContext", ctx_r1.Context);
} }
function TooltipComponent_Conditional_2_ng_template_0_Conditional_2_For_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "strong", 8);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const lLine_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", lLine_r3.Label, "\u00A0:\u00A0");
} }
function TooltipComponent_Conditional_2_ng_template_0_Conditional_2_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 6)(1, "span", 7);
    i0.ɵɵtext(2, "error");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(3, TooltipComponent_Conditional_2_ng_template_0_Conditional_2_For_2_Conditional_3_Template, 2, 1, "strong", 8);
    i0.ɵɵelementStart(4, "span", 9);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const lLine_r3 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(lLine_r3.Label ? 3 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(lLine_r3.Message);
} }
function TooltipComponent_Conditional_2_ng_template_0_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵrepeaterCreate(1, TooltipComponent_Conditional_2_ng_template_0_Conditional_2_For_2_Template, 6, 2, "span", 6, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.Lines);
} }
function TooltipComponent_Conditional_2_ng_template_0_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r1.Text, " ");
} }
function TooltipComponent_Conditional_2_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵlistener("mouseenter", function TooltipComponent_Conditional_2_ng_template_0_Template_span_mouseenter_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.OnBubbleEnter()); })("mouseleave", function TooltipComponent_Conditional_2_ng_template_0_Template_span_mouseleave_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.OnBubbleLeave()); });
    i0.ɵɵconditionalCreate(1, TooltipComponent_Conditional_2_ng_template_0_Conditional_1_Template, 2, 2, "span", 3)(2, TooltipComponent_Conditional_2_ng_template_0_Conditional_2_Template, 3, 0, "span", 4)(3, TooltipComponent_Conditional_2_ng_template_0_Conditional_3_Template, 1, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassMap(ctx_r1.BubbleClasses);
    i0.ɵɵstyleProp("max-width", ctx_r1.MaxWidth, "px");
    i0.ɵɵclassProp("tooltip__bubble--top", ctx_r1.Position === "top")("tooltip__bubble--right", ctx_r1.Position === "right")("tooltip__bubble--bottom", ctx_r1.Position === "bottom")("tooltip__bubble--left", ctx_r1.Position === "left")("tooltip__bubble--dark", ctx_r1.Variant === "dark")("tooltip__bubble--light", ctx_r1.Variant === "light")("tooltip__bubble--primary", ctx_r1.Variant === "primary")("tooltip__bubble--error", ctx_r1.Variant === "error");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.Template ? 1 : ctx_r1.Lines.length > 0 ? 2 : 3);
} }
function TooltipComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, TooltipComponent_Conditional_2_ng_template_0_Template, 4, 21, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
} }
class TooltipComponent extends BaseComponent$1 {
    //#region Inputs
    Text = '';
    Lines = [];
    Position = 'top';
    Variant = 'dark';
    Disabled = false;
    MaxWidth = 260;
    AriaLabel = '';
    /** Template personnalisé affiché dans la bulle (ex: carte, HTML riche). */
    Template;
    /** Contexte passé au Template personnalisé. */
    Context = {};
    //#endregion
    //#region Attributes
    _BubbleTemplate;
    _ElementRef = inject((ElementRef));
    _ViewContainerRef = inject(ViewContainerRef);
    _Renderer = inject(Renderer2);
    _PortalOutlet = null;
    _BodyContainer = null;
    _Portal = null;
    _IsVisible = false;
    _WindowScrollCleanup = null;
    _WindowResizeCleanup = null;
    _DestroyRef = inject(DestroyRef);
    _HideTimer = null;
    //#endregion
    //#region Properties
    get HasTooltip() {
        return !this.Disabled && (this.Text.trim().length > 0 || this.Lines.length > 0 || !!this.Template);
    }
    /** Indique si le tooltip contient du contenu interactif (template). */
    get IsInteractive() {
        return !!this.Template;
    }
    get TooltipAriaLabel() {
        if (this.AriaLabel.trim().length > 0) {
            return this.AriaLabel;
        }
        if (this.Text.trim().length > 0) {
            return this.Text;
        }
        return this.Lines.map((lLine) => `${lLine.Label ? `${lLine.Label} : ` : ''}${lLine.Message}`).join('. ');
    }
    get HostClasses() {
        return [
            'tooltip',
            `tooltip--${this.Position}`,
            `tooltip--${this.Variant}`,
            this.Disabled ? 'tooltip--disabled' : '',
            this.IsInteractive ? 'tooltip--interactive' : ''
        ].filter(Boolean);
    }
    get BubbleClasses() {
        return [
            'tooltip__bubble',
            'tooltip__bubble--portal',
            this.IsInteractive ? 'tooltip__bubble--interactive' : ''
        ].filter(Boolean);
    }
    get IsVisible() {
        return this._IsVisible;
    }
    //#endregion
    //#region CTOR
    constructor() {
        super();
        this._DestroyRef.onDestroy(() => this.Hide());
    }
    //#endregion
    //#region Visibility
    /**
     * Affiche la bulle dans un portail body et la positionne en fixed.
     */
    Show() {
        if (!this.HasTooltip || this._IsVisible) {
            return;
        }
        this.ClearHideTimer();
        this._IsVisible = true;
        this.AttachBubble();
        this.PositionBubble();
        this.AttachPositionListeners();
    }
    /**
     * Masque et détache la bulle du body.
     * En mode interactif, un petit délai permet de passer du trigger à la bulle sans clignotement.
     */
    Hide() {
        if (!this._IsVisible) {
            return;
        }
        this.ClearHideTimer();
        if (this.IsInteractive) {
            this._HideTimer = setTimeout(() => this.DoHide(), 120);
            return;
        }
        this.DoHide();
    }
    /**
     * Annule le masquage différé (appelé au survol de la bulle interactive).
     */
    OnBubbleEnter() {
        this.ClearHideTimer();
    }
    /**
     * Déclenche le masquage quand la souris quitte la bulle interactive.
     */
    OnBubbleLeave() {
        this.Hide();
    }
    DoHide() {
        if (!this._IsVisible) {
            return;
        }
        this._IsVisible = false;
        this.DetachBubble();
        this.ClearPositionListeners();
    }
    ClearHideTimer() {
        if (this._HideTimer) {
            clearTimeout(this._HideTimer);
            this._HideTimer = null;
        }
    }
    //#endregion
    //#region Portal
    /**
     * Attache la bulle au body via un portail CDK pour sortir de tout ancêtre overflow hidden.
     */
    AttachBubble() {
        if (!this._BubbleTemplate) {
            return;
        }
        if (!this._BodyContainer) {
            this._BodyContainer = this._Renderer.createElement('div');
            this._Renderer.addClass(this._BodyContainer, 'tooltip-portal-container');
            this._Renderer.appendChild(document.body, this._BodyContainer);
        }
        const lBodyContainer = this._BodyContainer;
        if (!lBodyContainer) {
            return;
        }
        if (!this._PortalOutlet) {
            this._PortalOutlet = new DomPortalOutlet(lBodyContainer, undefined, undefined);
        }
        if (!this._PortalOutlet.hasAttached()) {
            this._Portal = new TemplatePortal(this._BubbleTemplate, this._ViewContainerRef);
            this._PortalOutlet.attach(this._Portal);
        }
    }
    /**
     * Détache la bulle du portail body.
     */
    DetachBubble() {
        if (this._PortalOutlet?.hasAttached()) {
            this._PortalOutlet.detach();
        }
    }
    //#endregion
    //#region Positioning
    /**
     * Calcule et applique la position fixed de la bulle selon la position demandée et le viewport.
     */
    PositionBubble() {
        if (!this._BodyContainer) {
            return;
        }
        const lBubble = this._BodyContainer.querySelector('.tooltip__bubble');
        if (!lBubble) {
            return;
        }
        const lHostRect = this._ElementRef.nativeElement.getBoundingClientRect();
        const lBubbleRect = lBubble.getBoundingClientRect();
        const lSpacing = 10;
        let lTop = 0;
        let lLeft = 0;
        let lTransform = '';
        switch (this.Position) {
            case 'top':
                lTop = lHostRect.top - lBubbleRect.height - lSpacing;
                lLeft = lHostRect.left + lHostRect.width / 2;
                lTransform = 'translateX(-50%)';
                break;
            case 'bottom':
                lTop = lHostRect.bottom + lSpacing;
                lLeft = lHostRect.left + lHostRect.width / 2;
                lTransform = 'translateX(-50%)';
                break;
            case 'left':
                lTop = lHostRect.top + lHostRect.height / 2;
                lLeft = lHostRect.left - lBubbleRect.width - lSpacing;
                lTransform = 'translateY(-50%)';
                break;
            case 'right':
                lTop = lHostRect.top + lHostRect.height / 2;
                lLeft = lHostRect.right + lSpacing;
                lTransform = 'translateY(-50%)';
                break;
        }
        this._Renderer.setStyle(lBubble, 'position', 'fixed');
        this._Renderer.setStyle(lBubble, 'top', `${lTop}px`);
        this._Renderer.setStyle(lBubble, 'left', `${lLeft}px`);
        this._Renderer.setStyle(lBubble, 'transform', lTransform);
        this._Renderer.setStyle(lBubble, 'z-index', '10000');
    }
    /**
     * Attache les listeners de scroll/resize pour maintenir la bulle alignée au host.
     */
    AttachPositionListeners() {
        this.ClearPositionListeners();
        this._WindowScrollCleanup = this._Renderer.listen('window', 'scroll', () => this.PositionBubble());
        this._WindowResizeCleanup = this._Renderer.listen('window', 'resize', () => this.PositionBubble());
    }
    /**
     * Nettoie les listeners de positionnement.
     */
    ClearPositionListeners() {
        if (this._WindowScrollCleanup) {
            this._WindowScrollCleanup();
            this._WindowScrollCleanup = null;
        }
        if (this._WindowResizeCleanup) {
            this._WindowResizeCleanup();
            this._WindowResizeCleanup = null;
        }
    }
    static ɵfac = function TooltipComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TooltipComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TooltipComponent, selectors: [["app-tooltip"]], viewQuery: function TooltipComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx._BubbleTemplate = _t.first);
        } }, inputs: { Text: "Text", Lines: "Lines", Position: "Position", Variant: "Variant", Disabled: "Disabled", MaxWidth: "MaxWidth", AriaLabel: "AriaLabel", Template: "Template", Context: "Context" }, features: [i0.ɵɵInheritDefinitionFeature], ngContentSelectors: _c1$1, decls: 3, vars: 3, consts: [["bubbleTemplate", ""], [3, "mouseenter", "mouseleave", "focusin", "focusout", "ngClass"], ["role", "tooltip", 3, "mouseenter", "mouseleave"], [1, "tooltip__custom-content"], [1, "tooltip__lines"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "tooltip__line"], ["aria-hidden", "true", 1, "material-icons", "tooltip__line-icon"], [1, "tooltip__line-label"], [1, "tooltip__line-message"]], template: function TooltipComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "span", 1);
            i0.ɵɵlistener("mouseenter", function TooltipComponent_Template_span_mouseenter_0_listener() { return ctx.Show(); })("mouseleave", function TooltipComponent_Template_span_mouseleave_0_listener() { return ctx.Hide(); })("focusin", function TooltipComponent_Template_span_focusin_0_listener() { return ctx.Show(); })("focusout", function TooltipComponent_Template_span_focusout_0_listener() { return ctx.Hide(); });
            i0.ɵɵprojection(1);
            i0.ɵɵconditionalCreate(2, TooltipComponent_Conditional_2_Template, 2, 0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("ngClass", ctx.HostClasses);
            i0.ɵɵattribute("aria-label", ctx.TooltipAriaLabel);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.HasTooltip ? 2 : -1);
        } }, dependencies: [CommonModule, i1.NgClass, i1.NgTemplateOutlet, PortalModule], styles: [".tooltip[_ngcontent-%COMP%]{position:relative;width:fit-content;max-width:100%;vertical-align:middle}.tooltip__bubble[_ngcontent-%COMP%]{position:fixed;z-index:10000;width:max-content;min-width:0;padding:8px 10px;border-radius:8px;font-size:12px;font-weight:500;line-height:1.35;text-align:left;white-space:normal;pointer-events:none}.tooltip__bubble[_ngcontent-%COMP%]:after{content:\"\";position:absolute;width:8px;height:8px;background:inherit;transform:rotate(45deg)}.tooltip__lines[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:6px}.tooltip__line[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:6px}.tooltip__line-icon[_ngcontent-%COMP%]{flex-shrink:0;width:16px;height:16px;font-size:16px;line-height:1;margin-top:1px}.tooltip__line-label[_ngcontent-%COMP%]{font-weight:700;flex-shrink:0}.tooltip__line-message[_ngcontent-%COMP%]{font-weight:500}.tooltip__bubble--dark[_ngcontent-%COMP%]{color:#fff;background:#111827;box-shadow:0 10px 28px #11182738}.tooltip__bubble--light[_ngcontent-%COMP%]{color:var(--%NS%sm-text-primary);background:#fff;border:1px solid var(--%NS%sm-border-color);box-shadow:0 10px 28px #00000024}.tooltip__bubble--primary[_ngcontent-%COMP%]{color:#fff;background:#2196f3;box-shadow:0 10px 28px #2196f338}.tooltip__bubble--error[_ngcontent-%COMP%]{color:#f44336;background:#fff;border:1px solid #f44336;box-shadow:0 10px 28px rgba(var(--%NS%sm-error-rgb),.22)}.tooltip__bubble--error[_ngcontent-%COMP%]   .tooltip__line-icon[_ngcontent-%COMP%]{color:#f44336}.tooltip__bubble--error[_ngcontent-%COMP%]   .tooltip__line-label[_ngcontent-%COMP%]{color:#111827}.tooltip__bubble--error[_ngcontent-%COMP%]   .tooltip__line-message[_ngcontent-%COMP%]{color:#f44336}.tooltip__bubble--%NS%error[_ngcontent-%COMP%]:after{background:#f44336}.tooltip__bubble--interactive[_ngcontent-%COMP%]{padding:0;overflow:hidden;pointer-events:auto}.tooltip__bubble--interactive[_ngcontent-%COMP%]   .tooltip__custom-content[_ngcontent-%COMP%]{display:block;min-width:0}.tooltip__bubble--%NS%top[_ngcontent-%COMP%]:after{left:50%;bottom:-4px;margin-left:-4px}.tooltip__bubble--%NS%right[_ngcontent-%COMP%]:after{top:50%;left:-4px;margin-top:-4px}.tooltip__bubble--%NS%bottom[_ngcontent-%COMP%]:after{left:50%;top:-4px;margin-left:-4px}.tooltip__bubble--%NS%left[_ngcontent-%COMP%]:after{top:50%;right:-4px;margin-top:-4px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TooltipComponent, [{
        type: Component,
        args: [{ selector: 'app-tooltip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CommonModule, PortalModule], template: "<span [ngClass]=\"HostClasses\" [attr.aria-label]=\"TooltipAriaLabel\"\n  (mouseenter)=\"Show()\" (mouseleave)=\"Hide()\" (focusin)=\"Show()\" (focusout)=\"Hide()\">\n  <ng-content></ng-content>\n\n  @if (HasTooltip)\n  {\n    <ng-template #bubbleTemplate>\n      <span [class]=\"BubbleClasses\" role=\"tooltip\" [style.max-width.px]=\"MaxWidth\"\n        [class.tooltip__bubble--top]=\"Position === 'top'\"\n        [class.tooltip__bubble--right]=\"Position === 'right'\"\n        [class.tooltip__bubble--bottom]=\"Position === 'bottom'\"\n        [class.tooltip__bubble--left]=\"Position === 'left'\"\n        [class.tooltip__bubble--dark]=\"Variant === 'dark'\"\n        [class.tooltip__bubble--light]=\"Variant === 'light'\"\n        [class.tooltip__bubble--primary]=\"Variant === 'primary'\"\n        [class.tooltip__bubble--error]=\"Variant === 'error'\"\n        (mouseenter)=\"OnBubbleEnter()\" (mouseleave)=\"OnBubbleLeave()\">\n        @if (Template)\n        {\n          <span class=\"tooltip__custom-content\">\n            <ng-container *ngTemplateOutlet=\"Template; context: Context\"></ng-container>\n          </span>\n        }\n        @else if (Lines.length > 0)\n        {\n          <span class=\"tooltip__lines\">\n            @for (lLine of Lines; track $index)\n            {\n              <span class=\"tooltip__line\">\n                <span class=\"material-icons tooltip__line-icon\" aria-hidden=\"true\">error</span>\n                @if (lLine.Label)\n                {\n                  <strong class=\"tooltip__line-label\">{{ lLine.Label }}&nbsp;:&nbsp;</strong>\n                }\n                <span class=\"tooltip__line-message\">{{ lLine.Message }}</span>\n              </span>\n            }\n          </span>\n        }\n        @else\n        {\n          {{ Text }}\n        }\n      </span>\n    </ng-template>\n  }\n</span>\n", styles: [".tooltip{position:relative;width:fit-content;max-width:100%;vertical-align:middle}.tooltip__bubble{position:fixed;z-index:10000;width:max-content;min-width:0;padding:8px 10px;border-radius:8px;font-size:12px;font-weight:500;line-height:1.35;text-align:left;white-space:normal;pointer-events:none}.tooltip__bubble:after{content:\"\";position:absolute;width:8px;height:8px;background:inherit;transform:rotate(45deg)}.tooltip__lines{display:flex;flex-direction:column;gap:6px}.tooltip__line{display:flex;align-items:flex-start;gap:6px}.tooltip__line-icon{flex-shrink:0;width:16px;height:16px;font-size:16px;line-height:1;margin-top:1px}.tooltip__line-label{font-weight:700;flex-shrink:0}.tooltip__line-message{font-weight:500}.tooltip__bubble--dark{color:#fff;background:#111827;box-shadow:0 10px 28px #11182738}.tooltip__bubble--light{color:var(--sm-text-primary);background:#fff;border:1px solid var(--sm-border-color);box-shadow:0 10px 28px #00000024}.tooltip__bubble--primary{color:#fff;background:#2196f3;box-shadow:0 10px 28px #2196f338}.tooltip__bubble--error{color:#f44336;background:#fff;border:1px solid #f44336;box-shadow:0 10px 28px rgba(var(--sm-error-rgb),.22)}.tooltip__bubble--error .tooltip__line-icon{color:#f44336}.tooltip__bubble--error .tooltip__line-label{color:#111827}.tooltip__bubble--error .tooltip__line-message{color:#f44336}.tooltip__bubble--error:after{background:#f44336}.tooltip__bubble--interactive{padding:0;overflow:hidden;pointer-events:auto}.tooltip__bubble--interactive .tooltip__custom-content{display:block;min-width:0}.tooltip__bubble--top:after{left:50%;bottom:-4px;margin-left:-4px}.tooltip__bubble--right:after{top:50%;left:-4px;margin-top:-4px}.tooltip__bubble--bottom:after{left:50%;top:-4px;margin-left:-4px}.tooltip__bubble--left:after{top:50%;right:-4px;margin-top:-4px}\n"] }]
    }], () => [], { Text: [{
            type: Input
        }], Lines: [{
            type: Input
        }], Position: [{
            type: Input
        }], Variant: [{
            type: Input
        }], Disabled: [{
            type: Input
        }], MaxWidth: [{
            type: Input
        }], AriaLabel: [{
            type: Input
        }], Template: [{
            type: Input
        }], Context: [{
            type: Input
        }], _BubbleTemplate: [{
            type: ViewChild,
            args: ['bubbleTemplate', { static: false }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TooltipComponent, { className: "TooltipComponent", filePath: "shared/components/tooltip/tooltip.component.ts", lineNumber: 31 }); })();

function CardSkeletonComponent_For_1_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "app-skeleton", 6);
} if (rf & 2) {
    const ɵ$index_1_r1 = i0.ɵɵnextContext().$index;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("--%NS%shimmer-delay", ctx_r1.ComputeShimmerDelay(ɵ$index_1_r1, 3), "ms");
} }
function CardSkeletonComponent_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "article", 0)(1, "div", 1);
    i0.ɵɵelement(2, "app-skeleton", 2)(3, "app-skeleton", 3);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "app-skeleton", 4);
    i0.ɵɵconditionalCreate(5, CardSkeletonComponent_For_1_Conditional_5_Template, 1, 2, "app-skeleton", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ɵ$index_1_r1 = ctx.$index;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("--%NS%shimmer-delay", ctx_r1.ComputeShimmerDelay(ɵ$index_1_r1, 0), "ms");
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("--%NS%shimmer-delay", ctx_r1.ComputeShimmerDelay(ɵ$index_1_r1, 1), "ms");
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("--%NS%shimmer-delay", ctx_r1.ComputeShimmerDelay(ɵ$index_1_r1, 2), "ms");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.HasHint ? 5 : -1);
} }
/**
 * Composant skeleton réutilisable pour le loading des cartes KPI.
 * Affiche des cartes factices avec animation shimmer via <app-skeleton>.
 */
class CardSkeletonComponent {
    /** Nombre de cartes skeleton à afficher (défaut: 6). */
    set Count(pValue) {
        this._Count.set(pValue);
    }
    get Count() {
        return this._Count();
    }
    _Count = signal(6, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_Count" }] : /* istanbul ignore next */ []));
    /** Affiche une ligne de hint sous la valeur (défaut: true). */
    HasHint = true;
    /** Tableau d'indices pour le @for du template. */
    Cards = computed(() => Array.from({ length: this._Count() }, (_, i) => i), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "Cards" }] : /* istanbul ignore next */ []));
    /**
     * Calcule le delai d'animation shimmer (en ms) pour distribuer les cartes
     * de maniere desynchronisee. Formule : (carte * 200ms) + (slot * 30ms).
     * Couvre le cycle de 1.4s pour eviter un shimmer "fige" sur les dernieres cartes.
     * @param pCardIdx Index de la carte.
     * @param pSlot Index du slot a l'interieur de la carte (0..3 : avatar, name, value, hint).
     * @returns Le delai en millisecondes, modulo la duree du cycle.
     */
    ComputeShimmerDelay(pCardIdx, pSlot) {
        const lDelay = pCardIdx * 200 + pSlot * 30;
        return lDelay % 1400;
    }
    static ɵfac = function CardSkeletonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CardSkeletonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CardSkeletonComponent, selectors: [["app-card-skeleton"]], inputs: { Count: "Count", HasHint: "HasHint" }, decls: 2, vars: 0, consts: [[1, "card-skeleton"], [1, "card-skeleton__head"], ["Width", "24px", "Height", "24px"], ["Width", "120px", "Height", "16px"], ["Width", "70%", "Height", "28px"], ["Width", "90%", "Height", "12px", 3, "--%NS%shimmer-delay"], ["Width", "90%", "Height", "12px"]], template: function CardSkeletonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵrepeaterCreate(0, CardSkeletonComponent_For_1_Template, 6, 7, "article", 0, i0.ɵɵrepeaterTrackByIndex);
        } if (rf & 2) {
            i0.ɵɵrepeater(ctx.Cards());
        } }, dependencies: [SkeletonComponent$1], styles: ["[_nghost-%COMP%]{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;width:100%}.card-skeleton[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;padding:16px;background:var(--%NS%sm-card-background);border:1px solid var(--%NS%sm-border-color);border-top:3px solid var(--%NS%sm-border-color);border-radius:12px;box-shadow:0 2px 10px #0000001a;pointer-events:none}.card-skeleton__head[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px}@media(max-width:768px){[_nghost-%COMP%]{grid-template-columns:1fr}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CardSkeletonComponent, [{
        type: Component,
        args: [{ selector: 'app-card-skeleton', standalone: true, imports: [SkeletonComponent$1], changeDetection: ChangeDetectionStrategy.OnPush, template: "@for (lCard of Cards(); track $index; let lIdx = $index) {\n<article class=\"card-skeleton\">\n  <div class=\"card-skeleton__head\">\n    <app-skeleton Width=\"24px\" Height=\"24px\" [style.--shimmer-delay.ms]=\"ComputeShimmerDelay(lIdx, 0)\" />\n    <app-skeleton Width=\"120px\" Height=\"16px\" [style.--shimmer-delay.ms]=\"ComputeShimmerDelay(lIdx, 1)\" />\n  </div>\n  <app-skeleton Width=\"70%\" Height=\"28px\" [style.--shimmer-delay.ms]=\"ComputeShimmerDelay(lIdx, 2)\" />\n  @if (HasHint) {\n  <app-skeleton Width=\"90%\" Height=\"12px\" [style.--shimmer-delay.ms]=\"ComputeShimmerDelay(lIdx, 3)\" />\n  }\n</article>\n}\n", styles: [":host{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;width:100%}.card-skeleton{display:flex;flex-direction:column;gap:8px;padding:16px;background:var(--sm-card-background);border:1px solid var(--sm-border-color);border-top:3px solid var(--sm-border-color);border-radius:12px;box-shadow:0 2px 10px #0000001a;pointer-events:none}.card-skeleton__head{display:flex;align-items:center;gap:8px}@media(max-width:768px){:host{grid-template-columns:1fr}}\n"] }]
    }], null, { Count: [{
            type: Input
        }], HasHint: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CardSkeletonComponent, { className: "CardSkeletonComponent", filePath: "shared/components/card-skeleton/card-skeleton.component.ts", lineNumber: 16 }); })();

const _c0 = ["[slot=header-title]"];
const _c1 = ["*", [["", "slot", "header-title"]], [["", "slot", "header-actions"]], [["", "slot", "header-actions"]]];
const _c2 = ["*", "[slot='header-title']", "[slot='header-actions']", "[slot='header-actions']"];
function SectionCardComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.Icon);
} }
function SectionCardComponent_Conditional_1_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.Title);
} }
function SectionCardComponent_Conditional_1_Conditional_8_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function SectionCardComponent_Conditional_1_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 9);
    i0.ɵɵlistener("click", function SectionCardComponent_Conditional_1_Conditional_8_Template_span_click_0_listener($event) { return $event.stopPropagation(); });
    i0.ɵɵtemplate(1, SectionCardComponent_Conditional_1_Conditional_8_ng_container_1_Template, 1, 0, "ng-container", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r1.HeaderActions);
} }
function SectionCardComponent_Conditional_1_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "app-button", 15);
    i0.ɵɵlistener("ButtonClick", function SectionCardComponent_Conditional_1_Conditional_9_Template_app_button_ButtonClick_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.OnSeeAllClick($event)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("routerLink", ctx_r1.SeeAllLink);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.SeeAllLabel, " ");
} }
function SectionCardComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 4);
    i0.ɵɵlistener("click", function SectionCardComponent_Conditional_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.ToggleCollapsed()); });
    i0.ɵɵelementStart(1, "span", 5);
    i0.ɵɵconditionalCreate(2, SectionCardComponent_Conditional_1_Conditional_2_Template, 2, 1, "span", 6);
    i0.ɵɵprojection(3, 1);
    i0.ɵɵconditionalCreate(4, SectionCardComponent_Conditional_1_Conditional_4_Template, 2, 1, "span", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "span", 8)(6, "span", 9);
    i0.ɵɵlistener("click", function SectionCardComponent_Conditional_1_Template_span_click_6_listener($event) { return $event.stopPropagation(); });
    i0.ɵɵprojection(7, 2);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(8, SectionCardComponent_Conditional_1_Conditional_8_Template, 2, 1, "span", 10);
    i0.ɵɵconditionalCreate(9, SectionCardComponent_Conditional_1_Conditional_9_Template, 2, 2, "app-button", 11);
    i0.ɵɵelementStart(10, "span", 12)(11, "span", 13);
    i0.ɵɵtext(12, "expand_more");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-expanded", !ctx_r1.Collapsed)("aria-controls", ctx_r1.ContentId);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.Icon ? 2 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(!ctx_r1.HasHeaderTitleSlot ? 4 : -1);
    i0.ɵɵadvance(4);
    i0.ɵɵconditional(ctx_r1.HeaderActions ? 8 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.HasSeeAll ? 9 : -1);
} }
function SectionCardComponent_Conditional_2_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "app-button", 15);
    i0.ɵɵlistener("ButtonClick", function SectionCardComponent_Conditional_2_Conditional_5_Template_app_button_ButtonClick_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.SeeAllClick.emit($event)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("routerLink", ctx_r1.SeeAllLink);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.SeeAllLabel, " ");
} }
function SectionCardComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2)(1, "h2")(2, "span", 13);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(5, SectionCardComponent_Conditional_2_Conditional_5_Template, 2, 2, "app-button", 11);
    i0.ɵɵelementStart(6, "span", 10);
    i0.ɵɵprojection(7, 3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r1.Icon);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.Title, " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.HasSeeAll ? 5 : -1);
} }
/**
 * Compteur d'instances pour générer des identifiants uniques (ARIA).
 */
let lSectionCardInstanceCounter = 0;
/**
 * Composant carte section réutilisable.
 *
 * Deux modes :
 * - Mode statique (`Collapsible = false`, defaut) : header h2 + contenu visible en permanence.
 * - Mode repliable (`Collapsible = true`) : header cliquable (chevron + bouton) + corps
 *   anime via transition max-height/opacity. Supporte le slot `header-title` pour
 *   remplacer `Title` et le slot `header-actions` pour des boutons contextuels.
 *
 * Accessibilite : `aria-expanded`, `aria-controls`, header focusable.
 * Compatible `prefers-reduced-motion` (transitions retirees).
 *
 * @example
 * ```html
 * <app-section-card Title="Mes biens" Icon="apartment" [Collapsible]="true"
 *   [Collapsed]="false" (CollapsedChange)="onToggle($event)">
 *   <div slot="header-title"><h3>Carte</h3></div>
 *   <div slot="header-actions">
 *     <app-button variant="ghost" size="sm" icon="edit" />
 *   </div>
 *   <p>Contenu</p>
 * </app-section-card>
 * ```
 */
class SectionCardComponent extends BaseComponent$1 {
    //#region Attribute
    /** Identifiant de plateforme (browser vs SSR). */
    _PlatformId = inject(PLATFORM_ID);
    /**
     * Drapeau interne mis a jour via le setter de `_HeaderTitleSlot` pour indiquer
     * si le slot `header-title` a ete projete par le consommateur.
     */
    _hasHeaderTitleSlot = false;
    /**
     * Reference vers l'eventuel contenu projete dans le slot `header-title`.
     * Le setter met a jour `_hasHeaderTitleSlot` pour permettre au template
     * de masquer le titre par defaut (`Title`) lorsque le slot est utilise.
     */
    set _HeaderTitleSlot(pValue) {
        this._hasHeaderTitleSlot = !!pValue;
    }
    //#endregion
    //#region Property
    /** Titre affiche dans l'en-tete de la carte (masque si slot `header-title` projete). */
    Title = '';
    /** Icone Material Icons affichee a gauche du titre. Si vide, aucune icone n'est rendue. */
    Icon = '';
    /** Lien de navigation vers la page "Voir tout". Si null et pas de handler, le bouton est masque. */
    SeeAllLink = null;
    /** Libelle du bouton "Voir tout" (defaut : "Voir tout"). */
    SeeAllLabel = 'Voir tout';
    /** Force l'affichage du bouton "Voir tout" meme sans handler observe (null = auto). */
    ShowSeeAll = false;
    /** Active ou desactive la fonctionnalite de pliage (chevron + clic header). */
    Collapsible = false;
    /** Etat courant plie/deplie. Peut etre force depuis l'exterieur. */
    Collapsed = false;
    /**
     * Template optionnel pour injecter des actions supplementaires dans l'en-tete.
     * @deprecated Preferez le slot ng-content `header-actions` (plus flexible).
     */
    HeaderActions = null;
    /** Emis au clic sur "Voir tout" quand aucun SeeAllLink n'est defini. */
    SeeAllClick = new EventEmitter();
    /** Emis a chaque changement d'etat plie/deplie (peut etre intercepte par le parent). */
    CollapsedChange = new EventEmitter();
    /** Identifiant unique de l'instance (ARIA + cle). */
    InstanceId = `section-card-${++lSectionCardInstanceCounter}`;
    /** ID de la zone de contenu, derive de `InstanceId`. Utilise par `aria-controls`. */
    ContentId = `${this.InstanceId}-content`;
    /**
     * Indique si un slot `header-title` a ete projete par le consommateur.
     * Lorsqu'il est present, le titre par defaut (`Title`) est masque pour eviter
     * un doublon visuel avec le contenu projete.
     */
    get HasHeaderTitleSlot() {
        return this._hasHeaderTitleSlot;
    }
    //#endregion
    //#region Methods
    /**
     * Bascule l'etat plie/deplie. Sans effet si `Collapsible` est `false`.
     * Emet `CollapsedChange` a chaque changement.
     */
    ToggleCollapsed() {
        if (!this.Collapsible) {
            return;
        }
        this.Collapsed = !this.Collapsed;
        this.CollapsedChange.emit(this.Collapsed);
    }
    /**
     * Handler de clic sur "Voir tout" : stoppe la propagation pour ne pas replier la carte.
     * @param pEvent L'evenement de clic souris
     */
    OnSeeAllClick(pEvent) {
        pEvent.stopPropagation();
        this.SeeAllClick.emit(pEvent);
    }
    /**
     * Indique si le bouton "Voir tout" doit etre affiche.
     */
    get HasSeeAll() {
        if (this.ShowSeeAll !== null) {
            return this.ShowSeeAll;
        }
        return this.SeeAllLink !== null || this.SeeAllClick.observed;
    }
    static ɵfac = /*@__PURE__*/ (() => { let ɵSectionCardComponent_BaseFactory; return function SectionCardComponent_Factory(__ngFactoryType__) { return (ɵSectionCardComponent_BaseFactory || (ɵSectionCardComponent_BaseFactory = i0.ɵɵgetInheritedFactory(SectionCardComponent)))(__ngFactoryType__ || SectionCardComponent); }; })();
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SectionCardComponent, selectors: [["app-section-card"]], contentQueries: function SectionCardComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuery(dirIndex, _c0, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx._HeaderTitleSlot = _t.first);
        } }, inputs: { Title: "Title", Icon: "Icon", SeeAllLink: "SeeAllLink", SeeAllLabel: "SeeAllLabel", ShowSeeAll: "ShowSeeAll", Collapsible: "Collapsible", Collapsed: "Collapsed", HeaderActions: "HeaderActions" }, outputs: { SeeAllClick: "SeeAllClick", CollapsedChange: "CollapsedChange" }, features: [i0.ɵɵInheritDefinitionFeature], ngContentSelectors: _c2, decls: 5, vars: 9, consts: [[1, "section-card"], ["type", "button", 1, "section-card__header"], [1, "section-header"], [1, "section-card__body", 3, "id"], ["type", "button", 1, "section-card__header", 3, "click"], [1, "section-card__title"], [1, "material-icons", "section-card__icon"], [1, "section-card__title-text"], [1, "section-card__header-aside"], [1, "section-card__actions", 3, "click"], [1, "section-card__actions"], ["variant", "ghost", "size", "sm", "icon", "arrow_forward", "iconPosition", "right", 3, "routerLink"], ["aria-hidden", "true", 1, "section-card__chevron"], [1, "material-icons"], [4, "ngTemplateOutlet"], ["variant", "ghost", "size", "sm", "icon", "arrow_forward", "iconPosition", "right", 3, "ButtonClick", "routerLink"]], template: function SectionCardComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "section", 0);
            i0.ɵɵconditionalCreate(1, SectionCardComponent_Conditional_1_Template, 13, 6, "button", 1)(2, SectionCardComponent_Conditional_2_Template, 8, 3, "div", 2);
            i0.ɵɵelementStart(3, "div", 3);
            i0.ɵɵprojection(4);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("section-card--collapsed", ctx.Collapsed)("section-card--disabled", !ctx.Collapsible);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.Collapsible ? 1 : 2);
            i0.ɵɵadvance(2);
            i0.ɵɵclassProp("section-card__body--open", !ctx.Collapsed);
            i0.ɵɵproperty("id", ctx.ContentId);
            i0.ɵɵattribute("aria-hidden", ctx.Collapsed);
        } }, dependencies: [CommonModule, i1.NgTemplateOutlet, ButtonComponent$1], styles: [".section-card[_ngcontent-%COMP%]{background:var(--%NS%sm-card-background);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border-radius:16px;padding:20px;box-shadow:var(--%NS%sm-shadow);margin-bottom:24px;width:100%;box-sizing:border-box;transition:box-shadow .2s ease}.section-card[_ngcontent-%COMP%]:last-child{margin-bottom:0}.section-header[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.section-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;font-size:1rem;font-weight:600;line-height:1.2;letter-spacing:-.01em;color:var(--%NS%sm-text-primary);margin:0}.section-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#9c27b0;font-size:1.25rem}.section-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]   .unread-badge[_ngcontent-%COMP%]{background:#f44336;color:#fff;font-size:11px;padding:2px 8px;border-radius:10px;font-weight:600}.section-header[_ngcontent-%COMP%]   app-button[_ngcontent-%COMP%]     .btn-ghost.btn-sm{padding:4px 8px;border-width:1px;box-shadow:none}.section-card__header[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;width:100%;background:transparent;border:0;padding:0;margin:0 0 18px;cursor:pointer;font:inherit;color:inherit;text-align:left;transition:color .2s ease}.section-card__header[_ngcontent-%COMP%]:focus-visible{outline:2px solid #9c27b0;outline-offset:4px;border-radius:8px}.section-card__header[_ngcontent-%COMP%]:hover   .section-card__icon[_ngcontent-%COMP%]{color:#9c27b0}.section-card--collapsed[_ngcontent-%COMP%]   .section-card__header[_ngcontent-%COMP%]{margin-bottom:0}.section-card__title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;font-size:1rem;font-weight:600;line-height:1.2;letter-spacing:-.01em;color:var(--%NS%sm-text-primary);transition:color .2s ease}.section-card__title-text[_ngcontent-%COMP%]{transition:color .2s ease}.section-card__icon[_ngcontent-%COMP%]{color:#9c27b0;font-size:1.25rem;transition:color .2s ease}.section-card__header-aside[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px}.section-card__actions[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px}.section-card__chevron[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;color:var(--%NS%sm-text-secondary);transition:transform .3s ease,background-color .2s ease,color .2s ease}.section-card__chevron[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:24px}.section-card__header[_ngcontent-%COMP%]:hover   .section-card__chevron[_ngcontent-%COMP%]{background:#9c27b01a;color:#9c27b0}.section-card--collapsed[_ngcontent-%COMP%]   .section-card__chevron[_ngcontent-%COMP%]{transform:rotate(-90deg)}.section-card__body[_ngcontent-%COMP%]{overflow:hidden;max-height:5000px;opacity:1;transition:max-height .4s ease,opacity .3s ease}.section-card--collapsed[_ngcontent-%COMP%]   .section-card__body[_ngcontent-%COMP%]{max-height:0;opacity:0}.section-card__header-aside[_ngcontent-%COMP%]   app-button[_ngcontent-%COMP%]     .btn-ghost.btn-sm{padding:4px 8px;border-width:1px;box-shadow:none}@media(prefers-reduced-motion:reduce){.section-card[_ngcontent-%COMP%], .section-card__header[_ngcontent-%COMP%], .section-card__icon[_ngcontent-%COMP%], .section-card__chevron[_ngcontent-%COMP%], .section-card__body[_ngcontent-%COMP%]{transition:none!important}}@media(max-width:768px){.section-card[_ngcontent-%COMP%]{padding:16px;margin-bottom:16px}.section-header[_ngcontent-%COMP%]{margin-bottom:12px}.section-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-size:.875rem}.section-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:1.1rem}.section-header[_ngcontent-%COMP%]   app-button[_ngcontent-%COMP%]     .btn-ghost.btn-sm{padding:3px 6px}.section-card__header[_ngcontent-%COMP%]{margin-bottom:12px}.section-card__title[_ngcontent-%COMP%]{font-size:.875rem}.section-card__icon[_ngcontent-%COMP%]{font-size:1.1rem}}"], changeDetection: 1 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SectionCardComponent, [{
        type: Component,
        args: [{ selector: 'app-section-card', standalone: true, imports: [CommonModule, ButtonComponent$1], changeDetection: ChangeDetectionStrategy.Eager, template: "<!-- - cm - Wrapper principal de la carte section -->\n<section class=\"section-card\"\n    [class.section-card--collapsed]=\"Collapsed\"\n    [class.section-card--disabled]=\"!Collapsible\">\n\n    <!-- - cm - En-tete : 2 variantes selon `Collapsible` -->\n    @if (Collapsible) {\n        <button type=\"button\" class=\"section-card__header\"\n            [attr.aria-expanded]=\"!Collapsed\"\n            [attr.aria-controls]=\"ContentId\"\n            (click)=\"ToggleCollapsed()\">\n            <span class=\"section-card__title\">\n                @if (Icon) {\n                    <span class=\"material-icons section-card__icon\">{{ Icon }}</span>\n                }\n                <ng-content select=\"[slot='header-title']\"></ng-content>\n                @if (!HasHeaderTitleSlot) {\n                    <span class=\"section-card__title-text\">{{ Title }}</span>\n                }\n            </span>\n            <span class=\"section-card__header-aside\">\n                <span class=\"section-card__actions\" (click)=\"$event.stopPropagation()\">\n                    <ng-content select=\"[slot='header-actions']\"></ng-content>\n                </span>\n                @if (HeaderActions) {\n                    <span class=\"section-card__actions\" (click)=\"$event.stopPropagation()\">\n                        <ng-container *ngTemplateOutlet=\"HeaderActions\"></ng-container>\n                    </span>\n                }\n                @if (HasSeeAll) {\n                    <app-button\n                        variant=\"ghost\"\n                        size=\"sm\"\n                        icon=\"arrow_forward\"\n                        iconPosition=\"right\"\n                        [routerLink]=\"SeeAllLink\"\n                        (ButtonClick)=\"OnSeeAllClick($event)\">\n                        {{ SeeAllLabel }}\n                    </app-button>\n                }\n                <span class=\"section-card__chevron\" aria-hidden=\"true\">\n                    <span class=\"material-icons\">expand_more</span>\n                </span>\n            </span>\n        </button>\n    } @else {\n        <div class=\"section-header\">\n            <h2>\n                <span class=\"material-icons\">{{ Icon }}</span>\n                {{ Title }}\n            </h2>\n            @if (HasSeeAll) {\n                <app-button\n                    variant=\"ghost\"\n                    size=\"sm\"\n                    icon=\"arrow_forward\"\n                    iconPosition=\"right\"\n                    [routerLink]=\"SeeAllLink\"\n                    (ButtonClick)=\"SeeAllClick.emit($event)\">\n                    {{ SeeAllLabel }}\n                </app-button>\n            }\n            <span class=\"section-card__actions\">\n                <ng-content select=\"[slot='header-actions']\"></ng-content>\n            </span>\n        </div>\n    }\n\n    <!-- - cm - Zone de contenu pliable, animee via transition max-height/opacity -->\n    <div class=\"section-card__body\"\n        [class.section-card__body--open]=\"!Collapsed\"\n        [id]=\"ContentId\"\n        [attr.aria-hidden]=\"Collapsed\">\n        <ng-content></ng-content>\n    </div>\n</section>\n", styles: [".section-card{background:var(--sm-card-background);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border-radius:16px;padding:20px;box-shadow:var(--sm-shadow);margin-bottom:24px;width:100%;box-sizing:border-box;transition:box-shadow .2s ease}.section-card:last-child{margin-bottom:0}.section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.section-header h2{display:flex;align-items:center;gap:10px;font-size:1rem;font-weight:600;line-height:1.2;letter-spacing:-.01em;color:var(--sm-text-primary);margin:0}.section-header h2 .material-icons{color:#9c27b0;font-size:1.25rem}.section-header h2 .unread-badge{background:#f44336;color:#fff;font-size:11px;padding:2px 8px;border-radius:10px;font-weight:600}.section-header app-button ::ng-deep .btn-ghost.btn-sm{padding:4px 8px;border-width:1px;box-shadow:none}.section-card__header{display:flex;justify-content:space-between;align-items:center;width:100%;background:transparent;border:0;padding:0;margin:0 0 18px;cursor:pointer;font:inherit;color:inherit;text-align:left;transition:color .2s ease}.section-card__header:focus-visible{outline:2px solid #9c27b0;outline-offset:4px;border-radius:8px}.section-card__header:hover .section-card__icon{color:#9c27b0}.section-card--collapsed .section-card__header{margin-bottom:0}.section-card__title{display:flex;align-items:center;gap:10px;font-size:1rem;font-weight:600;line-height:1.2;letter-spacing:-.01em;color:var(--sm-text-primary);transition:color .2s ease}.section-card__title-text{transition:color .2s ease}.section-card__icon{color:#9c27b0;font-size:1.25rem;transition:color .2s ease}.section-card__header-aside{display:flex;align-items:center;gap:12px}.section-card__actions{display:flex;align-items:center;gap:8px}.section-card__chevron{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;color:var(--sm-text-secondary);transition:transform .3s ease,background-color .2s ease,color .2s ease}.section-card__chevron .material-icons{font-size:24px}.section-card__header:hover .section-card__chevron{background:#9c27b01a;color:#9c27b0}.section-card--collapsed .section-card__chevron{transform:rotate(-90deg)}.section-card__body{overflow:hidden;max-height:5000px;opacity:1;transition:max-height .4s ease,opacity .3s ease}.section-card--collapsed .section-card__body{max-height:0;opacity:0}.section-card__header-aside app-button ::ng-deep .btn-ghost.btn-sm{padding:4px 8px;border-width:1px;box-shadow:none}@media(prefers-reduced-motion:reduce){.section-card,.section-card__header,.section-card__icon,.section-card__chevron,.section-card__body{transition:none!important}}@media(max-width:768px){.section-card{padding:16px;margin-bottom:16px}.section-header{margin-bottom:12px}.section-header h2{font-size:.875rem}.section-header h2 .material-icons{font-size:1.1rem}.section-header app-button ::ng-deep .btn-ghost.btn-sm{padding:3px 6px}.section-card__header{margin-bottom:12px}.section-card__title{font-size:.875rem}.section-card__icon{font-size:1.1rem}}\n"] }]
    }], null, { _HeaderTitleSlot: [{
            type: ContentChild,
            args: ['[slot=header-title]']
        }], Title: [{
            type: Input
        }], Icon: [{
            type: Input
        }], SeeAllLink: [{
            type: Input
        }], SeeAllLabel: [{
            type: Input
        }], ShowSeeAll: [{
            type: Input
        }], Collapsible: [{
            type: Input
        }], Collapsed: [{
            type: Input
        }], HeaderActions: [{
            type: Input
        }], SeeAllClick: [{
            type: Output
        }], CollapsedChange: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SectionCardComponent, { className: "SectionCardComponent", filePath: "shared/components/section-card/section-card.component.ts", lineNumber: 54 }); })();

class ScrollIndicatorComponent extends BaseComponent$1 {
    /** Texte affiché au-dessus de la flèche */
    label = 'Découvrir';
    /** ID de l'élément vers lequel scroller */
    targetId = '';
    /** Durée totale du scroll en ms */
    duration = 1200;
    _IsBrowser;
    constructor(pPlatformId) {
        super();
        this._IsBrowser = isPlatformBrowser(pPlatformId);
    }
    /**
     * Déclenche un scroll progressif et accéléré vers l'élément cible.
     */
    OnClick() {
        if (!this._IsBrowser || !this.targetId)
            return;
        this.PostHog.Capture(this.BuildTrackingName('scroll_indicator_clique', 'tracking'), { cible: this.targetId });
        const lTarget = document.getElementById(this.targetId);
        if (!lTarget)
            return;
        const lStartY = window.scrollY || window.pageYOffset;
        const lTargetRect = lTarget.getBoundingClientRect();
        const lDistance = lTargetRect.top + lStartY - lStartY;
        const lStartTime = performance.now();
        // - cm - Easing personnalisé : accélération progressive (départ lent, fin rapide et freinage doux)
        const lEasing = (pT) => {
            // - cm - Custom ease-in-out avec accélération marquée
            return pT < 0.5
                ? 2 * pT * pT
                : 1 - Math.pow(-2 * pT + 2, 2) / 2;
        };
        const lAnimate = (pCurrentTime) => {
            const lElapsed = pCurrentTime - lStartTime;
            const lProgress = Math.min(lElapsed / this.duration, 1);
            const lEased = lEasing(lProgress);
            window.scrollTo(0, lStartY + lDistance * lEased);
            if (lProgress < 1) {
                requestAnimationFrame(lAnimate);
            }
        };
        requestAnimationFrame(lAnimate);
    }
    static ɵfac = function ScrollIndicatorComponent_Factory(__ngFactoryType__) { /* @ts-ignore */
    return new (__ngFactoryType__ || ScrollIndicatorComponent)(i0.ɵɵdirectiveInject(PLATFORM_ID)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ScrollIndicatorComponent, selectors: [["app-scroll-indicator"]], inputs: { label: "label", targetId: "targetId", duration: "duration" }, features: [i0.ɵɵInheritDefinitionFeature], decls: 5, vars: 1, consts: [[1, "scroll-indicator", 3, "click"], [1, "scroll-indicator__label"], [1, "scroll-indicator__icon", "material-icons"]], template: function ScrollIndicatorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵdomElementStart(0, "a", 0);
            i0.ɵɵdomListener("click", function ScrollIndicatorComponent_Template_a_click_0_listener() { return ctx.OnClick(); });
            i0.ɵɵdomElementStart(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵdomElementEnd();
            i0.ɵɵdomElementStart(3, "span", 2);
            i0.ɵɵtext(4, "keyboard_arrow_down");
            i0.ɵɵdomElementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.label);
        } }, styles: [".scroll-indicator[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;gap:.25rem;color:var(--%NS%sm-text-secondary);font-size:.875rem;cursor:pointer;text-decoration:none;transition:color .2s ease;-webkit-user-select:none;user-select:none}.scroll-indicator[_ngcontent-%COMP%]:hover{color:#9c27b0}.scroll-indicator[_ngcontent-%COMP%]:hover   .scroll-indicator__icon[_ngcontent-%COMP%]{transform:translateY(2px)}.scroll-indicator__label[_ngcontent-%COMP%]{font-weight:500;letter-spacing:.02em}.scroll-indicator__icon[_ngcontent-%COMP%]{font-size:1.5rem;transition:transform .2s ease;animation:_ngcontent-%COMP%_scroll-bounce 2s ease-in-out infinite}@keyframes _ngcontent-%COMP%_scroll-bounce{0%,20%,50%,80%,to{transform:translateY(0)}40%{transform:translateY(-6px)}60%{transform:translateY(-3px)}}"], changeDetection: 1 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ScrollIndicatorComponent, [{
        type: Component,
        args: [{ selector: 'app-scroll-indicator', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.Eager, template: "<a class=\"scroll-indicator\" (click)=\"OnClick()\">\n    <span class=\"scroll-indicator__label\">{{ label }}</span>\n    <span class=\"scroll-indicator__icon material-icons\">keyboard_arrow_down</span>\n</a>", styles: [".scroll-indicator{display:flex;flex-direction:column;align-items:center;gap:.25rem;color:var(--sm-text-secondary);font-size:.875rem;cursor:pointer;text-decoration:none;transition:color .2s ease;-webkit-user-select:none;user-select:none}.scroll-indicator:hover{color:#9c27b0}.scroll-indicator:hover .scroll-indicator__icon{transform:translateY(2px)}.scroll-indicator__label{font-weight:500;letter-spacing:.02em}.scroll-indicator__icon{font-size:1.5rem;transition:transform .2s ease;animation:scroll-bounce 2s ease-in-out infinite}@keyframes scroll-bounce{0%,20%,50%,80%,to{transform:translateY(0)}40%{transform:translateY(-6px)}60%{transform:translateY(-3px)}}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [PLATFORM_ID]
            }] }], { label: [{
            type: Input
        }], targetId: [{
            type: Input
        }], duration: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ScrollIndicatorComponent, { className: "ScrollIndicatorComponent", filePath: "shared/components/scroll-indicator/scroll-indicator.component.ts", lineNumber: 14 }); })();

/**
 * Classe abstraite de base pour les composants angular
 *
 */
class BaseComponent {
    //#region Properties
    /**
     * User Service
     */
    UsersService = inject(UsersService);
    /**
     * Utilitaire de navigation sur les routes
     */
    RouteUtils = inject(RouteUtils);
    /**
     * Service pour le busy
     */
    BusyService = inject(BusyService);
    /**
     * Service de navigation dans les vues
     */
    Nav = inject(NavigationService);
    /**
     * Service de gestion du sessionStorage
     */
    SessionStorage = inject(SessionStorageService);
    /**
     * Service de gestion du localStorage (persistant cross-session).
     */
    LocalStorage = inject(LocalStorageService);
    /**
     * Serivce des settings du user
     */
    SettingsService = inject(SettingsService);
    /**
     * Service PostHog pour le tracking et l'analytics
     */
    PostHog = inject(PostHogService);
    /**
     * Service de traduction (i18n) basé sur ngx-translate
     */
    Translate = inject(TranslationService);
    /**
     * Force le re-render du template dès que le dictionnaire de traductions est
     */
    constructor() {
        // - cm - Injections locales : pas de champs de classe → pas de collision
        const lCdr = inject(ChangeDetectorRef, { optional: true });
        const lDestroyRef = inject(DestroyRef);
        // - cm - Si ChangeDetectorRef n'est pas disponible (sous-classe service),
        if (lCdr) {
            // - cm - Boot initial asynchrone : le JSON est chargé après le 1er render.
            this.Translate.TranslationLoaded.pipe(takeUntilDestroyed(lDestroyRef)).subscribe(() => {
                lCdr.markForCheck();
            });
            // - cm - Changement explicite de langue via setLanguage()
            this.Translate.LanguageChanged.pipe(takeUntilDestroyed(lDestroyRef)).subscribe(() => {
                lCdr.markForCheck();
            });
        }
    }
    /**
     * Nom automatique du composant courant (ex: "OutilEstimationComponent")
     * Utilisé par les composants enfants (bouton, etc.) pour le tracking PostHog
     */
    get Name() {
        return this.constructor.name;
    }
    ApiBaseUrl = environment.apiBaseUrl;
    /**
    * Les routes de navigation
    */
    Routes = ROUTE_PATHS;
    /**
     * La vue en cours EX: dossiers, messages, dashboard
     */
    get View() {
        return this.Nav.View();
    }
    /**
     * Si l'utilisateur est connecter
     */
    get isLoggedIn() {
        return this.UsersService.isLoggedIn();
    }
    /**
     * Si l'utilisateur est un vendeur
     */
    get IsVendeur() {
        return this.UsersService.IsVendeur();
    }
    /**
     * Si l'utilisateur est un pro
     */
    get IsProfessionnel() {
        return this.UsersService.IsProfessionnel();
    }
    /**
   * Si l'utilisateur est un admin
   */
    get isAdmin() {
        return this.UsersService.isAdmin();
    }
    /**
     * Le role de l'utilisateur
     */
    get userRole() {
        return this.UsersService.getUserRole();
    }
    get CurrentUserId() {
        return this.UsersService.getUserId();
    }
    get userSubscription() {
        return this.UsersService.getUserPlan();
    }
    //#endregion
    //#region Methods
    /**
   * Construit un nom d'événement PostHog standardisé.
   * Format : tracking_{nomParent}_{label}
   * @param pLabel Texte à transformer (ex: texte du bouton)
   * @param pPrefix Préfixe optionnel (défaut: 'tracking')
   * @returns Nom d'événement formaté (ex: tracking_outil_estimation_suivant)
   */
    BuildTrackingName(pLabel, pPrefix = 'tracking') {
        const lParentName = this.Name
            .replace(/Component$/i, '')
            .replace(/([a-z])([A-Z])/g, '$1_$2')
            .toLowerCase();
        const lLabel = pLabel
            .toLowerCase()
            .replace(/[^a-z0-9\u00e0-\u00fc]+/g, '_')
            .replace(/^_|_$/g, '')
            .replace(/_+/g, '_');
        return `${pPrefix}_${lParentName}_${lLabel}`;
    }
    //#region CRUD brouillon — anti double POST
    /** Référence d'objet pour bloquer le re-déclenchement RowAdded → RowValidated. */
    _BrouillonTracker = new WeakSet();
    /** Handler unifié pour `(RowAdded)`. */
    async OnBrouillonRowAdded(pRow, pCreateFn, pPostCreateHook) {
        const lId = pRow.id;
        if (typeof lId === 'number' && lId > 0) {
            return;
        }
        this._BrouillonTracker.add(pRow);
        await pCreateFn(pRow);
        if (pPostCreateHook) {
            await pPostCreateHook(pRow);
        }
    }
    /** Handler unifié pour `(RowValidated)`. No-op si déjà créé. */
    async OnBrouillonRowValidated(pRow, pCreateFn, pPostCreateHook) {
        const lId = pRow.id;
        if (typeof lId === 'number' && lId > 0) {
            return;
        }
        if (this._BrouillonTracker.has(pRow)) {
            return;
        }
        this._BrouillonTracker.add(pRow);
        await pCreateFn(pRow);
        if (pPostCreateHook) {
            await pPostCreateHook(pRow);
        }
    }
    /** Prépare le DTO brouillon : delete id, hook recalculate, hook extra setup. */
    PrepareBrouillonDto(pRow, pRecalculate, pExtraSetup) {
        try {
            const lDto = { ...pRow };
            delete lDto.id;
            if (pRecalculate) {
                pRecalculate(lDto);
            }
            if (pExtraSetup) {
                pExtraSetup(lDto);
            }
            return lDto;
        }
        catch {
            return null;
        }
    }
    /** Extrait le message d'erreur métier du back (ServiceBase.create jette Error(message)). */
    ExtractBackError(pErr, pFallback) {
        return pErr?.message ?? pFallback;
    }
    //#endregion
    /**
   * Le nom de l'utilisateur complet
   * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
   */
    getFullName(pUser) {
        const targetUser = pUser ?? this.UsersService.currentUser;
        const firstName = targetUser?.firstName || '';
        const lastName = targetUser?.lastName || '';
        return firstName + " " + lastName || 'Utilisateur';
    }
    /**
     * Initial de l'utilisateur
     * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
     */
    getInitials(pUser) {
        const targetUser = pUser ?? this.UsersService.currentUser;
        const first = targetUser?.firstName?.charAt(0) || '';
        const last = targetUser?.lastName?.charAt(0) || '';
        return (first + last).toUpperCase() || 'U';
    }
    /**
     * Format le prix
     * @param pPrice le prix
     * @returns le prix en string formater
     */
    FormatPrice(pPrice) {
        if (pPrice === undefined || pPrice === null)
            return '';
        if (pPrice === 0)
            return '0 €';
        return new Intl.NumberFormat('fr-FR', {
            style: 'currency',
            currency: 'EUR',
            maximumFractionDigits: 0
        }).format(pPrice);
    }
    /**
     * Formate la date
     * @param pDate la date
     * @returns la date formater
     */
    FormatDate(pDate) {
        if (!pDate)
            return '';
        const lDate = typeof pDate === 'string' ? new Date(pDate) : pDate;
        return new Intl.DateTimeFormat('fr-FR', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        }).format(lDate);
    }
    /**
     * Formate la date avec l'heure précise (jour, mois, année, heure, minute, seconde).
     * @param pDate la date
     * @returns la date formatée avec l'heure
     */
    FormatDateTime(pDate) {
        if (!pDate)
            return '';
        const lDate = typeof pDate === 'string' ? new Date(pDate) : pDate;
        return new Intl.DateTimeFormat('fr-FR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        }).format(lDate);
    }
    //#region Navigation
    /**
     * Navigation vers la view
     * @param pView la vue
     */
    Go(pView) {
        this.Nav.Go(pView);
    }
    /**
     * Verifie si la view existe
     * @param pView la view
     * @returns vrai ou faux
     */
    Is(pView) {
        return this.Nav.Is(pView);
    }
    //#endregion
    /**
     * Convertit une chaîne de caractères en valeur d'énumération
     * @param value La chaîne à convertir
     * @param enumType Le type d'énumération cible
     * @returns La valeur d'énumération correspondante
     */
    ConvertToEnum(value, enumType) {
        return enumType[value];
    }
    /**
     * Convertit une valeur d'énumération en chaîne de caractères
     * @param enumValue La valeur d'énumération à convertir
     * @param enumType Le type d'énumération source
     * @returns La chaîne de caractères correspondante
     */
    EnumToString(enumValue, enumType) {
        const lKeys = Object.keys(enumType).filter(key => isNaN(Number(key)));
        const lValues = Object.values(enumType).filter(value => !isNaN(Number(value)));
        // Si c'est un nombre, on cherche la clé correspondante
        if (typeof enumValue === 'number') {
            const lIndex = lValues.indexOf(enumValue);
            return lIndex >= 0 ? lKeys[lIndex] : '';
        }
        // Sinon on retourne la valeur directement si c'est déjà une chaîne
        return String(enumValue);
    }
}

/**
 * Point d'entrée du package @sellmatch/ui.
 * Re-exporte les composants et briques partagées de SellMatch (shared, core, components)
 * pour consommation externe (CharifBoard, futurs projets).
 */
//#region Composants réutilisables
//#endregion

/**
 * Generated bundle index. Do not edit.
 */

export { BadgeComponent, BaseComponent, ButtonComponent, CardSkeletonComponent, ScrollIndicatorComponent, SectionCardComponent, SkeletonComponent, TooltipComponent };
//# sourceMappingURL=sellmatch-ui.mjs.map
