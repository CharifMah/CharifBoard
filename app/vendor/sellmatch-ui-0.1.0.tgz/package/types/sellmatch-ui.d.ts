import * as i0 from '@angular/core';
import { EventEmitter, AfterViewInit, OnDestroy, TemplateRef } from '@angular/core';
import { BaseComponent as BaseComponent$1 } from '@base/BaseComponent';
import { UsersService, SettingsService } from '@core/sellmatchdb/services';
import { RouteUtils } from '@shared/utils/route-utils';
import { BusyService } from '@core/services/busy/BusyService';
import { NavigationService } from '@core/sellmatchdb/services/NavigationService/NavigationService';
import { SubscriptionPlansDTO, UsersDTO } from '@core/sellmatchdb/dto';
import { SessionStorageService } from '@core/sellmatchdb/services/SessionStorage/SessionStorageService';
import { LocalStorageService } from '@core/sellmatchdb/services/LocalStorage/LocalStorageService';
import { PostHogService } from '@core/services/posthog/PostHogService';
import { TranslationService } from '@core/services/i18n/TranslationService';

/**
 * Composant skeleton générique réutilisable.
 * Affiche un bloc shimmer (animation de chargement) qu'on peut placer n'importe où.
 *
 * @example
 * ```html
 * <!-- Barre skeleton simple -->
 * <app-skeleton />
 *
 * <!-- Barre skeleton avec largeur et hauteur personnalisées -->
 * <app-skeleton Width="60%" Height="20px" />
 *
 * <!-- Petit skeleton (checkbox, icône) -->
 * <app-skeleton Size="sm" />
 * ```
 */
declare class SkeletonComponent {
    /** Largeur CSS du skeleton (défaut: '80%'). */
    Width: string;
    /** Hauteur CSS du skeleton (défaut: '16px'). */
    Height: string;
    /** Tailur prédéfinie : 'sm' pour petit (40px large), sinon taille normale. */
    Size: 'default' | 'sm';
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonComponent, "app-skeleton", never, { "Width": { "alias": "Width"; "required": false; }; "Height": { "alias": "Height"; "required": false; }; "Size": { "alias": "Size"; "required": false; }; }, {}, never, never, true, never>;
}

type BadgeType = 'new' | 'hot' | 'premium' | 'urgent' | 'success' | 'warning' | 'info' | 'error' | 'default';
type BadgeSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
type BadgePosition = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'inline' | 'left' | 'right' | 'top' | 'bottom';
type BadgeVariant = 'solid' | 'outline' | 'soft' | 'gradient';
type BadgeShape = 'rounded' | 'pill' | 'square' | 'circle';
declare class BadgeComponent extends BaseComponent$1 {
    type: BadgeType;
    size: BadgeSize;
    position: BadgePosition;
    variant: BadgeVariant;
    shape: BadgeShape;
    icon?: string;
    label?: string;
    count?: number;
    maxCount?: number;
    animated: boolean;
    pulse: boolean;
    IsVisible: boolean;
    glow: boolean;
    clickable: boolean;
    disabled: boolean;
    removable: boolean;
    showIcon: boolean;
    showClose: boolean;
    customColor?: string;
    customBgColor?: string;
    tooltip?: string;
    closed: EventEmitter<void>;
    clicked: EventEmitter<void>;
    private _isVisible;
    get displayLabel(): string;
    get CustomStyles(): Record<string, string>;
    get BadgeClasses(): string[];
    get DefaultIcon(): string;
    get DefaultLabel(): string;
    onClose(event: Event): void;
    onClick(): void;
    show(): void;
    hide(): void;
    private hexToRgba;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "app-badge", never, { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "position": { "alias": "position"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "label": { "alias": "label"; "required": false; }; "count": { "alias": "count"; "required": false; }; "maxCount": { "alias": "maxCount"; "required": false; }; "animated": { "alias": "animated"; "required": false; }; "pulse": { "alias": "pulse"; "required": false; }; "IsVisible": { "alias": "IsVisible"; "required": false; }; "glow": { "alias": "glow"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "removable": { "alias": "removable"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; "showClose": { "alias": "showClose"; "required": false; }; "customColor": { "alias": "customColor"; "required": false; }; "customBgColor": { "alias": "customBgColor"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, { "closed": "closed"; "clicked": "clicked"; }, never, never, true, never>;
}

type ButtonVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark' | 'ghost';
type ButtonSize = 'sm' | 'md' | 'lg' | 'xl';
type ButtonType = 'button' | 'submit' | 'reset';
type ButtonGradient = 'default' | 'sunset' | 'ocean' | 'neon' | 'aurora';
declare class ButtonComponent extends BaseComponent$1 implements AfterViewInit, OnDestroy {
    variant: ButtonVariant;
    size: ButtonSize;
    type: ButtonType;
    fullWidth: boolean;
    disabled: boolean;
    loading: boolean;
    icon: string | null;
    iconPosition: 'left' | 'right';
    rounded: boolean;
    outline: boolean;
    ariaLabel: string | null;
    circle: boolean;
    active: boolean;
    /**
     * Style CSS inline appliqué au `<span class="material-icons">` interne.
     * Utile pour piloter une transformation dynamique (ex: rotation du compass
     * selon le bearing de la carte). Vide = aucun style inline.
     */
    iconStyle: string | null;
    routerLink: string | null;
    routerLinkActive: string | null;
    routerLinkActiveOptions: {
        exact: boolean;
    } | null;
    /** Délai avant l'animation d'entrée CSS (ms). -1 = pas d'animation */
    animDelay: number;
    /** Déclencheur : 'auto' = immédiat avec animDelay, 'scroll' = au scroll */
    animTrigger: 'auto' | 'scroll' | 'none';
    ButtonClick: EventEmitter<MouseEvent>;
    toggleable: boolean;
    activeChange: EventEmitter<boolean>;
    gradient: ButtonGradient | null;
    private readonly _ElementRef;
    private readonly _IsBrowser;
    private _TrackingName;
    private _Observer;
    constructor(pPlatformId: object);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onClick(pEvent: MouseEvent): Promise<void>;
    get classes(): string;
    private _SetupScrollReveal;
    private _PlayEnter;
    private _Hide;
    private _Show;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "app-button", never, { "variant": { "alias": "variant"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; "fullWidth": { "alias": "fullWidth"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "outline": { "alias": "outline"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "circle": { "alias": "circle"; "required": false; }; "active": { "alias": "active"; "required": false; }; "iconStyle": { "alias": "iconStyle"; "required": false; }; "routerLink": { "alias": "routerLink"; "required": false; }; "routerLinkActive": { "alias": "routerLinkActive"; "required": false; }; "routerLinkActiveOptions": { "alias": "routerLinkActiveOptions"; "required": false; }; "animDelay": { "alias": "animDelay"; "required": false; }; "animTrigger": { "alias": "animTrigger"; "required": false; }; "toggleable": { "alias": "toggleable"; "required": false; }; "gradient": { "alias": "gradient"; "required": false; }; }, { "ButtonClick": "ButtonClick"; "activeChange": "activeChange"; }, never, ["*"], true, never>;
}

type TooltipPosition = 'top' | 'right' | 'bottom' | 'left';
type TooltipVariant = 'dark' | 'light' | 'primary' | 'error';
/**
 * Ligne structurée affichée dans un tooltip.
 */
interface TooltipLine {
    /** Libellé optionnel mis en avant (ex: nom de colonne). */
    Label?: string;
    /** Message principal. */
    Message: string;
}
declare class TooltipComponent extends BaseComponent$1 {
    Text: string;
    Lines: TooltipLine[];
    Position: TooltipPosition;
    Variant: TooltipVariant;
    Disabled: boolean;
    MaxWidth: number;
    AriaLabel: string;
    /** Template personnalisé affiché dans la bulle (ex: carte, HTML riche). */
    Template?: TemplateRef<unknown>;
    /** Contexte passé au Template personnalisé. */
    Context: Record<string, unknown>;
    private _BubbleTemplate;
    private _ElementRef;
    private _ViewContainerRef;
    private _Renderer;
    private _PortalOutlet;
    private _BodyContainer;
    private _Portal;
    private _IsVisible;
    private _WindowScrollCleanup;
    private _WindowResizeCleanup;
    private _DestroyRef;
    private _HideTimer;
    get HasTooltip(): boolean;
    /** Indique si le tooltip contient du contenu interactif (template). */
    get IsInteractive(): boolean;
    get TooltipAriaLabel(): string;
    get HostClasses(): string[];
    get BubbleClasses(): string[];
    get IsVisible(): boolean;
    constructor();
    /**
     * Affiche la bulle dans un portail body et la positionne en fixed.
     */
    Show(): void;
    /**
     * Masque et détache la bulle du body.
     * En mode interactif, un petit délai permet de passer du trigger à la bulle sans clignotement.
     */
    Hide(): void;
    /**
     * Annule le masquage différé (appelé au survol de la bulle interactive).
     */
    OnBubbleEnter(): void;
    /**
     * Déclenche le masquage quand la souris quitte la bulle interactive.
     */
    OnBubbleLeave(): void;
    private DoHide;
    private ClearHideTimer;
    /**
     * Attache la bulle au body via un portail CDK pour sortir de tout ancêtre overflow hidden.
     */
    private AttachBubble;
    /**
     * Détache la bulle du portail body.
     */
    private DetachBubble;
    /**
     * Calcule et applique la position fixed de la bulle selon la position demandée et le viewport.
     */
    private PositionBubble;
    /**
     * Attache les listeners de scroll/resize pour maintenir la bulle alignée au host.
     */
    private AttachPositionListeners;
    /**
     * Nettoie les listeners de positionnement.
     */
    private ClearPositionListeners;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent, "app-tooltip", never, { "Text": { "alias": "Text"; "required": false; }; "Lines": { "alias": "Lines"; "required": false; }; "Position": { "alias": "Position"; "required": false; }; "Variant": { "alias": "Variant"; "required": false; }; "Disabled": { "alias": "Disabled"; "required": false; }; "MaxWidth": { "alias": "MaxWidth"; "required": false; }; "AriaLabel": { "alias": "AriaLabel"; "required": false; }; "Template": { "alias": "Template"; "required": false; }; "Context": { "alias": "Context"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * Composant skeleton réutilisable pour le loading des cartes KPI.
 * Affiche des cartes factices avec animation shimmer via <app-skeleton>.
 */
declare class CardSkeletonComponent {
    /** Nombre de cartes skeleton à afficher (défaut: 6). */
    set Count(pValue: number);
    get Count(): number;
    private readonly _Count;
    /** Affiche une ligne de hint sous la valeur (défaut: true). */
    HasHint: boolean;
    /** Tableau d'indices pour le @for du template. */
    readonly Cards: i0.Signal<number[]>;
    /**
     * Calcule le delai d'animation shimmer (en ms) pour distribuer les cartes
     * de maniere desynchronisee. Formule : (carte * 200ms) + (slot * 30ms).
     * Couvre le cycle de 1.4s pour eviter un shimmer "fige" sur les dernieres cartes.
     * @param pCardIdx Index de la carte.
     * @param pSlot Index du slot a l'interieur de la carte (0..3 : avatar, name, value, hint).
     * @returns Le delai en millisecondes, modulo la duree du cycle.
     */
    ComputeShimmerDelay(pCardIdx: number, pSlot: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardSkeletonComponent, "app-card-skeleton", never, { "Count": { "alias": "Count"; "required": false; }; "HasHint": { "alias": "HasHint"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Composant carte section réutilisable.
 *
 * Deux modes :
 * - Mode statique (`Collapsible = false`, defaut) : header h2 + contenu visible en permanence.
 * - Mode repliable (`Collapsible = true`) : header cliquable (chevron + bouton) + corps
 *   anime via transition max-height/opacity. Supporte le slot `header-title` pour
 *   remplacer `Title` et le slot `header-actions` pour des boutons contextuels.
 *
 * Accessibilite : `aria-expanded`, `aria-controls`, header focusable.
 * Compatible `prefers-reduced-motion` (transitions retirees).
 *
 * @example
 * ```html
 * <app-section-card Title="Mes biens" Icon="apartment" [Collapsible]="true"
 *   [Collapsed]="false" (CollapsedChange)="onToggle($event)">
 *   <div slot="header-title"><h3>Carte</h3></div>
 *   <div slot="header-actions">
 *     <app-button variant="ghost" size="sm" icon="edit" />
 *   </div>
 *   <p>Contenu</p>
 * </app-section-card>
 * ```
 */
declare class SectionCardComponent extends BaseComponent$1 {
    /** Identifiant de plateforme (browser vs SSR). */
    private readonly _PlatformId;
    /**
     * Drapeau interne mis a jour via le setter de `_HeaderTitleSlot` pour indiquer
     * si le slot `header-title` a ete projete par le consommateur.
     */
    private _hasHeaderTitleSlot;
    /**
     * Reference vers l'eventuel contenu projete dans le slot `header-title`.
     * Le setter met a jour `_hasHeaderTitleSlot` pour permettre au template
     * de masquer le titre par defaut (`Title`) lorsque le slot est utilise.
     */
    private set _HeaderTitleSlot(value);
    /** Titre affiche dans l'en-tete de la carte (masque si slot `header-title` projete). */
    Title: string;
    /** Icone Material Icons affichee a gauche du titre. Si vide, aucune icone n'est rendue. */
    Icon: string;
    /** Lien de navigation vers la page "Voir tout". Si null et pas de handler, le bouton est masque. */
    SeeAllLink: string | null;
    /** Libelle du bouton "Voir tout" (defaut : "Voir tout"). */
    SeeAllLabel: string;
    /** Force l'affichage du bouton "Voir tout" meme sans handler observe (null = auto). */
    ShowSeeAll: boolean;
    /** Active ou desactive la fonctionnalite de pliage (chevron + clic header). */
    Collapsible: boolean;
    /** Etat courant plie/deplie. Peut etre force depuis l'exterieur. */
    Collapsed: boolean;
    /**
     * Template optionnel pour injecter des actions supplementaires dans l'en-tete.
     * @deprecated Preferez le slot ng-content `header-actions` (plus flexible).
     */
    HeaderActions: TemplateRef<unknown> | null;
    /** Emis au clic sur "Voir tout" quand aucun SeeAllLink n'est defini. */
    SeeAllClick: EventEmitter<MouseEvent>;
    /** Emis a chaque changement d'etat plie/deplie (peut etre intercepte par le parent). */
    CollapsedChange: EventEmitter<boolean>;
    /** Identifiant unique de l'instance (ARIA + cle). */
    readonly InstanceId: string;
    /** ID de la zone de contenu, derive de `InstanceId`. Utilise par `aria-controls`. */
    readonly ContentId: string;
    /**
     * Indique si un slot `header-title` a ete projete par le consommateur.
     * Lorsqu'il est present, le titre par defaut (`Title`) est masque pour eviter
     * un doublon visuel avec le contenu projete.
     */
    get HasHeaderTitleSlot(): boolean;
    /**
     * Bascule l'etat plie/deplie. Sans effet si `Collapsible` est `false`.
     * Emet `CollapsedChange` a chaque changement.
     */
    ToggleCollapsed(): void;
    /**
     * Handler de clic sur "Voir tout" : stoppe la propagation pour ne pas replier la carte.
     * @param pEvent L'evenement de clic souris
     */
    OnSeeAllClick(pEvent: MouseEvent): void;
    /**
     * Indique si le bouton "Voir tout" doit etre affiche.
     */
    get HasSeeAll(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SectionCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SectionCardComponent, "app-section-card", never, { "Title": { "alias": "Title"; "required": false; }; "Icon": { "alias": "Icon"; "required": false; }; "SeeAllLink": { "alias": "SeeAllLink"; "required": false; }; "SeeAllLabel": { "alias": "SeeAllLabel"; "required": false; }; "ShowSeeAll": { "alias": "ShowSeeAll"; "required": false; }; "Collapsible": { "alias": "Collapsible"; "required": false; }; "Collapsed": { "alias": "Collapsed"; "required": false; }; "HeaderActions": { "alias": "HeaderActions"; "required": false; }; }, { "SeeAllClick": "SeeAllClick"; "CollapsedChange": "CollapsedChange"; }, ["_HeaderTitleSlot"], ["[slot='header-title']", "[slot='header-actions']", "[slot='header-actions']", "*"], true, never>;
}

declare class ScrollIndicatorComponent extends BaseComponent$1 {
    /** Texte affiché au-dessus de la flèche */
    label: string;
    /** ID de l'élément vers lequel scroller */
    targetId: string;
    /** Durée totale du scroll en ms */
    duration: number;
    private readonly _IsBrowser;
    constructor(pPlatformId: object);
    /**
     * Déclenche un scroll progressif et accéléré vers l'élément cible.
     */
    OnClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollIndicatorComponent, "app-scroll-indicator", never, { "label": { "alias": "label"; "required": false; }; "targetId": { "alias": "targetId"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Classe abstraite de base pour les composants angular
 *
 */
declare abstract class BaseComponent {
    /**
     * User Service
     */
    protected UsersService: UsersService;
    /**
     * Utilitaire de navigation sur les routes
     */
    protected RouteUtils: RouteUtils;
    /**
     * Service pour le busy
     */
    protected BusyService: BusyService;
    /**
     * Service de navigation dans les vues
     */
    protected readonly Nav: NavigationService;
    /**
     * Service de gestion du sessionStorage
     */
    protected readonly SessionStorage: SessionStorageService;
    /**
     * Service de gestion du localStorage (persistant cross-session).
     */
    protected readonly LocalStorage: LocalStorageService;
    /**
     * Serivce des settings du user
     */
    protected readonly SettingsService: SettingsService;
    /**
     * Service PostHog pour le tracking et l'analytics
     */
    protected readonly PostHog: PostHogService;
    /**
     * Service de traduction (i18n) basé sur ngx-translate
     */
    protected readonly Translate: TranslationService;
    /**
     * Force le re-render du template dès que le dictionnaire de traductions est
     */
    constructor();
    /**
     * Nom automatique du composant courant (ex: "OutilEstimationComponent")
     * Utilisé par les composants enfants (bouton, etc.) pour le tracking PostHog
     */
    get Name(): string;
    ApiBaseUrl: string;
    /**
    * Les routes de navigation
    */
    protected Routes: {
        readonly HOME: "";
        readonly CONNEXION: "connexion";
        readonly INSCRIPTION_VENDEUR: "inscription-vendeur";
        readonly INSCRIPTION_PRO: "inscription-pro";
        readonly VENDEUR: "comment-ca-marche";
        readonly FAQ: "faq";
        readonly CONTACT: "contact";
        readonly DASHBOARD_VENDEUR: "dashboard-vendeur";
        readonly DASHBOARD_PRO: "dashboard-pro";
        readonly CRM: "crm";
        readonly PLAYGROUND: "playground";
        readonly MDP: "mot-de-passe-oublie";
        readonly UNAUTHORIZED: "unauthorized";
        readonly POLICY: "politique-confidentialite";
        readonly CGU: "cgu";
        readonly PROFILPRO: "profil/:profilUrl";
        readonly RESET_PASSWORD: "reset-password";
        readonly PRICING: "pricing";
        readonly PAYMENT_CONFIRMATION: "paiement/confirmation";
        readonly SUBSCRIPTION_MANAGEMENT: "mon-abonnement";
        readonly MENTIONSLEGALES: "mentions-legales";
        readonly COOKIESPOLICY: "politique-de-cookies";
        readonly CGV: "cgv";
        readonly OUTILESTIMATION: "estimation-immobiliere";
        readonly ESTIMATION_VILLE: "estimation-immobiliere/:ville";
        readonly BLOG: "blog";
        readonly BLOG_ARTICLE: "blog/:slug";
    };
    /**
     * La vue en cours EX: dossiers, messages, dashboard
     */
    get View(): string;
    /**
     * Si l'utilisateur est connecter
     */
    get isLoggedIn(): boolean;
    /**
     * Si l'utilisateur est un vendeur
     */
    get IsVendeur(): boolean;
    /**
     * Si l'utilisateur est un pro
     */
    get IsProfessionnel(): boolean;
    /**
   * Si l'utilisateur est un admin
   */
    get isAdmin(): boolean;
    /**
     * Le role de l'utilisateur
     */
    get userRole(): string | null;
    get CurrentUserId(): string | null;
    get userSubscription(): SubscriptionPlansDTO | null;
    /**
   * Construit un nom d'événement PostHog standardisé.
   * Format : tracking_{nomParent}_{label}
   * @param pLabel Texte à transformer (ex: texte du bouton)
   * @param pPrefix Préfixe optionnel (défaut: 'tracking')
   * @returns Nom d'événement formaté (ex: tracking_outil_estimation_suivant)
   */
    BuildTrackingName(pLabel: string, pPrefix?: string): string;
    /** Référence d'objet pour bloquer le re-déclenchement RowAdded → RowValidated. */
    private readonly _BrouillonTracker;
    /** Handler unifié pour `(RowAdded)`. */
    OnBrouillonRowAdded<T extends object>(pRow: T, pCreateFn: (pRow: T) => Promise<void>, pPostCreateHook?: (pRow: T) => Promise<void>): Promise<void>;
    /** Handler unifié pour `(RowValidated)`. No-op si déjà créé. */
    OnBrouillonRowValidated<T extends object>(pRow: T, pCreateFn: (pRow: T) => Promise<void>, pPostCreateHook?: (pRow: T) => Promise<void>): Promise<void>;
    /** Prépare le DTO brouillon : delete id, hook recalculate, hook extra setup. */
    PrepareBrouillonDto<TDTO extends {
        id?: number;
    }>(pRow: TDTO, pRecalculate?: (pDto: TDTO) => void, pExtraSetup?: (pDto: TDTO) => void): TDTO | null;
    /** Extrait le message d'erreur métier du back (ServiceBase.create jette Error(message)). */
    ExtractBackError(pErr: unknown, pFallback: string): string;
    /**
   * Le nom de l'utilisateur complet
   * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
   */
    getFullName(pUser?: UsersDTO): string;
    /**
     * Initial de l'utilisateur
     * @param pUser Utilisateur optionnel (utilise l'utilisateur courant si non fourni)
     */
    getInitials(pUser?: UsersDTO): string;
    /**
     * Format le prix
     * @param pPrice le prix
     * @returns le prix en string formater
     */
    FormatPrice(pPrice: number | undefined): string;
    /**
     * Formate la date
     * @param pDate la date
     * @returns la date formater
     */
    FormatDate(pDate: Date | string | undefined): string;
    /**
     * Formate la date avec l'heure précise (jour, mois, année, heure, minute, seconde).
     * @param pDate la date
     * @returns la date formatée avec l'heure
     */
    FormatDateTime(pDate: Date | string | undefined): string;
    /**
     * Navigation vers la view
     * @param pView la vue
     */
    Go(pView: string): void;
    /**
     * Verifie si la view existe
     * @param pView la view
     * @returns vrai ou faux
     */
    Is(pView: string): boolean;
    /**
     * Convertit une chaîne de caractères en valeur d'énumération
     * @param value La chaîne à convertir
     * @param enumType Le type d'énumération cible
     * @returns La valeur d'énumération correspondante
     */
    ConvertToEnum<T extends object, K extends keyof T>(value: string, enumType: T): T[K];
    /**
     * Convertit une valeur d'énumération en chaîne de caractères
     * @param enumValue La valeur d'énumération à convertir
     * @param enumType Le type d'énumération source
     * @returns La chaîne de caractères correspondante
     */
    EnumToString<T extends object>(enumValue: number | string, enumType: T): string;
}

export { BadgeComponent, BaseComponent, ButtonComponent, CardSkeletonComponent, ScrollIndicatorComponent, SectionCardComponent, SkeletonComponent, TooltipComponent };
export type { BadgePosition, BadgeShape, BadgeSize, BadgeType, BadgeVariant, ButtonGradient, ButtonSize, ButtonType, ButtonVariant, TooltipLine, TooltipPosition, TooltipVariant };
//# sourceMappingURL=sellmatch-ui.d.ts.map
